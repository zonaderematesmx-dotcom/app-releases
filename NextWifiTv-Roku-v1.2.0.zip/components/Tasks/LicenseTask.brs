' LicenseTask.brs
' Canjea un codigo de licencia de Next Wifi Tv contra el backend de
' licencias (POST /api/activate) y devuelve las credenciales
' Xtream que el servidor entrega al activar.
'
' Contrato del backend (backend/server.js -> /api/activate):
'   request : { code, deviceId }
'   response: { success, message, sessionToken, subscriberName,
'               phone, expDate,
'               credentials: { dns, username, password }, expiresAt }

sub init()
    m.top.functionName = "DoLicense"
end sub

sub DoLicense()
    code = m.top.code
    deviceId = m.top.deviceId

    if code = "" or deviceId = ""
        m.top.errorMsg = "Ingresa tu usuario."
        return
    end if

    url = "https://tanex-streaming.onrender.com/api/activate"
    body = FormatJson({ code: code, deviceId: deviceId })

    transfer = CreateObject("roUrlTransfer")
    transfer.AddHeader("User-Agent", "Mozilla/5.0")
    transfer.SetUrl(url)
    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.InitClientCertificates()
    transfer.RetainBodyOnError(true)
    transfer.AddHeader("Content-Type", "application/json")

    port = CreateObject("roMessagePort")
    transfer.SetMessagePort(port)
    if not transfer.AsyncPostFromString(body)
        m.top.errorMsg = "No fue posible contactar el servidor."
        return
    end if

    ' 45s: el backend puede estar "durmiendose" (Render) y tardar en
    ' despertar; preferimos esperar a cortarle la activacion al usuario.
    event = wait(45000, port)
    if event = invalid or type(event) <> "roUrlEvent"
        m.top.errorMsg = "Tiempo de espera agotado. Intenta de nuevo."
        return
    end if

    httpCode = event.GetResponseCode()
    data = ParseJSON(event.GetString())

    if data = invalid or data.success <> true
        msg = "Codigo de activacion invalido."
        if httpCode >= 500
            msg = "No fue posible contactar el servidor."
        else if data <> invalid and data.message <> invalid and data.message <> ""
            msg = data.message
        end if
        m.top.errorMsg = msg
        return
    end if

    creds = data.credentials
    if creds = invalid or creds.username = invalid or creds.password = invalid
        m.top.errorMsg = "No fue posible obtener tus credenciales."
        return
    end if

    m.top.username = creds.username
    m.top.password = creds.password
    m.top.validated = true
end sub
