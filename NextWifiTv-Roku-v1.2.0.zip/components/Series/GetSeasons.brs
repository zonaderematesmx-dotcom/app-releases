sub init()
    ' Se establece el nombre de la función que se ejecutará
    print "Starting go function..."
    m.top.functionName = "go"
end sub

sub go()
    ' Crear un nodo de contenido para almacenar las temporadas
    content = createObject("roSGNode", "ContentNode")
    
    ' Obtener el JSON completo (seasons + info con backdrop)
    json = jsonCompleto()
    if json = invalid then
        print "No se pudo obtener JSON"
        return
    end if

    ' Obtener backdrop de la serie - igual que PurpleTV usa movie_image primero
    if json.info <> invalid and type(json.info) = "roAssociativeArray"
        ' movie_image = backdrop panoramico de la serie
        if json.info.movie_image <> invalid and json.info.movie_image <> ""
            content.hdBackgroundImageUrl = json.info.movie_image
        end if
        ' cover_big como segunda opcion
        if content.hdBackgroundImageUrl = "" or content.hdBackgroundImageUrl = invalid
            if json.info.cover_big <> invalid and json.info.cover_big <> ""
                content.hdBackgroundImageUrl = json.info.cover_big
            end if
        end if
        ' backdrop_path como tercera opcion
        if content.hdBackgroundImageUrl = "" or content.hdBackgroundImageUrl = invalid
            if json.info.backdrop_path <> invalid
                bp = json.info.backdrop_path
                if type(bp) = "roArray" and bp.Count() > 0
                    content.hdBackgroundImageUrl = bp[0]
                else if type(bp) = "roString" and bp <> ""
                    content.hdBackgroundImageUrl = bp
                end if
            end if
        end if
        ' Poster de la serie
        if json.info.cover <> invalid and json.info.cover <> ""
            content.HDPosterUrl = json.info.cover
        else
            content.HDPosterUrl = "pkg:/images/no-poster.jpg"
        end if
    end if

    ' Obtener seasons
    seasons = []
    if json.seasons <> invalid and json.seasons.count() > 0
        seasons = json.seasons
    else
        print "No hay temporadas, usando default"
        seasons = [{
            "air_date": "2025-06-18",
            "episode_count": 0,
            "id": 0,
            "name": "Episodios",
            "season_number": 1,
            "vote_average": 0,
            "cover": "https://via.placeholder.com/150",
            "cover_big": "https://via.placeholder.com/300"
        }]
    end if

    ' Iterar sobre las temporadas y agregar los datos al nodo de contenido
    for each temporada in seasons
        print "Procesando temporada: "; temporada.name
        newSeason = content.createChild("ContentNode")
        newSeason.title = temporada.name
        snum = temporada.season_number
        snumStr = "1"
        if type(snum) = "roInt" or type(snum) = "roInteger" or type(snum) = "Integer"
            snumStr = snum.toStr()
        else if type(snum) = "roString" or type(snum) = "String"
            snumStr = snum
        end if
        newSeason.addFields({seasonNum: snumStr})
        print "Adding season: "; newSeason.title; " seasonNum="; snumStr
    end for
    
    ' Asignar el contenido creado al top del nodo
    m.top.content = content
    print "Contenido asignado a m.top.content"
end sub
function jsonCompleto() As Object
    request = CreateObject("roUrlTransfer")
    request.AddHeader("User-Agent", "Mozilla/5.0")
    
    ' Construir la URL
    url = m.global.serverURL + m.global.episode + m.top.cve
    print "Temporada Url = "; url
    
    ' Comprobar si la URL es HTTP o HTTPS
    if Instr(1, url, "https://") > 0 then
        print "Usando HTTPS"
        ' Si es HTTPS, configuramos certificados SSL
        request.setCertificatesFile("common:/certs/ca-bundle.crt")
        request.InitClientCertificates()
        request.enablehostverification(false)  ' Deshabilitar la verificación del host para pruebas
        request.enablepeerverification(false)  ' Deshabilitar la verificación del servidor para pruebas
    else
        print "Usando HTTP: No se verifica SSL."
    end if
    
    ' Realizar la solicitud HTTP
    request.SetUrl(url)
    response = request.GetToString()
    
    ' Imprimir la respuesta para ver qué devuelve la API
    print "Respuesta de la API: "; response
    
    ' Limpiar la respuesta y parsear como JSON
    data = response.Trim()
    if data = "" then
        print "Error: Response is empty."
        return invalid  ' Respuesta vacía
    end if
    
    json = ParseJSON(data)
    
    ' Verificar si el JSON es válido y contiene la propiedad 'seasons'
    if json <> invalid then
        if json.seasons <> invalid and json.seasons.count() > 0 then
            print "Datos de temporadas: "; json.seasons
            return json  ' Retornar json completo (seasons + info con backdrop)
        else
            print "Error: 'seasons' is empty or has no elements."
            ' Autorellenar con una temporada predeterminada llamada "Episodios" si no hay temporadas
            return json  ' Devolver json aunque seasons esté vacío, para conservar backdrop
        end if
    else
        print "Error: No se pudo parsear el JSON correctamente."
        return invalid  ' JSON inválido
    end if
end function
