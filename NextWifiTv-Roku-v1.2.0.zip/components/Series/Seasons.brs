' ============================================================
' Seasons.brs - VERSIÓN CORREGIDA (Focus Bug Fix)
' ============================================================

sub Init()
  m.top.observeField("visible", "onVisibleChange")
  
  m.favorite          =   m.top.findNode("optionText")
  m.loading           =   m.top.findNode("LoadingIndicator")
  m.buttons           =   m.top.findNode("Buttons")
  m.playbuttons       =   m.top.findNode("PlayButtons")
  m.videoPlayer       =   m.top.findNode("VideoPlayer")
  m.poster            =   m.top.findNode("Cover")
  m.description       =   m.top.findNode("lblDescription")
  m.background        =   m.top.findNode("Background")
  m.fadeIn            =   m.top.findNode("fadeinAnimation")
  m.fadeOut           =   m.top.findNode("fadeoutAnimation")
  m.tilte             =   m.top.findNode("lblTitle")
  m.date              =   m.top.findNode("lblDate")
  m.rating            =   m.top.findNode("lblRating")
  m.episodesgrid      =   m.top.findNode("EpisodesGrid")
  m.favBtnLabel       =   m.top.findNode("favBtnLabel")
  m.favBtnBg          =   m.top.findNode("favBtnBg")
  m.favBtnFocusRing   =   m.top.findNode("favBtnFocusRing")
  m.focusOnFav        =   false
  
  m.savePositionToReg = createObject("roSGNode", "WriteVideoPosition")
  m.savePositionToReg.section = "SerieResume"

  m.retryCount    = 0
  m.retryTimer    = createObject("roSGNode", "Timer")
  m.retryTimer.duration = 2
  m.retryTimer.repeat   = false
  m.retryTimer.observeField("fire", "onRetryTimer")

  m.bufferingGroup = m.top.findNode("bufferingGroup")
  m.bufferingBar   = m.top.findNode("bufferingBar")
  m.playerOverlay  = m.top.findNode("playerOverlay")
  m.overlayTitle   = m.top.findNode("overlayTitle")
  m.progressFill   = m.top.findNode("progressFill")
  m.progressDot    = m.top.findNode("progressDot")
  m.timeCurrent    = m.top.findNode("timeCurrent")
  m.timeDuration   = m.top.findNode("timeDuration")
  m.audioLabel     = m.top.findNode("audioLabel")
  m.subtitleLabel  = m.top.findNode("subtitleLabel")
  m.overlayTimer   = m.top.findNode("overlayTimer")
  m.progressTimer  = m.top.findNode("progressTimer")
  m.seekBufferTimer = m.top.findNode("seekBufferTimer")
  m.overlayTimer.observeField("fire",  "hidePlayerOverlay")
  m.progressTimer.observeField("fire", "onProgressTimer")
  if m.seekBufferTimer <> invalid then m.seekBufferTimer.observeField("fire", "onSeekBufferTimer")

  ' --- Barra de controles propia (igual a Android: ver el comentario ---
  ' junto a enableUI en Seasons.xml). m.ctrlBar es la lista, en el mismo
  ' orden en que Izquierda/Derecha se mueve entre ellos (indice 5 =
  ' engranaje de audio/subtitulos, arriba de todo, igual que en Android).
  m.ctrlPlayPauseLabel = m.top.findNode("ctrlPlayPauseLabel")
  m.ctrlBar = [
      m.top.findNode("ctrlPrevFocusRing"),
      m.top.findNode("ctrlSeekBackFocusRing"),
      m.top.findNode("ctrlPlayPauseFocusRing"),
      m.top.findNode("ctrlSeekFwdFocusRing"),
      m.top.findNode("ctrlNextFocusRing"),
      m.top.findNode("gearBtnFocusRing")
  ]
  m.ctrlBarFocusIdx = 2 ' play/pausa por defecto, igual que Android (DPAD_CENTER)

  ' --- Navegacion de capitulos con arriba/abajo (ver onKeyEvent) y avisos ---
  m.episodeNavHint         = m.top.findNode("episodeNavHint")
  m.episodeNavHintLabel    = m.top.findNode("episodeNavHintLabel")
  m.episodeNavHintTimer    = m.top.findNode("episodeNavHintTimer")
  m.nextEpisodeBanner      = m.top.findNode("nextEpisodeBanner")
  m.nextEpisodeBannerTitle = m.top.findNode("nextEpisodeBannerTitle")
  m.episodeNavHintTimer.observeField("fire", "hideEpisodeNavHint")
  m.pendingCrossSeason = invalid
  m.nextBannerShown = false
  ' true mientras NOSOTROS detuvimos el video a proposito (para
  ' arrancar otro capitulo, reintentar, o salir) -- ver
  ' OnVideoPlayerStateChange()/"finished" para el porque.
  m.switchingEpisode = false
  ' true mientras se esta cargando el siguiente/anterior capitulo por
  ' arriba/abajo -- bloquea nuevas apretadas hasta que cargue.
  m.episodeNavBusy = false
  ' Posicion pendiente de aplicar con seek() apenas arranque a
  ' reproducir de verdad (ver resumeSelected/playDirectEpisode/
  ' OnVideoPlayerStateChange) -- fix real de "Continuar viendo siempre
  ' reinicia desde 0".
  m.pendingSeekPos = 0

  m.subtitlesOn = false
  m.rwRegistered = false

  m.seasons = createObject("roSGNode", "GetSeasons")
  m.seasons.observeField("content", "createSeasons")
  
  m.episodes = createObject("roSGNode", "GetEpisodes")
  m.episodes.observeField("content", "setEpisodes")
  
  m.videoPlayer.observeField("state", "OnVideoPlayerStateChange")
  m.videoPlayer.observeField("position", "savePosition")
  ' Ver el comentario en onBufferingStatusChange() -- forma correcta
  ' (la que usa el sample oficial de Roku rokudev/transport-control) de
  ' saber si el video YA de verdad esta listo para verse, en vez de
  ' adivinar con un timer fijo.
  m.videoPlayer.observeField("bufferingStatus", "onBufferingStatusChange")
  m.episodesgrid.observeField("itemSelected", "onEpisodeSelected")

  ' --- Color de marca (focusColor del config.json) ---
  applyBrandColor()
  m.global.observeField("focusColor", "applyBrandColor")

  ' --- Sembrar progreso de capitulos desde servidor (solo si el local esta vacio) ---
  m.seedWatchProgress = createObject("roSGNode", "SeedWatchProgress")
  m.seedWatchProgress.control = "RUN"
End sub

' ============================================================
' Aplica el focusColor del config remoto a la barra de progreso
' del video. Se re-ejecuta si el color cambia despues de iniciar.
' ============================================================
sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0x00A8FFFF"
    if m.progressFill <> invalid then m.progressFill.color = fc
    if m.progressDot  <> invalid then m.progressDot.color  = fc
    if m.bufferingBar <> invalid then m.bufferingBar.color = fc
    ' Marco de foco del boton Favorito (el boton en si es blanco fijo)
    for each rid in ["favBtnFocusTop", "favBtnFocusBottom", "favBtnFocusLeft", "favBtnFocusRight"]
        n = m.top.findNode(rid)
        if n <> invalid then n.color = fc
    end for
    ' Marco de foco de la barra de controles del reproductor (igual a
    ' Android: color de marca configurable, no fijo).
    for each rid in ["ctrlPrevFocusRing", "ctrlSeekBackFocusRing", "ctrlPlayPauseFocusRing", "ctrlSeekFwdFocusRing", "ctrlNextFocusRing", "gearBtnFocusRing"]
        grp = m.top.findNode(rid)
        if grp <> invalid
            for i = 0 to grp.getChildCount() - 1
                grp.getChild(i).color = fc
            end for
        end if
    end for
End sub

sub checkFavorite()
    m.checkFavTask = createObject("roSGNode", "CheckFavoriteTask")
    m.checkFavTask.cve = m.top.content.id.toStr()
    m.checkFavTask.tipo = "serie"
    m.checkFavTask.observeField("isFavorite", "onCheckFavDone")
    m.checkFavTask.control = "RUN"
end sub

sub onCheckFavDone()
    m.isFavorite = m.checkFavTask.isFavorite
    if m.isFavorite
        m.favorite.text = "Unfavorite"
        m.favBtnLabel.text = "★ Quitar"
    else
        m.favorite.text = "Favorite"
        m.favBtnLabel.text = "★ Favorito"
    end if
end sub

sub onFavButtonSelected()
    m.addFavorite = createObject("roSGNode", "AddFavorite")
    m.addFavorite.cve = m.top.content.id
    m.addFavorite.tipo = "serie"
    if m.isFavorite <> true
        m.addFavorite.itemJson = FormatJSON(Fav_NodeToAA(m.top.content, Fav_VodSerieFields()))
    end if
    m.addFavorite.control = "RUN"
    m.addFavorite.observeField("isFavorite", "onFavToggled")
end sub

sub createSeasons()
    m.buttons.content = m.seasons.content
    m.buttons.unobserveField("itemSelected")
    m.buttons.observeField("itemSelected", "onItemSelected")
    m.loading.control = "stop"

    ' Si ya hay un episodio reproduciendose de una vez (Continuar viendo
    ' desde Recien Vistas -- ver playDirectEpisode()/onVisibleChange),
    ' este listado de temporadas llega DESPUES por ser una consulta de
    ' red aparte, y si se muestra/enfoca aqui como siempre, tapa la
    ' pantalla del reproductor y le roba el foco justo cuando estaba
    ' arrancando -- por eso "Si, continuar" parecia no reproducir nada.
    ' El contenido ya se dejo listo arriba (m.buttons.content) para
    ' cuando el usuario regrese con "back" desde el video.
    if m.videoPlayer.visible <> true
        m.buttons.visible = true
        m.buttons.setFocus(true)
    end if
end sub

' Portada REAL de la serie para usar como respaldo en los capitulos:
' se usa DIRECTAMENTE la imagen que ya esta puesta en pantalla en el
' control "Cover" (m.poster.uri, llenado por OnContentChange con
' m.top.content.HDPosterUrl apenas se abre esta pantalla) -- es
' literalmente "la portada de la serie" que el usuario esta viendo en
' este momento, sin ninguna re-derivacion de otro campo que pueda no
' coincidir con lo que se ve en pantalla. Solo si esa imagen resulta
' ser invalida o el placeholder generico se intenta con las otras dos
' fuentes conocidas (la que acaba de traer GetSeasons.brs del servidor,
' o el content original) como ultimo recurso.
function SeasonsRealCover() as String
    placeholder = "pkg:/images/no-poster.jpg"
    ' Fuente MAS confiable primero: el catalogo completo ya sincronizado
    ' localmente (CategoriesLocalStore.brs, el mismo que usa la pantalla
    ' de Series para sus propias tarjetas) buscado por el id de ESTA
    ' serie. A diferencia de m.top.content (que trae la tarjeta de
    ' cualquier pantalla que haya abierto Seasons -- Favoritos y Recien
    ' Vistos a veces solo tienen id/tipo/titulo, sin portada real), este
    ' catalogo siempre tiene el campo "cover" tal cual lo manda el
    ' proveedor para esa serie, igual que se ve correctamente en
    ' Peliculas/Series/Busqueda.
    if m.top.content <> invalid and m.top.content.id <> invalid
        usuario = getStrValFromReg("user_tv", "datos_tv")
        catItem = Cat_LocalFindById(usuario, "series", m.top.content.id.toStr())
        if catItem <> invalid and catItem.HDPosterUrl <> invalid
            c = catItem.HDPosterUrl
            if c <> "" and c <> placeholder then return c
        end if
    end if
    if m.poster <> invalid and m.poster.uri <> invalid
        c = m.poster.uri
        if c <> "" and c <> placeholder then return c
    end if
    if m.top.content <> invalid and m.top.content.HDPosterUrl <> invalid
        c = m.top.content.HDPosterUrl
        if c <> "" and c <> placeholder then return c
    end if
    if m.seasons <> invalid and m.seasons.content <> invalid and m.seasons.content.HDPosterUrl <> invalid
        c = m.seasons.content.HDPosterUrl
        if c <> "" and c <> placeholder then return c
    end if
    ' Si de plano no hay ninguna portada real conocida, se usa lo que
    ' haya (aunque sea el placeholder) en vez de dejar el campo vacio.
    if m.poster <> invalid and m.poster.uri <> invalid and m.poster.uri <> "" then return m.poster.uri
    if m.top.content <> invalid and m.top.content.HDPosterUrl <> invalid then return m.top.content.HDPosterUrl
    if m.seasons <> invalid and m.seasons.content <> invalid and m.seasons.content.HDPosterUrl <> invalid then return m.seasons.content.HDPosterUrl
    return ""
end function

' Respaldo (ademas del que ya intenta GetEpisodes.brs via seriesCover):
' a cada capitulo que se haya quedado sin imagen propia (shortDescriptionLine1
' vacio) se le pone la portada REAL de la serie (SeasonsRealCover()).
' Solo aplica a capitulos de series, como se pidio.
sub ensureEpisodeThumbnails(episodeContent as Object)
    if episodeContent = invalid then return
    serieCover = SeasonsRealCover()
    if serieCover = "" then return
    for i = 0 to episodeContent.getChildCount() - 1
        ep = episodeContent.getChild(i)
        if ep <> invalid and (ep.shortDescriptionLine1 = invalid or ep.shortDescriptionLine1 = "")
            ep.shortDescriptionLine1 = serieCover
        end if
    end for
end sub

sub setEpisodes()
    print "[Seasons] setEpisodes called"
    if m.episodes.content.getChild(0) = invalid then
        if m.pendingCrossSeason <> invalid
            ' Se cruzo a una temporada que resulto vacia -- no hay a donde
            ' avanzar/retroceder, se deja como estaba (fin de la serie).
            m.pendingCrossSeason = invalid
            restoreSeasonsFocus()
            return
        end if
        if m.videoPlayer.visible = true
            ' Video ya reproduciendose: esto es la carga en segundo plano
            ' de playDirectEpisode() (ver ahi) que no pudo resolver la
            ' temporada. No se debe mostrar nada ni robarle el foco al
            ' video -- arriba/abajo seguiran sin hacer nada, igual que
            ' antes de este intento.
            m.loading.control = "stop"
            return
        end if
        m.episodesgrid.visible = false
        m.buttons.visible = true
        m.buttons.setFocus(true)
        m.loading.control = "stop"
    else
        print "SetEpisodes in grid - asignando contenido y observer"
        ensureEpisodeThumbnails(m.episodes.content)
        m.episodesgrid.unobserveField("itemSelected")
        m.episodesgrid.observeField("itemSelected", "onEpisodeSelected")
        m.episodesgrid.content = m.episodes.content
        m.loading.control = "stop"
        if m.pendingCrossSeason <> invalid
            ' Venimos de cruzar de temporada por arriba/abajo o autoplay:
            ' hay que seguir reproduciendo, no mostrar la lista de capitulos.
            crossMode = m.pendingCrossSeason
            m.pendingCrossSeason = invalid
            m.episodesgrid.visible = true
            if crossMode = "first"
                playEpisodeAtIndex(0)
            else
                playEpisodeAtIndex(m.episodesgrid.content.getChildCount() - 1)
            end if
        else if m.videoPlayer.visible = true
            ' El video ya se esta reproduciendo -- llegamos aqui porque
            ' playDirectEpisode() ("Continuar viendo" desde Recien Vistas)
            ' esta cargando la temporada en segundo plano SOLO para que
            ' arriba/abajo tengan de donde sacar el capitulo siguiente/
            ' anterior (ver el comentario en playDirectEpisode). No se debe
            ' mostrar la grilla ni robarle el foco al video.
        else
            m.episodesgrid.visible = true
            m.episodesgrid.setFocus(true)
        end if
    end if
end sub

Sub onVisibleChange()
  if m.top.visible
    m.fadeIn.control="start"
    m.episodesgrid.visible = false
    m.episodesgrid.content = invalid
    m.buttons.visible = true
    m.buttons.jumpToItem = 0
    m.buttons.setFocus(true)
    m.focusOnFav = false
    if m.favBtnFocusRing <> invalid then m.favBtnFocusRing.visible = false
    checkFavorite()

    ' "Continuar viendo" desde Recien Vistas (ver HomeScreen.brs/
    ' onRWResumeRespuesta): directPlayEpisode/directPlayPos se pusieron
    ' ANTES de asignar "content" (que ya corrio, disparando
    ' OnContentChange, antes de que "visible" llegara a true). Se
    ' dispara la reproduccion AQUI (al final, despues de
    ' buttons.setFocus(true) de arriba) y no desde OnContentChange,
    ' para que el foco real de SceneGraph que playEpisode() le da al
    ' reproductor sea el ULTIMO en asignarse -- si se disparara antes,
    ' el buttons.setFocus(true) de esta misma funcion se lo robaria de
    ' vuelta un instante despues.
    if m.top.directPlayEpisode <> invalid
        playDirectEpisode()
    end if
  else
    m.fadeOut.control="start"
    m.buttons.visible = false
    m.episodesgrid.visible = false
    m.episodesgrid.content = invalid
    m.poster.uri=""
    m.background.uri=""
    m.progressTimer.control = "stop"
    m.overlayTimer.control  = "stop"
    m.retryTimer.control    = "stop"
    if m.videoPlayer.visible = true
        m.switchingEpisode = true
        m.episodeNavBusy = false
        m.videoPlayer.control = "stop"
        m.videoPlayer.visible = false
        if m.playerOverlay <> invalid then m.playerOverlay.visible = false
        if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
    end if
    if m.playErrorDialog <> invalid then
        m.top.getScene().dialog = invalid
        m.playErrorDialog = invalid
        m.showingPlayError = false
    end if
  end if
End Sub

' Al salir del reproductor -- por error, por "back", o porque el
' episodio termino -- el foco debe volver a lo que el usuario SI puede
' ver. En la navegacion normal (temporada -> lista de capitulos) eso es
' m.episodesgrid. Pero cuando se llego aqui por "Continuar viendo"
' desde Recien Vistas (ver playDirectEpisode/onVisibleChange), esa
' lista de capitulos NUNCA se lleno ni se mostro -- ahi lo unico
' visible es m.buttons (la lista de temporadas). setFocus(true) sobre
' un nodo invisible/sin contenido no hace nada, asi que sin este
' chequeo el usuario se quedaba sin poder moverse (ni con back).
sub restoreSeasonsFocus()
    if m.episodesgrid <> invalid and m.episodesgrid.visible = true
        m.episodesgrid.setFocus(true)
    else if m.buttons <> invalid
        m.buttons.visible = true
        m.buttons.setFocus(true)
    end if
end sub

Sub onVideoVisibleChange()
  if m.videoPlayer.visible = false and m.top.visible = true
    restoreSeasonsFocus()
    m.episodesgrid.observeField("itemSelected", "onEpisodeSelected")
    m.videoPlayer.control = "stop"
  else
    m.episodesgrid.unobserveField("itemSelected")
  end if
End Sub

Sub OnVideoPlayerStateChange()
  state = m.videoPlayer.state
  if state = "buffering"
      if m.bufferingGroup <> invalid then m.bufferingGroup.visible = true
  else if state = "playing"
      print "DEBUG STATEPLAYING(ep) - m.videoPlayer.position REAL al empezar a reproducir: "; m.videoPlayer.position; " | content.PlayStart era: "; m.videoPlayer.content.PlayStart
      m.retryCount = 0
      m.progressTimer.control = "start"
      m.videoPlayer.setFocus(true)
      registerRecentlyWatched()
      ' Nuevo capitulo arrancando: la barra de controles propia debe
      ' reflejar "Pausar" (esta reproduciendo), sin importar en que
      ' estado haya quedado el boton en el capitulo anterior.
      updatePlayPauseLabel()
      ' El capitulo ya arranco de verdad -- de aqui en adelante, un
      ' "finished" real (terminar de verdad) debe procesarse normal.
      m.switchingEpisode = false
      m.episodeNavBusy = false
      ' FIX REAL de "Continuar viendo/reanudar siempre empieza en 0":
      ' content.PlayStart resulto no ser confiable en este reproductor
      ' (se confirmo con logs del usuario: PlayStart quedaba bien
      ' puesto pero la posicion real siempre era 0). Lo que SI se
      ' confirmo que funciona -- se ve en los mismos logs -- es un seek
      ' manual UNA VEZ que el capitulo ya esta reproduciendo. Se aplica
      ' aqui la posicion que se dejo pendiente en resumeSelected()/
      ' playDirectEpisode().
      ' Pedido explicito: antes de este cambio, con "Continuar viendo" se
      ' veia un instante el capitulo arrancando en el minuto 0 y RECIEN
      ' despues saltaba a la posicion guardada -- "arranca, vuelve a
      ' cargar, arranca bien". El primer intento de arreglar esto (un
      ' timer fijo de 1.5s para destapar el "cargando") fallaba en
      ' algunos capitulos que tardan mas en rebufferizar que otros: el
      ' timer destapaba la pantalla ANTES de que Roku terminara de
      ' verdad, y el "buffering" real llegaba despues, mostrando el
      ' mismo glitch otra vez. El fix real (igual al sample oficial de
      ' Roku rokudev/transport-control) es no adivinar con un timer sino
      ' esperar bufferingStatus.percentage=100 (ver
      ' onBufferingStatusChange, mas abajo) antes de destapar el
      ' "cargando" -- eso aplica siempre, haya o no seek pendiente. El
      ' seekBufferTimer se deja arrancado como ultimo respaldo por si
      ' este dispositivo nunca avisa bufferingStatus.
      if m.seekBufferTimer <> invalid
          m.seekBufferTimer.control = "stop"
          m.seekBufferTimer.control = "start"
      end if
      if m.pendingSeekPos > 0
          print "DEBUG SEEKFIX(ep) - aplicando seek pendiente. pos="; m.pendingSeekPos
          m.videoPlayer.seek = m.pendingSeekPos
          m.pendingSeekPos = 0
      end if
  else if state = "finished"
      ' Roku NO tiene un estado "stopped" -- llamar
      ' m.videoPlayer.control="stop" a proposito (para cambiar de
      ' capitulo, reintentar, o salir) SIEMPRE dispara "finished" como
      ' efecto secundario, aunque el capitulo no haya terminado de
      ' verdad. Sin este chequeo, cada cambio de capitulo disparaba
      ' tryAutoPlayNext() de inmediato y encadenaba capitulos sin parar
      ' (el bug de "se traba cambiando de capitulo en capitulo").
      if m.switchingEpisode = true
          m.switchingEpisode = false
          return
      end if
      m.progressTimer.control = "stop"
      if m.playerOverlay <> invalid then m.playerOverlay.visible = false
      if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
      m.videoPlayer.visible = false
      refreshEpisodesGridProgress()
      tryAutoPlayNext()
  else if state = "error"
      if m.showingPlayError = true then return
      m.retryCount++
      if m.retryCount <= 3
          m.retryTimer.control = "stop"
          m.retryTimer.control = "start"
      else
          m.retryCount = 0
          m.showingPlayError = true
          m.progressTimer.control = "stop"
          if m.playerOverlay <> invalid then m.playerOverlay.visible = false
          if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
          ' No se pone m.switchingEpisode aqui: si el capitulo no se
          ' pudo reproducir despues de 3 intentos, el "finished" que
          ' dispara este stop debe procesarse NORMAL (como un final
          ' real) para que tryAutoPlayNext() avance solo al siguiente
          ' capitulo, igual que cuando un capitulo termina bien. El
          ' guard de playEpisode() ya evita que esto vuelva a
          ' encadenarse sin parar.
          m.videoPlayer.control = "stop"
          m.videoPlayer.visible = false
          errMsg = m.videoPlayer.errorMsg
          if errMsg = invalid or errMsg = "" then errMsg = "Could not play this episode"
          dialog = createObject("roSGNode", "Dialog")
          dialog.title   = "Playback Error"
          dialog.message = errMsg
          dialog.buttons = ["OK"]
          dialog.observeField("buttonSelected", "onPlayErrorClose")
          m.top.getScene().dialog = dialog
          m.playErrorDialog = dialog
      end if
  else
      ' Respaldo: cualquier otro estado (p.ej. "stop") oculta el aviso de carga
      if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
  end if
End Sub

sub onRetryTimer()
    m.switchingEpisode = true
    m.videoPlayer.control = "stop"
    sf = m.videoPlayer.content.streamFormat
    if sf <> invalid and sf <> "" and sf <> "hls" and sf <> "mp4" and sf <> "smooth" and sf <> "mpeg-dash" and sf <> "mkv" and sf <> "ts"
        m.videoPlayer.content.streamFormat = ""
    end if
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(m.global.user + ":" + m.global.pass)
    headers = []
    headers[0] = "X-Content:" + ba.ToBase64String()
    headers[1] = "X-Roku-Reserved-Dev-Id: 132fdf0cb94f9eb9a3a0132af460b8cd"
    headers[2] = "User-Agent: Mozilla/5.0"
    m.videoPlayer.content.HttpHeaders = headers
    m.videoPlayer.control = "play"
end sub

sub onPlayErrorClose()
    m.showingPlayError = false
    m.top.getScene().dialog = invalid
    m.playErrorDialog = invalid
    restoreSeasonsFocus()
end sub

sub tryAutoPlayNext()
    ' false: el aviso "Cambiando a capitulo..." solo debe verse cuando
    ' el usuario aprieta arriba/abajo, no en el avance automatico normal.
    goToNextEpisode(false)
end sub

' ============================================================
' Navegacion de capitulos con arriba (anterior) / abajo (siguiente)
' durante la reproduccion, y avance automatico al terminar un
' capitulo (ver OnVideoPlayerStateChange -> tryAutoPlayNext).
' Cruza de temporada automaticamente al llegar al primer/ultimo
' capitulo de la temporada actual, usando m.pendingCrossSeason para
' que setEpisodes() sepa que debe reproducir en vez de solo mostrar
' la lista una vez que el nuevo listado de capitulos llegue del
' servidor (GetEpisodes es asincrono).
' ============================================================

function currentEpisodeIndex() as Integer
    if m.episodesgrid = invalid or m.episodesgrid.content = invalid then return -1
    if m.videoPlayer = invalid or m.videoPlayer.content = invalid then return -1
    curId = m.videoPlayer.content.id
    if curId = invalid then return -1
    curId = curId.toStr()
    for i = 0 to m.episodesgrid.content.getChildCount() - 1
        ep = m.episodesgrid.content.getChild(i)
        if ep <> invalid and ep.id <> invalid and ep.id.toStr() = curId
            return i
        end if
    end for
    return -1
end function

function currentSeasonButtonIndex() as Integer
    if m.buttons = invalid or m.buttons.content = invalid then return -1
    curSeason = m.episodes.season
    if curSeason = invalid then return -1
    for i = 0 to m.buttons.content.getChildCount() - 1
        btn = m.buttons.content.getChild(i)
        if btn <> invalid
            if btn.doesExist("seasonNum")
                if btn.seasonNum = curSeason then return i
            else
                if btn.id = curSeason then return i
            end if
        end if
    end for
    return -1
end function

sub loadSeasonButtonAtIndex(index as Integer)
    if m.buttons = invalid or m.buttons.content = invalid then return
    selectedBtn = m.buttons.content.getChild(index)
    if selectedBtn = invalid then return
    m.episodes.cve = m.top.content.id
    if selectedBtn.doesExist("seasonNum")
        m.episodes.season = selectedBtn.seasonNum
    else
        m.episodes.season = selectedBtn.id
    end if
    m.episodes.seriesCover = SeasonsRealCover()
    m.buttons.visible = false
    m.episodes.control = "RUN"
end sub

sub playEpisodeAtIndex(index as Integer)
    if m.episodesgrid = invalid or m.episodesgrid.content = invalid then return
    ep = m.episodesgrid.content.getChild(index)
    if ep = invalid then return
    m.videoPlayer.content = ep
    m.videoPlayer.content.PlayStart = 0
    m.pendingSeekPos = 0
    playEpisode()
end sub

' showHint: true solo cuando la llamada viene de que el usuario apreto
' "abajo" (ver onKeyEvent) -- el aviso "Cambiando a capitulo..." pedido
' explicitamente NO debe verse en el avance automatico normal (ver
' tryAutoPlayNext) ni al saltar con OK sobre el aviso de siguiente
' capitulo.
sub goToNextEpisode(showHint as Boolean)
    ' DEBUG TEMPORAL: para confirmar por que arriba/abajo a veces no
    ' hacen nada (ver el comentario en playDirectEpisode/setEpisodes).
    ' Se puede borrar despues de revisar el log.
    gridInvalido = (m.episodesgrid = invalid or m.episodesgrid.content = invalid)
    print "DEBUG GOTONEXT - episodesgrid.content invalido="; gridInvalido
    if gridInvalido then
        m.episodeNavBusy = false
        ' Si el video ya esta reproduciendose, no se debe tocar el foco
        ' ni mostrar la lista de temporadas encima -- eso robaba el foco
        ' del video en silencio (sin verse, porque el video lo tapa) y
        ' dejaba arriba/abajo sin efecto en los apretones siguientes.
        if m.videoPlayer.visible <> true then restoreSeasonsFocus()
        return
    end if
    idx = currentEpisodeIndex()
    print "DEBUG GOTONEXT - currentEpisodeIndex="; idx
    if idx = -1 then
        m.episodeNavBusy = false
        if m.videoPlayer.visible <> true then restoreSeasonsFocus()
        return
    end if
    count = m.episodesgrid.content.getChildCount()
    if idx + 1 < count
        if showHint then showChangingEpisodeHint(nextEpisodeTitle(), "Siguiente capítulo")
        playEpisodeAtIndex(idx + 1)
    else
        segIdx = currentSeasonButtonIndex()
        if segIdx <> -1 and m.buttons.content <> invalid and segIdx + 1 < m.buttons.content.getChildCount()
            if showHint then showChangingEpisodeHint(nextEpisodeTitle(), "Siguiente temporada")
            m.pendingCrossSeason = "first"
            loadSeasonButtonAtIndex(segIdx + 1)
        else
            ' No hay mas temporadas: fin de la serie.
            m.episodeNavBusy = false
            restoreSeasonsFocus()
        end if
    end if
end sub

' Solo se llama al apretar "arriba" (siempre manual) -- el aviso se
' muestra siempre.
sub goToPreviousEpisode()
    ' DEBUG TEMPORAL: ver el comentario en goToNextEpisode().
    gridInvalido = (m.episodesgrid = invalid or m.episodesgrid.content = invalid)
    print "DEBUG GOTOPREV - episodesgrid.content invalido="; gridInvalido
    if gridInvalido then
        m.episodeNavBusy = false
        return
    end if
    idx = currentEpisodeIndex()
    print "DEBUG GOTOPREV - currentEpisodeIndex="; idx
    if idx = -1 then
        m.episodeNavBusy = false
        return
    end if
    if idx - 1 >= 0
        showChangingEpisodeHint(previousEpisodeTitle(), "Capítulo anterior")
        playEpisodeAtIndex(idx - 1)
    else
        segIdx = currentSeasonButtonIndex()
        if segIdx <> -1 and m.buttons.content <> invalid and segIdx - 1 >= 0
            showChangingEpisodeHint(previousEpisodeTitle(), "Temporada anterior")
            m.pendingCrossSeason = "last"
            loadSeasonButtonAtIndex(segIdx - 1)
        else
            ' Si no hay temporada anterior, no se hace nada (ya es el primer capitulo).
            m.episodeNavBusy = false
        end if
    end if
end sub

' Titulo del capitulo que sigue, para el aviso de "siguiente capitulo"
' (checkNextEpisodeBanner). Si el siguiente capitulo cruza de temporada
' y esa temporada aun no se ha cargado, se usa el titulo de la
' temporada como respaldo en vez de disparar una carga solo para
' averiguarlo. Regresa "" si no hay siguiente (fin de la serie).
function nextEpisodeTitle() as String
    if m.episodesgrid = invalid or m.episodesgrid.content = invalid then return ""
    idx = currentEpisodeIndex()
    if idx = -1 then return ""
    count = m.episodesgrid.content.getChildCount()
    if idx + 1 < count
        ep = m.episodesgrid.content.getChild(idx + 1)
        if ep <> invalid and ep.title <> invalid and ep.title <> "" then return ep.title
        return "Siguiente capítulo"
    else
        segIdx = currentSeasonButtonIndex()
        if segIdx <> -1 and m.buttons.content <> invalid and segIdx + 1 < m.buttons.content.getChildCount()
            nextBtn = m.buttons.content.getChild(segIdx + 1)
            if nextBtn <> invalid and nextBtn.title <> invalid and nextBtn.title <> ""
                return nextBtn.title
            end if
            return "Siguiente temporada"
        end if
        return ""
    end if
end function

' Igual que nextEpisodeTitle() pero para "arriba" (capitulo anterior),
' usado por el aviso "Cambiando a capitulo...".
function previousEpisodeTitle() as String
    if m.episodesgrid = invalid or m.episodesgrid.content = invalid then return ""
    idx = currentEpisodeIndex()
    if idx = -1 then return ""
    if idx - 1 >= 0
        ep = m.episodesgrid.content.getChild(idx - 1)
        if ep <> invalid and ep.title <> invalid and ep.title <> "" then return ep.title
        return "Capítulo anterior"
    else
        segIdx = currentSeasonButtonIndex()
        if segIdx <> -1 and m.buttons.content <> invalid and segIdx - 1 >= 0
            prevBtn = m.buttons.content.getChild(segIdx - 1)
            if prevBtn <> invalid and prevBtn.title <> invalid and prevBtn.title <> ""
                return prevBtn.title
            end if
            return "Temporada anterior"
        end if
        return ""
    end if
end function

sub checkNextEpisodeBanner()
    if m.nextEpisodeBanner = invalid then return
    if m.nextBannerShown = true then return
    curPos = m.videoPlayer.position
    curDur = m.videoPlayer.duration
    if curDur = invalid or curDur <= 0 then return
    if curPos = invalid then return
    remaining = curDur - curPos
    if remaining > 0 and remaining <= 30
        title = nextEpisodeTitle()
        if title <> ""
            m.nextBannerShown = true
            m.nextEpisodeBannerTitle.text = title
            m.nextEpisodeBanner.visible = true
        end if
    end if
end sub

sub hideEpisodeNavHint()
    if m.episodeNavHint <> invalid then m.episodeNavHint.visible = false
end sub

' Pedido explicito: al apretar arriba/abajo, mostrar en la MISMA
' posicion del aviso instructivo el mensaje "Cambiando a capitulo:
' (nombre)". Se queda visible (se detiene el timer que lo oculta solo)
' hasta que playEpisode() del capitulo nuevo reponga el texto normal.
sub showChangingEpisodeHint(episodeTitle as String, fallback as String)
    if m.episodeNavHint = invalid or m.episodeNavHintLabel = invalid then return
    label = fallback
    if episodeTitle <> invalid and episodeTitle <> "" then label = episodeTitle
    m.episodeNavHintLabel.text = "Cambiando a capítulo: " + label
    m.episodeNavHint.visible = true
    if m.episodeNavHintTimer <> invalid then m.episodeNavHintTimer.control = "stop"
end sub

Sub onEpisodeFocused()
End Sub

Sub onItemSelected()
  m.loading.control = "start"
  m.episodes.cve = m.top.content.id
  selectedBtn = m.buttons.content.getChild(m.buttons.itemSelected)
  if selectedBtn.doesExist("seasonNum")
      m.episodes.season = selectedBtn.seasonNum
  else
      m.episodes.season = selectedBtn.id
  end if
  print "Cargando season="; m.episodes.season
  m.episodes.seriesCover = SeasonsRealCover()
  m.episodes.control = "RUN"
  m.buttons.visible = false
End Sub

sub onEpisodeSelected()
    m.autoPlayCancelled = false
    idx = m.episodesgrid.itemSelected
    selectedEp = m.episodesgrid.content.getChild(idx)
    if selectedEp = invalid then return
    m.videoPlayer.content = selectedEp
    m.resume = createObject("roSGNode", "ResumeVideo")
    m.resume.section = "SerieResume"
    m.resume.cve = selectedEp.id
    m.resume.control = "RUN"
    m.resume.observeField("state", "resume")
end sub

sub resume()
    print "DEBUG RESUME(ep) - m.resume.state="; m.resume.state; " m.resume.pos="; m.resume.pos
    if m.resume.state = "stop"
        ' El registro local (SerieResume) es SOLO de este dispositivo. Si
        ' aqui no hay nada, probamos con el progreso sincronizado del
        ' servidor (WatchProgressLocalStore), que si viaja entre
        ' dispositivos -- asi "Resume" tambien funciona si viste el
        ' episodio en otro Roku.
        m.resumePos = m.resume.pos
        if m.resumePos < 3
            epId = m.videoPlayer.content.id
            if epId <> invalid and epId <> ""
                wp = WP_LocalRead(epId.toStr())
                if wp <> invalid and wp.pos <> invalid and wp.pos >= 3
                    m.resumePos = wp.pos
                    print "DEBUG RESUME(ep) - registro local vacio/insuficiente, usando progreso sincronizado del servidor. pos="; m.resumePos
                end if
            end if
        end if

        if m.resumePos >= 3 then
            print "DEBUG RESUME(ep) - mostrando dialogo, pos="; m.resumePos
            m.dialog = createObject("roSGNode", "Dialog")
            m.dialog.title = "¿Como deseas continuar viendo?"
            m.dialog.optionsDialog = true
            minutes = int(m.resumePos/60)
            seconds = int(m.resumePos MOD 60)
            secondsStr = seconds.toStr()
            if seconds < 10 then secondsStr = "0" + seconds.toStr()
            resumePosLabel = "Continuar viendo desde el minuto " + minutes.tostr() + ":" + secondsStr
            m.dialog.buttons = [resumePosLabel,"Reproducir desde el inicio"]  
            m.top.getScene().dialog = m.dialog
            m.dialog.observeField("buttonSelected","resumeSelected")
        else
            print "DEBUG RESUME(ep) - NO se muestra dialogo (pos<3), reproduciendo desde el inicio"
            m.pendingSeekPos = 0
            playEpisode()
        end if
    end if
end sub

sub resumeSelected()
    print "DEBUG RESUMESELECTED(ep) - buttonSelected="; m.dialog.buttonSelected; " pos a aplicar="; m.resumePos
    if m.dialog.buttonSelected = 0 then
        m.videoPlayer.content.PlayStart = m.resumePos
        ' Ver el comentario en OnVideoPlayerStateChange(): content.PlayStart
        ' no es confiable aqui, se aplica con seek() apenas el capitulo
        ' arranque a reproducir de verdad.
        m.pendingSeekPos = m.resumePos
        print "DEBUG RESUMESELECTED(ep) - PlayStart asignado. content.PlayStart="; m.videoPlayer.content.PlayStart; " pendingSeekPos="; m.pendingSeekPos
        playEpisode()
    else
        m.videoPlayer.content.PlayStart = 0
        m.pendingSeekPos = 0
        playEpisode()
    end if
    m.dialog.close = true
end sub

sub playEpisode()
    print "DEBUG PLAYEPISODE - content.PlayStart ANTES de control=stop: "; m.videoPlayer.content.PlayStart
    m.retryCount = 0
    m.rwRegistered = false

    ' Aviso de siguiente capitulo: se reinicia con cada capitulo nuevo.
    m.nextBannerShown = false
    if m.nextEpisodeBanner <> invalid then m.nextEpisodeBanner.visible = false

    ' Pedido explicito: ya no se muestra el aviso instructivo "ARRIBA:
    ' capitulo anterior  ABAJO: siguiente capitulo" al arrancar cada
    ' capitulo. Se sigue ocultando aqui (y deteniendo su timer) por si
    ' quedo puesto el aviso de "Cambiando a capitulo..." del capitulo
    ' anterior (showChangingEpisodeHint, disparado por arriba/abajo).
    if m.episodeNavHint <> invalid then m.episodeNavHint.visible = false
    if m.episodeNavHintTimer <> invalid then m.episodeNavHintTimer.control = "stop"
    if m.playerOverlay <> invalid then m.playerOverlay.visible = false
    if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
    m.progressTimer.control = "stop"
    ' Este control="stop" SOLO se hace si el reproductor YA esta
    ' visible/activo -- es decir, si venimos de arriba/abajo (cambio de
    ' capitulo en pleno video) donde SI hay un capitulo previo
    ' reproduciendose de verdad que hay que cortar antes de cargar el
    ' siguiente. Roku no tiene un estado "stopped" real -- ese
    ' control="stop" SIEMPRE dispara "finished" como efecto secundario
    ' (ver OnVideoPlayerStateChange), por eso se avisa con
    ' m.switchingEpisode que fuimos NOSOTROS quienes lo detuvimos.
    '
    ' Pero si esto es un capitulo NUEVO (recien elegido en la grilla, o
    ' "Continuar viendo"), el reproductor TODAVIA no esta visible aqui
    ' porque Roku nunca reprodujo nada en este nodo de video. Se
    ' confirmo que hacerle control="stop" a un Video que nunca arranco
    ' provoca que ignore content.PlayStart y siempre arranque en 0 --
    ' por eso "Continuar viendo"/reanudar en el minuto tal siempre
    ' volvia al inicio. Por eso aqui NO se llama a stop en ese caso: no
    ' hay nada que detener todavia y asi content.PlayStart si se respeta.
    if m.videoPlayer.visible = true
        m.switchingEpisode = true
        m.videoPlayer.control = "stop"
    end if
    print "DEBUG PLAYEPISODE - content.PlayStart DESPUES de control=stop: "; m.videoPlayer.content.PlayStart
    sf = m.videoPlayer.content.streamFormat
    if sf <> invalid and sf <> "" and sf <> "hls" and sf <> "mp4" and sf <> "smooth" and sf <> "mpeg-dash" and sf <> "mkv" and sf <> "ts"
        m.videoPlayer.content.streamFormat = ""
    end if
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(m.global.user + ":" + m.global.pass)
    headers = []
    headers[0] = "X-Content:" + ba.ToBase64String()
    headers[1] = "X-Roku-Reserved-Dev-Id: 132fdf0cb94f9eb9a3a0132af460b8cd"
    headers[2] = "User-Agent: Mozilla/5.0"
    m.videoPlayer.content.HttpHeaders = headers
    ' FIX REAL del bug de "Continuar viendo siempre reinicia desde 0":
    ' PlayStart se le puso a este mismo objeto de contenido (m.videoPlayer.content)
    ' DESPUES de que ya se le habia asignado a m.videoPlayer.content la
    ' primera vez (en onEpisodeSelected/playEpisodeAtIndex/playDirectEpisode).
    ' Roku SOLO lee PlayStart (y demas campos) en el momento en que el
    ' campo "content" del nodo Video CAMBIA -- si se modifica un campo del
    ' MISMO objeto ya asignado, Roku no se entera y arranca siempre en 0,
    ' aunque content.PlayStart siga mostrando el valor correcto (por eso
    ' los DEBUG de arriba SI mostraban el valor bien puesto). Se fuerza
    ' aqui un cambio real (invalid -> el mismo objeto, ya con PlayStart,
    ' streamFormat y HttpHeaders correctos) para que Roku lo vuelva a leer
    ' completo justo antes de reproducir.
    epContent = m.videoPlayer.content
    m.videoPlayer.content = invalid
    m.videoPlayer.content = epContent
    m.videoPlayer.visible = true
    m.videoPlayer.setFocus(true)
    print "DEBUG PLAYEPISODE - streamFormat final: "; m.videoPlayer.content.streamFormat; " | content.PlayStart JUSTO ANTES de control=play: "; m.videoPlayer.content.PlayStart
    m.videoPlayer.control = "play"
    showPlayerOverlay()
    if m.progressTimer <> invalid then
        m.progressTimer.control = "start"
    end if
end sub

' Se registra la SERIE (m.top.content), no el episodio: el nodo de
' episodio no trae poster/backdrop/descripcion de la serie (ver
' GetEpisodes.brs), y ademas "Recien Vistas" debe mostrar la serie
' como un solo item, no un item distinto por cada episodio visto.
' Una sola vez por sesion de reproduccion (mismo criterio que
' DetailsScreen.registerRecentlyWatched).
sub registerRecentlyWatched()
    if m.rwRegistered = true then return
    m.rwRegistered = true

    itemAA = Fav_NodeToAA(m.top.content, Fav_VodSerieFields())
    ' Guardamos tambien el id del EPISODIO especifico que se esta viendo
    ' (m.top.content.id es el id de la SERIE) -- asi el Home puede
    ' buscar el progreso real de este episodio, no de la serie.
    if m.videoPlayer.content <> invalid and m.videoPlayer.content.id <> invalid
        itemAA["lastEpisodeId"] = m.videoPlayer.content.id.toStr()
        ' Datos completos del capitulo (url, streamFormat, etc.), no
        ' solo su id -- para que "Continuar viendo" desde Recien
        ' Vistas pueda alimentar el reproductor DIRECTO con esto,
        ' sin tener que volver a buscar el capitulo por red (ver
        ' HomeScreen.brs/playRWSerieDirect).
        itemAA["lastEpisodeData"] = FormatJSON(Fav_NodeToAA(m.videoPlayer.content, RW_EpisodeFields()))
    end if
    print "DEBUG REGISTERRW(serie) - seriesId="; m.top.content.id; " lastEpisodeId guardado="; itemAA["lastEpisodeId"]

    m.registerRW = createObject("roSGNode", "RegisterRecentlyWatched")
    m.registerRW.cve  = m.top.content.id
    m.registerRW.tipo = "serie"
    m.registerRW.itemJson = FormatJSON(itemAA)
    m.registerRW.control = "RUN"
end sub

sub savePosition()
    curPos = m.videoPlayer.position
    curDur = m.videoPlayer.duration
    if m.playerOverlay <> invalid and m.playerOverlay.visible then updateSeasonProgressBar()

    epId = invalid
    if m.videoPlayer.content <> invalid then epId = m.videoPlayer.content.id

    if int(curPos) MOD 2 = 0 and curPos > 10
        m.savePositionToReg.cve = epId
        m.savePositionToReg.pos = curPos - 10
        m.savePositionToReg.control = "RUN"

        ' Progreso local para la barra tipo Netflix (mismo ritmo que el resume)
        if epId <> invalid and epId <> "" and curDur <> invalid and curDur > 0
            WP_LocalWrite(epId.toStr(), int(curPos), int(curDur))
        end if
    end if

    ' Sincronizar con servidor cada 1 min (no en cada tick, para no saturar red)
    if int(curPos) MOD 60 = 0 and curPos > 10
        if epId <> invalid and epId <> "" and curDur <> invalid and curDur > 0
            m.saveWatchProgress = createObject("roSGNode", "SaveWatchProgress")
            m.saveWatchProgress.cve = epId.toStr()
            m.saveWatchProgress.pos = int(curPos)
            m.saveWatchProgress.duration = int(curDur)
            m.saveWatchProgress.control = "RUN"
        end if
    end if
end sub

' MarkupGrid no vuelve a llamar itemContentChanged() en cada item solo
' porque el registro local cambio (esos datos viven fuera del ContentNode).
' Al volver a la lista de capitulos, se reasigna el mismo content para
' forzar que cada item se repinte y lea el progreso mas reciente.
sub refreshEpisodesGridProgress()
    if m.episodesgrid = invalid then return
    currentContent = m.episodesgrid.content
    if currentContent = invalid then return
    m.episodesgrid.content = invalid
    m.episodesgrid.content = currentContent
end sub

Sub OnContentChange()
  print "Seasons.brs - [OnContentChange]"
  m.description.text = m.top.content.description
  m.poster.uri                 = m.top.content.HDPosterUrl
  if m.top.content.hdBackgroundImageUrl <> invalid and m.top.content.hdBackgroundImageUrl <> "" then
      m.background.uri = m.top.content.hdBackgroundImageUrl
  else if m.top.content.HDPosterUrl <> invalid and m.top.content.HDPosterUrl <> "" then
      m.background.uri = m.top.content.HDPosterUrl
  end if
  m.tilte.text                 = m.top.content.title
  m.date.text                  = m.top.content.releasedate
  m.rating.text                = m.top.content.rating
  m.episodesgrid.visible = false
  m.episodesgrid.content = invalid
  m.buttons.content = invalid
  if m.seasons.cve <> m.top.content.id then
      m.loading.control = "start"
      m.seasons.cve = m.top.content.id
      m.seasons.control = "RUN"
      m.buttons.visible = false
  else
      m.loading.control = "start"
      m.seasons.control = "RUN"
  end if
  ' Nota: si viene un "directPlayEpisode" pendiente (Continuar viendo
  ' desde Recien Vistas), la reproduccion se dispara desde
  ' onVisibleChange (no aqui) -- ver el comentario ahi para el porque.
end Sub

sub playDirectEpisode()
    ep = m.top.directPlayEpisode
    m.top.directPlayEpisode = invalid
    if ep = invalid then return
    m.videoPlayer.content = ep
    m.videoPlayer.content.PlayStart = m.top.directPlayPos
    ' Ver el comentario en OnVideoPlayerStateChange(): content.PlayStart
    ' no es confiable aqui, se aplica con seek() apenas el capitulo
    ' arranque a reproducir de verdad.
    m.pendingSeekPos = m.top.directPlayPos
    m.top.directPlayPos = 0

    ' BUG "arriba/abajo no sirven" cuando se entra por "Continuar viendo"
    ' (Recien Vistas): este flujo nunca pasa por la grilla de capitulos,
    ' asi que m.episodesgrid.content se queda invalid, y
    ' goToNextEpisode()/goToPreviousEpisode() no tienen de donde sacar
    ' cual es el capitulo siguiente/anterior -- por eso arriba/abajo no
    ' hacian nada (silenciosamente). Se intenta cargar aqui, en segundo
    ' plano, la temporada de ESTE capitulo (sin mostrar la grilla -- ver
    ' el chequeo agregado en setEpisodes()) para que arriba/abajo
    ' funcionen tambien en este caso. Si no se puede saber la temporada
    ' (dato viejo/incompleto sincronizado desde otro dispositivo), se
    ' deja igual que antes: arriba/abajo simplemente no haran nada, sin
    ' arriesgar la reproduccion.
    ' DEBUG TEMPORAL: para confirmar si se pudo resolver la temporada
    ' de este capitulo (necesario para que arriba/abajo funcionen aqui).
    print "DEBUG PLAYDIRECT - ep.titleSeason="; ep.titleSeason
    if ep.titleSeason <> invalid and Left(ep.titleSeason, 1) = "S"
        seasonNum = val(Mid(ep.titleSeason, 2))
        print "DEBUG PLAYDIRECT - seasonNum resuelto="; seasonNum
        if seasonNum > 0 and m.top.content <> invalid and m.top.content.id <> invalid
            m.episodes.seriesCover = SeasonsRealCover()
            m.episodes.cve = m.top.content.id
            m.episodes.season = seasonNum.toStr()
            m.episodes.control = "RUN"
        end if
    end if

    playEpisode()
end sub

sub onFavToggled()
    m.isFavorite = m.addFavorite.isFavorite
    if m.isFavorite
        m.favorite.text    = "Unfavorite"
        m.favBtnLabel.text = "★ Quitar"
    else
        m.favorite.text    = "Favorite"
        m.favBtnLabel.text = "★ Favorito"
    end if
end sub

sub changeFavoriteText()
    if m.favorite.text = "Favorite" then
        m.favorite.text = "Unfavorite"
        m.favBtnLabel.text = "★ Quitar"
    else
        m.favorite.text = "Favorite"
        m.favBtnLabel.text = "★ Favorito"
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
  ' DEBUG TEMPORAL: para confirmar si arriba/abajo llegan aqui de verdad
  ' en el primer apreton durante la reproduccion, o si Roku se los queda
  ' antes (por el reproductor nativo) y nunca entran a esta funcion.
  ' Se puede borrar despues de revisar el log.
  print "DEBUG ONKEYEVENT key="; key; " press="; press; " videoplayer.visible="; m.videoplayer.visible; " episodeNavBusy="; m.episodeNavBusy
  result = false
  if press then
    if key = "back"
      if m.buttons.visible = false and m.videoplayer.visible = false and m.episodesgrid.visible = true
        m.episodesgrid.visible = false
        m.buttons.visible = true
        m.buttons.setFocus(true)
        result = true
      end if
    else if key = "up"
        if (m.buttons.visible or m.episodesgrid.visible) and not m.videoplayer.visible and m.focusOnFav <> true
            m.lastFocusWasGrid = m.episodesgrid.visible
            if m.buttons.visible
                m.buttons.setFocus(false)
            end if
            if m.episodesgrid.visible
                m.episodesgrid.setFocus(false)
            end if
            fc = m.global.focusColor
            if fc = invalid or fc = "" then fc = "0x00A8FFFF"
            if m.favBtnFocusRing <> invalid then m.favBtnFocusRing.visible = true
            m.focusOnFav = true
            m.top.setFocus(true)
            result = true
        end if
    else if key = "down"
        if m.focusOnFav = true
            m.focusOnFav = false
            if m.favBtnFocusRing <> invalid then m.favBtnFocusRing.visible = false
            m.buttons.opacity = 1.0
            m.episodesgrid.opacity = 1.0
            if m.lastFocusWasGrid = true and m.episodesgrid.visible
                m.episodesgrid.setFocus(true)
            else
                m.buttons.setFocus(true)
            end if
            result = true
        end if
    else if key = "OK"
        if m.focusOnFav = true
            m.addFavorite = createObject("roSGNode", "AddFavorite")
            m.addFavorite.cve = m.top.content.id
            m.addFavorite.tipo = "serie"
            if m.isFavorite <> true
                m.addFavorite.itemJson = FormatJSON(Fav_NodeToAA(m.top.content, Fav_VodSerieFields()))
            end if
            m.addFavorite.control = "RUN"
            m.addFavorite.observeField("isFavorite", "onFavToggled")
            result = true
        end if
    else if key = "options"
        if m.videoplayer.visible
            showSeasonControlsMenu()
            result = true
        else if m.top.visible
            m.addFavorite = createObject("roSGNode","AddFavorite")
            m.addFavorite.cve = m.top.content.id
            m.addFavorite.tipo = "serie"
            if m.isFavorite <> true
                m.addFavorite.itemJson = FormatJSON(Fav_NodeToAA(m.top.content, Fav_VodSerieFields()))
            end if
            m.addFavorite.control = "RUN"
            m.addFavorite.observeField("isFavorite","changeFavoriteText")
            result = true
        end if
    end if

    if m.videoplayer.visible
        if key = "back"
            ' Igual que cualquier otro stop intencional: sin esto, salir
            ' con "back" dispara un "finished" falso que auto-avanzaria
            ' al siguiente capitulo en vez de simplemente salir.
            m.switchingEpisode = true
            m.episodeNavBusy = false
            m.videoPlayer.control = "stop"
            m.videoPlayer.visible = false
            if m.playerOverlay <> invalid then m.playerOverlay.visible = false
            if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
            refreshEpisodesGridProgress()
            restoreSeasonsFocus()
            result = true
        else if key = "OK"
            if m.nextEpisodeBanner <> invalid and m.nextEpisodeBanner.visible
                ' Aviso de "siguiente capitulo" visible: OK salta ya.
                m.nextEpisodeBanner.visible = false
                goToNextEpisode(false)
            else if m.playerOverlay <> invalid
                if m.playerOverlay.visible
                    ' Igual que Android: con la barra visible, OK activa
                    ' el control que este enfocado (no la esconde).
                    activateFocusedControl()
                else
                    showPlayerOverlay()
                end if
            end if
            result = true
        else if key = "play"
            ' Boton fisico de play/pausa del control remoto (si lo
            ' tiene): pausa/reproduce directo, igual que en Android, sin
            ' necesidad de tener la barra enfocada primero.
            togglePlayPause()
            if m.playerOverlay <> invalid and m.playerOverlay.visible <> true then showPlayerOverlay()
            result = true
        else if key = "rewind"
            seekRelative(-10)
            if m.playerOverlay <> invalid and m.playerOverlay.visible <> true then showPlayerOverlay()
            result = true
        else if key = "fastforward"
            seekRelative(10)
            if m.playerOverlay <> invalid and m.playerOverlay.visible <> true then showPlayerOverlay()
            result = true
        else if key = "left"
            ' Pedido explicito: izquierda/derecha NO deben adelantar/
            ' atrasar la linea de tiempo por su cuenta -- para eso estan
            ' los botones -10s/+10s de la barra. Si la barra esta
            ' visible, mueven el foco entre botones; si no, no hacen
            ' nada. result=true SIEMPRE (aunque no se haga nada) para
            ' que Roku no le pase la tecla a su propio trick play nativo
            ' (enableTrickPlay sigue en true, solo para que el seek()
            ' que hacemos nosotros funcione -- sin este result=true,
            ' Roku hacia el seek el solo con izquierda/derecha aunque la
            ' barra nativa este apagada).
            if m.playerOverlay <> invalid and m.playerOverlay.visible
                moveCtrlBarFocus(-1)
            end if
            result = true
        else if key = "right"
            if m.playerOverlay <> invalid and m.playerOverlay.visible
                moveCtrlBarFocus(1)
            end if
            result = true
        else if key = "down"
            ' Pedido explicito: abajo adelanta capitulo durante la
            ' reproduccion. Se ignora si ya hay un cambio de capitulo en
            ' curso -- solo se puede apretar una vez hasta que el
            ' siguiente capitulo cargue y empiece a reproducir (evita
            ' que apretar varias veces seguidas trabe la app).
            if m.episodeNavBusy <> true
                m.episodeNavBusy = true
                goToNextEpisode(true)
            end if
            result = true
        else if key = "up"
            ' Pedido explicito: arriba atrasa capitulo durante la
            ' reproduccion. Mismo bloqueo que "down".
            if m.episodeNavBusy <> true
                m.episodeNavBusy = true
                goToPreviousEpisode()
            end if
            result = true
        end if
    end if
  end if
  return result
end function

sub showPlayerOverlay()
    ' Barra de controles propia (igual a Android): reemplaza la UI
    ' nativa de Roku, que quedo apagada (enableUI="false" en Seasons.xml).
    if m.playerOverlay = invalid then return
    if m.overlayTitle <> invalid and m.top.content <> invalid
        t = m.top.content.title
        if t = invalid then t = ""
        m.overlayTitle.text = t
    end if
    updateSeasonProgressBar()
    updatePlayPauseLabel()
    m.ctrlBarFocusIdx = 2 ' foco por defecto: play/pausa, igual que Android
    updateCtrlBarFocusVisuals()
    m.playerOverlay.visible = true
    m.overlayTimer.control = "stop"
    m.overlayTimer.control = "start"
end sub

sub hidePlayerOverlay()
    if m.playerOverlay = invalid then return
    m.playerOverlay.visible = false
    m.overlayTimer.control = "stop"
end sub

' Mueve el foco entre los controles de la barra (Izquierda/Derecha).
' delta: -1 (izquierda) o +1 (derecha). Reinicia el autoocultado, igual
' que cualquier otra interaccion con la barra.
sub moveCtrlBarFocus(delta as Integer)
    if m.ctrlBar = invalid or m.ctrlBar.count() = 0 then return
    n = m.ctrlBar.count()
    m.ctrlBarFocusIdx = (m.ctrlBarFocusIdx + delta + n) MOD n
    updateCtrlBarFocusVisuals()
    m.overlayTimer.control = "stop"
    m.overlayTimer.control = "start"
end sub

sub updateCtrlBarFocusVisuals()
    if m.ctrlBar = invalid then return
    for i = 0 to m.ctrlBar.count() - 1
        ring = m.ctrlBar[i]
        if ring <> invalid then ring.visible = (i = m.ctrlBarFocusIdx)
    end for
end sub

' Activa el control actualmente enfocado (OK). Mismo orden que m.ctrlBar
' (ver Init): 0=anterior 1=-10s 2=play/pausa 3=+10s 4=siguiente 5=engranaje.
sub activateFocusedControl()
    m.overlayTimer.control = "stop"
    m.overlayTimer.control = "start"
    idx = m.ctrlBarFocusIdx
    if idx = 0
        if m.episodeNavBusy <> true
            m.episodeNavBusy = true
            goToPreviousEpisode()
        end if
    else if idx = 1
        seekRelative(-10)
    else if idx = 2
        togglePlayPause()
    else if idx = 3
        seekRelative(10)
    else if idx = 4
        if m.episodeNavBusy <> true
            m.episodeNavBusy = true
            goToNextEpisode(true)
        end if
    else if idx = 5
        showSeasonControlsMenu()
    end if
end sub

' +10s/-10s, igual que los botones de Android (seekBy). Se recorta a
' [0, duracion] para no mandar el seek fuera de rango.
sub seekRelative(deltaSeconds as Integer)
    curPos = m.videoPlayer.position
    if curPos = invalid then curPos = 0
    curDur = m.videoPlayer.duration
    newPos = curPos + deltaSeconds
    if newPos < 0 then newPos = 0
    if curDur <> invalid and curDur > 0 and newPos > curDur - 1 then newPos = curDur - 1
    ' DEBUG TEMPORAL: para confirmar el valor real de posicion/duracion
    ' que ve este seek relativo, por si "adelantar" termina en un lugar
    ' equivocado. Se puede borrar despues de revisar el log.
    print "DEBUG SEEKRELATIVE(ep) - curPos="; curPos; " curDur="; curDur; " delta="; deltaSeconds; " newPos="; newPos
    m.videoPlayer.seek = newPos
    updateSeasonProgressBar()
end sub

' Play/pausa, igual que el boton central de Android (togglePlayPause).
sub togglePlayPause()
    if m.videoPlayer.state = "paused"
        m.videoPlayer.control = "resume"
    else
        m.videoPlayer.control = "pause"
    end if
    updatePlayPauseLabel()
end sub

sub updatePlayPauseLabel()
    if m.ctrlPlayPauseLabel = invalid then return
    if m.videoPlayer.state = "paused"
        m.ctrlPlayPauseLabel.text = "Reproducir"
    else
        m.ctrlPlayPauseLabel.text = "Pausar"
    end if
end sub

sub onProgressTimer()
    if m.playerOverlay <> invalid and m.playerOverlay.visible
        updateSeasonProgressBar()
    end if
    checkNextEpisodeBanner()
end sub

' Respaldo del fix de "arranca-vuelve a cargar-arranca bien" (ver el
' comentario en OnVideoPlayerStateChange, rama pendingSeekPos): si Roku
' hizo el seek sin volver a avisar "buffering"/"playing" (a veces el
' salto es practicamente instantaneo), este timer destapa el "cargando"
' de todas formas. Si en ese momento Roku SI esta buffering de verdad
' (el seek si tardo), no se hace nada -- el manejo normal de estados se
' encarga de destaparlo cuando de verdad este listo.
' Ultimo respaldo si este dispositivo nunca avisa bufferingStatus (ver
' onBufferingStatusChange): despues de un tiempo generoso, destapa el
' "cargando" salvo que Roku este de verdad todavia en "buffering".
sub onSeekBufferTimer()
    if m.videoPlayer <> invalid and m.videoPlayer.state <> "buffering"
        if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
    end if
end sub

' Forma correcta (la que usa el sample oficial de Roku
' rokudev/transport-control, funcion handleBufferingStatus) de saber si
' el video YA de verdad esta listo para verse sin que se note el salto
' del seek -- en vez de adivinar con un timer fijo (que fallaba en
' capitulos que tardan mas o menos en rebufferizar), se espera a que
' Roku avise que el buffer llego al 100%.
sub onBufferingStatusChange()
    status = m.videoPlayer.bufferingStatus
    if status <> invalid and status.percentage <> invalid and status.percentage >= 100
        if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
        if m.seekBufferTimer <> invalid then m.seekBufferTimer.control = "stop"
    end if
end sub

sub updateSeasonProgressBar()
    if m.progressFill = invalid then return
    curPos = m.videoPlayer.position
    curDur = m.videoPlayer.duration
    if curDur = invalid or curDur <= 0 then return
    pct  = curPos / curDur
    barW = int(1173.3 * pct)
    m.progressFill.width      = barW
    m.progressDot.translation = [49.3 + barW, 496]
    m.timeCurrent.text  = seasonFmtTime(int(curPos))
    m.timeDuration.text = seasonFmtTime(int(curDur))
end sub

sub updateSeasonTrackLabels()
    if m.audioLabel = invalid then return
    tracks = m.videoPlayer.audioTracks
    if tracks <> invalid and tracks.count() > 0
        selIdx = m.videoPlayer.selectedAudioTrack
        if selIdx = invalid then selIdx = 0
        t = tracks[selIdx]
        name = ""
        if t <> invalid
            if t.language <> invalid and t.language <> "" then name = t.language
            if name = "" and t.name <> invalid then name = t.name
        end if
        if name = "" then name = "Track " + (selIdx + 1).toStr()
        m.audioLabel.text = "Audio: " + name
    else
        m.audioLabel.text = "Audio: -"
    end if
    sTracks = m.videoPlayer.subtitleTracks
    if sTracks <> invalid and sTracks.count() > 0
        if m.subtitlesOn then m.subtitleLabel.text = "CC: On" else m.subtitleLabel.text = "CC: Off"
    else
        m.subtitleLabel.text = "CC: -"
    end if
end sub

sub showSeasonControlsMenu()
    tracks  = m.videoPlayer.audioTracks
    sTracks = m.videoPlayer.subtitleTracks
    items = []
    if tracks <> invalid and tracks.count() > 0
        items.push("Audio Tracks  (" + tracks.count().toStr() + " available)")
    end if
    if sTracks <> invalid and sTracks.count() > 0
        if m.subtitlesOn
            items.push("Subtitles: ON  (press to turn off)")
        else
            items.push("Subtitles: OFF  (press to turn on)")
        end if
    end if
    items.push("Close")
    dlg = createObject("roSGNode", "Dialog")
    dlg.title   = "Player Controls"
    dlg.buttons = items
    dlg.observeField("buttonSelected", "onSeasonControlsSelected")
    m.controlsDlg = dlg
    m.top.getScene().dialog = dlg
end sub

sub onSeasonControlsSelected()
    if m.controlsDlg = invalid then return
    btn = m.controlsDlg.buttonSelected
    m.top.getScene().dialog = invalid
    m.controlsDlg = invalid
    m.videoPlayer.setFocus(true)
    tracks  = m.videoPlayer.audioTracks
    sTracks = m.videoPlayer.subtitleTracks
    hasAudio = tracks <> invalid and tracks.count() > 0
    hasSubs  = sTracks <> invalid and sTracks.count() > 0
    if btn = 0 and hasAudio
        showSeasonAudioMenu()
    else if btn = 0 and not hasAudio and hasSubs
        toggleSeasonSubs()
    else if btn = 1 and hasAudio and hasSubs
        toggleSeasonSubs()
    end if
end sub

sub showSeasonAudioMenu()
    tracks = m.videoPlayer.audioTracks
    if tracks = invalid or tracks.count() = 0 then return
    items = []
    selIdx = m.videoPlayer.selectedAudioTrack
    if selIdx = invalid then selIdx = 0
    for i = 0 to tracks.count() - 1
        t = tracks[i]
        name = ""
        if t.language <> invalid and t.language <> "" then name = t.language
        if name = "" and t.name <> invalid then name = t.name
        if name = "" then name = "Track " + (i + 1).toStr()
        if i = selIdx then name = name + "  ✓"
        items.push(name)
    end for
    items.push("Cancel")
    dlg = createObject("roSGNode", "Dialog")
    dlg.title   = "Select Audio Track"
    dlg.buttons = items
    dlg.observeField("buttonSelected", "onSeasonAudioSelected")
    m.audioDlg = dlg
    m.top.getScene().dialog = dlg
end sub

sub onSeasonAudioSelected()
    if m.audioDlg = invalid then return
    btn = m.audioDlg.buttonSelected
    m.top.getScene().dialog = invalid
    m.audioDlg = invalid
    tracks = m.videoPlayer.audioTracks
    if tracks <> invalid and btn >= 0 and btn < tracks.count()
        m.videoPlayer.selectedAudioTrack = btn
        updateSeasonTrackLabels()
    end if
    m.videoPlayer.setFocus(true)
end sub

sub toggleSeasonSubs()
    sTracks = m.videoPlayer.subtitleTracks
    if sTracks = invalid or sTracks.count() = 0 then return
    if m.subtitlesOn
        m.videoPlayer.selectedSubtitleTrack = -1
        m.subtitlesOn = false
    else
        m.videoPlayer.selectedSubtitleTrack = 0
        m.subtitlesOn = true
    end if
    updateSeasonTrackLabels()
    m.videoPlayer.setFocus(true)
end sub

function seasonFmtTime(secs as Integer) as String
    h  = int(secs / 3600)
    mn = int((secs mod 3600) / 60)
    s  = secs mod 60
    if h > 0 then return h.toStr() + ":" + szp(mn) + ":" + szp(s)
    return mn.toStr() + ":" + szp(s)
end function

function szp(n as Integer) as String
    if n < 10 then return "0" + n.toStr()
    return n.toStr()
end function
