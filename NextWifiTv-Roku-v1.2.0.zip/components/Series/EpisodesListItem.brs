sub Init()
    m.poster       = m.top.FindNode("poster")
    m.title        = m.top.FindNode("title")
    m.description  = m.top.FindNode("description")
    m.info         = m.top.FindNode("info")
    m.focusRing    = m.top.FindNode("focusRing")
    m.focusTop     = m.top.FindNode("focusTop")
    m.focusBottom  = m.top.FindNode("focusBottom")
    m.focusLeft    = m.top.FindNode("focusLeft")
    m.focusRight   = m.top.FindNode("focusRight")
    m.watchProgressBg   = m.top.FindNode("watchProgressBg")
    m.watchProgressFill = m.top.FindNode("watchProgressFill")
    m.title.font.size       = 18
    m.description.font.size = 12
    m.info.font.size        = 14

    ' Recorta cualquier contenido que intente dibujarse fuera del slot
    ' completo del item (tarjeta + margen del anillo de foco).
    m.top.clippingRect = [0.0, 0.0, 1150.0, 95.0]

    applyEpisodeFocusColor()
    m.global.observeField("focusColor", "applyEpisodeFocusColor")
end sub

sub applyEpisodeFocusColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0x00A8FFFF"
    m.focusTop.color    = fc
    m.focusBottom.color = fc
    m.focusLeft.color   = fc
    m.focusRight.color  = fc
end sub

sub onFocusChanged()
    m.focusRing.visible = m.top.itemHasFocus
end sub

sub itemContentChanged()
    itemContent = m.top.itemContent
    if itemContent = invalid then return

    ' shortDescriptionLine1 guarda la URL de la imagen del episodio
    posterUrl = itemContent.shortDescriptionLine1
    print "[ITEM] posterUrl="; posterUrl
    print "[ITEM] title="; itemContent.title

    if posterUrl <> invalid and posterUrl <> ""
        m.poster.uri = posterUrl
    else
        m.poster.uri = "pkg:/images/no-poster-wide.jpg"
    end if

    t = itemContent.title
    if t = invalid then t = ""

    episode = ""
    if itemContent.episodeNumber <> invalid then episode = itemContent.episodeNumber.toStr()

    combinedTitle = t
    if episode <> "" then combinedTitle = t + "   |   Ep. " + episode
    m.title.text = combinedTitle

    if itemContent.description <> invalid
        m.description.text = itemContent.description
    end if

    ' --- Barra de "visto" (estilo Netflix), segun progreso guardado local ---
    epId = itemContent.id
    frac = 0.0
    if epId <> invalid and epId <> "" then frac = WP_LocalFraction(epId.toStr())
    if frac > 0.0
        m.watchProgressBg.visible   = true
        m.watchProgressFill.visible = true
        m.watchProgressFill.width   = 1130.0 * frac
    else
        m.watchProgressBg.visible   = false
        m.watchProgressFill.visible = false
    end if
end sub
