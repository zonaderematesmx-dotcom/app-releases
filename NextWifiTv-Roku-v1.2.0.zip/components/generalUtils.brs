Function getStrValFromReg(keyname As String, section As String) As String
    reg = CreateObject("roRegistrySection", section)
    if reg.Exists(keyname) then
        return reg.Read(keyname)
    endif
    return ""
End Function

Function saveStrValToReg(keyname As String, val As String, section As String) As Boolean
    reg = CreateObject("roRegistrySection", section)
    reg.Write(keyname, val)
    return reg.Flush()
End Function

Function delStrValToReg(keyname As String, section As String)
    sec = CreateObject("roRegistrySection", section)
    sec.Delete(keyname)
    sec.Flush()
End Function

Function RegRead(key, section=invalid)
    if section = invalid then section = "Default"
    sec = CreateObject("roRegistrySection", section)
    if sec.Exists(key) then return sec.Read(key)
    return invalid
End Function

Function RegWrite(key, val, section=invalid)
    if section = invalid then section = "Default"
    sec = CreateObject("roRegistrySection", section)
    sec.Write(key, val)
    sec.Flush() 'commit it
End Function

Function RegDelete(key, section=invalid)
    if section = invalid then section = "Default"
    sec = CreateObject("roRegistrySection", section)
    sec.Delete(key)
    sec.Flush()
End Function

Function GetDeviceESN() as string
    r = CreateObject("roRegex", "-", "")
	arr = r.Split(createObject("roDeviceInfo").GetChannelClientId())
    return arr[4]
End Function

Function GetModel() as string
    'r = CreateObject("roRegex", " - ", "")
	'arr = r.Split(createObject("roDeviceInfo").getFriendlyName())
    'return arr[0]
	
    models = {}
    models["N1050"] = "Roku SD"
    models["N1000"] = "Roku HD Classic"
    models["N1100"] = "Roku HD Classic"
    models["2050X"] = "Roku XD"
    models["2050N"] = "Roku XD"
    models["N1101"] = "Roku XD|S Classic"
    models["2100X"] = "Roku XD|S"
    models["2100N"] = "Roku XD|S"
    models["2000C"] = "Roku HD"
    models["2500X"] = "Roku HD"
    models["2400X"] = "Roku LT"
    models["2450X"] = "Roku LT"
    models["2400SK"] = "Roku TV"
    models["2700X"] = "Roku LT" '2013
    models["2710X"] = "Roku 1" '2013
    models["2710R"] = "Roku 1" '2015
    models["2720X"] = "Roku 2" '2013
    models["3000X"] = "Roku 2 HD"
    models["3050X"] = "Roku 2 XD"
    models["3100X"] = "Roku 2 XS"
    models["3400X"] = "Roku Streaming Stick"
    models["3420X"] = "Roku Streaming Stick"
    models["3500R"] = "Roku Streaming Stick" '2014
    models["3500X"] = "Roku Streaming Stick" '2015
    models["4200X"] = "Roku 3"
    models["4200R"] = "Roku 3"
    models["4210X"] = "Roku 2" '2015
    models["4210R"] = "Roku 2" '2015
    models["4230X"] = "Roku 3" '2015
    models["4230R"] = "Roku 3" '2015 
    models["3600X"] = "Roku Streaming Stick"
    models["4400X"] = "Roku 4"
    models["3700X"] = "Roku Express"
    models["3710X"] = "Roku Express+"
    models["4620X"] = "Roku Premiere"
    models["4630X"] = "Roku Premiere+"
    models["4640X"] = "Roku Ultra"
    models["5000X"] = "Roku TV"
    models["5101X"] = "Roku TV"
    models["5103X"] = "Roku TV"
    models["6000X"] = "Roku 4K TV"
    models["7000X"] = "Roku 4K TV"
    models["7010X"] = "Roku 4K TV"
    
    device = CreateObject("roDeviceInfo")

    modelNumber = device.GetModel()

   If models.DoesExist(modelNumber) Then
        modelName = models[modelNumber]
    Else
        modelName = "Roku " + modelNumber
    End If

    return modelName
End Function

Function GetAppVersion() as string
    return CreateObject("roAppInfo").GetValue("version")
end function

Function generar_token() As String
    hexChars = "0123456789abcde"
    hexString = ""
    For i = 1 to 25
        hexString = hexString + hexChars.Mid(Rnd(16) - 1, 1)
    Next
    return hexString+"&genkey="+hexString
End Function

Function strReplace(basestr As String, oldsub As String, newsub As String) As String
    newstr = ""

    i = 1
    while i <= Len(basestr)
        x = Instr(i, basestr, oldsub)
        if x = 0 then
            newstr = newstr + Mid(basestr, i)
            exit while
        endif

        if x > i then
            newstr = newstr + Mid(basestr, i, x-i)
            i = x
        endif

        newstr = newstr + newsub
        i = i + Len(oldsub)
    end while

    return newstr
End Function

Function deviceModel() as string
    models = {}
    models["N1050"] = "Roku SD"
    models["N1000"] = "Roku HD Classic"
    models["N1100"] = "Roku HD Classic"
    models["2050X"] = "Roku XD"
    models["2050N"] = "Roku XD"
    models["N1101"] = "Roku XD|S Classic"
    models["2100X"] = "Roku XD|S"
    models["2100N"] = "Roku XD|S"
    models["2000C"] = "Roku HD"
    models["2500X"] = "Roku HD"
    models["2400X"] = "Roku LT"
    models["2450X"] = "Roku LT"
    models["2400SK"] = "Roku TV"
    models["2700X"] = "Roku LT" '2013
    models["2710X"] = "Roku 1" '2013
    models["2710R"] = "Roku 1" '2015
    models["2720X"] = "Roku 2" '2013
    models["3000X"] = "Roku 2 HD"
    models["3050X"] = "Roku 2 XD"
    models["3100X"] = "Roku 2 XS"
    models["3400X"] = "Roku Streaming Stick"
    models["3420X"] = "Roku Streaming Stick"
    models["3500R"] = "Roku Streaming Stick" '2014
    models["3500X"] = "Roku Streaming Stick" '2015
    models["4200X"] = "Roku 3"
    models["4200R"] = "Roku 3"
    models["4210X"] = "Roku 2" '2015
    models["4210R"] = "Roku 2" '2015
    models["4230X"] = "Roku 3" '2015
    models["4230R"] = "Roku 3" '2015 
    models["3600X"] = "Roku Streaming Stick"
    models["4400X"] = "Roku 4"
    models["3700X"] = "Roku Express"
    models["3710X"] = "Roku Express+"
    models["4620X"] = "Roku Premiere"
    models["4630X"] = "Roku Premiere+"
    models["4640X"] = "Roku Ultra"
    models["5000X"] = "Roku TV"
    models["5101X"] = "Roku TV"
    models["5103X"] = "Roku TV"
    models["6000X"] = "Roku 4K TV"
    models["7000X"] = "Roku 4K TV"
    models["7010X"] = "Roku 4K TV"
    
    device = CreateObject("roDeviceInfo")

    modelNumber = device.GetModel()

   If models.DoesExist(modelNumber) Then
        modelName = models[modelNumber]
    Else
        modelName = "Roku " + modelNumber
    End If

    return modelName
End Function

' Url-encode simple para query strings (espacios, acentos, simbolos).
' Usado para mandar el titulo de peliculas/series al servidor propio
' sin romper la URL. Nombre con prefijo GU_ para no chocar con
' funciones locales del mismo nombre en otros Tasks (ej.
' SettingsSyncTask.brs ya tiene su propio UrlEncodeSimple).
function GU_UrlEncode(s as Dynamic) as String
    if s = invalid then return ""
    ut = CreateObject("roUrlTransfer")
    ut.AddHeader("User-Agent", "Mozilla/5.0")
    return ut.Escape(s.toStr())
end function

' ============================================================
' NormalizeServerList
' Convierte el "serverURLs" de config.json a un formato unico
' [{variante:"N", url:"..."}], sin importar si el panel todavia
' manda el formato viejo (arreglo de strings) o el nuevo (arreglo de
' objetos {variante,url}). Usado por LoginTask.brs y ConfirmUser.brs
' para que ambos entiendan cualquiera de los dos formatos igual.
'
' Con el formato viejo (solo strings) la variante se asigna por
' posicion (1,2,3...) -- es estable mientras el panel no reordene el
' arreglo, pero ya no cambia de identidad si el panel se actualiza al
' formato nuevo y ahi si trae una variante fija por servidor.
' ============================================================
function NormalizeServerList(raw as Object) as Object
    result = []
    if raw = invalid or type(raw) <> "roArray" then return result
    idx = 0
    for each entry in raw
        idx = idx + 1
        if type(entry) = "roAssociativeArray"
            if entry.url <> invalid and entry.url <> ""
                variante = idx.toStr()
                if entry.variante <> invalid and entry.variante.toStr() <> "" then variante = entry.variante.toStr()
                result.push({ variante: variante, url: entry.url })
            end if
        else if type(entry) = "roString" or type(entry) = "String"
            if entry <> "" then result.push({ variante: idx.toStr(), url: entry })
        end if
    end for
    return result
end function

' ─── Diagnóstico de reproducción (Movies) ──────────────────────────────────
' Guarda en m.global.movieDiag el detalle de cada intento de carga/reproduccion
' de una pelicula, para poder comparar por que unas abren y otras no.
sub resetMovieDiag(item as Object)
    d = {
        id: "", title: "", url: "", streamFormat: "",
        vodInfoUrl: "", vodInfoHttp: 0, vodInfoOk: false,
        playErrorCode: "", playErrorMsg: "", retryCount: 0
    }
    if item <> invalid
        if item.id <> invalid
            if type(item.id) = "roString" or type(item.id) = "String"
                d.id = item.id
            else
                d.id = item.id.toStr()
            end if
        end if
        if item.title <> invalid then d.title = item.title
        if item.url <> invalid then d.url = item.url
        if item.streamFormat <> invalid then d.streamFormat = item.streamFormat
    end if
    m.global.movieDiag = d
end sub

sub logMovieDiag(field as String, value as Dynamic)
    d = m.global.movieDiag
    if d = invalid then d = {}
    d[field] = value
    m.global.movieDiag = d
end sub

function movieDiagText() as String
    d = m.global.movieDiag
    if d = invalid then return "Sin datos de diagnostico para este contenido."
    txt = ""
    txt = txt + "Titulo: " + d.title + Chr(10)
    txt = txt + "ID: " + d.id + Chr(10)
    txt = txt + "URL stream: " + d.url + Chr(10)
    txt = txt + "Formato (container_extension): " + d.streamFormat + Chr(10)
    txt = txt + "get_vod_info HTTP: " + d.vodInfoHttp.toStr() + " (ok=" + d.vodInfoOk.toStr() + ")" + Chr(10)
    txt = txt + "Reintentos de reproduccion: " + d.retryCount.toStr() + Chr(10)
    if d.playErrorCode <> "" or d.playErrorMsg <> ""
        txt = txt + "Error player: [" + d.playErrorCode + "] " + d.playErrorMsg
    end if
    return txt
end function

function requestData(url, timeoutMs = 10000 as Integer)
    http = createObject("roUrlTransfer")
    http.AddHeader("User-Agent", "Mozilla/5.0")
    http.RetainBodyOnError(true)
    port = createObject("roMessagePort")
    http.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    http.setPort(port)

    ' Check HTTPS vs HTTP
    if Instr(1, url, "https://") > 0 then
        http.setCertificatesFile("common:/certs/ca-bundle.crt")
        http.InitClientCertificates()
        http.enablehostverification(false)
        http.enablepeerverification(false)
    end if

    http.setUrl(url)

    if http.AsyncGetToString() Then
        msg = wait(timeoutMs, port)
        if (type(msg) = "roUrlEvent")
            if (msg.getresponsecode() > 0 and msg.getresponsecode() < 400)
                return msg.getstring()
            else
                print "HTTP error: "; msg.getresponsecode(); " "; url
            end if
        else
            print "HTTP timeout: "; url
            http.asynccancel()
        end if
    end if
    return ""
end function


function convertTimestampToYyyyMmDd(timestamp As String) As Object
  '"HORA ";timestamp
  date = CreateObject("roDatetime")
  date.fromSeconds(timestamp)
  return date.ToISOString().split("T")[0]
end function

' ============================================================
' Valida que un string tenga forma de color Roku (0xRRGGBB[AA])
' Si no es valido, devuelve el color por defecto (fallback)
' ============================================================
Function SafeColor(value As Dynamic, fallback As String) As String
    if value = invalid then return fallback
    if type(value) <> "String" then return fallback
    if Left(value, 2) <> "0x" then return fallback
    ' 0x + RRGGBB (8) o 0x + RRGGBBAA (10)
    if Len(value) <> 8 and Len(value) <> 10 then return fallback
    return value
End Function

' ============================================================
' Throttle compartido para las sincronizaciones periodicas
' (favoritos, recien vistas, ajustes, progreso). En vez de
' sincronizar en CADA carga de pantalla, solo lo hace si ya
' pasaron al menos 2 horas desde el ultimo intento -- asi se
' sigue enterando de cambios de otros dispositivos, pero sin
' pegarle al servidor constantemente.
'
' storeKey: nombre corto que identifica que se esta sincronizando
'           (ej. "fav-ms", "recientes", "ajustes", "progreso").
' usuario:  usuario actual, para que cada cuenta tenga su propio
'           reloj (por si el dispositivo cambia de usuario).
'
' Devuelve true si ya toca sincronizar (y de una vez marca "ahora"
' como el ultimo intento, para no repetir aunque la llamada tarde).
' Devuelve false si todavia no pasan las 2 horas -- el llamador
' debe saltarse la sincronizacion por completo en ese caso.
' ============================================================
Function SyncThrottle_ShouldRunNow(storeKey as String, usuario as String) as Boolean
    SYNC_INTERVAL_SECONDS = 7200 ' 2 horas
    sec = CreateObject("roRegistrySection", "SyncThrottle")
    key = storeKey + "-" + usuario
    raw = sec.Read(key)
    now = CreateObject("roDateTime").AsSeconds()
    if raw <> invalid and raw <> ""
        lastRun = raw.toInt()
        if (now - lastRun) < SYNC_INTERVAL_SECONDS then return false
    end if
    sec.Write(key, now.toStr())
    sec.Flush()
    return true
End Function

' Fuerza a que la proxima llamada a SyncThrottle_ShouldRunNow() para
' esta combinacion storeKey/usuario corra de inmediato, sin esperar
' las 2 horas. Util si algo fallo y se quiere reintentar ya.
Sub SyncThrottle_Reset(storeKey as String, usuario as String)
    sec = CreateObject("roRegistrySection", "SyncThrottle")
    sec.Delete(storeKey + "-" + usuario)
    sec.Flush()
End Sub

' ============================================================
' Item de "Perfil" en la barra de menu superior -- COMPARTIDO por
' TODAS las pantallas (antes solo vivia en HomeScreen.brs). Mismo
' avatar+nombre en Home, Peliculas, Series, Television y Buscar, para
' que se vea igual "en todas las secciones, no solo en home" (pedido
' explicito). Cada pantalla ya incluye generalUtils.brs, asi que estas
' funciones quedan disponibles ahi sin duplicar el codigo 5 veces.
' ============================================================

' Rellena el avatar (color+inicial) y el nombre del item de "Perfil"
' con el perfil actual (m.global.profileNombre/profileColor -- los
' mismos campos que ya usa HomeScreen.brs).
Sub GU_FillProfileNavItem(bgNode as Object, initialNode as Object, labelNode as Object)
    nombre = ""
    if m.global.profileNombre <> invalid then nombre = m.global.profileNombre.toStr()
    if nombre = "" then nombre = "Perfil"

    if labelNode <> invalid then labelNode.text = nombre
    if initialNode <> invalid then initialNode.text = UCase(Left(nombre, 1))

    color = "0x00A8FFFF"
    if m.global.profileColor <> invalid and m.global.profileColor.toStr() <> "" then color = m.global.profileColor.toStr()
    if bgNode <> invalid then bgNode.color = color
End Sub

' Dialogo de "¿Deseas cambiar de perfil?" al seleccionar el item de
' Perfil desde CUALQUIER pantalla. Si el usuario dice que si, se le
' pone a "targetNode" (siempre m.top de quien llama) el valor que le
' toca a ESA pantalla en su propio campo menuItemSelected para que
' MainScene.brs la cierre y abra el selector de perfiles -- en todas
' las pantallas menos Home eso es -2 (misma señal que ya usa
' SettingsScreen.brs para "Cambiar de Perfil" desde su menu, ver
' MainScene.brs/onSubScreenMenuSelected); Home tiene su propio flujo
' aparte (ver HomeScreen.brs/onProfileNavSelected) y no usa esto.
Sub GU_ShowChangeProfileDialog(targetNode as Object, selectedValue as Integer)
    nombre = ""
    if m.global.profileNombre <> invalid then nombre = m.global.profileNombre.toStr()

    dialog = createObject("roSGNode", "Dialog")
    dialog.title = "Cambiar de perfil"
    if nombre <> ""
        dialog.message = "Hola " + nombre + ", ¿deseas cambiar de perfil?"
    else
        dialog.message = "¿Deseas cambiar de perfil?"
    end if
    dialog.buttons = ["Si", "No"]

    scene = targetNode.getScene()
    if scene = invalid then return
    m.guProfileDialogTarget = targetNode
    m.guProfileDialogValue = selectedValue
    scene.dialog = dialog
    dialog.observeField("buttonSelected", "GU_OnChangeProfileRespuesta")
End Sub

Sub GU_OnChangeProfileRespuesta()
    if m.guProfileDialogTarget = invalid then return
    scene = m.guProfileDialogTarget.getScene()
    if scene = invalid then return
    dialog = scene.dialog
    if dialog = invalid then return

    seleccion = dialog.buttonSelected
    dialog.close = true
    scene.dialog = invalid

    if seleccion = 0
        m.guProfileDialogTarget.menuItemSelected = m.guProfileDialogValue
    end if
End Sub


