sub init()
    m.top.setFocus(true)
    m.pinTitle   = m.top.findNode("pinTitle")
    m.pinMessage = m.top.findNode("pinMessage")
    m.dimRect    = m.top.findNode("dimRect")

    ' Color de oscurecimiento = mismo color de marca que ya viene del
    ' servidor (m.global.focusColor, el mismo que usa el resto de la
    ' app para acentos). Mismo fallback que usan las demas pantallas.
    dc = m.global.focusColor
    if dc = invalid or dc = "" then dc = "0x00A8FFFF"
    if m.dimRect <> invalid then m.dimRect.color = dc

    m.dots = []
    m.dots.push(m.top.findNode("dot0"))
    m.dots.push(m.top.findNode("dot1"))
    m.dots.push(m.top.findNode("dot2"))
    m.dots.push(m.top.findNode("dot3"))

    m.top.observeField("title",   "onTitleChanged")
    m.top.observeField("message", "onMessageChanged")
    m.top.observeField("pin",     "onPinChanged")

    m.keyBgs = []
    m.digits = []
    keyOrder = ["1","2","3","4","5","6","7","8","9","Del","0","Ok"]
    for each k in keyOrder
        bg = m.top.findNode("key" + k + "Bg")
        if bg <> invalid then
            m.keyBgs.push(bg)
            m.digits.push(k)
        end if
    end for

    m.focusIdx = 0
    m.entered  = ""
    updateFocus()
    updateDots()
end sub

sub onTitleChanged()
    if m.pinTitle <> invalid then
        m.pinTitle.text = m.top.title
    end if
end sub

sub onMessageChanged()
    if m.pinMessage <> invalid then
        m.pinMessage.text = m.top.message
    end if
end sub

sub onPinChanged()
    if m.top.pin = "" then
        m.entered = ""
        updateDots()
    end if
end sub

sub updateDots()
    n = Len(m.entered)
    for i = 0 to 3
        if m.dots[i] <> invalid then
            if i < n then
                m.dots[i].color = "0x00A8FFFF"
            else
                m.dots[i].color = "0x444444FF"
            end if
        end if
    end for
end sub

sub updateFocus()
    for i = 0 to m.keyBgs.count() - 1
        if m.keyBgs[i] <> invalid then
            if i = m.focusIdx then
                m.keyBgs[i].color = "0xFFFFFFFF"
            else
                lbl = m.digits[i]
                if lbl = "Del" then
                    m.keyBgs[i].color = "0x555555FF"
                else if lbl = "Ok" then
                    m.keyBgs[i].color = "0x8B0000FF"
                else
                    m.keyBgs[i].color = "0x333333FF"
                end if
            end if
        end if
    end for
end sub

sub pressKey(k as String)
    if k = "Del" then
        if Len(m.entered) > 0 then
            m.entered = Left(m.entered, Len(m.entered) - 1)
            updateDots()
        end if
    else if k = "Ok" then
        if Len(m.entered) = 4 then
            m.top.pin = m.entered
        end if
    else
        if Len(m.entered) < 4 then
            m.entered = m.entered + k
            updateDots()
            if Len(m.entered) = 4 then
                m.top.pin = m.entered
            end if
        end if
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    cols   = 3
    row    = Int(m.focusIdx / cols)
    col    = m.focusIdx mod cols
    maxIdx = m.keyBgs.count() - 1

    if key = "right" then
        if col < cols - 1 then
            m.focusIdx = m.focusIdx + 1
            updateFocus()
        end if
        return true
    else if key = "left" then
        if col > 0 then
            m.focusIdx = m.focusIdx - 1
            updateFocus()
        end if
        return true
    else if key = "down" then
        newIdx = m.focusIdx + cols
        if newIdx <= maxIdx then
            m.focusIdx = newIdx
            updateFocus()
        end if
        return true
    else if key = "up" then
        newIdx = m.focusIdx - cols
        if newIdx >= 0 then
            m.focusIdx = newIdx
            updateFocus()
        end if
        return true
    else if key = "OK" then
        pressKey(m.digits[m.focusIdx])
        return true
    else if key = "back" then
        m.top.closed = true
        return true
    end if

    return false
end function
