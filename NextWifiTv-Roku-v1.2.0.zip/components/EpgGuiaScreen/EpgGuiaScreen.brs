' EpgGuiaScreen - Live TV Netflix style con Zapping y control de interfaz

function init()
    m.loading = m.top.findNode("Loading")
    ' Cert: una sola vez por instancia se dispara EPGLaunchComplete
    ' (ver onContentLoaded, cuando la guia queda navegable).
    m.epgLaunchBeaconFired = false
    m.guideUI = m.top.findNode("guideUI")
    m.catLabel = m.top.findNode("catLabel")
    m.lblDate = m.top.findNode("lblDate")
    m.lblTime = m.top.findNode("lblTime")
    m.focusTrap = m.top.findNode("focusTrap")

    ' Load nav logo
    logoImage = m.top.findNode("logoImage")
    if logoImage <> invalid
        dt = CreateObject("roDateTime").AsSeconds().ToStr()
        logoImage.uri = m.global.panelURL + "/img/logo.png?ts=" + dt
    end if

    m.CategoryList = m.top.findNode("CategoryList")
    m.ChannelList = m.top.findNode("ChannelList")

    ' Bandera de foco REAL de ChannelList (cada fila la observa para saber
    ' si debe verse "activa" o "atenuada"), SIN tocar jamas la opacidad
    ' del contenedor/fondo de la lista -- esa opacidad (0.60, fija en el
    ' XML) le da su transparencia constante al fondo gris y nunca se toca.
    if not m.global.hasField("epgChannelsRealFocus")
        m.global.addFields({epgChannelsRealFocus: true})
    end if

    ' Search nodes
    m.searchKeyboard = m.top.findNode("searchKeyboard")
    m.searchLoading  = m.top.findNode("searchLoading")
    m.isSearchMode   = false
    m.allChannels    = invalid

    ' Favoritos (canales)
    m.favLoading        = m.top.findNode("favLoading")
    m.noFavoritesLabel  = m.top.findNode("noFavoritesLabel")
    m.isFavoritesMode   = false
    m.pendingAllChannelsFor = ""
    m.favoriteIds = {}
    m.favTasks = []

    m.videoContainer = m.top.findNode("videoContainer")
    m.Video = m.top.findNode("VideoPlayer")
    m.VideoLoading = m.top.findNode("VideoLoading")

    m.nowChIcon = m.top.findNode("nowChIcon")
    m.nowChName = m.top.findNode("nowChName")
    m.nowEpgTitle = m.top.findNode("nowEpgTitle")
    m.nowEpgTime = m.top.findNode("nowEpgTime")
    m.nextEpgTitle = m.top.findNode("nextEpgTitle")
    m.nextEpgTime = m.top.findNode("nextEpgTime")

    m.infoOverlay = m.top.findNode("infoOverlay")
    m.infoChName = m.top.findNode("infoChName")
    m.infoChNameCopy = m.top.findNode("infoChNameCopy")
    m.chNameTrack = m.top.findNode("chNameTrack")
    m.chNameScrollAnim = m.top.findNode("chNameScrollAnim")
    m.chNameScrollInterp = m.top.findNode("chNameScrollInterp")
    m.infoDateFull = m.top.findNode("infoDateFull")
    m.infoTimeFull = m.top.findNode("infoTimeFull")
    m.infoEpgTime = m.top.findNode("infoEpgTime")
    m.infoEpgNow = m.top.findNode("infoEpgNow")
    m.infoEpgLater = m.top.findNode("infoEpgLater")
    m.infoChPoster = m.top.findNode("infoChPoster")

    m.clock = m.top.findNode("clock")
    m.infoTimer = m.top.findNode("infoTimer")
    m.focusTrap = m.top.findNode("focusTrap")

    m.clock.observeField("fire", "updateTime")
    m.infoTimer.observeField("fire", "hideInfo")
    m.CategoryList.observeField("itemSelected", "onCatSelected")
    ' NOTA: se quitó el observeField("itemSelected", "onChannelSelected") de
    ' ChannelList -- el OK del remoto no lo consume el MarkupList, asi que
    ' tambien burbujeaba hasta onKeyEvent (focusArea="channels"), y ahi se
    ' volvia a llamar playChannel() + goFullscreen(). Eso causaba que el
    ' video se recargara DOS veces por cada seleccion (efecto "dos pantallas").
    ' onKeyEvent ya cubre el flujo completo (play + fullscreen), asi que
    ' onChannelSelected() se queda sin usar (se deja el sub por si se
    ' necesita reactivar, pero ya no esta conectado).
    m.Video.observeField("state", "onVideoState")
    m.searchKeyboard.observeField("confirmed", "onSearchConfirmed")
    m.searchKeyboard.observeField("goUp", "onSearchGoUp")

    m.channelCount = 0
    m.currentChannel = -1
    m.videocontent = invalid
    m.isFullscreen = false
    m.focusArea = "channels"
    m.lastCatIndex = 0
    m.top.boxFlag = false
    m.pendingCatId    = ""
    m.pendingCatTitle = ""
    m.livePinDlg = invalid
    m.livePinWrongDlg = invalid
    m.catSelectedNatively = false
    m.lastPlayingNode = invalid
    m.lastActiveCatNode = invalid

    m.epgLoaded = {}
    m.epgBatchBusy = false
    m.epgGeneration = 0
    m.epgNextStart = 0
    m.retryCount = 0
    m.retryTimer = m.top.findNode("retryTimer")
    m.retryTimer.observeField("fire", "retryPlay")

    ' Deteccion de canal congelado: el estado del reproductor se queda
    ' en "playing" aunque el stream se trabe (no llegan cuadros
    ' nuevos), asi que hay que vigilar la posicion aparte -- ver
    ' checkFrozenVideo().
    m.lastVideoPosition = -1
    m.freezeStrikes = 0
    m.freezeCheckTimer = m.top.findNode("freezeCheckTimer")
    m.freezeCheckTimer.observeField("fire", "checkFrozenVideo")

    m.clock.control = "start"
    updateTime()
    requestContent("", "")
    loadFavoriteIds()

    ' Nav bar init
    m.epgNavBgs    = []
    m.epgNavLabels = []
    m.totalNavItems = 7
    for i = 0 to m.totalNavItems - 1
        m.epgNavBgs.push(m.top.findNode("epgNavBg" + i.toStr()))
        m.epgNavLabels.push(m.top.findNode("epgNavLabel" + i.toStr()))
    end for
    m.navFocusedIndex = -1
    m.profileAvatarBg      = m.top.findNode("profileAvatarBg")
    m.profileAvatarInitial = m.top.findNode("profileAvatarInitial")
    GU_FillProfileNavItem(m.profileAvatarBg, m.profileAvatarInitial, m.epgNavLabels[6])
    m.currentNavIndex = 4  ' LiveTV = 4
    m.inNav = false
    m.navInitTimer = m.top.findNode("navInitTimer")
    m.navInitTimer.observeField("fire", "onNavInitTimer")
    m.navInitTimer.control = "start"

    m.videoBorder   = m.top.findNode("videoBorder")
    m.topNavOverlay = m.top.findNode("topNavOverlay")

    ' --- Color de marca (focusColor del config.json) ---
    m.sidebarTitle = m.top.findNode("sidebarTitle")
    m.lblAhora     = m.top.findNode("lblAhora")
    m.nowBar       = m.top.findNode("nowBar")
    m.nowIcon      = m.top.findNode("nowIcon")
    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")
end function

' ============================================================
' Aplica el focusColor del config remoto a todos los acentos
' rojos de esta pantalla. Se llama al iniciar y cada vez que
' m.global.focusColor cambia (por si el config llega tarde).
' ============================================================
sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0x00A8FFFF"

    if m.sidebarTitle <> invalid then m.sidebarTitle.color = fc
    if m.lblAhora <> invalid then m.lblAhora.color = fc
    if m.nowBar <> invalid then m.nowBar.color = fc
    if m.nowIcon <> invalid then m.nowIcon.color = fc

    ' Re-pinta el tab activo del nav si ya estaba resaltado
    if m.epgNavBgs <> invalid and m.currentNavIndex <> invalid
        epgNavHighlight(m.navFocusedIndex)
    end if
end sub

sub onNavInitTimer()
    epgShowScreenNav()
end sub

' ============== EPOCH TO TIME STRING ==============
function epochToTimeStr(epoch as Dynamic) as String
    if epoch = invalid then return ""
    ts = 0
    if type(epoch) = "roString" or type(epoch) = "String" then
        ts = val(epoch)
    else if type(epoch) = "roInteger" or type(epoch) = "Integer" or type(epoch) = "roFloat" or type(epoch) = "Float" or type(epoch) = "Double" then
        ts = epoch
    end if
    if ts = 0 then return ""
    if ts > 1000000000 then
        d = createObject("roDateTime")
        d.FromSeconds(int(ts))
        d.ToLocalTime()
        hr = d.getHours()
        mn = d.getMinutes()
        ms = istr(mn)
        if mn < 10 then ms = "0" + ms
        ap = "AM"
        if hr = 0 then
            h = "12"
        else if hr = 12 then
            h = "12" : ap = "PM"
        else if hr > 12 then
            h = istr(hr - 12) : ap = "PM"
        else
            h = istr(hr)
        end if
        return h + ":" + ms + " " + ap
    end if
    return istr(int(ts))
end function

' ============== FORMAT TIME RANGE ==============
function formatTimeRange(startVal as Dynamic, endVal as Dynamic) as String
    s = ""
    e = ""
    if startVal <> invalid then
        if type(startVal) = "roString" or type(startVal) = "String" then
            if instr(1, startVal, ":") > 0 then s = startVal else s = epochToTimeStr(startVal)
        else
            s = epochToTimeStr(startVal)
        end if
    end if
    if endVal <> invalid then
        if type(endVal) = "roString" or type(endVal) = "String" then
            if instr(1, endVal, ":") > 0 then e = endVal else e = epochToTimeStr(endVal)
        else
            e = epochToTimeStr(endVal)
        end if
    end if
    if s <> "" and e <> "" then return s + " - " + e
    if s <> "" then return s
    return e
end function

sub updateTime()
    d = createObject("roDateTime")
    d.ToLocalTime()

    mn = d.getMinutes()
    ms = istr(mn)
    if mn < 10 then ms = "0" + ms

    hr = d.getHours()
    h = ""
    ap = ""

    if hr = 0 then
        h = "12"
        ap = "AM"
    else if hr > 12 then
        h = istr(hr - 12)
        ap = "PM"
    else if hr = 12 then
        h = "12"
        ap = "PM"
    else
        h = istr(hr)
        ap = "AM"
    end if

    if m.lblTime <> invalid then
        m.lblTime.text = h + ":" + ms + " " + ap
    end if
end sub

sub requestContent(cat as String, title as String)
    m.epgGeneration = m.epgGeneration + 1
    m.epgBatchBusy = false
    m.epgLoaded = {}
    m.epgNextStart = 0
    m.loading.control = "start"

    ' Si ya habia una tarea de una categoria anterior corriendo (el
    ' usuario cambio de categoria antes de que terminara), se cancela
    ' primero. Sin esto la tarea vieja seguia corriendo en segundo
    ' plano compitiendo por red/CPU con la nueva -- y encima, si
    ' terminaba tarde, disparaba "contentSet" de todos modos y
    ' onContentLoaded la procesaba como si fuera la categoria actual,
    ' dejando la lista vacia o con datos de otra categoria.
    if m.task <> invalid
        m.task.unobserveField("contentSet")
        m.task.control = "stop"
    end if

    ' roSGNode no se puede comparar entre si con "=" / "<>" (solo
    ' contra invalid) -- comparar dos nodos directamente truena con
    ' "Type Mismatch". Se usa un numero de generacion en su lugar: se
    ' guarda en la tarea misma (genId) y se compara ese numero.
    if m.taskGen = invalid then m.taskGen = 0
    m.taskGen = m.taskGen + 1
    m.currentTaskGen = m.taskGen

    m.task = CreateObject("roSGNode", "EpgGetContent")
    m.task.genId = m.taskGen
    m.task.observeField("contentSet", "onContentLoaded")
    m.task.cat = cat
    m.task.title = title
    m.task.control = "RUN"
end sub

sub onContentLoaded(event as Object)
    ' Si esta tarea ya no es la actual (el usuario volvio a cambiar de
    ' categoria mientras esta corria), se ignora su resultado -- ya se
    ' mando "stop" en requestContent, pero una tarea que ya estaba a
    ' mitad de una peticion de red puede tardar en notar el stop y
    ' disparar este evento de todos modos.
    triggeringTask = event.GetRoSGNode()
    if triggeringTask = invalid or triggeringTask.genId <> m.currentTaskGen then return

    m.loading.control = "stop"
    if m.task = invalid then return

    if m.task.categoriesNode <> invalid then
        searchCat = createObject("roSGNode", "ContentNode")
        searchCat.id    = "__search__"
        searchCat.title = "Buscar"
        m.task.categoriesNode.insertChild(searchCat, 0)

        favCat = createObject("roSGNode", "ContentNode")
        favCat.id    = "__favorites__"
        favCat.title = "★ Favoritos"
        m.task.categoriesNode.insertChild(favCat, 1)

        m.CategoryList.content = m.task.categoriesNode
    end if

    if m.task.itemsNode <> invalid then
        applyFavoriteFlags(m.task.itemsNode)
        m.ChannelList.content = m.task.itemsNode
    end if

    cc = 0
    if m.ChannelList.content <> invalid then cc = m.ChannelList.content.getChildCount()
    m.channelCount = 0
    if cc > 0 then m.channelCount = cc - 1

    if m.catLabel <> invalid and m.task.title <> invalid and m.task.title <> "" then
        m.catLabel.text = m.task.title
    end if

    ' Busca el ultimo canal reproducido (guardado en playChannel()) dentro
    ' de la categoria recien cargada. Si esta ahi, se abre ese en vez de
    ' siempre el primero. Si no aparece (categoria distinta a la de la
    ' ultima vez, o primera vez que se abre la app), se usa 0 como antes.
    startIdx = 0
    lastChId = RegRead(m.global.catGet, "LastChannelID")
    if lastChId <> invalid and lastChId <> "" and m.ChannelList.content <> invalid
        for i = 0 to m.ChannelList.content.getChildCount() - 1
            chNd = m.ChannelList.content.getChild(i)
            if chNd <> invalid and chNd.id = lastChId
                startIdx = i
                exit for
            end if
        end for
    end if

    m.top.channel = startIdx
    m.ChannelList.jumpToItem = startIdx
    catIdx = findCatIdx(m.task.cat)
    m.CategoryList.jumpToItem = catIdx
    m.lastCatIndex = catIdx
    if m.CategoryList.content <> invalid
        catNd = m.CategoryList.content.getChild(catIdx)
        if catNd <> invalid then markActiveCategory(catNd)
    end if
    m.focusArea = "channels"
    m.global.epgChannelsRealFocus = true
    m.ChannelList.setFocus(true)
    m.top.boxFlag = false
    m.epgLoaded = {}
    m.epgBatchBusy = false
    m.epgNextStart = 0
    launchBatch()

    if m.channelCount >= 0 and m.ChannelList.content <> invalid then
        nd = m.ChannelList.content.getChild(startIdx)
        if nd <> invalid then
            m.videocontent = nd
            playChannel()
        end if
    end if
end sub

function findCatIdx(catId as Dynamic) as Integer
    ' idx 0 = Buscar, idx 1 = Favoritos, idx 2 = primera categoria real
    if catId = invalid or catId = "" then return 2
    if m.CategoryList.content = invalid then return 2
    for i = 0 to m.CategoryList.content.getChildCount() - 1
        c = m.CategoryList.content.getChild(i)
        if c <> invalid and c.id = catId then return i
    end for
    return 2
end function

' ============== FAVORITOS (CANALES) ==============

sub loadFavoriteIds()
    m.favIdsTask = createObject("roSGNode", "ChannelFavoritesTask")
    m.favIdsTask.favAction = "list"
    m.favIdsTask.observeField("doneFlag", "onFavIdsLoaded")
    m.favIdsTask.control = "RUN"
end sub

sub onFavIdsLoaded()
    if m.favIdsTask = invalid then return
    ids = m.favIdsTask.favIds
    if ids = invalid or type(ids) <> "roAssociativeArray" then ids = {}
    m.favoriteIds = ids

    if m.ChannelList.content <> invalid then applyFavoriteFlags(m.ChannelList.content)
    if m.allChannels <> invalid then applyFavoriteFlags(m.allChannels)
end sub

sub applyFavoriteFlags(node as Object)
    if node = invalid then return
    if m.favoriteIds = invalid then return
    for i = 0 to node.getChildCount() - 1
        ch = node.getChild(i)
        if ch <> invalid and ch.id <> invalid and ch.id <> ""
            if not ch.hasField("isFavorite") then ch.addFields({isFavorite: false})
            ch.isFavorite = m.favoriteIds.doesExist(ch.id)
        end if
    end for
end sub

' Lista de ids de categoria "reales" (excluye Buscar/Favoritos),
' usada para pedir el catalogo completo de canales. Extraida como
' funcion auxiliar porque la necesitan 2 flujos distintos ahora
' (sembrado inicial y resolucion de altas nuevas por sync).
function collectCatIds() as Object
    catIds = []
    if m.CategoryList.content <> invalid
        for i = 0 to m.CategoryList.content.getChildCount() - 1
            c = m.CategoryList.content.getChild(i)
            if c <> invalid and c.id <> "__search__" and c.id <> "__favorites__" and c.id <> "" then
                catIds.push(c.id)
            end if
        end for
    end if
    return catIds
end function

sub enterFavoritesMode()
    m.isFavoritesMode = true

    if m.CategoryList.content <> invalid
        favNd = m.CategoryList.content.getChild(1) ' "__favorites__" siempre en idx 1
        if favNd <> invalid then markActiveCategory(favNd)
    end if

    ' --- LOCAL PRIMERO ---
    ' Si ya tenemos canales favoritos con datos COMPLETOS (titulo,
    ' icono, url) guardados localmente, los mostramos directo: CERO
    ' llamadas de red, ni siquiera la lista corta de ids, y mucho
    ' menos el catalogo completo de canales de todas las categorias.
    locChannels = Fav_LocalListByType("canal")
    if locChannels.count() > 0
        ' Se muestra YA, de inmediato, sin esperar nada de red -- antes
        ' se esperaba a que terminara la revision rapida del servidor
        ' para recien ahi pintar la pantalla, lo cual se sentia como
        ' "recargar todo" cada vez que volvias a esta pantalla (que se
        ' crea de cero en cada visita), aunque no hubiera ningun
        ' cambio real que traer.
        renderFavoriteChannelsFromLocal(locChannels)

        ' --- SYNC LIGERO: revisar si cambio algo desde otro dispositivo ---
        ' La llamada de red va DENTRO de ChannelFavoritesTask (su propio
        ' hilo) -- crear roUrlTransfer aqui directo (render thread de
        ' esta Scene) no es valido en Roku y hace crashear la app. Si
        ' encuentra cambios, actualiza la pantalla otra vez en
        ' silencio (ver onChannelDeltaReady); si no encuentra nada, no
        ' hace falta tocar nada mas, ya se ve correcto desde ya.
        m.favDeltaTask = createObject("roSGNode", "ChannelFavoritesTask")
        m.favDeltaTask.favAction = "delta"
        m.favDeltaTask.observeField("doneFlag", "onChannelDeltaReady")
        m.favDeltaTask.control = "RUN"
        return
    end if

    ' --- LOCAL VACIO ---
    ' Unica vez que hace falta ir al servidor. Para poder cachear el
    ' objeto COMPLETO de cada favorito (no solo el id) necesitamos
    ' cruzarlos contra el catalogo completo de canales (es la unica
    ' fuente que trae titulo/icono/url por canal). Una vez sembrado el
    ' local aqui, esto no se vuelve a repetir -- ni en esta sesion ni
    ' en las futuras, porque el local vive en el registro del Roku.
    print "DEBUG enterFavoritesMode - local vacio, sembrando (unica vez)"
    if m.favLoading <> invalid then m.favLoading.visible = true
    m.pendingAllChannelsFor = "favorites"

    ' Antes, aqui mismo se arrancaba YA el catalogo completo de canales
    ' (EpgGetContent, "__all__") EN PARALELO a pedir la lista de ids --
    ' eso significaba una peticion HTTP POR CADA CATEGORIA de television
    ' del proveedor, sin importar cuantos favoritos hubiera (aunque
    ' fuera uno solo), y era lo que hacia esta pantalla sentirse muy
    ' lenta con proveedores de muchas categorias. Ahora esa descarga
    ' completa SOLO se arranca como ultimo recurso, dentro de
    ' onFavIdsReloadedForFavMode, y unicamente si resolver.php no esta
    ' configurado en el panel -- igual que ya se hacia para resolver
    ' altas nuevas detectadas por sync (ver onChannelDeltaReady).
    m.favReloadTask = createObject("roSGNode", "ChannelFavoritesTask")
    m.favReloadTask.favAction = "list"
    m.favReloadTask.observeField("doneFlag", "onFavIdsReloadedForFavMode")
    m.favReloadTask.control = "RUN"
end sub

' Se dispara cuando ChannelFavoritesTask (favAction="delta") termina.
' Aplica los borrados directo (barato) y, si hay altas nuevas, pide el
' catalogo completo para resolverlas (unica llamada "cara" posible
' aqui, y solo si de verdad hace falta).
sub onChannelDeltaReady()
    if m.favDeltaTask = invalid then return
    added = m.favDeltaTask.deltaAdded
    removed = m.favDeltaTask.deltaRemoved
    if added = invalid then added = []
    if removed = invalid then removed = []

    for each chId in removed
        Fav_LocalDelete("canal", chId)
    end for

    if added.count() = 0 and Fav_ChannelPendingList().count() = 0
        locChannels = Fav_LocalListByType("canal")
        print "DEBUG enterFavoritesMode - servido desde LOCAL (sync al dia), total = "; locChannels.count()
        renderFavoriteChannelsFromLocal(locChannels)
        return
    end if

    ' Se registran los nuevos como pendientes (si ya estaban, no se
    ' reinicia su contador de fallos) y se reintentan junto con
    ' cualquier pendiente de sincronizaciones anteriores que aun no
    ' haya llegado al limite de 3 intentos.
    for each chId in added
        Fav_ChannelPendingAdd(chId)
    end for
    pending = Fav_ChannelPendingList()

    print "DEBUG enterFavoritesMode - "; pending.count(); " canal(es) pendiente(s) por resolver contra catalogo"
    if m.favLoading <> invalid then m.favLoading.visible = true
    m.pendingNewFavoriteChannelIds = pending

    ' Ruta rapida: resolver.php resuelve TODOS los pendientes en una
    ' sola peticion. Si todavia no esta configurado en el panel, cae
    ' al metodo viejo mas abajo (bajar el catalogo completo categoria
    ' por categoria, mucho mas lento con proveedores de muchas
    ' categorias).
    if Fav_ResolverApiBase() <> ""
        if m.channelResolveGen = invalid then m.channelResolveGen = 0
        m.channelResolveGen = m.channelResolveGen + 1
        m.currentChannelResolveGen = m.channelResolveGen

        m.channelResolveTask = createObject("roSGNode", "SearchChannelsTask")
        m.channelResolveTask.genId = m.channelResolveGen
        m.channelResolveTask.ids = pending
        m.channelResolveTask.observeField("searchDone", "onChannelIdsResolved")
        m.channelResolveTask.control = "RUN"
        return
    end if

    if m.allChannels <> invalid
        resolveAndMergeNewFavoriteChannels()
        return
    end if

    catIds = collectCatIds()
    if catIds.count() = 0
        if m.favLoading <> invalid then m.favLoading.visible = false
        ' No se pudo pedir el catalogo; al menos mostramos lo que ya
        ' hay local (los borrados de sync ya se aplicaron arriba).
        renderFavoriteChannelsFromLocal(Fav_LocalListByType("canal"))
        return
    end if

    m.searchLoadTask = createObject("roSGNode", "EpgGetContent")
    m.searchLoadTask.cat = "__all__"
    m.searchLoadTask.catList = catIds
    m.searchLoadTask.observeField("contentSet", "onAllChannelsLoadedForNewFavorites")
    m.searchLoadTask.control = "RUN"
end sub

' Se dispara cuando SearchChannelsTask (modo ids) termina de resolver
' los favoritos de canal pendientes -- ruta rapida via resolver.php,
' UNA sola peticion en vez de bajar el catalogo completo categoria por
' categoria (ver resolveAndMergeNewFavoriteChannels, que hace lo mismo
' pero a partir del catalogo completo, como respaldo si resolver.php
' no esta configurado).
sub onChannelIdsResolved(event as Object)
    triggeringTask = event.GetRoSGNode()
    if triggeringTask = invalid or triggeringTask.genId <> m.currentChannelResolveGen then return

    if m.favLoading <> invalid then m.favLoading.visible = false
    if m.pendingNewFavoriteChannelIds = invalid then return

    pendingMap = {}
    for each chId in m.pendingNewFavoriteChannelIds
        pendingMap[chId] = true
    end for

    resultsNode = triggeringTask.resultsNode
    if resultsNode <> invalid
        total = resultsNode.getChildCount()
        for i = 0 to total - 1
            ch = resultsNode.getChild(i)
            if ch <> invalid and ch.id <> invalid and pendingMap.doesExist(ch.id)
                aa = Fav_NodeToAA(ch, ["id", "title", "HDPosterUrl", "url", "ContentType"])
                Fav_LocalWrite("canal", ch.id, aa)
                Fav_ChannelPendingResolved(ch.id)
                pendingMap.delete(ch.id)
            end if
        end for
    end if

    ' Lo que quedo en pendingMap no aparecio ni en el catalogo completo
    ' del panel (bajado de una sola vez): se marca como intento
    ' fallido (con limite de 3, ver Fav_ChannelPendingFail).
    resolved = m.pendingNewFavoriteChannelIds.count() - pendingMap.count()
    for each chId in pendingMap
        Fav_ChannelPendingFail(chId)
    end for

    print "DEBUG onChannelIdsResolved - resueltos y agregados = "; resolved; " de "; m.pendingNewFavoriteChannelIds.count(); " pendientes (via resolver.php)"
    m.pendingNewFavoriteChannelIds = invalid

    locChannels = Fav_LocalListByType("canal")
    renderFavoriteChannelsFromLocal(locChannels)
end sub

' Resuelve SOLO los ids en m.pendingNewFavoriteChannelIds contra el
' catalogo completo (m.allChannels): a diferencia de
' seedAndShowFavoriteChannels() (que asume el local vacio y sustituye
' todo), esta SUMA los favoritos nuevos detectados por sync a los que
' ya habia local, sin tocar los existentes.
sub resolveAndMergeNewFavoriteChannels()
    if m.favLoading <> invalid then m.favLoading.visible = false
    if m.pendingNewFavoriteChannelIds = invalid or m.allChannels = invalid then return

    pendingMap = {}
    for each chId in m.pendingNewFavoriteChannelIds
        pendingMap[chId] = true
    end for

    total = m.allChannels.getChildCount()
    for i = 0 to total - 1
        ch = m.allChannels.getChild(i)
        if ch <> invalid and ch.id <> invalid and pendingMap.doesExist(ch.id)
            aa = Fav_NodeToAA(ch, ["id", "title", "HDPosterUrl", "url", "ContentType"])
            Fav_LocalWrite("canal", ch.id, aa)
            Fav_ChannelPendingResolved(ch.id)
            pendingMap.delete(ch.id)
        end if
    end for

    ' Lo que quedo en pendingMap no aparecio en el catalogo: se marca
    ' como intento fallido (con limite de 3, ver Fav_ChannelPendingFail).
    resolved = m.pendingNewFavoriteChannelIds.count() - pendingMap.count()
    for each chId in pendingMap
        Fav_ChannelPendingFail(chId)
    end for

    print "DEBUG resolveAndMergeNewFavoriteChannels - resueltos y agregados = "; resolved; " de "; m.pendingNewFavoriteChannelIds.count(); " pendientes"
    m.pendingNewFavoriteChannelIds = invalid

    locChannels = Fav_LocalListByType("canal")
    renderFavoriteChannelsFromLocal(locChannels)
end sub

' Se dispara cuando termina de cargar el catalogo completo, en el
' flujo de "resolver altas nuevas por sync" (paralelo al viejo
' onAllChannelsLoaded, que sigue intacto para el sembrado inicial).
sub onAllChannelsLoadedForNewFavorites()
    if m.searchLoadTask = invalid then return
    if m.searchLoadTask.itemsNode = invalid then return
    m.allChannels = m.searchLoadTask.itemsNode
    applyFavoriteFlags(m.allChannels)
    if m.isFavoritesMode then resolveAndMergeNewFavoriteChannels()
end sub

' Se dispara cuando termina la lista de favIds (rapida). Si el
' catalogo completo TAMBIEN esta listo ya (el otro pedazo async),
' sembramos+mostramos aqui; si no, lo hace onAllChannelsLoaded cuando
' termine (cualquiera de los dos que termine AL ULTIMO es quien pinta).
sub onFavIdsReloadedForFavMode()
    if m.favReloadTask = invalid then return
    ids = m.favReloadTask.favIds
    if ids = invalid or type(ids) <> "roAssociativeArray" then ids = {}
    m.favoriteIds = ids

    if m.allChannels <> invalid then applyFavoriteFlags(m.allChannels)
    if m.ChannelList.content <> invalid then applyFavoriteFlags(m.ChannelList.content)

    if not m.isFavoritesMode then return

    if m.allChannels <> invalid
        ' Ya tenemos el catalogo completo en memoria (de una busqueda
        ' previa en esta sesion) -- sembrar de ahi, sin red extra.
        seedAndShowFavoriteChannels()
        return
    end if

    ' --- Catalogo completo NO cargado todavia (caso normal, primera vez) ---
    idsArr = []
    for each k in ids
        idsArr.push(k)
    end for

    if idsArr.count() = 0
        ' Cuenta sin ningun canal favorito: nada que resolver, no hace
        ' falta pedir nada al servidor.
        m.pendingAllChannelsFor = ""
        if m.favLoading <> invalid then m.favLoading.visible = false
        renderFavoriteChannelsFromLocal([])
        return
    end if

    ' Ruta rapida (igual que onChannelDeltaReady): resolver.php resuelve
    ' TODOS los favoritos en una sola peticion, sin bajar el catalogo
    ' completo categoria por categoria. Si el panel todavia no lo tiene
    ' configurado, cae al metodo viejo mas abajo.
    if Fav_ResolverApiBase() <> ""
        m.pendingAllChannelsFor = ""
        m.pendingNewFavoriteChannelIds = idsArr
        if m.channelResolveGen = invalid then m.channelResolveGen = 0
        m.channelResolveGen = m.channelResolveGen + 1
        m.currentChannelResolveGen = m.channelResolveGen

        m.channelResolveTask = createObject("roSGNode", "SearchChannelsTask")
        m.channelResolveTask.genId = m.channelResolveGen
        m.channelResolveTask.ids = idsArr
        m.channelResolveTask.observeField("searchDone", "onChannelIdsResolved")
        m.channelResolveTask.control = "RUN"
        return
    end if

    ' --- Respaldo: resolver.php no configurado, metodo viejo (lento) ---
    catIds = collectCatIds()
    if catIds.count() = 0
        m.pendingAllChannelsFor = ""
        if m.favLoading <> invalid then m.favLoading.visible = false
        return
    end if

    m.searchLoadTask = createObject("roSGNode", "EpgGetContent")
    m.searchLoadTask.cat = "__all__"
    m.searchLoadTask.catList = catIds
    m.searchLoadTask.observeField("contentSet", "onAllChannelsLoaded")
    m.searchLoadTask.control = "RUN"
end sub

sub exitFavoritesMode()
    m.isFavoritesMode = false
    if m.favLoading <> invalid then m.favLoading.visible = false
    if m.noFavoritesLabel <> invalid then m.noFavoritesLabel.visible = false
    if m.task <> invalid and m.task.itemsNode <> invalid
        m.ChannelList.content = m.task.itemsNode
        cc = m.task.itemsNode.getChildCount()
        m.channelCount = 0
        if cc > 0 then m.channelCount = cc - 1
    end if
end sub

' Cruza m.favoriteIds contra el catalogo completo (m.allChannels),
' escribe el objeto COMPLETO de cada favorito en el local (para que
' esto no se vuelva a repetir nunca mas), y pinta la lista resultante.
' Se llama SOLO cuando ya tenemos favIds y catalogo completo listos.
sub seedAndShowFavoriteChannels()
    if m.favoriteIds = invalid or m.allChannels = invalid then return

    locChannels = []
    total = m.allChannels.getChildCount()
    for i = 0 to total - 1
        ch = m.allChannels.getChild(i)
        if ch <> invalid and ch.id <> invalid and m.favoriteIds.doesExist(ch.id)
            aa = Fav_NodeToAA(ch, ["id", "title", "HDPosterUrl", "url", "ContentType"])
            Fav_LocalWrite("canal", ch.id, aa)
            locChannels.push(aa)
        end if
    end for

    print "DEBUG seedAndShowFavoriteChannels - sembrados localmente = "; locChannels.count()
    renderFavoriteChannelsFromLocal(locChannels)
end sub

' Pinta el ChannelList a partir de objetos YA cacheados localmente
' (array de AAs, formato Fav_LocalListByType). No toca la red.
' Pinta el ChannelList con los canales favoritos (desde local, siempre).
' A PROPOSITO no mueve el foco a la lista de canales ni dispara el
' preview/playChannel: el usuario se queda viendo categorias + la
' lista de canales, y decide el cuando pasar a los canales (right/OK).
' Antes esto SI saltaba el foco automaticamente, lo cual causaba que
' un segundo OK (interpretado por el usuario como "reseleccionar
' Favoritos") en realidad cayera sobre el canal ya enfocado y lo
' mandara a pantalla completa sin querer.
sub renderFavoriteChannelsFromLocal(locChannels as Object)
    if m.favLoading <> invalid then m.favLoading.visible = false

    filtered = createObject("roSGNode", "ContentNode")
    for each aa in locChannels
        node = Fav_AAToNode(aa)
        if not node.hasField("shortdescriptionline1") then node.addFields({shortdescriptionline1: "", shortdescriptionline2: ""})
        if not node.hasField("isFavorite") then node.addFields({isFavorite: false})
        node.isFavorite = true
        filtered.appendChild(node)
    end for

    m.ChannelList.content = filtered
    fc = filtered.getChildCount()
    m.channelCount = 0
    if fc > 0 then m.channelCount = fc - 1
    if m.noFavoritesLabel <> invalid then m.noFavoritesLabel.visible = (fc = 0)
    print "DEBUG renderFavoriteChannelsFromLocal - pintado sin mover foco, total = "; fc
end sub

' Se usa cuando el usuario re-selecciona "Favoritos" estando YA parado
' en esa categoria (el fallback de onKeyEvent). Simplemente refresca
' los datos por si algo cambio (se agrego/quito un favorito desde otra
' pantalla) y repinta -- mismo comportamiento que renderFavoriteChannelsFromLocal.
sub refreshFavoriteChannelsInPlace()
    locChannels = Fav_LocalListByType("canal")

    if locChannels.count() = 0
        ' Nada guardado localmente todavia (caso raro aqui, ya deberia
        ' haber datos si llegamos a re-seleccionar Favoritos). Dejamos
        ' que el flujo normal se encargue de sembrar desde el servidor.
        enterFavoritesMode()
        return
    end if

    renderFavoriteChannelsFromLocal(locChannels)
end sub

sub toggleFavoriteFocused()
    print "DEBUG toggleFavoriteFocused - inicio"
    if m.ChannelList = invalid or m.ChannelList.content = invalid then
        print "DEBUG toggleFavoriteFocused - ChannelList o content invalido"
        return
    end if

    idx = m.ChannelList.itemFocused
    print "DEBUG toggleFavoriteFocused - idx foco = "; idx
    if idx = invalid or idx < 0 or idx >= m.ChannelList.content.getChildCount() then
        print "DEBUG toggleFavoriteFocused - idx fuera de rango"
        return
    end if

    nd = m.ChannelList.content.getChild(idx)
    if nd = invalid or nd.id = invalid or nd.id = "" then
        print "DEBUG toggleFavoriteFocused - nodo invalido o sin id"
        return
    end if

    chId = nd.id
    isFav = false
    if nd.hasField("isFavorite") then isFav = nd.isFavorite
    newState = not isFav
    print "DEBUG toggleFavoriteFocused - chId="; chId; " isFav actual="; isFav; " nuevoEstado="; newState

    ' Limite de 100 canales favoritos (mismo criterio que peliculas/
    ' series en AddFavorite.xml) -- si ya se llego al limite, no se
    ' agrega ninguno mas.
    if newState and Fav_LocalListByType("canal").Count() >= 100
        print "DEBUG toggleFavoriteFocused - limite de 100 canales favoritos alcanzado, no se agrega"
        return
    end if

    if m.favoriteIds = invalid then m.favoriteIds = {}
    if newState
        m.favoriteIds[chId] = true
    else
        m.favoriteIds.delete(chId)
    end if

    if m.favTasks = invalid then m.favTasks = []
    task = createObject("roSGNode", "ChannelFavoritesTask")
    if task = invalid then
        print "DEBUG toggleFavoriteFocused - ERROR: no se pudo crear ChannelFavoritesTask (componente no encontrado)"
        return
    end if
    task.cve = chId
    if newState
        task.favAction = "add"
        task.itemJson = FormatJSON(Fav_NodeToAA(nd, ["id", "title", "HDPosterUrl", "url", "ContentType"]))
    else
        task.favAction = "remove"
    end if
    m.favTasks.push(task) ' evita que el garbage collector lo destruya antes de terminar
    task.control = "RUN"
    print "DEBUG toggleFavoriteFocused - task lanzada"

    if m.isFavoritesMode and not newState
        m.ChannelList.content.removeChild(nd)
        cc = m.ChannelList.content.getChildCount()
        m.channelCount = 0
        if cc > 0 then m.channelCount = cc - 1
        if m.noFavoritesLabel <> invalid then m.noFavoritesLabel.visible = (cc = 0)
        if cc > 0
            newIdx = idx
            if newIdx > m.channelCount then newIdx = m.channelCount
            if newIdx < 0 then newIdx = 0
            m.ChannelList.jumpToItem = newIdx
        end if
    else
        if not nd.hasField("isFavorite") then nd.addFields({isFavorite: false})
        nd.isFavorite = newState
        m.ChannelList.content = m.ChannelList.content ' fuerza redibujo de la estrella
        m.ChannelList.jumpToItem = idx
    end if

    if m.allChannels <> invalid
        for i = 0 to m.allChannels.getChildCount() - 1
            c2 = m.allChannels.getChild(i)
            if c2 <> invalid and c2.id = chId
                if not c2.hasField("isFavorite") then c2.addFields({isFavorite: false})
                c2.isFavorite = newState
                exit for
            end if
        end for
    end if
    print "DEBUG toggleFavoriteFocused - fin"
end sub

' ============== EPG BATCH ==============
sub launchBatch()
    if m.epgBatchBusy then return
    if m.ChannelList.content = invalid then return
    if m.epgNextStart > m.channelCount then return
    ids = {} : cnt = 0 : idx = m.epgNextStart
    while idx <= m.channelCount and cnt < 10
        k = istr(idx)
        if not m.epgLoaded.doesExist(k) then
            nd = m.ChannelList.content.getChild(idx)
            if nd <> invalid and nd.id <> invalid and nd.id <> "" then
                ids[k] = nd.id : cnt = cnt + 1
            end if
        end if
        idx = idx + 1
    end while
    m.epgNextStart = idx
    if cnt = 0 then
        if m.epgNextStart <= m.channelCount then launchBatch()
        return
    end if
    m.epgBatchBusy = true
    m.batchGen = m.epgGeneration
    m.batchTask = createObject("roSGNode", "EpgBatchTask")
    m.batchTask.channelIds = ids
    m.batchTask.observeField("contentSet", "onBatchDone")
    m.batchTask.control = "RUN"
end sub

sub onBatchDone()
    m.epgBatchBusy = false
    if m.batchGen <> m.epgGeneration then return
    if m.batchTask = invalid then return
    res = m.batchTask.results
    if res = invalid or type(res) <> "roAssociativeArray" then return
    for each k in res
        e = res[k]
        if e <> invalid and type(e) = "roAssociativeArray" then
            idx = val(k)
            if m.ChannelList.content <> invalid then
                nd = m.ChannelList.content.getChild(idx)
                if nd <> invalid then
                    nw = "" : lt = ""
                    if e.doesExist("now") and e.now <> invalid then nw = e.now
                    if e.doesExist("later") and e.later <> invalid then lt = e.later
                    nd.shortdescriptionline1 = nw
                    nd.shortdescriptionline2 = lt
                end if
            end if
            m.epgLoaded[k] = true
        end if
    end for
    launchBatch()
end sub

sub ensureEpg()
    if m.epgBatchBusy then return
    k = istr(m.top.channel)
    if not m.epgLoaded.doesExist(k) then
        m.epgNextStart = m.top.channel
        launchBatch()
    end if
end sub

' ============== CHANNEL FOCUS / VIDEO ==============
sub setVideo()
    if m.ChannelList.content = invalid then return
    nd = m.ChannelList.content.getChild(m.top.channel)
    if nd = invalid then return

    m.videocontent = nd
    loadFocusedEpg()
    ensureEpg()

    if m.nowChName <> invalid then m.nowChName.text = nd.title
    if m.nowChIcon <> invalid then
        if nd.HDPosterUrl <> invalid and nd.HDPosterUrl <> "" then
            m.nowChIcon.uri = nd.HDPosterUrl
            m.nowChIcon.visible = true
        else
            m.nowChIcon.visible = false
        end if
    end if
    if m.nowEpgTitle <> invalid and nd.shortdescriptionline1 <> invalid then
        m.nowEpgTitle.text = nd.shortdescriptionline1
    end if
    if m.nextEpgTitle <> invalid and nd.shortdescriptionline2 <> invalid then
        m.nextEpgTitle.text = nd.shortdescriptionline2
    end if
end sub

sub playChannel()
    if m.videocontent = invalid then return

    vn = createObject("roSGNode", "ContentNode")
    vn.url = m.videocontent.url
    vn.title = m.videocontent.title
    vn.VideoDisableUI = true
    ' Marca el contenido como EN VIVO (no seekeable). Sin esto, Roku
    ' no distingue este stream de un archivo normal, lo cual afecta
    ' como maneja una reconexion (ver retryPlay()/triggerReconnect()).
    vn.live = true

    if m.videocontent.HDPosterUrl <> invalid then
        vn.HDPosterUrl = m.videocontent.HDPosterUrl
    end if

    ba = CreateObject("roByteArray")
    ba.FromAsciiString(m.global.user + ":" + m.global.pass)
    headers = []
    headers[0] = "X-Content:" + ba.ToBase64String()
    headers[1] = "X-Roku-Reserved-Dev-Id: 132fdf0cb94f9eb9a3a0132af460b8cd"
    headers[2] = "User-Agent: Mozilla/5.0"
    vn.HttpHeaders = headers

    m.Video.content = vn
    m.Video.control = "play"
    m.Video.visible = true
    m.VideoLoading.text = "Cargando canal..."
    m.VideoLoading.visible = true
    m.currentChannel = m.top.channel
    m.retryCount = 0
    m.retryTimer.control = "stop"

    markNowPlaying(m.videocontent)

    if m.videocontent.id <> invalid and m.videocontent.id <> ""
        RegWrite(m.global.catGet, m.videocontent.id, "LastChannelID")
    end if

    if m.nowChName <> invalid then m.nowChName.text = m.videocontent.title
    if m.nowChIcon <> invalid then
        if m.videocontent.HDPosterUrl <> invalid and m.videocontent.HDPosterUrl <> "" then
            m.nowChIcon.uri = m.videocontent.HDPosterUrl
            m.nowChIcon.visible = true
        else
            m.nowChIcon.visible = false
        end if
    end if
end sub

' Marca el canal REALMENTE sintonizado (punto "EN VIVO" en ChannelRowItem),
' independiente del foco del control remoto. Desmarca el anterior, marca
' el nuevo, y fuerza el redibujo de la lista (mismo truco que ya se usa
' para refrescar la estrella de favoritos).
sub markNowPlaying(nd as Object)
    if nd = invalid then return

    if m.lastPlayingNode <> invalid
        if m.lastPlayingNode.hasField("isPlayingNow") then
            m.lastPlayingNode.isPlayingNow = false
        end if
    end if

    if not nd.hasField("isPlayingNow") then nd.addFields({isPlayingNow: false})
    nd.isPlayingNow = true
    m.lastPlayingNode = nd

    if m.ChannelList.content <> invalid then
        focoActual = m.ChannelList.itemFocused
        m.ChannelList.content = m.ChannelList.content ' fuerza redibujo del punto EN VIVO
        m.ChannelList.jumpToItem = focoActual ' restaura la posicion, si no se va al inicio
    end if
end sub

' Marca la categoria REALMENTE activa (3 cuadros en CategoryRowItem),
' independiente del foco -- mismo mecanismo que markNowPlaying pero para
' CategoryList. Se le pasa el nodo directamente (no el indice) porque se
' llama desde varios flujos distintos (categoria normal, Buscar, Favoritos).
sub markActiveCategory(nd as Object)
    if nd = invalid then return

    if m.lastActiveCatNode <> invalid
        if m.lastActiveCatNode.hasField("isActiveCategory") then
            m.lastActiveCatNode.isActiveCategory = false
        end if
    end if

    if not nd.hasField("isActiveCategory") then nd.addFields({isActiveCategory: false})
    nd.isActiveCategory = true
    m.lastActiveCatNode = nd

    if m.CategoryList.content <> invalid then
        focoActual = m.CategoryList.itemFocused
        m.CategoryList.content = m.CategoryList.content ' fuerza redibujo de los 3 cuadros
        m.CategoryList.jumpToItem = focoActual ' restaura la posicion, si no se va al inicio
    end if
end sub

' ============== FOCUSED EPG ==============
sub loadFocusedEpg()
    if m.videocontent = invalid then return
    if m.videocontent.id = invalid or m.videocontent.id = "" then return
    m.epgTask = createObject("roSGNode", "Epg")
    m.epgTask.cve = m.videocontent.id
    m.epgTask.observeField("contentSet", "onFocusedEpg")
    m.epgTask.control = "RUN"
end sub

sub onFocusedEpg()
    if m.epgTask = invalid then return
    nw = "" : lt = "" : st = invalid : en = invalid
    nst = invalid : nen = invalid
    if m.epgTask.title <> invalid then nw = m.epgTask.title
    if m.epgTask.next <> invalid then lt = m.epgTask.next
    if m.epgTask.start <> invalid then st = m.epgTask.start
    if m.epgTask.end <> invalid then en = m.epgTask.end
    if m.epgTask.nextStart <> invalid then nst = m.epgTask.nextStart
    if m.epgTask.nextEnd <> invalid then nen = m.epgTask.nextEnd

    if m.nowEpgTitle <> invalid then m.nowEpgTitle.text = nw
    if m.nextEpgTitle <> invalid then m.nextEpgTitle.text = lt

    timeText = formatTimeRange(st, en)
    if m.nowEpgTime <> invalid then m.nowEpgTime.text = timeText

    nextTimeText = formatTimeRange(nst, nen)
    if m.nextEpgTime <> invalid then m.nextEpgTime.text = nextTimeText

    if m.infoEpgTime <> invalid then m.infoEpgTime.text = timeText
    if m.infoEpgNow <> invalid then m.infoEpgNow.text = nw
    if m.infoEpgLater <> invalid then m.infoEpgLater.text = lt

    k = istr(m.top.channel)
    if not m.epgLoaded.doesExist(k) then
        if m.ChannelList.content <> invalid then
            nd = m.ChannelList.content.getChild(m.top.channel)
            if nd <> invalid then
                nd.shortdescriptionline1 = nw
                nd.shortdescriptionline2 = lt
            end if
        end if
        m.epgLoaded[k] = true
    end if
end sub

' ============== CATEGORY ==============
sub onCatSelected()
    idx = m.CategoryList.itemSelected
    ' Marcamos que el evento nativo itemSelected SI disparo este observer
    ' en esta pulsacion de OK (se usa en onKeyEvent para saber si hace
    ' falta forzar la logica manualmente cuando el indice no cambia).
    m.catSelectedNatively = true
    if idx >= 0 and m.CategoryList.content <> invalid then
        nd = m.CategoryList.content.getChild(idx)
        if nd <> invalid then
            catId    = nd.id
            catTitle = nd.title

            if catId = "__search__" then
                if m.isFavoritesMode then exitFavoritesMode()
                enterSearchMode()
                return
            end if

            if catId = "__favorites__" then
                if m.isSearchMode then exitSearchMode()
                enterFavoritesMode()
                return
            end if

            if m.isSearchMode then exitSearchMode()
            if m.isFavoritesMode then exitFavoritesMode()

            m.lastCatIndex = idx
            if PC_isCatBlocked(catId, "live")
                m.pendingCatId    = catId
                m.pendingCatTitle = catTitle
                showLivePinDialog()
            else
                requestContent(catId, catTitle)
            end if
        end if
    end if
end sub

' ============== MODO BÚSQUEDA ==============
sub enterSearchMode()
    m.isSearchMode = true
    m.allChannels  = invalid

    empty = createObject("roSGNode", "ContentNode")
    m.ChannelList.content = empty
    m.channelCount = 0

    if m.CategoryList.content <> invalid
        searchNd = m.CategoryList.content.getChild(0) ' "__search__" siempre en idx 0
        if searchNd <> invalid then markActiveCategory(searchNd)
    end if

    m.searchKeyboard.visible = true
    m.searchKeyboard.text = ""
    m.searchKeyboard.setFocus(true)
    m.focusArea = "search"
end sub

sub onAllChannelsLoaded()
    if m.searchLoadTask = invalid then return
    if m.searchLoadTask.itemsNode = invalid then return
    m.allChannels = m.searchLoadTask.itemsNode
    applyFavoriteFlags(m.allChannels)

    if m.pendingAllChannelsFor = "favorites" then
        m.pendingAllChannelsFor = ""
        seedAndShowFavoriteChannels()
        return
    end if

    m.searchLoading.visible = false
    doFilter()
    m.searchKeyboard.visible = false
    m.focusArea = "channels"
    m.global.epgChannelsRealFocus = true
    m.ChannelList.setFocus(true)
end sub

sub doFilter()
    if m.allChannels = invalid then return
    rawText = m.searchKeyboard.text
    if rawText = invalid then rawText = ""
    query = LCase(rawText.trim())
    if Len(query) < 3 then return

    filtered = createObject("roSGNode", "ContentNode")
    total = m.allChannels.getChildCount()
    for i = 0 to total - 1
        ch = m.allChannels.getChild(i)
        if ch <> invalid then
            chTitle = ch.title
            if chTitle = invalid then chTitle = ""
            if instr(1, LCase(chTitle), query) > 0 then
                filtered.appendChild(ch)
            end if
        end if
    end for

    m.ChannelList.content = filtered
    fc = filtered.getChildCount()
    m.channelCount = 0
    if fc > 0 then m.channelCount = fc - 1
end sub

sub onSearchConfirmed()
    if not m.isSearchMode then return
    rawText = m.searchKeyboard.text
    if rawText = invalid then rawText = ""
    if Len(rawText.trim()) < 3 then return

    ' Busqueda rapida via buscador.php: una sola peticion, ya filtrada
    ' del lado del servidor. Reemplaza el metodo viejo (bajar TODAS las
    ' categorias de canales una por una antes de poder buscar), que era
    ' lento con proveedores con muchas categorias.
    if m.searchChannelsTask <> invalid
        m.searchChannelsTask.unobserveField("searchDone")
        m.searchChannelsTask.control = "stop"
    end if

    m.searchLoading.visible = true

    if m.searchTaskGen = invalid then m.searchTaskGen = 0
    m.searchTaskGen = m.searchTaskGen + 1
    m.currentSearchTaskGen = m.searchTaskGen

    m.searchChannelsTask = createObject("roSGNode", "SearchChannelsTask")
    m.searchChannelsTask.genId = m.searchTaskGen
    m.searchChannelsTask.query = rawText.trim()
    m.searchChannelsTask.observeField("searchDone", "onChannelSearchDone")
    m.searchChannelsTask.control = "RUN"
end sub

sub onChannelSearchDone(event as Object)
    ' Si el usuario ya lanzo otra busqueda mientras esta corria, se
    ' ignora este resultado tardio (mismo criterio que se uso para el
    ' cambio de categoria -- ver requestContent/onContentLoaded).
    ' roSGNode no se puede comparar entre si con "=" / "<>" (solo
    ' contra invalid), asi que se compara un numero de generacion.
    triggeringTask = event.GetRoSGNode()
    if triggeringTask = invalid or triggeringTask.genId <> m.currentSearchTaskGen then return

    m.searchLoading.visible = false
    if m.searchChannelsTask = invalid or m.searchChannelsTask.resultsNode = invalid then return

    results = m.searchChannelsTask.resultsNode
    applyFavoriteFlags(results)
    m.ChannelList.content = results
    fc = results.getChildCount()
    m.channelCount = 0
    if fc > 0 then m.channelCount = fc - 1

    m.searchKeyboard.visible = false
    m.focusArea = "channels"
    m.global.epgChannelsRealFocus = true
    m.ChannelList.setFocus(true)
end sub

sub onSearchGoUp()
    exitSearchMode()
    m.focusArea = "categories"
    m.CategoryList.opacity = 1.0
    m.CategoryList.setFocus(true)
end sub

sub exitSearchMode()
    m.isSearchMode = false
    m.searchKeyboard.visible = false
    m.searchLoading.visible = false
    m.allChannels = invalid
    if m.searchChannelsTask <> invalid
        m.searchChannelsTask.unobserveField("searchDone")
        m.searchChannelsTask.control = "stop"
        m.searchChannelsTask = invalid
    end if
    if m.task <> invalid and m.task.itemsNode <> invalid then
        m.ChannelList.content = m.task.itemsNode
        cc = m.task.itemsNode.getChildCount()
        m.channelCount = 0
        if cc > 0 then m.channelCount = cc - 1
    end if
end sub

sub showLivePinDialog()
    dlg = createObject("roSGNode", "LivePinDialog")
    dlg.title   = "Control Parental"
    dlg.message = "Ingresa PIN 0000 sino cambiaste"
    dlg.observeField("pin",    "onLivePinResult")
    dlg.observeField("closed", "onLivePinClosed")
    m.livePinDlg = dlg
    m.top.getScene().dialog = dlg
end sub

sub onLivePinClosed()
    if m.livePinDlg = invalid then return
    if m.livePinDlg.closed = true then
        m.top.getScene().dialog = invalid
        m.livePinDlg      = invalid
        m.pendingCatId    = ""
        m.pendingCatTitle = ""
    end if
end sub

sub onLivePinResult()
    if m.livePinDlg = invalid then return
    text = m.livePinDlg.pin.trim()
    if text = "" then return
    m.top.getScene().dialog = invalid
    m.livePinDlg = invalid

    stored = PC_getPin()
    if stored = "" then stored = "0000"

    if text = stored
        requestContent(m.pendingCatId, m.pendingCatTitle)
        m.pendingCatId    = ""
        m.pendingCatTitle = ""
    else
        dlg2 = createObject("roSGNode", "StandardMessageDialog")
        dlg2.title   = "Control Parental"
        dlg2.message = "PIN Incorrecto"
        dlg2.buttons = ["Volver a Intentar", "Cancelar"]
        dlg2.observeField("buttonSelected", "onLivePinWrong")
        m.livePinWrongDlg = dlg2
        m.top.getScene().dialog = dlg2
    end if
end sub

sub onLivePinWrong()
    if m.livePinWrongDlg = invalid then return
    btn = m.livePinWrongDlg.buttonSelected
    m.top.getScene().dialog = invalid
    m.livePinWrongDlg = invalid
    if btn = 0 then showLivePinDialog()
end sub

sub onChannelSelected()
    idx = m.ChannelList.itemSelected
    if m.ChannelList.content <> invalid then
        nd = m.ChannelList.content.getChild(idx)
        if nd <> invalid then
            m.top.channel = idx
            m.videocontent = nd
            playChannel()
        end if
    end if
end sub

' ============== FULLSCREEN / GUIDE ==============
sub goFullscreen()
    if m.videocontent = invalid then return
    m.isFullscreen = true
    m.guideUI.visible = false
    if m.topNavOverlay <> invalid then m.topNavOverlay.visible = false

    m.videoContainer.translation = "[0, 0]"
    m.videoContainer.scale = "[1.0, 1.0]"

    if m.videoBorder <> invalid then m.videoBorder.visible = false
    m.VideoLoading.visible = false
    m.focusTrap.visible = true
    m.focusTrap.setFocus(true)
    showInfo()
end sub

sub goGuide()
    m.isFullscreen = false
    m.guideUI.visible = true
    if m.topNavOverlay <> invalid then m.topNavOverlay.visible = true

    m.videoContainer.translation = "[0, 0]"
    m.videoContainer.scale = "[1.0, 1.0]"

    if m.videoBorder <> invalid then m.videoBorder.visible = false
    m.infoOverlay.visible = false
    m.infoTimer.control = "stop"
    m.focusTrap.visible = false
    m.ChannelList.jumpToItem = m.top.channel
    m.global.epgChannelsRealFocus = true
    m.ChannelList.setFocus(true)
    m.focusArea = "channels"
end sub

sub showInfo()
    if m.videocontent <> invalid then
        startChannelNameMarquee(m.videocontent.title)
        if m.videocontent.HDPosterUrl <> invalid then m.infoChPoster.uri = m.videocontent.HDPosterUrl
    end if
    updateTime()
    loadFocusedEpg()
    m.infoOverlay.visible = true
    m.infoTimer.control = "start"
end sub

' Arma el scroll infinito del nombre del canal, limitado al ancho del
' poster (113.3). Si el nombre entra completo en ese ancho, se deja
' quieto (no tiene caso animarlo). Si no entra, se pone una segunda
' copia del texto pegada despues de la primera (con un espacio de
' separacion) y se anima el contenedor hacia la izquierda exactamente
' el ancho de una copia -- al llegar ahi, la copia 2 queda exactamente
' donde arranco la copia 1, y el loop (repeat="true") se ve continuo.
sub startChannelNameMarquee(title as String)
    if m.infoChName = invalid or m.chNameTrack = invalid then return

    safeTitle = title
    if safeTitle = invalid then safeTitle = ""

    m.chNameScrollAnim.control = "stop"
    m.chNameTrack.translation = [0.0, 0.0]
    m.infoChName.text = safeTitle
    m.infoChNameCopy.visible = false

    clipWidth = 113.3
    textWidth = clipWidth
    fontNode = m.infoChName.font
    if fontNode <> invalid
        sizePt = 24
        if fontNode.size <> invalid then sizePt = fontNode.size
        ' roFontRegistry (para medir el texto con precision de pixel)
        ' solo se puede crear en el hilo Main/Task, no aqui (Render
        ' thread) -- truena si se intenta. Se usa un ancho aproximado
        ' por caracter en su lugar; no necesita ser exacto, solo sirve
        ' para saber si hace falta el scroll y que tan rapido moverlo.
        avgCharWidth = sizePt * 0.62
        textWidth = Len(safeTitle) * avgCharWidth
    end if

    if textWidth <= clipWidth or m.infoChNameCopy = invalid or m.chNameScrollAnim = invalid or m.chNameScrollInterp = invalid
        ' No hace falta scroll, el nombre ya cabe completo.
        return
    end if

    gap = 40.0
    loopWidth = textWidth + gap
    m.infoChNameCopy.text = safeTitle
    m.infoChNameCopy.translation = [loopWidth, 0.0]
    m.infoChNameCopy.visible = true

    ' Velocidad constante sin importar que tan largo sea el nombre.
    pxPerSecond = 40.0
    duration = loopWidth / pxPerSecond
    if duration < 1.0 then duration = 1.0

    m.chNameScrollAnim.duration = duration
    m.chNameScrollInterp.keyValue = [[0.0, 0.0], [-loopWidth, 0.0]]
    m.chNameScrollAnim.control = "start"
end sub

sub hideInfo()
    m.infoOverlay.visible = false
    m.infoTimer.control = "stop"
end sub

' ============== VIDEO STATE ==============
sub onVideoState()
    st = m.Video.state

    if st = "buffering" then
        m.VideoLoading.text = "Cargando canal..."
        m.VideoLoading.visible = true
        ' Durante el buffer normal es esperado que la posicion no
        ' avance -- se pausa el chequeo de congelamiento mientras dure.
        m.freezeCheckTimer.control = "stop"

    else if st = "playing" then
        m.VideoLoading.visible = false
        m.retryCount = 0
        m.retryTimer.control = "stop"
        ' Arranca (o reinicia) la vigilancia de congelamiento: mientras
        ' el estado siga diciendo "playing", la posicion debe seguir
        ' avanzando. Si un stream se congela, el estado NUNCA cambia a
        ' error -- se queda en "playing" aunque no lleguen cuadros
        ' nuevos -- por eso hace falta este chequeo aparte.
        m.lastVideoPosition = -1
        m.freezeStrikes = 0
        m.freezeCheckTimer.control = "start"

    else if st = "error" or st = "finished" then
        m.freezeCheckTimer.control = "stop"
        triggerReconnect()
    end if
end sub

' Se llama cada vez que el reproductor reporta error/finished, Y
' cuando checkFrozenVideo() detecta que se congelo -- mismo cascada de
' reintentos para ambos casos (4 casi inmediatos + 2 con 3 segundos de
' espera, 6 intentos en total antes de "Canal en Mantenimiento").
sub triggerReconnect()
    if m.retryCount < 5 then
        m.retryCount = m.retryCount + 1
        m.VideoLoading.text = "Buscando otra señal..."
        m.VideoLoading.visible = true
        m.retryTimer.control = "stop"
        if m.retryCount <= 3
            m.retryTimer.duration = 0.1
        else
            m.retryTimer.duration = 3
        end if
        m.retryTimer.control = "start"
    else
        m.retryTimer.control = "stop"
        m.VideoLoading.text = "Canal en Mantenimiento"
        m.VideoLoading.visible = true
        m.Video.control = "stop"
    end if
end sub

' Chequeo periodico (cada 6s, ver freezeCheckTimer) mientras el
' reproductor dice "playing": si la posicion no avanzo desde el
' chequeo anterior, es señal de que el stream se congelo aunque el
' estado siga diciendo que va bien. Con 4 chequeos seguidos sin
' avanzar (~24 segundos de imagen pegada) se fuerza una reconexion,
' igual que si hubiera dado error. Antes eran solo 2 chequeos
' (~12s) -- un umbral muy sensible que disparaba reconexiones (y por
' lo tanto cortes/repeticion de la señal, ver retryPlay()) ante
' baches normales de una conexion IPTV que se hubieran resuelto
' solos sin necesidad de cortar el video.
sub checkFrozenVideo()
    if m.Video.state <> "playing" then
        m.freezeCheckTimer.control = "stop"
        return
    end if

    curPos = m.Video.position
    if curPos <> invalid and curPos = m.lastVideoPosition
        m.freezeStrikes = m.freezeStrikes + 1
        print "DEBUG checkFrozenVideo - posicion sin avanzar ("; curPos; "s), strike "; m.freezeStrikes
        if m.freezeStrikes >= 4
            print "DEBUG checkFrozenVideo - canal congelado, forzando reconexion"
            m.freezeCheckTimer.control = "stop"
            m.freezeStrikes = 0
            triggerReconnect()
            return
        end if
    else
        m.freezeStrikes = 0
    end if
    m.lastVideoPosition = curPos
end sub

sub retryPlay()
    if m.videocontent = invalid then return

    ' Reintento SUAVE (primeros 2 intentos): no se corta el video ni
    ' se reconstruye el ContentNode desde cero -- solo se le pide al
    ' mismo Video node que retome el mismo stream. Antes, CADA
    ' reintento (incluido el primero, a los 0.1s) hacia stop + creaba
    ' un ContentNode nuevo con la misma URL, lo cual cortaba la señal
    ' y la volvia a pedir desde el principio del buffer -- eso era lo
    ' que se veia como "se regresa y se repite". Reservamos el
    ' stop+reconstruccion completa solo para cuando el reintento suave
    ' ya fallo varias veces.
    if m.retryCount <= 2
        m.Video.control = "play"
        return
    end if

    m.Video.control = "stop"
    vn = createObject("roSGNode", "ContentNode")
    vn.url = m.videocontent.url
    vn.title = m.videocontent.title
    vn.VideoDisableUI = true
    vn.live = true
    if m.videocontent.HDPosterUrl <> invalid then
        vn.HDPosterUrl = m.videocontent.HDPosterUrl
    end if
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(m.global.user + ":" + m.global.pass)
    headers = []
    headers[0] = "X-Content:" + ba.ToBase64String()
    headers[1] = "X-Roku-Reserved-Dev-Id: 132fdf0cb94f9eb9a3a0132af460b8cd"
    headers[2] = "User-Agent: Mozilla/5.0"
    vn.HttpHeaders = headers
    m.Video.content = vn
    m.Video.control = "play"
end sub

' ============== KEY HANDLING ==============
Function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    print "DEBUG onKeyEvent EPG - key recibida = "; key; " | focusArea="; m.focusArea; " focusZone="; m.focusZone; " isFullscreen="; m.isFullscreen

    if m.isFullscreen then
        if key = "back" or key = "left" then
            goGuide()
            return true
        else if key = "up" then
            if m.ChannelList.content <> invalid and m.top.channel > 0 then
                m.top.channel = m.top.channel - 1
                nd = m.ChannelList.content.getChild(m.top.channel)
                if nd <> invalid then
                    m.videocontent = nd
                    playChannel()
                    showInfo()
                end if
            end if
            return true
        else if key = "down" then
            if m.ChannelList.content <> invalid and m.top.channel < m.channelCount then
                m.top.channel = m.top.channel + 1
                nd = m.ChannelList.content.getChild(m.top.channel)
                if nd <> invalid then
                    m.videocontent = nd
                    playChannel()
                    showInfo()
                end if
            end if
            return true
        else if key = "OK" or key = "play" then
            if m.infoOverlay.visible then hideInfo() else showInfo()
            return true
        end if
        return true
    end if

    if m.focusZone = "nav" then
        if key = "right" then
            if m.navFocusedIndex < m.totalNavItems - 1 then m.navFocusedIndex = m.navFocusedIndex + 1 else m.navFocusedIndex = 0
            epgNavHighlight(m.navFocusedIndex)
            return true
        else if key = "left" then
            if m.navFocusedIndex > 0 then m.navFocusedIndex = m.navFocusedIndex - 1 else m.navFocusedIndex = m.totalNavItems - 1
            epgNavHighlight(m.navFocusedIndex)
            return true
        else if key = "down" then
            epgNavClear()
            m.focusZone = "guide"
            m.focusArea = "categories"
            m.CategoryList.opacity = 1.0
            m.CategoryList.setFocus(true)
            return true
        else if key = "OK" then
            epgNavSelect(m.navFocusedIndex)
            return true
        end if
        return true
    end if

    if m.focusArea = "search" then
        if key = "right" then
            if m.ChannelList.content <> invalid and m.ChannelList.content.getChildCount() > 0 then
    m.focusArea = "channels"
    m.global.epgChannelsRealFocus = true
    m.ChannelList.setFocus(true)
    if not m.epgLaunchBeaconFired
        m.epgLaunchBeaconFired = true
        m.top.signalBeacon("EPGLaunchComplete")
    end if
            end if
            return true
        end if
        return false
    end if

    if m.focusArea = "categories" then
        if key = "OK" then
            ' El evento nativo itemSelected de CategoryList solo dispara
            ' onCatSelected() cuando el INDICE cambia. Si el usuario le da
            ' OK de nuevo sobre la MISMA categoria ya seleccionada (ej.
            ' Favoritos), el indice no cambia y onCatSelected no corre.
            ' Detectamos eso aqui con m.catSelectedNatively (que
            ' onCatSelected pone en true justo antes de este punto si
            ' SI corrio) y, si no corrio, disparamos la logica a mano.
            if not m.catSelectedNatively
                focIdx = m.CategoryList.itemFocused
                if focIdx >= 0 and m.CategoryList.content <> invalid
                    focNd = m.CategoryList.content.getChild(focIdx)
                    if focNd <> invalid and focNd.id = "__favorites__"
                        ' Re-seleccionar Favoritos estando ya parado ahi:
                        ' solo refrescamos los datos, SIN mover el foco a
                        ' la lista de canales ni disparar el preview. Si
                        ' lo hicieramos, un "right"/"OK" inmediato despues
                        ' (que el usuario interpreta como "darle a
                        ' Favoritos otra vez") caeria sobre el bloque de
                        ' abajo y mandaria a fullscreen sin querer.
                        print "DEBUG onKeyEvent EPG - reselect manual de Favoritos (itemSelected no cambio), refresco sin mover foco"
                        if m.isSearchMode then exitSearchMode()
                        refreshFavoriteChannelsInPlace()
                        m.catSelectedNatively = false
                        return true
                    end if
                end if
            end if
            m.catSelectedNatively = false

            ' Favoritos (seleccionado por el camino nativo, con cambio
            ' real de indice) tampoco debe saltar el foco a canales:
            ' se queda en categorias, el usuario decide cuando entrar
            ' a los canales con un right/OK explicito. Si forzaramos
            ' el salto aqui, un segundo OK caeria sobre el canal ya
            ' enfocado y lo mandaria a pantalla completa sin querer.
            if m.isFavoritesMode
                return true
            end if

            m.focusArea = "channels"
            m.CategoryList.opacity = 0.5
            m.CategoryList.setFocus(false)
            m.global.epgChannelsRealFocus = true
            m.ChannelList.setFocus(true)
            return true
        else if key = "right" then
            m.focusArea = "channels"
            m.CategoryList.opacity = 0.5
            m.CategoryList.setFocus(false)
            m.global.epgChannelsRealFocus = true
            m.ChannelList.setFocus(true)
            return true
        else if key = "up" then
            m.CategoryList.opacity = 0.5
            m.CategoryList.setFocus(false)
            epgGoToNav()
            return true
        else if key = "back" then
            m.focusArea = "channels"
            m.CategoryList.opacity = 0.5
            m.CategoryList.setFocus(false)
            m.global.epgChannelsRealFocus = true
            m.ChannelList.setFocus(true)
            return true
        end if
        return false
    end if

    if m.focusArea = "channels" then
        if key = "right" then
            goFullscreen()
            return true
        else if key = "left" then
            if m.isSearchMode then
                m.focusArea = "categories"
                m.CategoryList.opacity = 1.0
                m.CategoryList.setFocus(true)
                m.CategoryList.jumpToItem = 0
                m.global.epgChannelsRealFocus = false
            else if m.isFavoritesMode then
                m.focusArea = "categories"
                m.CategoryList.opacity = 1.0
                m.CategoryList.setFocus(true)
                m.CategoryList.jumpToItem = 1
                m.global.epgChannelsRealFocus = false
            else
                m.focusArea = "categories"
                m.CategoryList.opacity = 1.0
                m.CategoryList.setFocus(true)
                m.CategoryList.jumpToItem = m.lastCatIndex
                m.global.epgChannelsRealFocus = false
            end if
            return true
        else if key = "OK" then
            if m.loading.state = "stopped" and m.ChannelList.content <> invalid then
                focusedIdx = m.ChannelList.itemFocused
                nd = m.ChannelList.content.getChild(focusedIdx)
                if nd <> invalid then
                    m.top.channel = focusedIdx
                    m.videocontent = nd
                    playChannel()
                end if
            end if
            return true
        else if key = "replay" then
            toggleFavoriteFocused()
            return true
        end if
    end if

    if key = "fastforward" then
        if m.top.channel < m.channelCount then
            jump = m.top.channel + 7
            if jump > m.channelCount then jump = m.channelCount
            m.top.channel = jump
            m.ChannelList.animateToItem = m.top.channel
        end if
        return true
    else if key = "rewind" then
        if m.top.channel > 0 then
            jump = m.top.channel - 7
            if jump < 0 then jump = 0
            m.top.channel = jump
            m.ChannelList.jumpToItem = m.top.channel
        end if
        return true
    else if key = "back" then
        if m.Video.state = "playing" then m.Video.control = "stop"
        m.freezeCheckTimer.control = "stop"
        if m.task <> invalid and PC_isCatBlocked(m.task.cat, "live")
            RegDelete(m.global.catGet, "CatID")
            RegDelete(m.global.catGet, "CatTITLE")
        end if
        return false
    end if

    return false
End Function

function istr(num as Integer) as String
    raw = Str(num)
    out = ""
    for ci = 1 to Len(raw)
        ch = Mid(raw, ci, 1)
        if ch <> " " then out = out + ch
    end for
    return out
end function

sub epgShowScreenNav()
    for i = 0 to m.totalNavItems - 1
        if m.epgNavBgs[i] <> invalid
            m.epgNavBgs[i].color = "0x00000000"
            m.epgNavBgs[i].opacity = 0.0
            m.epgNavLabels[i].color = "0xAAAAAAFF"
        end if
    end for
end sub

sub epgGoToNav()
    m.CategoryList.setFocus(false)
    m.ChannelList.setFocus(false)
    m.focusZone = "nav"
    m.focusArea = "none"
    m.navFocusedIndex = m.currentNavIndex
    epgNavHighlight(m.navFocusedIndex)
    m.top.setFocus(true)
end sub

sub epgNavHighlight(idx as Integer)
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0x00A8FFFF"
    for i = 0 to m.totalNavItems - 1
        if m.epgNavBgs[i] <> invalid
            if i = idx
                m.epgNavBgs[i].color = fc
                m.epgNavBgs[i].opacity = 0.8
                m.epgNavLabels[i].color = "0xFFFFFFFF"
            else if i = m.currentNavIndex
                m.epgNavBgs[i].color = fc
                m.epgNavBgs[i].opacity = 0.5
                m.epgNavLabels[i].color = "0xFFFFFFFF"
            else
                m.epgNavBgs[i].color = "0x00000000"
                m.epgNavBgs[i].opacity = 0.0
                m.epgNavLabels[i].color = "0xAAAAAAFF"
            end if
        end if
    end for
end sub

sub epgNavClear()
    epgShowScreenNav()
end sub

sub epgNavSelect(idx as Integer)
    if m.task <> invalid and PC_isCatBlocked(m.task.cat, "live")
        RegDelete(m.global.catGet, "CatID")
        RegDelete(m.global.catGet, "CatTITLE")
    end if
    if idx = 0
        m.top.menuItemSelected = 4
    else if idx = 1
        m.top.menuItemSelected = 5
    else if idx = 2
        m.top.menuItemSelected = 1
    else if idx = 3
        m.top.menuItemSelected = 2
    else if idx = 4
        m.inNav = false
        epgNavClear()
        m.global.epgChannelsRealFocus = true
        m.ChannelList.setFocus(true)
    else if idx = 5
        m.top.menuItemSelected = 3
    else if idx = 6
        GU_ShowChangeProfileDialog(m.top, -2) ' Perfil
    end if
end sub
