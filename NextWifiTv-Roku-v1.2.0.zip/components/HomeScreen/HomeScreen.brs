sub init()
    m.top.setFocus(true)

    m.navBgs = []
    m.navLabels = []
    m.totalNavItems = 7
    for i = 0 to m.totalNavItems - 1
        m.navBgs.push(m.top.findNode("navBg" + i.toStr()))
        m.navLabels.push(m.top.findNode("navLabel" + i.toStr()))
    end for
    m.navFocusedIndex = 1
    m.activeNavIndex = 1
    m.logoImage = m.top.findNode("logoImage")
    m.profileAvatarBg      = m.top.findNode("profileAvatarBg")
    m.profileAvatarInitial = m.top.findNode("profileAvatarInitial")
    m.loading = m.top.findNode("LoadingIndicator")
    m.mensajeBg    = m.top.findNode("mensajeBg")
    m.mensajeLabel = m.top.findNode("mensajeLabel")
    if m.global.focusColor <> invalid and m.global.focusColor <> ""
        m.mensajeBg.color = m.global.focusColor
    end if
    fetchMensaje()

    m.heroBgFront = m.top.findNode("heroBgFront")
    m.heroBgBack = m.top.findNode("heroBgBack")
    m.heroInfoGroup = m.top.findNode("heroInfoGroup")

    ' Pedido explicito: el fondo de Home ya no debe ser la imagen de
    ' marca del panel (panelURL/img/fondo.jpg, la misma que usa el
    ' login), debe quedar NEGRO solido. baseBg (Poster) ya no recibe
    ' ningun uri, asi que queda transparente y se ve el Rectangle negro
    ' que esta debajo de el en el XML (baseBgBlack). El carrusel de
    ' backdrops (heroBgBack/heroBgFront) sigue dibujandose encima,
    ' igual que antes, cuando hay uno disponible.
    m.baseBg = m.top.findNode("baseBg")
    m.heroInfoGroup.visible = false
    m.heroTitle = m.top.findNode("heroTitle")
    m.heroRating = m.top.findNode("heroRating")
    m.heroRatingBg = m.top.findNode("heroRatingBg")
    m.heroRatingIcon = m.top.findNode("heroRatingIcon")
    m.heroYearIcon  = m.top.findNode("heroYearIcon")
    m.heroDurIcon   = m.top.findNode("heroDurIcon")
    m.heroYear = m.top.findNode("heroYear")
    m.heroDesc     = m.top.findNode("heroDesc")
    m.heroGenre    = m.top.findNode("heroGenre")
    m.heroDuration = m.top.findNode("heroDuration")
    m.heroFadeOut  = m.top.findNode("heroFadeOut")
    m.heroFadeIn = m.top.findNode("heroFadeIn")
    m.heroFadeOut.observeField("state", "onHeroCrossfadeComplete")
    m.heroLastUri = ""
    m.heroLastVodId = ""
    m.backdropCache = {}
    m.vodInfoTask = invalid

    ' Carrusel automatico del fondo (reemplaza el fondo-por-foco de
    ' antes, ver refreshHeroCarouselItems/showHeroCarouselSlide mas
    ' abajo): 2 series + 2 peliculas mas recientes, rotando cada 10s
    ' con zoom continuo, igual que Android.
    m.heroCarouselTimer = m.top.findNode("heroCarouselTimer")
    m.heroZoomLoop      = m.top.findNode("heroZoomLoop")
    m.heroCarouselTimer.observeField("fire", "onHeroCarouselTimerFire")
    m.heroCarouselItems = []
    m.heroCarouselIndex = -1
    m.heroCarouselTasks = []

    m.recentlyWatchedGrid  = m.top.findNode("recentlyWatchedGrid")
    m.recentlyWatchedLabel = m.top.findNode("recentlyWatchedLabel")
    m.recentMoviesGrid = m.top.findNode("recentMoviesGrid")
    m.recentMoviesLabel = m.top.findNode("recentMoviesLabel")
    m.recentSeriesGrid = m.top.findNode("recentSeriesGrid")
    m.recentSeriesLabel = m.top.findNode("recentSeriesLabel")
    m.recentlyWatchedGrid.observeField("itemSelected", "onRecentlyWatchedSelected")
    m.recentMoviesGrid.observeField("itemSelected", "onRecentMovieSelected")
    m.recentSeriesGrid.observeField("itemSelected", "onRecentSerieSelected")
    ' Pedido explicito: el fondo ya NO sigue el foco de las filas (ver
    ' carrusel automatico arriba) -- por eso ya no se observa
    ' "itemFocused" de estos grids hacia onRecentlyWatchedFocused/
    ' onMovieFocused/onSerieFocused (quedan sin usar, se dejan
    ' definidas por si algo mas las llamara, pero nada las conecta ya).

    m.favoritesGrid = m.top.findNode("favoritesGrid")
    m.favoritesLabel = m.top.findNode("favoritesLabel")
    m.favoritesGrid.observeField("itemSelected", "onFavoriteSelected")
    ' (ver nota arriba: onFavoriteFocused ya no se conecta a itemFocused)
    m.contentArea = m.top.findNode("contentArea")
    m.contentAreaSlide       = m.top.findNode("contentAreaSlide")
    m.contentAreaSlideInterp = m.top.findNode("contentAreaSlideInterp")
    m.rowFadeBottom          = m.top.findNode("rowFadeBottom")
    m.isSliding = false
    m.pendingSlideZone = ""
    m.contentAreaSlide.observeField("state", "onContentAreaSlideDone")

    ' Orden de filas de arriba a abajo. Se usa para navegar con
    ' arriba/abajo saltando filas vacias, y para calcular cuanto hay
    ' que scrollear el contentArea segun cual fila esta enfocada.
    m.zoneOrder = ["recentlywatched", "series", "movies", "favorites"]

    m.detailsScreen = m.top.findNode("homeDetailsScreen")
    m.detailsScreen.observeField("requestClose", "onDetailsRequestClose")
    m.detailsScreen.observeField("visible", "onOverlayVisibleChanged")
    m.seasons = m.top.findNode("homeSeasons")
    m.seasons.observeField("visible", "onOverlayVisibleChanged")

    m.focusZone = "nav"
    m.top.isInMenu = true
    updateNavHighlight()

    ' Si el config remoto (colores) llega despues de haberse creado esta pantalla,
    ' se re-aplica automaticamente aqui.
    m.global.observeField("focusColor", "onFocusColorChanged")

    m.subsWarningBg    = m.top.findNode("subsWarningBg")
    m.subsWarningLabel = m.top.findNode("subsWarningLabel")
    m.subsWarningBg.visible    = false
    m.subsWarningLabel.visible = false
    m.subsTimer = m.top.findNode("warningTimer")
    m.subsTimer.observeField("fire", "onSubsTimerFire")

    loadRemoteAssets()
    updateProfileNavItem()

    m.top.observeField("visible", "onVisibleChanged")
    m.top.observeField("returnFocusToNav", "onReturnFocusToNav")

    ' Cargar contenido: si credenciales ya listas, cargar directo; si no, esperar
    m.global.observeField("serverURL", "onServerReady")
    print "DEBUG init check serverURL="; m.global.serverURL
    if m.global.serverURL <> ""
        print "DEBUG init - cargando directo"
        loadRecentlyWatched()
        loadRecentMovies()
        loadRecentSeries()
        loadFavorites()
        checkExpiration()
        startFullCatalogBackgroundSync()
    end if
end sub

sub onServerReady()
    print "DEBUG onServerReady fired - serverURL="; m.global.serverURL
    if m.global.serverURL = "" then return
    loadRecentlyWatched()
    loadRecentMovies()
    loadRecentSeries()
    loadFavorites()
    checkExpiration()
    startFullCatalogBackgroundSync()
end sub

sub checkExpiration()
    sec = CreateObject("roRegistrySection", "IPTV_PC")
    expTs = sec.Read("exp_date")
    print "DEBUG checkExpiration - expTs="; expTs
    if expTs = invalid or expTs = "" or expTs = "0" then return

    now = CreateObject("roDateTime").AsSeconds()
    expSecs = expTs.toInt()
    diffSecs = expSecs - now
    fourDaysSecs = 4 * 24 * 60 * 60

    if diffSecs >= 0 and diffSecs <= fourDaysSecs
        daysLeft = int(diffSecs / 86400)
        if daysLeft = 0
            msg = "TU SUSCRIPCIÓN EXPIRA HOY"
        else if daysLeft = 1
            msg = "TU SUSCRIPCIÓN EXPIRA MAÑANA"
        else
            msg = "TU SUSCRIPCIÓN ESTÁ POR FINALIZAR"
        end if
        m.subsWarningLabel.text = msg
        m.subsWarningBg.visible = true
        m.subsWarningLabel.visible = true
        m.subsTimer.control = "start"
    end if
end sub

sub onSubsTimerFire()
    m.subsWarningBg.visible = false
    m.subsWarningLabel.visible = false
end sub

sub onVisibleChanged()
    if not m.top.visible
        clearNavHighlight()
        return
    end if

    if m.top.visible
        if m.detailsScreen <> invalid then m.detailsScreen.visible = false
        if m.seasons <> invalid then m.seasons.visible = false

        m.recentlyWatchedGrid.setFocus(false)
        m.recentMoviesGrid.setFocus(false)
        m.recentSeriesGrid.setFocus(false)
        m.focusZone = "nav"
        updateRowScroll("recentlywatched")
        m.top.isInMenu = true
        m.navFocusedIndex = 1
        updateNavHighlight()
        m.top.setFocus(true)
        updateProfileNavItem()

        ' Antes esto solo recargaba Recien Agregadas (peliculas/series) si
        ' el grid estaba VACIO -- una vez cargado la primera vez, volver
        ' al Home nunca volvia a revisar si habia contenido nuevo en el
        ' servidor (aunque se hubiera subido una pelicula/serie nueva
        ' desde el panel mientras tanto), a diferencia de Recien Vistas/
        ' Favoritos, que si se recargaban siempre. Ahora se recargan
        ' igual que esas dos, cada vez que se vuelve al Home -- las
        ' propias loadRecentMovies()/loadRecentSeries() ya pintan de
        ' inmediato desde el cache local y solo actualizan la fila si el
        ' servidor de verdad trae algo distinto, asi que no se siente
        ' como una recarga completa cada vez.
        loadRecentMovies()
        loadRecentSeries()
        ' Recien Vistas cambia con cada reproduccion, asi que se
        ' recarga siempre al volver al Home (igual que Favoritos).
        m.recentlyWatchedGrid.content = invalid
        loadRecentlyWatched()
        m.favoritesGrid.content = invalid
        loadFavorites()
    end if
end sub

sub onDetailsRequestClose()
    if m.detailsScreen = invalid then return
    m.detailsScreen.visible = false
    restoreFocus()
end sub

sub loadRemoteAssets()
    dt = CreateObject("roDateTime").AsSeconds().ToStr()
    m.logoImage.uri = m.global.panelURL + "/img/logo.png?ts=" + dt
end sub

sub fetchMensaje()
    ' El config.json ya se descarga una sola vez al iniciar la app
    ' (ver MainScene.brs/onConfigResponse); aqui solo se lee el
    ' resultado, sin otra llamada de red aparte para el mensaje.
    onMensajeDone()
    m.global.observeField("mensaje", "onMensajeDone")
end sub

sub onMensajeDone()
    msg = m.global.mensaje
    if msg = invalid then msg = ""
    if msg <> ""
        m.mensajeLabel.text    = msg
        m.mensajeLabel.visible = true
        m.mensajeBg.visible    = true
    else
        m.mensajeLabel.visible = false
        m.mensajeBg.visible    = false
    end if
end sub

' Nombre + inicial/color de avatar del perfil actual en el item de
' "Perfil" de la barra de menu (a la derecha de Ajustes, donde antes
' estaba el reloj). Se llama al iniciar y cada vez que Home vuelve a
' ser visible (por ejemplo, al volver de "Cambiar de Perfil"), para
' que siempre refleje al perfil con el que se esta viendo ahora.
sub updateProfileNavItem()
    nombre = ""
    if m.global.profileNombre <> invalid then nombre = m.global.profileNombre.toStr()
    if nombre = "" then nombre = "Perfil"

    if m.navLabels <> invalid and m.navLabels.Count() > 6 and m.navLabels[6] <> invalid
        m.navLabels[6].text = nombre
    end if
    if m.profileAvatarInitial <> invalid then m.profileAvatarInitial.text = UCase(Left(nombre, 1))

    color = "0x00A8FFFF"
    if m.global.profileColor <> invalid and m.global.profileColor.toStr() <> "" then color = m.global.profileColor.toStr()
    if m.profileAvatarBg <> invalid then m.profileAvatarBg.color = color
end sub

' ============================================================
' Item de "Perfil" en la barra de menu (a la derecha de Ajustes).
' Al darle OK se pregunta si se quiere cambiar de perfil; si dice que
' si, se manda menuItemSelected=5, que MainScene.brs (onHomeMenuSelected)
' interpreta igual que "Cambiar de Perfil" desde Ajustes: quita Home y
' vuelve a mostrar el selector de perfiles.
' ============================================================
sub onProfileNavSelected()
    nombre = ""
    if m.global.profileNombre <> invalid then nombre = m.global.profileNombre.toStr()

    dialog = createObject("roSGNode", "Dialog")
    dialog.title = "Cambiar de perfil"
    if nombre <> ""
        dialog.message = "Hola " + nombre + ", ¿deseas cambiar de perfil?"
    else
        dialog.message = "¿Deseas cambiar de perfil?"
    end if
    dialog.buttons = ["Si", "No"]

    scene = m.top.getScene()
    if scene = invalid then return
    scene.dialog = dialog
    dialog.observeField("buttonSelected", "onChangeProfileRespuesta")
end sub

sub onChangeProfileRespuesta()
    scene = m.top.getScene()
    if scene = invalid then return
    dialog = scene.dialog
    if dialog = invalid then return

    seleccion = dialog.buttonSelected
    dialog.close = true
    scene.dialog = invalid

    if seleccion = 0
        ' "Si" -- volver a la pantalla de seleccion de perfiles.
        m.top.menuItemSelected = 5
    end if
    ' "No" (o cualquier otra cosa) -- no hace nada mas, el dialogo ya
    ' se cerro arriba.
end sub

sub onFocusColorChanged()
    updateNavHighlight()
    if m.mensajeBg <> invalid and m.global.focusColor <> invalid and m.global.focusColor <> ""
        m.mensajeBg.color = m.global.focusColor
    end if
end sub

sub updateNavHighlight()
    focusColor = m.global.focusColor
    if focusColor = invalid or focusColor = "" then focusColor = "0x00A8FFFF"
    for i = 0 to m.totalNavItems - 1
        if i = m.navFocusedIndex
            m.navLabels[i].color = "0xFFFFFFFF"
            m.navBgs[i].color = focusColor
            m.navBgs[i].opacity = 0.8
        else if i = m.activeNavIndex
            m.navLabels[i].color = "0xFFFFFFFF"
            m.navBgs[i].color = focusColor
            m.navBgs[i].opacity = 0.5
        else
            m.navLabels[i].color = "0xAAAAAAFF"
            m.navBgs[i].color = "0x00000000"
            m.navBgs[i].opacity = 0.0
        end if
    end for
end sub

sub clearNavHighlight()
    for i = 0 to m.totalNavItems - 1
        m.navLabels[i].color = "0xAAAAAAFF"
        m.navBgs[i].color = "0x00000000"
        m.navBgs[i].opacity = 0.0
    end for
end sub

sub goToNav()
    m.recentlyWatchedGrid.setFocus(false)
    m.recentMoviesGrid.setFocus(false)
    m.recentSeriesGrid.setFocus(false)
    m.favoritesGrid.setFocus(false)
    m.focusZone = "nav"
    updateRowScroll("recentlywatched")
    m.top.isInMenu = true
    ' SIEMPRE al boton de Home (indice 1), nunca la ultima posicion que
    ' se haya quedado en el menu -- mismo criterio que ya usa
    ' MoviesBrowseScreen.goToNav() con m.currentScreenNav para Peliculas
    ' y Series (cada pantalla vuelve a SU PROPIO boton, no al que haya
    ' quedado resaltado de antes). Antes, si el menu se habia quedado
    ' en otro indice (por ejemplo tras pasar por Series) y se volvia a
    ' Home, "arriba" desde la primera fila dejaba el foco visual en ese
    ' otro boton en vez del de Home.
    m.navFocusedIndex = 1
    updateNavHighlight()
    m.top.setFocus(true)
end sub

' ============================================================
' Navegacion generica entre las filas del contentArea (Recien
' Vistas / Series / Peliculas / Favoritos). Reemplaza el manejo
' ad-hoc que existia antes fila por fila: ahora cualquier fila
' puede estar vacia (tipicamente "Recien Vistas" en un dispositivo
' nuevo) y la navegacion la salta automaticamente.
' ============================================================

function zoneGrid(zoneName as String) as Object
    if zoneName = "recentlywatched" then return m.recentlyWatchedGrid
    if zoneName = "series"           then return m.recentSeriesGrid
    if zoneName = "movies"           then return m.recentMoviesGrid
    if zoneName = "favorites"        then return m.favoritesGrid
    return invalid
end function

function zoneLabel(zoneName as String) as Object
    if zoneName = "recentlywatched" then return m.recentlyWatchedLabel
    if zoneName = "series"           then return m.recentSeriesLabel
    if zoneName = "movies"           then return m.recentMoviesLabel
    if zoneName = "favorites"        then return m.favoritesLabel
    return invalid
end function

function zoneHasContent(zoneName as String) as Boolean
    grid = zoneGrid(zoneName)
    return grid <> invalid and grid.content <> invalid and grid.content.getChildCount() > 0
end function

function zoneIndex(zoneName as String) as Integer
    for i = 0 to m.zoneOrder.count() - 1
        if m.zoneOrder[i] = zoneName then return i
    end for
    return -1
end function

' Siguiente fila hacia abajo (o la primera de todas si zoneName=""),
' saltando filas vacias. Devuelve "" si no hay ninguna mas abajo.
function nextZoneDown(zoneName as String) as String
    i = zoneIndex(zoneName) + 1
    while i < m.zoneOrder.count()
        if zoneHasContent(m.zoneOrder[i]) then return m.zoneOrder[i]
        i = i + 1
    end while
    return ""
end function

' Fila anterior hacia arriba, saltando vacias. Devuelve "" si hay
' que salir del contentArea (ir al menu de arriba).
function nextZoneUp(zoneName as String) as String
    i = zoneIndex(zoneName) - 1
    while i >= 0
        if zoneHasContent(m.zoneOrder[i]) then return m.zoneOrder[i]
        i = i - 1
    end while
    return ""
end function

' Ventana de 2 filas visibles a la vez. La fila con foco siempre va
' arriba, completa; la siguiente (si existe) se asoma a la mitad
' abajo con un degradado -- al llegar a la ultima fila, no hay
' siguiente que asomar y el degradado se oculta.
' El degradado inferior vive por encima de todo (declarado al final del
' XML para quedar sobre las portadas) -- pero eso tambien lo pone
' encima de Detalles/Temporadas (incluyendo el reproductor de video).
' Se oculta mientras cualquiera de esos este abierto, y se restaura
' segun corresponda al cerrarse.
sub onOverlayVisibleChanged()
    overlayOpen = false
    if m.detailsScreen <> invalid and m.detailsScreen.visible then overlayOpen = true
    if m.seasons <> invalid and m.seasons.visible then overlayOpen = true

    if overlayOpen
        if m.rowFadeBottom <> invalid then m.rowFadeBottom.visible = false
    else
        updateRowScroll(m.focusZone)
    end if
end sub

sub updateRowScroll(zoneName as String)
    idx = zoneIndex(zoneName)
    if idx < 0 then idx = 0
    windowStart = idx

    for i = 0 to m.zoneOrder.count() - 1
        name = m.zoneOrder[i]
        hasContent = zoneHasContent(name)
        lbl  = zoneLabel(name)
        grid = zoneGrid(name)
        ' Ya no se prende/apaga "justo a tiempo" segun la ventana --
        ' eso causaba que la fila entrante apareciera de golpe cerca
        ' de arriba al subir (se veia como que "caia"). Ahora toda fila
        ' con contenido queda visible siempre, y el recorte
        ' (clippingRect en contentArea) es quien oculta lo que este
        ' fuera del area visible, sin importar la direccion.
        if lbl  <> invalid then lbl.visible  = hasContent
        if grid <> invalid then grid.visible = hasContent
    end for

    ' Cada fila ocupa 252.3px (label + grid + separacion), mismo
    ' valor que ya usaba este Home entre filas.
    targetY = 0 - (windowStart * 252.3)
    slideContentAreaTo(targetY)

    ' El degradado de abajo solo se muestra si hay una fila siguiente
    ' con contenido que asomar (si no, no tiene caso insinuar mas).
    hasNext = false
    j = idx + 1
    while j < m.zoneOrder.count()
        if zoneHasContent(m.zoneOrder[j])
            hasNext = true
            exit while
        end if
        j = j + 1
    end while
    overlayOpen = false
    if m.detailsScreen <> invalid and m.detailsScreen.visible then overlayOpen = true
    if m.seasons <> invalid and m.seasons.visible then overlayOpen = true
    if m.rowFadeBottom <> invalid then m.rowFadeBottom.visible = (hasNext and not overlayOpen)
end sub

' Anima el deslizamiento de contentArea hacia targetY en vez de saltar
' de golpe (misma Animation node reutilizada en cada llamada).
sub slideContentAreaTo(targetY as Float)
    m.isSliding = true
    if m.contentAreaSlide = invalid or m.contentAreaSlideInterp = invalid then
        if m.contentArea <> invalid then m.contentArea.translation = [0, targetY]
        m.isSliding = false
        return
    end if
    currentY = m.contentArea.translation[1]
    m.contentAreaSlide.control = "stop"
    m.contentAreaSlideInterp.keyValue = [[0.0, currentY], [0.0, targetY]]
    m.contentAreaSlide.control = "start"
end sub

' Se libera el seguro cuando la animacion termina. Si mientras
' deslizaba se presiono abajo/arriba de nuevo (ignorado momentaneamente
' para no encimar animaciones), aqui se aplica esa ultima intencion en
' vez de perderla -- se siente como "en cola", no como trabado.
sub onContentAreaSlideDone()
    if m.contentAreaSlide.state <> "stopped" then return
    m.isSliding = false
    print "DEBUG SLIDEDONE - pendingSlideZone="; m.pendingSlideZone; " m.focusZone actual="; m.focusZone
    if m.pendingSlideZone <> ""
        zone = m.pendingSlideZone
        m.pendingSlideZone = ""
        enterZone(zone)
    end if
end sub

' Le da foco a una fila del contentArea, ajustando scroll/visibilidad.
sub enterZone(zoneName as String)
    m.recentlyWatchedGrid.setFocus(false)
    m.recentSeriesGrid.setFocus(false)
    m.recentMoviesGrid.setFocus(false)
    m.favoritesGrid.setFocus(false)

    m.focusZone = zoneName
    updateRowScroll(zoneName)

    grid = zoneGrid(zoneName)
    hasContentNow = (grid <> invalid and grid.content <> invalid and grid.content.getChildCount() > 0)
    print "DEBUG ENTERZONE - zoneName="; zoneName; " grid.visible="; grid.visible; " hasContentNow="; hasContentNow
    if grid <> invalid then grid.setFocus(true)
    print "DEBUG ENTERZONE - despues de setFocus(true), grid.hasFocus()="; grid.hasFocus(); " m.top.hasFocus()="; m.top.hasFocus()
end sub

sub updateHeroFromItem(item as Object)
    if item = invalid then return
    m.heroInfoGroup.visible = false
    titulo = item.title
    if titulo = invalid then titulo = ""
    parenIdx = Instr(1, titulo, " (")
    if parenIdx > 1 then titulo = Left(titulo, parenIdx - 1)
    m.heroTitle.text = UCase(titulo)

    m.heroRating.visible = false
    m.heroRatingIcon.visible = false
    m.heroRatingBg.visible = false
    m.heroRating.text = ""
    m.heroYearIcon.visible = false
    m.heroYear.text = ""
    m.heroDurIcon.visible = false
    if m.heroDuration <> invalid then m.heroDuration.text = ""
    if m.heroGenre <> invalid then m.heroGenre.text = ""
    m.heroDesc.text = ""

    m.heroInfoGroup.visible = true

    vodId = item.id
    if vodId = invalid then vodId = ""

    if vodId <> "" and m.backdropCache.DoesExist(vodId)
        cachedUri = m.backdropCache[vodId]
        if cachedUri <> m.heroLastUri
            m.heroLastUri = cachedUri
            m.heroBgBack.uri = cachedUri
            m.heroFadeOut.control = "start"
            m.heroFadeIn.control = "start"
        end if
        return
    end if

    ' Respaldo: la portada del titulo (si existe), usada SOLO como
    ' ultimo recurso si la consulta al servidor confirma que no hay
    ' fondo dedicado (ver onVodInfoResult). No se muestra de inmediato
    ' aqui -- eso causaba un "flash" feo (portada -> fondo real) cada
    ' vez que el fondo no venia ya en la lista.
    m.heroPosterFallback = ""
    if item.HDPosterUrl <> invalid and item.HDPosterUrl <> "" and item.HDPosterUrl <> "pkg:/images/no-poster.jpg"
        m.heroPosterFallback = item.HDPosterUrl
    end if

    if item.hdBackgroundImageUrl <> invalid and item.hdBackgroundImageUrl <> ""
        newUri = item.hdBackgroundImageUrl
        if vodId <> "" then m.backdropCache[vodId] = newUri
        if newUri <> m.heroLastUri
            m.heroLastUri = newUri
            m.heroBgBack.uri = newUri
            m.heroFadeOut.control = "start"
            m.heroFadeIn.control = "start"
        end if
        return
    end if

    if vodId <> "" and vodId <> m.heroLastVodId
        m.heroLastVodId = vodId
        if m.vodInfoTask <> invalid
            m.vodInfoTask.control = "stop"
            m.vodInfoTask = invalid
        end if
        m.vodInfoTask = CreateObject("roSGNode", "GetVodInfo")
        m.vodInfoTask.vodId = vodId
        m.vodInfoTask.observeField("result", "onVodInfoResult")
        m.vodInfoTask.control = "RUN"
    end if
end sub

sub onVodInfoResult()
    result = m.vodInfoTask.result
    if result = invalid then return
    vodId = m.vodInfoTask.vodId
    if vodId <> m.heroLastVodId then return ' el usuario ya se movio a otro item, ignorar

    if result.hdBackgroundImageUrl <> invalid and result.hdBackgroundImageUrl <> ""
        newUri = result.hdBackgroundImageUrl
        if vodId <> "" then m.backdropCache[vodId] = newUri
        if newUri <> m.heroLastUri
            m.heroLastUri = newUri
            m.heroBgBack.uri = newUri
            m.heroFadeOut.control = "start"
            m.heroFadeIn.control = "start"
        end if
    else if m.heroPosterFallback <> "" and m.heroPosterFallback <> m.heroLastUri
        ' El servidor confirma que este titulo no tiene fondo dedicado:
        ' se usa la portada como ultimo recurso (unica transicion aqui,
        ' no hay "flash" porque es la primera vez que se toca el fondo
        ' para este item).
        m.heroLastUri = m.heroPosterFallback
        m.heroBgBack.uri = m.heroPosterFallback
        m.heroFadeOut.control = "start"
        m.heroFadeIn.control = "start"
    end if
end sub

sub onHeroCrossfadeComplete()
    if m.heroFadeOut.state = "stopped"
        m.heroBgFront.uri = m.heroBgBack.uri
        m.heroBgFront.opacity = 1.0
        m.heroBgBack.opacity = 0.0
        ' La imagen que acaba de quedar al frente arranca su propio
        ' zoom continuo de 10s (se detiene y reinicia en cada cambio de
        ' diapositiva, ver setHeroCarouselUri).
        if m.heroZoomLoop <> invalid
            m.heroZoomLoop.control = "stop"
            m.heroZoomLoop.control = "start"
        end if
    end if
end sub

' ============================================================
' Carrusel automatico del fondo de Home (reemplaza el sistema anterior
' de "fondo sigue al foco" -- updateHeroFromItem/onMovieFocused/
' onSerieFocused/onFavoriteFocused/onRecentlyWatchedFocused, que ya no
' se conectan a nada). Rota siempre, sin importar que fila tenga el
' foco, entre los backdrops de las 2 series y las 2 peliculas mas
' recientes -- igual que el HeroBannerController de Android (10s por
' diapositiva, con zoom continuo).
' ============================================================

sub refreshHeroCarouselItems()
    items = []

    if m.recentSeriesGrid <> invalid and m.recentSeriesGrid.content <> invalid
        cnt = m.recentSeriesGrid.content.getChildCount()
        for i = 0 to 1
            if i < cnt then items.push({ node: m.recentSeriesGrid.content.getChild(i), isSerie: true })
        end for
    end if

    if m.recentMoviesGrid <> invalid and m.recentMoviesGrid.content <> invalid
        cnt = m.recentMoviesGrid.content.getChildCount()
        for i = 0 to 1
            if i < cnt then items.push({ node: m.recentMoviesGrid.content.getChild(i), isSerie: false })
        end for
    end if

    wasEmpty = (m.heroCarouselItems = invalid or m.heroCarouselItems.count() = 0)
    m.heroCarouselItems = items

    if items.count() = 0
        if m.heroCarouselTimer <> invalid then m.heroCarouselTimer.control = "stop"
        return
    end if

    if m.heroCarouselIndex = invalid or m.heroCarouselIndex >= items.count() then m.heroCarouselIndex = -1

    if wasEmpty
        m.heroCarouselIndex = 0
        showHeroCarouselSlide(0)
        if m.heroCarouselTimer <> invalid then m.heroCarouselTimer.control = "start"
    end if
end sub

sub onHeroCarouselTimerFire()
    if m.heroCarouselItems = invalid or m.heroCarouselItems.count() = 0 then return
    nextIdx = (m.heroCarouselIndex + 1) mod m.heroCarouselItems.count()
    m.heroCarouselIndex = nextIdx
    showHeroCarouselSlide(nextIdx)
end sub

sub showHeroCarouselSlide(idx as Integer)
    if m.heroCarouselItems = invalid or idx < 0 or idx >= m.heroCarouselItems.count() then return
    entry = m.heroCarouselItems[idx]
    item = entry.node
    if item = invalid then return

    ' Pedido explicito: regresar el titulo del backdrop mostrado (se
    ' actualiza de una vez con la diapositiva, sin esperar a que
    ' termine de cargar/confirmarse el backdrop).
    applyHeroTitleFor(item)

    uri = heroBackdropUriFor(item)
    if uri = ""
        ' Sin backdrop todavia en el nodo: pedirlo al servidor (mismo
        ' GetVodInfo/GetSeriesInfo que ya se usaba antes para esto) y
        ' mostrar esta diapositiva en cuanto llegue la respuesta.
        fetchHeroCarouselBackdrop(item, entry.isSerie, idx)
        return
    end if

    setHeroCarouselUri(uri)
end sub

' Mismo criterio que el updateHeroFromItem/updateHeroFromItemSerie de
' antes (ver mas abajo, ya sin usar): titulo sin el "(año)" del final,
' en mayusculas. El resto de heroInfoGroup (rating/año/duracion/genero/
' descripcion) nunca tuvo datos reales en esta pantalla -- se deja
' oculto igual que ya quedaba antes, solo se muestra el titulo, en la
' misma posicion que usa Android (ver HomeScreen.xml, heroTitle).
sub applyHeroTitleFor(item as Object)
    if item = invalid then return
    titulo = item.title
    if titulo = invalid then titulo = ""
    parenIdx = Instr(1, titulo, " (")
    if parenIdx > 1 then titulo = Left(titulo, parenIdx - 1)
    m.heroTitle.text = UCase(titulo)

    m.heroRating.visible = false
    m.heroRatingIcon.visible = false
    m.heroRatingBg.visible = false
    m.heroRating.text = ""
    m.heroYearIcon.visible = false
    m.heroYear.text = ""
    m.heroDurIcon.visible = false
    if m.heroDuration <> invalid then m.heroDuration.text = ""
    if m.heroGenre <> invalid then m.heroGenre.text = ""
    m.heroDesc.text = ""

    m.heroInfoGroup.visible = true
end sub

' Pedido explicito: se estaba mostrando la PORTADA en vez del backdrop
' real -- esta funcion regresaba HDPosterUrl/streamIcon de inmediato
' cuando el nodo no traia hdBackgroundImageUrl ya cargado, y los items
' de "recien agregados" casi nunca lo traen (eso requiere consultar
' get_vod_info/get_series_info aparte). Ahora SOLO reporta un backdrop
' ya confirmado; si no hay, showHeroCarouselSlide pide el real al
' servidor (fetchHeroCarouselBackdrop) y la portada queda solo como
' ultimo recurso, SOLO si el servidor confirma que no hay backdrop
' dedicado (ver onHeroCarouselBackdropResult).
function heroBackdropUriFor(item as Object) as String
    if item = invalid then return ""
    if item.hdBackgroundImageUrl <> invalid and item.hdBackgroundImageUrl <> "" then return item.hdBackgroundImageUrl
    return ""
end function

function heroPosterFallbackFor(item as Object) as String
    if item = invalid then return ""
    if item.HDPosterUrl <> invalid and item.HDPosterUrl <> "" and item.HDPosterUrl <> "pkg:/images/no-poster.jpg" then return item.HDPosterUrl
    if item.streamIcon <> invalid and item.streamIcon <> "" and item.streamIcon <> "pkg:/images/no-poster.jpg" then return item.streamIcon
    return ""
end function

sub setHeroCarouselUri(uri as String)
    if uri = "" or uri = m.heroLastUri then return
    m.heroLastUri = uri
    if m.heroZoomLoop <> invalid then m.heroZoomLoop.control = "stop"
    m.heroBgBack.uri = uri
    m.heroFadeOut.control = "start"
    m.heroFadeIn.control = "start"
end sub

sub fetchHeroCarouselBackdrop(item as Object, isSerie as Boolean, idx as Integer)
    vodId = item.id
    if vodId = invalid or vodId = ""
        ' Sin id no se puede consultar al servidor -- unico caso en que
        ' se usa la portada de una vez, sin esperar nada.
        setHeroCarouselUri(heroPosterFallbackFor(item))
        return
    end if
    if isSerie
        task = CreateObject("roSGNode", "GetSeriesInfo")
        task.seriesId = vodId
    else
        task = CreateObject("roSGNode", "GetVodInfo")
        task.vodId = vodId
    end if
    task.addFields({ carouselIdx: idx, carouselPosterFallback: heroPosterFallbackFor(item) })
    task.observeField("result", "onHeroCarouselBackdropResult")
    if m.heroCarouselTasks = invalid then m.heroCarouselTasks = []
    m.heroCarouselTasks.push(task)
    task.control = "RUN"
end sub

sub onHeroCarouselBackdropResult(event as Object)
    task = event.getRoSGNode()
    if task = invalid then return
    result = task.result
    idx = task.carouselIdx
    posterFallback = task.carouselPosterFallback
    if posterFallback = invalid then posterFallback = ""

    uri = ""
    if result <> invalid and result.hdBackgroundImageUrl <> invalid and result.hdBackgroundImageUrl <> "" then uri = result.hdBackgroundImageUrl

    if uri <> "" and m.heroCarouselItems <> invalid and idx >= 0 and idx < m.heroCarouselItems.count()
        entry = m.heroCarouselItems[idx]
        if entry <> invalid and entry.node <> invalid then entry.node.hdBackgroundImageUrl = uri
    end if

    ' El servidor confirma que este titulo no tiene backdrop dedicado:
    ' AHORA si se usa la portada, como ultimo recurso.
    if uri = "" then uri = posterFallback
    if uri = "" then return

    ' Solo se pinta ahora si el carrusel sigue en (o esta a punto de
    ' mostrar) precisamente esta diapositiva.
    if idx = m.heroCarouselIndex then setHeroCarouselUri(uri)
end sub

sub onMovieFocused()
    if m.recentMoviesGrid.content = invalid then return
    idx = m.recentMoviesGrid.itemFocused
    if idx >= 0 and idx < m.recentMoviesGrid.content.getChildCount()
        updateHeroFromItem(m.recentMoviesGrid.content.getChild(idx))
    end if
end sub

sub onSerieFocused()
    if m.recentSeriesGrid.content = invalid then return
    idx = m.recentSeriesGrid.itemFocused
    if idx >= 0 and idx < m.recentSeriesGrid.content.getChildCount()
        updateHeroFromItemSerie(m.recentSeriesGrid.content.getChild(idx))
    end if
end sub

sub updateHeroFromItemSerie(item as Object)
    if item = invalid then return
    m.heroInfoGroup.visible = false
    titulo = item.title
    if titulo = invalid then titulo = ""
    parenIdx = Instr(1, titulo, " (")
    if parenIdx > 1 then titulo = Left(titulo, parenIdx - 1)
    m.heroTitle.text = UCase(titulo)

    m.heroRating.visible = false
    m.heroRatingIcon.visible = false
    m.heroRatingBg.visible = false
    m.heroRating.text = ""
    m.heroYearIcon.visible = false
    m.heroYear.text = ""
    m.heroDurIcon.visible = false
    if m.heroDuration <> invalid then m.heroDuration.text = ""
    if m.heroGenre <> invalid then m.heroGenre.text = ""
    m.heroDesc.text = ""

    newUri = ""
    if item.hdBackgroundImageUrl <> invalid and item.hdBackgroundImageUrl <> ""
        newUri = item.hdBackgroundImageUrl
    else if item.HDPosterUrl <> invalid and item.HDPosterUrl <> "" and item.HDPosterUrl <> "pkg:/images/no-poster.jpg"
        newUri = item.HDPosterUrl
    else if item.streamIcon <> invalid and item.streamIcon <> "" and item.streamIcon <> "pkg:/images/no-poster.jpg"
        newUri = item.streamIcon
    end if
    if newUri <> "" and newUri <> m.heroLastUri
        m.heroLastUri = newUri
        m.heroBgBack.uri = newUri
        m.heroFadeOut.control = "start"
        m.heroFadeIn.control = "start"
    end if
    m.heroInfoGroup.visible = true
end sub

sub loadRecentlyWatched()
    if m.recentlyWatchedTask <> invalid and m.recentlyWatchedTask.control = "RUN" then return

    ' Se muestra YA el contenido local real (sin esperar red), y en
    ' silencio se sincroniza/actualiza despues -- da la impresion de
    ' que la app es mas rapida, en vez de dejar la fila vacia o con
    ' shimmer mientras carga.
    localItems = RW_LocalListAllSorted(18)
    if localItems.count() > 0
        localContent = createObject("roSGNode", "ContentNode")
        for each aa in localItems
            node = Fav_AAToNode(aa)
            if aa.tipo = "serie"
                if not node.hasField("isSerie") then node.addFields({isSerie: true})
            end if
            ' setFields() (adentro de Fav_AAToNode) solo asigna campos
            ' que YA existen en el nodo -- sin esto, "Continuar viendo"
            ' (checkRWResumeSerie) no encontraria el ultimo capitulo
            ' visto mientras se pinta desde el cache local (antes de que
            ' termine de sincronizar con el servidor, ver mas abajo).
            if aa.lastEpisodeId <> invalid and aa.lastEpisodeId <> ""
                node.addFields({lastEpisodeId: aa.lastEpisodeId.toStr()})
            else if not node.hasField("lastEpisodeId")
                node.addFields({lastEpisodeId: ""})
            end if
            ' Mismo motivo que lastEpisodeId de arriba: setFields() no
            ' crea campos nuevos, asi que lastEpisodeData (los datos
            ' completos del capitulo para "Continuar viendo") se pierde
            ' en silencio si no se agrega asi explicitamente.
            if aa.lastEpisodeData <> invalid and aa.lastEpisodeData <> ""
                node.addFields({lastEpisodeData: aa.lastEpisodeData.toStr()})
            else if not node.hasField("lastEpisodeData")
                node.addFields({lastEpisodeData: ""})
            end if
            localContent.appendChild(node)
        end for
        m.recentlyWatchedGrid.content = localContent
    end if

    ' ESTO FALTABA POR COMPLETO: WP_SyncFromServer (el "descargar
    ' avance del servidor" de WatchProgressLocalStore.brs) existia
    ' desde hace tiempo pero nada en toda la app lo llamaba -- el
    ' avance ("seguir viendo") solo se leia del cache local de ESTE
    ' dispositivo, asi que lo que se avanzaba en otro (Android, u otro
    ' Roku) nunca se veia reflejado aqui aunque el servidor si lo
    ' tuviera guardado. No necesita pintar nada por su cuenta: solo
    ' refresca el cache local en disco que checkRWResumeMovie/
    ' checkRWResumeSerie ya leen directo (WP_LocalRead).
    m.progressSyncTask = createObject("roSGNode", "HomeContentTask")
    m.progressSyncTask.taskType = "progress"
    m.progressSyncTask.control = "RUN"

    m.recentlyWatchedTask = createObject("roSGNode", "HomeContentTask")
    m.recentlyWatchedTask.taskType = "recentlyWatched"
    m.recentlyWatchedTask.observeField("contentResults", "onRecentlyWatchedLoaded")
    m.recentlyWatchedTask.control = "RUN"
end sub

sub onRecentlyWatchedLoaded()
    if m.recentlyWatchedTask = invalid then return
    content = m.recentlyWatchedTask.contentResults
    if content = invalid then return
    m.recentlyWatchedGrid.content = content
    ' La fila puede aparecer/desaparecer segun tenga o no contenido
    ' (a diferencia de las otras filas, en un dispositivo nuevo esta
    ' arranca vacia), asi que recalculamos que se ve.
    updateRowScroll(m.focusZone)
    ' Reasignar content a un grid enfocado le puede quitar el foco a
    ' toda la pantalla en silencio (sin aviso) -- si la fila que se
    ' acaba de recargar es la que esta activa ahora mismo, se le
    ' regresa el foco explicitamente para no quedar sin nada enfocado.
    if m.focusZone = "recentlywatched" then m.recentlyWatchedGrid.setFocus(true)
end sub

sub onRecentlyWatchedFocused()
    if m.recentlyWatchedGrid.content = invalid then return
    idx = m.recentlyWatchedGrid.itemFocused
    if idx < 0 or idx >= m.recentlyWatchedGrid.content.getChildCount() then return
    item = m.recentlyWatchedGrid.content.getChild(idx)
    if item = invalid then return
    if item.doesExist("isSerie") and item.isSerie = true
        updateHeroFromItemSerie(item)
    else
        updateHeroFromItem(item)
    end if
end sub

sub onRecentlyWatchedSelected()
    if m.recentlyWatchedGrid.content = invalid then return
    idx = m.recentlyWatchedGrid.itemSelected
    if idx < 0 or idx >= m.recentlyWatchedGrid.content.getChildCount() then return
    item = m.recentlyWatchedGrid.content.getChild(idx)
    if item = invalid then return
    m.lastFocusZone = "recentlywatched"
    m.lastZoneIdx = idx
    if item.doesExist("isSerie") and item.isSerie = true
        checkRWResumeSerie(item)
    else
        checkRWResumeMovie(item)
    end if
end sub

' ============================================================
' "Continuar viendo" -- SOLO en la fila de Recien Vistas (a
' diferencia de Favoritos/Peliculas recientes/Series recientes, que
' siguen abriendo la pagina normal de siempre sin preguntar nada).
' Si el item tiene un avance real guardado (>= 3 seg, y no ya casi
' terminado), se pregunta primero; si no, se abre la pagina normal
' tal como ya funcionaba.
' ============================================================

' Mismo criterio que ya usan DetailsScreen.resume()/Seasons.resume()
' al presionar Play/seleccionar un capitulo: el registro local
' especifico de esa pantalla (MovieResume/SerieResume, mas preciso
' pero solo de este dispositivo) manda; si no hay nada ahi (o es muy
' poco), se cae al progreso sincronizado (WatchProgressLocalStore),
' que si viaja entre dispositivos.
function RW_ResumePosFor(cve as String, section as String) as Integer
    ' "pos" a secas NO se puede usar como nombre de variable local --
    ' es una funcion builtin heredada de BrightScript (POS(0), columna
    ' de impresion) y el compilador la reclama como "Builtin function
    ' call expected". Por eso en el resto de la app siempre se usa
    ' "resumePos"/"curPos"/"posSec" en vez de "pos" a secas (wp.pos,
    ' como CAMPO de un objeto, si esta bien -- el choque es solo con el
    ' nombre de variable suelto).
    resumePos = 0
    raw = RegRead(cve, section)
    if raw <> invalid and raw.toInt() >= 3 then resumePos = raw.toInt()
    if resumePos < 3
        wp = WP_LocalRead(cve)
        if wp <> invalid and wp.pos <> invalid and wp.pos >= 3 then resumePos = wp.pos
    end if
    return resumePos
end function

sub checkRWResumeMovie(item as Object)
    vodId = ""
    if item.id <> invalid then vodId = item.id.toStr()
    if vodId = ""
        openRWDetailsNormal(item)
        return
    end if

    resumePos = RW_ResumePosFor(vodId, "MovieResume")

    ' Si ya esta en el ultimo 10% de la duracion (cuando se conoce), no
    ' tiene caso ofrecer "continuar" -- mismo criterio que DetailsScreen.resume().
    dur = 0
    wp = WP_LocalRead(vodId)
    if wp <> invalid and wp.duration <> invalid then dur = wp.duration
    lenOk = true
    if dur > 0 and resumePos >= (dur * 0.9) then lenOk = false

    if resumePos >= 3 and lenOk
        m.rwResumePos = resumePos
        m.rwResumeIsSerie = false
        showRWResumeDialog(item)
    else
        openRWDetailsNormal(item)
    end if
end sub

sub checkRWResumeSerie(item as Object)
    epId = ""
    if item.doesExist("lastEpisodeId") and item.lastEpisodeId <> invalid then epId = item.lastEpisodeId.toStr()

    ' Sin lastEpisodeId (perfiles/registros viejos, de antes de que se
    ' empezara a guardar) no hay forma de saber cual capitulo continuar.
    if epId = ""
        openRWSeasonsNormal(item)
        return
    end if

    resumePos = RW_ResumePosFor(epId, "SerieResume")
    if resumePos >= 3
        m.rwResumePos = resumePos
        m.rwResumeIsSerie = true
        m.rwResumeEpisodeId = epId
        showRWResumeDialog(item)
    else
        openRWSeasonsNormal(item)
    end if
end sub

sub showRWResumeDialog(item as Object)
    m.rwPendingItem = item

    titulo = ""
    if item.title <> invalid then titulo = item.title.toStr()

    dialog = createObject("roSGNode", "Dialog")
    dialog.title = "Continuar viendo"
    if titulo <> ""
        dialog.message = "¿Quieres continuar viendo " + titulo + " donde te quedaste?"
    else
        dialog.message = "¿Quieres continuar donde te quedaste?"
    end if
    dialog.buttons = ["Si, continuar", "Ver desde el inicio", "No, elegir"]

    scene = m.top.getScene()
    if scene = invalid then return
    scene.dialog = dialog
    dialog.observeField("buttonSelected", "onRWResumeRespuesta")
end sub

sub onRWResumeRespuesta()
    scene = m.top.getScene()
    if scene = invalid then return
    dialog = scene.dialog
    if dialog = invalid then return

    seleccion = dialog.buttonSelected
    dialog.close = true
    scene.dialog = invalid

    item = m.rwPendingItem
    if item = invalid then return

    if seleccion = 0
        ' "Si, continuar" -- desde donde se quedo.
        if m.rwResumeIsSerie
            playRWSerieDirect(item)
        else
            openRWDetailsResume(item)
        end if
    else if seleccion = 1
        ' "Ver desde el inicio" -- mismo capitulo/pelicula que iba a
        ' continuar, pero arrancando en el segundo 0 en vez de la
        ' posicion guardada (sin pasar por la pagina normal).
        m.rwResumePos = 0
        if m.rwResumeIsSerie
            playRWSerieDirect(item)
        else
            openRWDetailsResume(item)
        end if
    else
        ' "No, elegir" -- pagina normal, igual que antes.
        if m.rwResumeIsSerie
            openRWSeasonsNormal(item)
        else
            openRWDetailsNormal(item)
        end if
    end if
end sub

' --- Pelicula: pagina normal (con Reproducir/Favorito), igual que al ---
' --- presionar cualquier portada de pelicula en el resto de la app.  ---
sub openRWDetailsNormal(item as Object)
    m.global.play = "/movie/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie = "false"
    m.detailsScreen.content = item
    m.detailsScreen.visible = true
    m.detailsScreen.setFocus(true)
end sub

' --- Pelicula: "Si, continuar" -- reproduce de una vez desde el punto ---
' --- guardado, sin pasar por la pagina de Reproducir/Favorito.       ---
sub openRWDetailsResume(item as Object)
    m.global.play = "/movie/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie = "false"
    m.detailsScreen.resumeFromRW = m.rwResumePos
    m.detailsScreen.content = item
    m.detailsScreen.visible = true
    m.detailsScreen.setFocus(true)
end sub

' --- Serie: pagina normal de temporadas/capitulos, igual que al ---
' --- presionar cualquier portada de serie en el resto de la app. ---
sub openRWSeasonsNormal(item as Object)
    m.global.play = "/series/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie = "true"
    m.global.episode = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series_info&series_id="
    m.seasons.content = item
    m.seasons.visible = true
    m.seasons.setFocus(true)
end sub

' --- Serie: "Si, continuar" / "Ver desde el inicio" -- alimenta el ---
' --- reproductor DIRECTO con los datos del capitulo que ya se      ---
' --- guardaron al verlo (ver Seasons.brs/registerRecentlyWatched), ---
' --- sin volver a pedirle nada al servidor. Antes esto buscaba el  ---
' --- capitulo por red (FindEpisodeTask, revisando temporada por    ---
' --- temporada); esa busqueda a veces no volvia y la pantalla se   ---
' --- quedaba trabada sin reproducir nada. Ahora es puramente local ---
' --- y no puede "colgarse": si faltan los datos (registro viejo,   ---
' --- de antes de este cambio, o incompleto), se cae a la pagina    ---
' --- normal de temporadas de una vez.                              ---
sub playRWSerieDirect(item as Object)
    epAA = invalid
    if item.doesExist("lastEpisodeData")
        raw = item.lastEpisodeData
        if raw <> invalid and raw.toStr() <> ""
            epAA = ParseJSON(raw.toStr())
        end if
    end if

    ' Cada chequeo por separado (nunca combinados con "or" en la misma
    ' linea): si epAA resultara invalid, evaluar epAA.id en la misma
    ' condicion se puede reventar -- ese fue justo el bug que dejaba
    ' la pantalla trabada antes.
    if epAA = invalid
        openRWSeasonsNormal(item)
        return
    end if
    if type(epAA) <> "roAssociativeArray"
        openRWSeasonsNormal(item)
        return
    end if
    ' Se exige "id" (SIEMPRE presente, venga de Roku o de Android), no
    ' "url": si el ultimo capitulo se vio en Android, el JSON nunca
    ' trae "url" (Android arma su propia URL con id+ext, ver
    ' EpisodeCache en LocalModels.kt) -- RW_EpisodeAAToNode() ya sabe
    ' reconstruirla a partir de "id"/"ext" con la misma formula que usa
    ' GetEpisodes.brs, asi que no hace falta rendirse aqui por eso.
    if epAA.id = invalid or epAA.id.toStr() = ""
        openRWSeasonsNormal(item)
        return
    end if

    m.global.play = "/series/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie = "true"
    m.global.episode = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series_info&series_id="

    m.seasons.directPlayEpisode = RW_EpisodeAAToNode(epAA)
    m.seasons.directPlayPos = m.rwResumePos
    m.seasons.content = item
    m.seasons.visible = true
    m.seasons.setFocus(true)
end sub

sub loadRecentMovies()
    print "DEBUG HomeScreen.loadRecentMovies llamado"
    if m.recentMoviesTask <> invalid and m.recentMoviesTask.control = "RUN" then return

    ' Pintar de inmediato desde el cache local (sin esperar red); la
    ' sync real sigue igual, en silencio, justo debajo.
    localItems = RA_LocalRead("movies")
    huboCacheLocal = false
    if localItems <> invalid and localItems.count() > 0
        cn = RA_ItemsToContentNode(localItems)
        m.recentMoviesGrid.content = cn
        huboCacheLocal = true
        print "DEBUG RECENTMOVIES-CACHE - orden pintado desde cache local:"
        for i = 0 to cn.getChildCount() - 1
            print "  #"; i; " "; cn.getChild(i).title
        end for
        refreshHeroCarouselItems()
    end if

    if not huboCacheLocal and m.loading <> invalid then m.loading.control = "start"
    m.recentMoviesTask = createObject("roSGNode", "HomeContentTask")
    m.recentMoviesTask.taskType = "recentMovies"
    m.recentMoviesTask.observeField("contentResults", "onRecentMoviesLoaded")
    m.recentMoviesTask.control = "RUN"
end sub

sub onRecentMoviesLoaded()
    if m.recentMoviesTask = invalid or m.recentMoviesTask.contentResults = invalid then return
    if m.loading <> invalid then m.loading.control = "stop"
    content = m.recentMoviesTask.contentResults
    if content <> invalid and content.getChildCount() > 0
        m.recentMoviesGrid.content = content
        print "DEBUG RECENTMOVIES-FRESH - orden recibido del servidor (ya ordenado por sortByAdded):"
        for i = 0 to content.getChildCount() - 1
            print "  #"; i; " "; content.getChild(i).title
        end for
        refreshHeroCarouselItems()
        ' Guardar para la proxima vez que se entre al Home (pintar
        ' instantaneo desde cache en vez de esperar red de nuevo).
        aaList = []
        for i = 0 to content.getChildCount() - 1
            aaList.push(Fav_NodeToAA(content.getChild(i), Fav_VodSerieFields()))
        end for
        RA_LocalWrite("movies", aaList)
    end if
    updateRowScroll(m.focusZone)
    if m.focusZone = "movies" then m.recentMoviesGrid.setFocus(true)
end sub

sub loadRecentSeries()
    if m.recentSeriesTask <> invalid and m.recentSeriesTask.control = "RUN" then return

    localItems = RA_LocalRead("series")
    if localItems <> invalid and localItems.count() > 0
        cn = RA_ItemsToContentNode(localItems)
        m.recentSeriesGrid.content = cn
        print "DEBUG RECENTSERIES-CACHE - orden pintado desde cache local:"
        for i = 0 to cn.getChildCount() - 1
            print "  #"; i; " "; cn.getChild(i).title
        end for
        refreshHeroCarouselItems()
    end if

    m.recentSeriesTask = createObject("roSGNode", "HomeContentTask")
    m.recentSeriesTask.taskType = "recentSeries"
    m.recentSeriesTask.observeField("contentResults", "onRecentSeriesLoaded")
    m.recentSeriesTask.control = "RUN"
end sub

sub onRecentSeriesLoaded()
    content = m.recentSeriesTask.contentResults
    if content <> invalid and content.getChildCount() > 0
        m.recentSeriesGrid.content = content
        print "DEBUG RECENTSERIES-FRESH - orden recibido del servidor (ya ordenado por sortByAdded):"
        for i = 0 to content.getChildCount() - 1
            print "  #"; i; " "; content.getChild(i).title
        end for
        refreshHeroCarouselItems()
        aaList = []
        for i = 0 to content.getChildCount() - 1
            aaList.push(Fav_NodeToAA(content.getChild(i), Fav_VodSerieFields()))
        end for
        RA_LocalWrite("series", aaList)
    end if
    updateRowScroll(m.focusZone)
    if m.focusZone = "series" then m.recentSeriesGrid.setFocus(true)
end sub

sub loadFavorites()
    ' Mismo candado que loadRecentMovies/loadRecentSeries/loadRecentlyWatched:
    ' si ya hay una carga de favoritos en curso, no se crea otra encima.
    ' Sin esto, llamadas casi simultaneas a loadFavorites() (pasa varias
    ' veces al iniciar Home) competian entre si -- con el throttle de
    ' sincronizacion, la que "perdia" la carrera leia el almacenamiento
    ' local ANTES de que la primera terminara de escribir todo, y
    ' mostraba la fila de favoritos vacia o incompleta.
    if m.favoritesTask <> invalid and m.favoritesTask.control = "RUN" then return

    ' Se muestra YA el contenido local real (sin esperar red), y en
    ' silencio se sincroniza/actualiza despues -- misma idea que
    ' Recien Vistas, para que la app se sienta mas rapida.
    localContent = Fav_BuildTop20ContentNode()
    if localContent.getChildCount() > 0
        m.favoritesGrid.content = localContent
    end if

    m.favoritesTask = createObject("roSGNode", "HomeContentTask")
    m.favoritesTask.taskType = "favorites"
    m.favoritesTask.observeField("contentResults", "onFavoritesLoaded")
    m.favoritesTask.control = "RUN"
end sub

sub onFavoritesLoaded()
    if m.favoritesTask = invalid then
        print "DEBUG onFavoritesLoaded - task invalid"
        return
    end if
    content = m.favoritesTask.contentResults
if content = invalid then return
if content.getChildCount() > 0
        m.favoritesGrid.content = content
        print "DEBUG onFavoritesLoaded - grid actualizado"
    end if
    updateRowScroll(m.focusZone)
    ' Reasignar content a un grid enfocado le puede quitar el foco a
    ' toda la pantalla en silencio (sin aviso) -- si la fila que se
    ' acaba de recargar es la que esta activa ahora mismo, se le
    ' regresa el foco explicitamente para no quedar sin nada enfocado.
    if m.focusZone = "favorites" then m.favoritesGrid.setFocus(true)
end sub

sub onFavoriteFocused()
    if m.favoritesGrid.content = invalid then return
    idx = m.favoritesGrid.itemFocused
    if idx < 0 or idx >= m.favoritesGrid.content.getChildCount() then return
    item = m.favoritesGrid.content.getChild(idx)
    if item = invalid then return
    if item.doesExist("isSerie") and item.isSerie = true
        updateHeroFromItemSerie(item)
    else
        updateHeroFromItem(item)
    end if
end sub

sub onFavoriteSelected()
    if m.favoritesGrid.content = invalid then return
    idx = m.favoritesGrid.itemSelected
    if idx < 0 or idx >= m.favoritesGrid.content.getChildCount() then return
    item = m.favoritesGrid.content.getChild(idx)
    if item = invalid then return
    m.lastFocusZone = "favorites"
    m.lastZoneIdx = idx
    if item.doesExist("isSerie") and item.isSerie = true
        m.global.play = "/series/" + m.global.user + "/" + m.global.pass + "/"
        m.global.serie = "true"
        m.global.episode = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series_info&series_id="
        m.seasons.content = item
        m.seasons.visible = true
        m.seasons.setFocus(true)
    else
        m.global.play = "/movie/" + m.global.user + "/" + m.global.pass + "/"
        m.global.serie = "false"
        m.detailsScreen.content = item
        m.detailsScreen.visible = true
        m.detailsScreen.setFocus(true)
    end if
end sub

sub onRecentMovieSelected()
    if m.recentMoviesGrid.content = invalid then return
    idx = m.recentMoviesGrid.itemSelected
    if idx < 0 or idx >= m.recentMoviesGrid.content.getChildCount() then return
    item = m.recentMoviesGrid.content.getChild(idx)
    if item = invalid then return
    m.lastFocusZone = "movies"
    m.lastZoneIdx = idx
    m.global.play = "/movie/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie = "false"
    m.detailsScreen.content = item
    m.detailsScreen.visible = true
    m.detailsScreen.setFocus(true)
end sub

sub onRecentSerieSelected()
    if m.recentSeriesGrid.content = invalid then return
    idx = m.recentSeriesGrid.itemSelected
    if idx < 0 or idx >= m.recentSeriesGrid.content.getChildCount() then return
    item = m.recentSeriesGrid.content.getChild(idx)
    if item = invalid then return
    m.lastFocusZone = "series"
    m.lastZoneIdx = idx
    m.global.play = "/series/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie = "true"
    m.global.episode = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series_info&series_id="
    m.seasons.content = item
    m.seasons.visible = true
    m.seasons.setFocus(true)
end sub

sub restoreFocus()
    if m.lastFocusZone = "favorites" or m.lastFocusZone = "movies" or m.lastFocusZone = "series" or m.lastFocusZone = "recentlywatched"
        enterZone(m.lastFocusZone)
        grid = zoneGrid(m.lastFocusZone)
        if grid <> invalid and m.lastZoneIdx <> invalid and m.lastZoneIdx > 0
            grid.jumpToItem = m.lastZoneIdx
        end if
    else
        enterZone("movies")
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    if m.detailsScreen <> invalid and m.detailsScreen.visible then
        if key <> "back" and key <> "options" then return true
    end if
    if m.seasons <> invalid and m.seasons.visible then
        if key <> "back" and key <> "options" then return true
    end if

    if key = "options"
        if m.detailsScreen <> invalid and m.detailsScreen.visible then return false
        if m.seasons <> invalid and m.seasons.visible then return false
        goToNav()
        return true
    end if

    if key = "back"
        if m.detailsScreen <> invalid and m.detailsScreen.visible = true
            if m.detailsScreen.videoPlayerVisible = true
                m.detailsScreen.videoPlayerVisible = false
            else
                m.detailsScreen.visible = false
                restoreFocus()
            end if
            return true
        end if
        if m.seasons <> invalid and m.seasons.visible = true
            if m.seasons.videoPlayerVisible = true
                m.seasons.videoPlayerVisible = false
            else
                m.seasons.visible = false
                restoreFocus()
            end if
            return true
        end if
        if m.focusZone = "recentlywatched" or m.focusZone = "series" or m.focusZone = "movies" or m.focusZone = "favorites"
            goToNav()
            return true
        end if
        return false
    end if

    if m.focusZone = "nav"
        m.top.isInMenu = true
        if key = "right"
            if m.navFocusedIndex < m.totalNavItems - 1
                m.navFocusedIndex = m.navFocusedIndex + 1
                updateNavHighlight()
            end if
            return true
        else if key = "left"
            if m.navFocusedIndex > 0
                m.navFocusedIndex = m.navFocusedIndex - 1
                updateNavHighlight()
            end if
            return true
        else if key = "down"
            clearNavHighlight()
            m.top.isInMenu = false
            target = nextZoneDown("")
            if target <> "" then enterZone(target)
            return true
        else if key = "OK"
            if m.navFocusedIndex = 0
                m.top.menuItemSelected = 4
            else if m.navFocusedIndex = 1
                return true
            else if m.navFocusedIndex = 2
                m.top.menuItemSelected = 1
            else if m.navFocusedIndex = 3
                m.top.menuItemSelected = 2
            else if m.navFocusedIndex = 4
                m.top.menuItemSelected = 0
            else if m.navFocusedIndex = 5
                m.top.menuItemSelected = 3
            else if m.navFocusedIndex = 6
                onProfileNavSelected()
            end if
            return true
        end if
        return true
    end if

    if m.focusZone = "recentlywatched" or m.focusZone = "series" or m.focusZone = "movies" or m.focusZone = "favorites"
        if key = "up"
            target = nextZoneUp(m.focusZone)
            print "DEBUG HOMEKEY - key=up focusZone="; m.focusZone; " target="; target; " isSliding="; m.isSliding
            if target = ""
                if not m.isSliding then goToNav()
            else
                if m.isSliding then
                    m.pendingSlideZone = target
                    print "DEBUG HOMEKEY - encolado (isSliding) pendingSlideZone="; target
                else
                    enterZone(target)
                end if
            end if
            return true
        else if key = "down"
            target = nextZoneDown(m.focusZone)
            print "DEBUG HOMEKEY - key=down focusZone="; m.focusZone; " target="; target; " isSliding="; m.isSliding
            if target <> ""
                if m.isSliding then
                    m.pendingSlideZone = target
                    print "DEBUG HOMEKEY - encolado (isSliding) pendingSlideZone="; target
                else
                    enterZone(target)
                end if
            end if
            return true
        end if
        return false
    end if

    return false
end function

' ============================================================
' Sincronizacion COMPLETA del catalogo (peliculas + series) al abrir
' la app, en segundo plano -- mismo criterio que ya usa la app de
' Android/PC (que descarga todo el catalogo al abrir). En Roku se
' hace EN SILENCIO, sin bloquear pantalla ni afectar la navegacion
' (a diferencia de Android, que muestra un mensaje de "descargando
' catalogo"): dos CategoriesSyncTask en paralelo (peliculas y
' series), cada uno en su propio hilo -- mismo Task que ya usa
' MoviesBrowseScreen para su sync en segundo plano.
'
' Cuando AMBOS terminan, se reconstruyen Favoritos y Recien Vistas.
' Motivo: un favorito agregado desde otro dispositivo llega del
' servidor solo con su id: Fav_SyncFromServer intenta resolverlo
' primero contra el catalogo local (rapido, sin red) y solo si no
' esta ahi cae a una consulta individual (get_vod_info/
' get_series_info) que varios proveedores Xtream responden de forma
' inestable -- a diferencia de la descarga masiva por categoria
' (get_vod_streams/get_series) que usa este mismo sync, mucho mas
' confiable. Con el catalogo ya completo local, esos favoritos se
' resuelven con portada y url reales en vez de quedar a medias.
' ============================================================
sub startFullCatalogBackgroundSync()
    if m.global.serverURL = "" then return
    if m.catalogSyncMovies <> invalid and m.catalogSyncMovies.control = "RUN" then return
    if m.catalogSyncSeries <> invalid and m.catalogSyncSeries.control = "RUN" then return

    m.catalogSyncMoviesDone = false
    m.catalogSyncSeriesDone = false

    print "DEBUG startFullCatalogBackgroundSync - iniciando descarga completa de catalogo (peliculas+series) en segundo plano"

    m.catalogSyncMovies = createObject("roSGNode", "CategoriesSyncTask")
    m.catalogSyncMovies.isSerie = false
    m.catalogSyncMovies.observeField("syncComplete", "onCatalogSyncMoviesDone")
    m.catalogSyncMovies.control = "RUN"

    m.catalogSyncSeries = createObject("roSGNode", "CategoriesSyncTask")
    m.catalogSyncSeries.isSerie = true
    m.catalogSyncSeries.observeField("syncComplete", "onCatalogSyncSeriesDone")
    m.catalogSyncSeries.control = "RUN"
end sub

sub onCatalogSyncMoviesDone()
    m.catalogSyncMoviesDone = true
    print "DEBUG onCatalogSyncMoviesDone - catalogo de peliculas listo"
    onFullCatalogSyncMaybeDone()
end sub

sub onCatalogSyncSeriesDone()
    m.catalogSyncSeriesDone = true
    print "DEBUG onCatalogSyncSeriesDone - catalogo de series listo"
    onFullCatalogSyncMaybeDone()
end sub

sub onFullCatalogSyncMaybeDone()
    if m.catalogSyncMoviesDone <> true or m.catalogSyncSeriesDone <> true then return
    print "DEBUG onFullCatalogSyncMaybeDone - catalogo completo listo, reconstruyendo Favoritos y Recien Vistas"
    ' Se recargan desde cero (no solo "si estan vacios") para que
    ' cualquier favorito/reciente que haya quedado incompleto por una
    ' consulta individual fallida se resuelva ahora contra el
    ' catalogo recien bajado. Recien Agregadas (peliculas/series) tambien
    ' se recarga aqui -- antes no se tocaba en este callback, asi que la
    ' primera sincronizacion completa del catalogo nunca reflejaba nada
    ' nuevo en esas dos filas hasta salir y volver a entrar a la app.
    m.favoritesGrid.content = invalid
    loadFavorites()
    m.recentlyWatchedGrid.content = invalid
    loadRecentlyWatched()
    loadRecentMovies()
    loadRecentSeries()
end sub
