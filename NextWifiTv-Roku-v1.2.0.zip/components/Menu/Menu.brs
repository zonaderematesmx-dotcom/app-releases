sub init()
    ' Configuración del panel
    m.top.panelSize = "narrow"
    m.top.focusable = true
    m.top.hasNextPanel = true
    m.top.leftOnly = true
    m.top.createNextPanelOnItemFocus = false
    m.top.selectButtonMovesPanelForward = true
    m.top.optionsAvailable = true
    m.top.overhangTitle = "Menu"
    m.top.list = m.top.findNode("menuList")

    ' --- Color de marca (focusColor del config.json) ---
    ' menu.png se tine dinamicamente via focusBitmapBlendColor,
    ' no se reemplaza el archivo de imagen (igual que en Account.xml).
    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")

    ' Refrescar la imagen con un parámetro dinámico para evitar caché
    refreshAd()
end sub

sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0x00A8FFFF"
    m.top.list.focusBitmapBlendColor = fc
end sub

sub refreshAd()
    baseUrl = m.global.panelURL + "/img/ads.jpg"
    dt = CreateObject("roDateTime")
    ts = dt.AsSeconds().ToStr()   ' timestamp actual en segundos
    poster = m.top.findNode("MenuBackgroundImage")
    poster.uri = baseUrl + "?cb=" + ts
end sub
