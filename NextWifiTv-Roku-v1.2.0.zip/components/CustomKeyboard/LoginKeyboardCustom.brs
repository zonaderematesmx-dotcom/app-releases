sub init()
    m.top.setFocus(true)
    m.entered  = ""
    m.capsOn   = false
    m.numMode  = false
    m.focusRow = 0
    m.focusCol = 0

    m.textDisplay = m.top.findNode("textDisplay")

    m.rows = []
    m.rows[0] = [
        {id:"kq", lo:"q", up:"Q", nm:"1"},
        {id:"kw", lo:"w", up:"W", nm:"2"},
        {id:"ke", lo:"e", up:"E", nm:"3"},
        {id:"kr", lo:"r", up:"R", nm:"4"},
        {id:"kt", lo:"t", up:"T", nm:"5"},
        {id:"ky", lo:"y", up:"Y", nm:"6"},
        {id:"ku", lo:"u", up:"U", nm:"7"},
        {id:"ki", lo:"i", up:"I", nm:"8"},
        {id:"ko", lo:"o", up:"O", nm:"9"},
        {id:"kp", lo:"p", up:"P", nm:"0"}
    ]
    m.rows[1] = [
        {id:"ka", lo:"a", up:"A", nm:"@"},
        {id:"ks", lo:"s", up:"S", nm:"#"},
        {id:"kd", lo:"d", up:"D", nm:"$"},
        {id:"kf", lo:"f", up:"F", nm:"%"},
        {id:"kg", lo:"g", up:"G", nm:"&"},
        {id:"kh", lo:"h", up:"H", nm:"*"},
        {id:"kj", lo:"j", up:"J", nm:"("},
        {id:"kk", lo:"k", up:"K", nm:")"},
        {id:"kl", lo:"l", up:"L", nm:"!"},
        {id:"kEnye", lo:"ñ", up:"Ñ", nm:"'"}
    ]
    m.rows[2] = [
        {id:"kCaps", lo:"Mayús",  up:"Mayús",  nm:"Mayús"},
        {id:"kz",    lo:"z",      up:"Z",      nm:"~"},
        {id:"kx",    lo:"x",      up:"X",      nm:"/"},
        {id:"kc",    lo:"c",      up:"C",      nm:":"},
        {id:"kv",    lo:"v",      up:"V",      nm:";"},
        {id:"kb",    lo:"b",      up:"B",      nm:"+"},
        {id:"kn",    lo:"n",      up:"N",      nm:"="},
        {id:"km",    lo:"m",      up:"M",      nm:"?"},
        {id:"kDel",  lo:"Borrar", up:"Borrar", nm:"Borrar"}
    ]
    m.rows[3] = [
        {id:"kDot",   lo:".",   up:".",   nm:"."},
        {id:"kAt",    lo:"@",   up:"@",   nm:"@"},
        {id:"kUnd",   lo:"_",   up:"_",   nm:"_"},
        {id:"kDash",  lo:"-",   up:"-",   nm:"-"},
        {id:"kSpace", lo:" ",   up:" ",   nm:" "},
        {id:"kNum",   lo:"123", up:"123", nm:"abc"},
        {id:"kOK",    lo:"OK",  up:"OK",  nm:"OK"}
    ]

    m.keyBgs = []
    m.keyLbls = []
    for r = 0 to m.rows.count() - 1
        rowBgs = []
        rowLbls = []
        for c = 0 to m.rows[r].count() - 1
            rowBgs[c] = m.top.findNode(m.rows[r][c].id)
            lblId = "l" + Mid(m.rows[r][c].id, 2)
            rowLbls[c] = m.top.findNode(lblId)
        end for
        m.keyBgs[r] = rowBgs
        m.keyLbls[r] = rowLbls
    end for

    ' Centro X real (absoluto) de cada tecla, para poder mover el foco
    ' hacia arriba/abajo hacia la tecla mas cercana espacialmente en vez
    ' de por indice de columna (las filas 3 y 4 tienen teclas de ancho
    ' distinto -Mayus, Borrar, Espacio, OK- asi que el mismo indice de
    ' columna no cae en la misma posicion horizontal entre filas).
    m.rowGroups = []
    for r = 0 to m.rows.count() - 1
        m.rowGroups[r] = m.top.findNode("row" + Str(r + 1).Trim())
    end for

    m.keyCenters = []
    for r = 0 to m.rows.count() - 1
        centers = []
        rgX = m.rowGroups[r].translation[0]
        for c = 0 to m.rows[r].count() - 1
            bg = m.keyBgs[r][c]
            centers[c] = rgX + bg.translation[0] + bg.width / 2
        end for
        m.keyCenters[r] = centers
    end for

    m.top.observeField("text",       "onTextSet")
    m.top.observeField("isPassword", "onIsPasswordSet")

    updateLabels()
    updateFocus()
    updateDisplay()

    ' --- Color de marca (focusColor del config.json) ---
    m.global.observeField("focusColor", "updateFocus")
end sub

sub updateLabels()
    for r = 0 to m.rows.count() - 1
        for c = 0 to m.rows[r].count() - 1
            lbl = m.keyLbls[r][c]
            if lbl = invalid then goto nextLbl
            key = m.rows[r][c]
            if key.id = "kDel" or key.id = "kOK" or key.id = "kSpace" or key.id = "kCaps" or key.id = "kDot" or key.id = "kAt" or key.id = "kUnd" or key.id = "kDash"
                goto nextLbl
            end if
            if key.id = "kNum"
                if m.numMode then lbl.text = "abc" else lbl.text = "123"
                goto nextLbl
            end if
            if m.numMode
                lbl.text = key.nm
            else if m.capsOn
                lbl.text = key.up
            else
                lbl.text = key.lo
            end if
            nextLbl:
        end for
    end for
end sub

sub onTextSet()
    if m.top.text <> m.entered
        m.entered = m.top.text
        updateDisplay()
    end if
end sub

sub onIsPasswordSet()
    updateDisplay()
end sub

sub updateDisplay()
    if m.textDisplay = invalid then return
    txt = m.entered
    if m.top.isPassword and txt <> ""
        masked = ""
        for i = 1 to Len(txt) - 1
            masked = masked + "•"
        end for
        masked = masked + Right(txt, 1)
        m.textDisplay.text = masked
    else
        m.textDisplay.text = txt
    end if
end sub

sub updateFocus()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0x00A8FFFF"
    for r = 0 to m.rows.count() - 1
        for c = 0 to m.rows[r].count() - 1
            bg = m.keyBgs[r][c]
            if bg = invalid then goto nextKey
            id = m.rows[r][c].id
            if r = m.focusRow and c = m.focusCol
                bg.color = fc
            else if id = "kCaps"
                if m.capsOn
                    bg.color = fc
                else
                    bg.color = "0x444444FF"
                end if
            else if id = "kDel"
                bg.color = "0x555555FF"
            else if id = "kOK"
                bg.color = "0x555555FF"
            else if id = "kNum"
                bg.color = "0x444444FF"
            else
                bg.color = "0x333333FF"
            end if
            nextKey:
        end for
    end for
end sub

sub pressKey()
    row = m.rows[m.focusRow]
    key = row[m.focusCol]
    ch = ""
    if m.numMode
        ch = key.nm
    else if m.capsOn
        ch = key.up
    else
        ch = key.lo
    end if

    if ch = "Borrar"
        if Len(m.entered) > 0
            m.entered = Left(m.entered, Len(m.entered) - 1)
            updateDisplay()
            m.top.text = m.entered
        end if
    else if ch = "Mayús"
        m.capsOn  = not m.capsOn
        m.numMode = false
        updateLabels()
        updateFocus()
    else if ch = "OK"
        m.top.text = m.entered
        m.top.confirmed = false
        m.top.confirmed = true
    else if ch = "123" or ch = "abc"
        m.numMode = not m.numMode
        m.capsOn  = false
        updateLabels()
        updateFocus()
    else
        m.entered = m.entered + ch
        updateDisplay()
        m.top.text = m.entered
    end if
end sub

function findNearestCol(centers as Object, targetCenter as Float) as Integer
    bestIdx  = 0
    bestDist = Abs(centers[0] - targetCenter)
    for c = 1 to centers.count() - 1
        d = Abs(centers[c] - targetCenter)
        if d < bestDist
            bestDist = d
            bestIdx  = c
        end if
    end for
    return bestIdx
end function

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    cols   = m.rows[m.focusRow].count()
    maxRow = m.rows.count() - 1

    if key = "right"
        if m.focusCol < cols - 1
            m.focusCol = m.focusCol + 1
        else
            m.focusCol = 0
        end if
        updateFocus()
        return true
    else if key = "left"
        if m.focusCol > 0
            m.focusCol = m.focusCol - 1
        else
            m.focusCol = cols - 1
        end if
        updateFocus()
        return true
    else if key = "down"
        if m.focusRow < maxRow
            curCenter = m.keyCenters[m.focusRow][m.focusCol]
            m.focusRow = m.focusRow + 1
            m.focusCol = findNearestCol(m.keyCenters[m.focusRow], curCenter)
        end if
        updateFocus()
        return true
    else if key = "up"
        if m.focusRow > 0
            curCenter = m.keyCenters[m.focusRow][m.focusCol]
            m.focusRow = m.focusRow - 1
            m.focusCol = findNearestCol(m.keyCenters[m.focusRow], curCenter)
            updateFocus()
        else
            m.top.goUp = false
            m.top.goUp = true
        end if
        return true
    else if key = "OK"
        pressKey()
        return true
    else if key = "back"
        if Len(m.entered) > 0
            m.entered = Left(m.entered, Len(m.entered) - 1)
            updateDisplay()
            m.top.text = m.entered
        else
            m.top.goUp = false
            m.top.goUp = true
        end if
        return true
    end if

    return false
end function
