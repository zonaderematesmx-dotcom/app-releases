' ============================================================
' FavoritesLocalStore.brs
' Fuente de verdad LOCAL para favoritos (canales, peliculas, series).
' Se incluye como <script> extra en los Tasks/pantallas que lo
' necesiten (junto a generalUtils.brs), no es un componente propio.
'
' Formato de guardado: archivos en cachefs:/favorites/
'   <tipo>_<id>.json     -> AA completa de ese favorito
'   <tipo>_index.json    -> array de ids favoritos de ese tipo
'   tipo: "canal" | "pelicula" | "serie"
' (antes era roRegistrySection("Favorites"); ver
' Fav_MigrateRegistryToFilesIfNeeded mas abajo).
'
' IMPORTANTE - por que hay un indice y no simplemente listar la
' carpeta: roFileSystem (necesario para listar/borrar archivos) SOLO
' se puede crear en hilos MAIN o TASK (mismo motivo por el que
' CategoriesLocalStore.brs evita escribir su indice desde el hilo de
' render, ver el comentario en MoviesBrowseScreen.brs). A diferencia
' del catalogo, Favoritos SI se lee/escribe directo desde pantallas
' Group -- osea hilo de RENDER, no Task -- en varios lugares (el
' boton de favorito de canal en EpgGuiaScreen.brs, "Mi Top 20" en
' HomeScreen.brs, limpiar al desvincular en SettingsScreen.brs). Si
' esas funciones usaran roFileSystem, fallarian en silencio ahi (la
' primera version de este cambio tenia justo ese bug: devolvia listas
' vacias y, peor, la migracion del registro viejo llegaba a borrar
' los datos originales sin lograr escribir los nuevos). Por eso todo
' aqui usa SOLO ReadAsciiFile/WriteAsciiFile (funciones globales que
' si funcionan en cualquier hilo) para leer, escribir, listar
' (via indice) y "borrar" (sacandolo del indice, sin tocar el
' archivo fisico -- roFileSystem.Delete() no esta disponible aqui).
' La carpeta en si se crea una sola vez desde un hilo Task
' (HomeContentTask.brs la asegura al arrancar, ver su execute()).
' ============================================================

function Fav_BaseDir() as String
    return "cachefs:/favorites"
end function

' Solo tiene efecto si se llama desde un hilo MAIN o TASK; desde un
' Group (render) queda en silencio sin romper nada -- la carpeta ya
' se asegura por otro lado (ver nota arriba).
sub Fav_EnsureDir()
    fs = CreateObject("roFileSystem")
    if fs <> invalid and not fs.Exists(Fav_BaseDir())
        fs.CreateDirectory(Fav_BaseDir())
    end if
end sub

' Los ids que llegan aqui son casi siempre numericos (stream_id/
' series_id/id de canal del proveedor), pero por seguridad se
' sanitiza igual que ya hace Cat_SafeUsuario en CategoriesLocalStore.
function Fav_SafeFileId(id as String) as String
    if id = invalid then return "x"
    clean = id
    clean = clean.Replace("/", "_")
    clean = clean.Replace("\", "_")
    clean = clean.Replace(" ", "_")
    return clean
end function

' Usuario+variante de servidor actual, para que los archivos de cada
' cuenta/servidor queden separados entre si (ver Fav_CurrentUser mas
' abajo). Antes estos paths NO llevaban usuario para nada -- por eso
' CUALQUIER cuenta que iniciara sesion en el dispositivo veia los
' favoritos de la ultima cuenta que los sincronizo. Se sanitiza igual
' que Fav_SafeFileId por si el usuario trae caracteres raros.
function Fav_FilePath(tipo as String, id as String) as String
    return Fav_BaseDir() + "/" + Fav_CurrentUser() + "_" + tipo + "_" + Fav_SafeFileId(id) + ".json"
end function

' --- Indice de ids por tipo (para poder listar sin roFileSystem) ---
function Fav_IndexPath(tipo as String) as String
    return Fav_BaseDir() + "/" + Fav_CurrentUser() + "_" + tipo + "_index.json"
end function

function Fav_CurrentUser() as String
    u = "unknown"
    raw = getStrValFromReg("user_tv", "datos_tv")
    if raw <> invalid and raw <> ""
        u = raw
    else if m.global <> invalid and m.global.user <> invalid and m.global.user <> ""
        u = m.global.user
    end if
    clean = u
    clean = clean.Replace("/", "_")
    clean = clean.Replace("\", "_")
    clean = clean.Replace(" ", "_")
    variante = "0"
    if m.global <> invalid and m.global.serverVariant <> invalid and m.global.serverVariant.toStr() <> ""
        variante = m.global.serverVariant.toStr()
    end if
    perfil = "0"
    if m.global <> invalid and m.global.profileId <> invalid and m.global.profileId.toStr() <> ""
        perfil = m.global.profileId.toStr()
    end if
    return clean + "-v" + variante + "-p" + perfil
end function

' Variante de servidor actual, sola (sin el usuario) -- para mandarla
' como parametro "&variante=" al panel (add_favorites.php) en cada
' llamada, para que el panel sepa a que servidor pertenece cada
' favorito y no mezcle cuentas con el mismo usuario en servidores
' distintos. "0" como respaldo (mismo default que usa add_favorites.php
' del lado servidor) si todavia no esta disponible.
function Fav_CurrentVariante() as String
    if m.global <> invalid and m.global.serverVariant <> invalid and m.global.serverVariant.toStr() <> ""
        return m.global.serverVariant.toStr()
    end if
    return "0"
end function

' Perfil actual (de hasta 5 por cuenta+servidor -- ver
' SelectProfileScreen.brs/perfiles.php), para mandarlo como parametro
' "&perfil=" al panel en cada llamada, mismo motivo y patron que
' Fav_CurrentVariante(): sin esto, todos los perfiles de una cuenta
' compartirian los mismos favoritos. "0" = perfil desconocido/legado
' (mismo default que usa add_favorites.php del lado servidor).
function Fav_CurrentPerfil() as String
    if m.global <> invalid and m.global.profileId <> invalid and m.global.profileId.toStr() <> ""
        return m.global.profileId.toStr()
    end if
    return "0"
end function

function Fav_ReadIndex(tipo as String) as Object
    raw = ReadAsciiFile(Fav_IndexPath(tipo))
    if raw = invalid or raw = "" then return []
    parsed = ParseJSON(raw)
    if parsed = invalid or type(parsed) <> "roArray" then return []
    return parsed
end function

sub Fav_WriteIndex(tipo as String, idsArr as Object)
    if idsArr = invalid then idsArr = []
    WriteAsciiFile(Fav_IndexPath(tipo), FormatJSON(idsArr))
end sub

sub Fav_IndexAdd(tipo as String, id as String)
    ids = Fav_ReadIndex(tipo)
    for each existingId in ids
        if existingId = id then return
    end for
    ids.push(id)
    Fav_WriteIndex(tipo, ids)
end sub

sub Fav_IndexRemove(tipo as String, id as String)
    ids = Fav_ReadIndex(tipo)
    newIds = []
    changed = false
    for each existingId in ids
        if existingId = id
            changed = true
        else
            newIds.push(existingId)
        end if
    end for
    if changed then Fav_WriteIndex(tipo, newIds)
end sub

' Migracion/backfill UNICA. Dos partes, cada una tolerante a correr
' primero desde el hilo de render (donde roFileSystem no esta
' disponible):
'  1) Lo que haya quedado en el registro viejo ("Favorites") se
'     copia a archivos -- y SOLO se borra del registro la entrada
'     cuya copia se confirma leyendo el archivo de vuelta. Si la
'     escritura no cuaja (por ejemplo, la carpeta todavia no existe
'     porque este hilo no puede crearla), la entrada vieja se deja
'     intacta para reintentar despues, en vez de perderla.
'  2) Backfill: archivos de favoritos que ya existieran en disco sin
'     estar en el indice (por ejemplo, de una version anterior de
'     este mismo cambio) se agregan al indice. Esto si necesita
'     roFileSystem para listar la carpeta, asi que solo se hace
'     cuando esta disponible.
' La bandera de "ya migrado" SOLO se marca si ambas partes quedaron
' completas; si no, se reintenta en la proxima llamada (desde
' cualquier hilo) hasta lograrlo.
sub Fav_MigrateRegistryToFilesIfNeeded()
    migSec = Fav_SyncSection()
    if m.favDirVerified = true then return ' ya se confirmo en esta misma corrida

    flagKey = "migrated-files-v2"
    already = migSec.Read(flagKey)
    if already <> invalid and already <> ""
        ' Autocuracion: la bandera vive en el registro (sobrevive al
        ' recompilar/redesplegar desde VSCode), pero los datos viven en
        ' cachefs:/favorites (que SI se vacia al redesplegar). Si la
        ' bandera dice "ya migrado" pero la carpeta ya no existe, se
        ' ignora la bandera y se vuelve a crear todo -- solo se puede
        ' verificar esto desde un hilo MAIN/TASK; si no se puede (hilo
        ' de render), se confia en la bandera como antes.
        fsCheck = CreateObject("roFileSystem")
        if fsCheck <> invalid
            if fsCheck.Exists(Fav_BaseDir())
                m.favDirVerified = true
                return
            end if
            print "DEBUG Fav_MigrateRegistryToFilesIfNeeded - la bandera decia 'ya migrado' pero la carpeta ya no existe (probable redespliegue durante desarrollo), se vuelve a crear todo"
        else
            return
        end if
    end if

    Fav_EnsureDir()
    allOk = true

    ' --- 1) registro viejo -> archivos ---
    oldSec = CreateObject("roRegistrySection", "Favorites")
    keys = oldSec.GetKeyList()
    total = 0
    if keys <> invalid
        total = keys.count()
        for each key in keys
            raw = oldSec.Read(key)
            migratedOk = false
            if raw <> invalid and raw <> ""
                parsed = ParseJSON(raw)
                if parsed <> invalid and type(parsed) = "roAssociativeArray"
                    rest = key
                    if Left(rest, 4) = "fav-" then rest = Mid(rest, 5)
                    sep = Instr(1, rest, "-")
                    if sep > 0
                        tipo = Left(rest, sep - 1)
                        id = Mid(rest, sep + 1)
                        if tipo <> "" and id <> ""
                            existingRaw = ReadAsciiFile(Fav_FilePath(tipo, id))
                            if existingRaw <> invalid and existingRaw <> ""
                                Fav_IndexAdd(tipo, id)
                                migratedOk = true
                            else
                                if parsed._addedAt = invalid then parsed._addedAt = CreateObject("roDateTime").AsSeconds()
                                WriteAsciiFile(Fav_FilePath(tipo, id), FormatJSON(parsed))
                                checkRaw = ReadAsciiFile(Fav_FilePath(tipo, id))
                                if checkRaw <> invalid and checkRaw <> ""
                                    Fav_IndexAdd(tipo, id)
                                    migratedOk = true
                                end if
                            end if
                        end if
                    end if
                end if
            else
                migratedOk = true ' entrada vacia/corrupta, no hay nada que preservar
            end if

            if migratedOk
                oldSec.Delete(key)
            else
                allOk = false
            end if
        end for
        oldSec.Flush()
    end if

    ' --- 2) backfill de archivos huerfanos (sin indice todavia) ---
    fs = CreateObject("roFileSystem")
    if fs <> invalid and fs.Exists(Fav_BaseDir())
        files = fs.GetDirectoryListing(Fav_BaseDir())
        if files <> invalid
            for each fname in files
                if Right(fname, 5) = ".json" and Instr(1, fname, "_index.json") = 0
                    us = Instr(1, fname, "_")
                    if us > 0
                        tipo = Left(fname, us - 1)
                        idPart = Mid(fname, us + 1)
                        idPart = Left(idPart, Len(idPart) - 5) ' quitar ".json"
                        if tipo <> "" and idPart <> ""
                            raw2 = ReadAsciiFile(Fav_BaseDir() + "/" + fname)
                            if raw2 <> invalid and raw2 <> "" then Fav_IndexAdd(tipo, idPart)
                        end if
                    end if
                end if
            end for
        end if

        ' Se crean los 3 indices vacios si todavia no existen. Sin esto,
        ' Fav_ReadIndex intenta leer un archivo que no existe CADA VEZ que
        ' se arma una tarjeta de cualquier pelicula/serie del catalogo
        ' (fillMovieNode/fillSerieNode consultan favoritos como respaldo
        ' de titulo para TODO el catalogo, no solo lo favorito) -- eso es
        ' lo que de verdad generaba miles de líneas de ERROR en el log
        ' cuando el usuario todavia no tiene ningun favorito guardado.
        for each tipo in ["canal", "pelicula", "serie"]
            idxPath = Fav_IndexPath(tipo)
            if not fs.Exists(idxPath) then WriteAsciiFile(idxPath, "[]")
        end for
    else
        allOk = false
    end if

    if allOk
        migSec.Write(flagKey, "1")
        migSec.Flush()
        m.favDirVerified = true
        print "DEBUG Fav_MigrateRegistryToFilesIfNeeded - completa, "; total; " entradas de registro revisadas"
    else
        print "DEBUG Fav_MigrateRegistryToFilesIfNeeded - incompleta (sin acceso a disco en este hilo), se reintentara despues"
    end if
end sub

' Devuelve la URL de add_favorites.php que llego del config.json
' (m.global.urlFavoritos, editable desde el panel en "Base de datos").
' Ya no trae ningun link fijo en el codigo: si el servidor todavia no
' lo ha mandado, regresa "" y las funciones de sync no hacen nada.
function Fav_ApiBase() as String
    if m.global <> invalid and m.global.urlFavoritos <> invalid then
        return m.global.urlFavoritos
    end if
    return ""
end function

' Devuelve la URL de resolver.php (m.global.urlResolver, editable desde
' el panel en "Base de datos", igual que las demas). Si no esta
' configurada regresa "" -- el codigo que la usa cae de vuelta al
' metodo viejo (uno por uno) en ese caso, para no perder
' funcionalidad en dispositivos que todavia no tienen este link puesto.
function Fav_ResolverApiBase() as String
    if m.global <> invalid and m.global.urlResolver <> invalid then
        return m.global.urlResolver
    end if
    return ""
end function

' Resuelve una LISTA de ids de una sola vez contra resolver.php (en vez
' de una peticion por id). tipoid: "1"=canal, "2"=pelicula, "3"=serie.
' Regresa el array crudo de items que si se encontraron (mismo formato
' que ya usa buscador.php: campos originales de Xtream + tipoid +
' url_reproduccion). Array vacio si no esta configurado, si la lista
' de ids viene vacia, o si la peticion no responde nada util.
function Fav_ResolveIdsBatch(idsArr as Object, tipoid as String, su as String, u as String, p as String) as Object
    result = []
    if idsArr = invalid or idsArr.count() = 0 then return result
    apiBase = Fav_ResolverApiBase()
    if apiBase = "" then return result

    idsStr = ""
    for each idVal in idsArr
        if idsStr <> "" then idsStr = idsStr + ","
        idsStr = idsStr + idVal
    end for

    url = apiBase + "?username=" + GU_UrlEncode(u) + "&password=" + GU_UrlEncode(p) + "&ids=" + GU_UrlEncode(idsStr) + "&tipoid=" + tipoid + "&baseurl=" + GU_UrlEncode(su)
    data = ParseJSON(requestData(url, 20000))
    if data <> invalid and type(data) = "roArray" then result = data
    return result
end function

' Arma la misma AA "plana" que ya arman Fav_FetchVodInfo/
' Fav_FetchSerieInfo (id/title/description/HDPosterUrl/url/etc), pero a
' partir de un item que ya vino de resolver.php (formato crudo de
' Xtream, no el de get_vod_info/get_series_info) -- para que
' Fav_LocalWrite guarde exactamente lo mismo sin importar por cual de
' los dos caminos se resolvio.
function Fav_BuildAAFromBulkItem(item as Object, tipo as String, su as String, u as String, p as String) as Object
    aa = {}
    idVal = ""
    if tipo = "serie"
        if item.series_id <> invalid then idVal = item.series_id.toStr()
    else
        if item.stream_id <> invalid then idVal = item.stream_id.toStr()
    end if
    aa["id"] = idVal
    if item.name <> invalid and item.name <> "" then aa["title"] = item.name
    if item.plot <> invalid and item.plot <> "" then aa["description"] = item.plot
    if item.rating <> invalid then aa["rating"] = item.rating.toStr()
    if item.releasedate <> invalid then aa["releaseDate"] = item.releasedate.toStr()
    if item.genre <> invalid then aa["genre"] = item.genre

    if tipo = "serie"
        if item.cover <> invalid and item.cover <> "" then
            aa["HDPosterUrl"] = item.cover
        else
            aa["HDPosterUrl"] = "pkg:/images/no-poster.jpg"
        end if
        aa["ContentType"] = "2"
    else
        if item.stream_icon <> invalid and item.stream_icon <> "" then
            aa["HDPosterUrl"] = item.stream_icon
        else
            aa["HDPosterUrl"] = "pkg:/images/no-poster.jpg"
        end if
        if item.director <> invalid then aa["director"] = item.director
        ext = "ts"
        if item.container_extension <> invalid and item.container_extension <> "" then ext = item.container_extension
        aa["url"] = su + "/movie/" + u + "/" + p + "/" + idVal + "." + ext
    end if
    return aa
end function

function Fav_LocalKey(tipo as String, id as String) as String
    return "fav-" + tipo + "-" + id
end function

' Ni pelicula ni serie resolvieron con datos completos (ni en el
' catalogo local, ni en el catalogo completo del panel via
' resolver.php, ni con el metodo viejo uno-por-uno). En vez de dejarlo
' invisible para siempre mientras se reintenta, se guarda YA un
' marcador (con el titulo del SERVIDOR propio si ya lo tiene, en vez
' del generico) para que el favorito SI aparezca en la lista -- si mas
' adelante el proveedor vuelve a tener los datos, se reemplaza con la
' info real. Regresa false si hay que reintentar en la siguiente
' sincronizacion (para no avanzar el cursor), true si ya se agoto el
' limite de intentos por esta vez (se resetea el contador para
' reintentar fresco despues, sin bloquear el cursor para siempre).
function Fav_HandleUnresolvedFavorite(cleanId as String, rowTitulo as String, rowTipo as String, giveUpSec as Object, usuario as String) as Boolean
    placeholderTitle = "Contenido no disponible"
    if rowTitulo <> "" then placeholderTitle = rowTitulo
    tipoToUse = "pelicula"
    if rowTipo = "serie" then tipoToUse = "serie"
    placeholder = {
        id: cleanId,
        title: placeholderTitle,
        HDPosterUrl: "pkg:/images/no-poster.jpg"
    }
    Fav_LocalWrite(tipoToUse, cleanId, placeholder)

    ' --- Auto-eliminacion segura de favoritos cuyo contenido ya no
    ' existe en el catalogo del proveedor ---
    ' Para llegar hasta aqui, ESTA MISMA pasada de sincronizacion ya
    ' verifico EN VIVO contra el servidor actual (catalogo local
    ' PASO 1, resolver.php PASO 2 en lote, y/o get_vod_info/
    ' get_series_info uno-por-uno) y ninguno encontro el id -- no es un
    ' dato cacheado viejo lo que esta fallando. Aun asi, una sola
    ' pasada fallida puede deberse a una caida temporal del panel/
    ' proveedor, no a que el contenido de verdad se elimino. Por eso
    ' solo se borra cuando ademas: (a) esto lleva pasando en varias
    ' pasadas de sincronizacion SEPARADAS (no solo varios intentos
    ' seguidos en el mismo momento), y (b) ya paso un tiempo minimo
    ' real desde el primer fallo. Ambas condiciones juntas evitan
    ' repetir el error de una version anterior, que borraba favoritos
    ' reales por fallas momentaneas del panel (ver comentario original
    ' de esta funcion, unas lineas arriba).
    firstMissKey  = "firstmiss-" + cleanId
    missRoundsKey = "missrounds-" + cleanId
    nowSec = CreateObject("roDateTime").AsSeconds()

    firstMissRaw = giveUpSec.Read(firstMissKey)
    if firstMissRaw = invalid or firstMissRaw = ""
        firstMissAt = nowSec
        giveUpSec.Write(firstMissKey, firstMissAt.toStr())
    else
        firstMissAt = firstMissRaw.toInt()
    end if

    roundsRaw = giveUpSec.Read(missRoundsKey)
    rounds = 0
    if roundsRaw <> invalid and roundsRaw <> "" then rounds = roundsRaw.toInt()
    rounds = rounds + 1
    giveUpSec.Write(missRoundsKey, rounds.toStr())
    giveUpSec.Flush()

    MIN_ROUNDS_PARA_BORRAR = 5
    MIN_HORAS_PARA_BORRAR  = 48
    horasDesdePrimerFallo = (nowSec - firstMissAt) / 3600.0

    if rounds >= MIN_ROUNDS_PARA_BORRAR and horasDesdePrimerFallo >= MIN_HORAS_PARA_BORRAR
        print "DEBUG Fav_SyncFromServer - id="; cleanId; " confirmado ausente del catalogo tras "; rounds; " sincronizaciones y "; horasDesdePrimerFallo; "h -- se elimina automaticamente (local y servidor)"
        Fav_LocalDelete("pelicula", cleanId)
        Fav_LocalDelete("serie", cleanId)
        Fav_ClearMissTracking(giveUpSec, cleanId)
        giveUpSec.Flush()
        ' Se avisa al servidor (borrado suave, action=d) para que el
        ' resto de dispositivos de la misma cuenta tambien lo quiten al
        ' sincronizar -- igual que un borrado manual del usuario.
        Fav_PushDeleteToServer(usuario, cleanId, tipoToUse)
        return true
    end if

    MAX_RETRIES = 3
    failKey = "failcount-" + cleanId
    failCountRaw = giveUpSec.Read(failKey)
    failCount = 0
    if failCountRaw <> invalid and failCountRaw <> "" then failCount = failCountRaw.toInt()
    failCount = failCount + 1

    if failCount >= MAX_RETRIES
        ' Ya NO se marca como "me rindo para siempre" -- eso dejaba el
        ' favorito roto (sin url, sin poster real) de forma permanente
        ' aunque el panel se recuperara despues. Se reinicia el
        ' contador nada mas, para que la SIGUIENTE sincronizacion lo
        ' vuelva a intentar fresco (sin martillar el servidor en el
        ' mismo momento, que es lo que MAX_RETRIES si evita). El
        ' conteo de rondas para auto-eliminacion (arriba) es
        ' independiente y NO se reinicia con esto.
        giveUpSec.Delete(failKey)
        giveUpSec.Flush()
        print "DEBUG Fav_SyncFromServer - id="; cleanId; " fallo "; failCount; " veces en esta pasada, se reintentara en la proxima sincronizacion (ya no se rinde para siempre)"
        return true
    else
        giveUpSec.Write(failKey, failCount.toStr())
        giveUpSec.Flush()
        print "DEBUG Fav_SyncFromServer - no se pudo resolver id="; cleanId; " (intento "; failCount; " de "; MAX_RETRIES; "), queda como generico por ahora y se reintentara"
        return false
    end if
end function

' Limpia el rastro de intentos fallidos de un id (failcount + los de
' auto-eliminacion) cuando SI se logro resolver. Sin esto, un item que
' fallo unas rondas y luego volvio a aparecer en el catalogo (caida
' temporal del proveedor, no borrado real) seguiria arrastrando su
' conteo de rondas -- y si mas adelante vuelve a fallar por otra causa
' distinta, se borraria de mas rapido de lo debido en vez de empezar a
' contar de cero.
sub Fav_ClearMissTracking(giveUpSec as Object, cleanId as String)
    giveUpSec.Delete("failcount-" + cleanId)
    giveUpSec.Delete("firstmiss-" + cleanId)
    giveUpSec.Delete("missrounds-" + cleanId)
end sub

' Lee un favorito local. Devuelve la AsociativeArray guardada,
' o invalid si no existe / esta corrupta.
' Se consulta primero el indice antes de intentar abrir el archivo:
' esta funcion se llama para CUALQUIER id (fillMovieNode/fillSerieNode
' la usan como respaldo de titulo para todo el catalogo, no solo
' favoritos), asi que sin este filtro se intenta leer un archivo que
' no existe para cada item que nunca fue favorito -- funcionalmente
' inofensivo, pero Roku imprime una linea de ERROR en el log por cada
' intento fallido, miles de veces en un catalogo grande.
function Fav_LocalRead(tipo as String, id as String) as Object
    Fav_MigrateRegistryToFilesIfNeeded()
    ids = Fav_ReadIndex(tipo)
    enIndice = false
    for each existingId in ids
        if existingId = id then enIndice = true
    end for
    if not enIndice then return invalid

    raw = ReadAsciiFile(Fav_FilePath(tipo, id))
    if raw = invalid or raw = "" then return invalid
    parsed = ParseJSON(raw)
    if parsed = invalid or type(parsed) <> "roAssociativeArray" then return invalid
    return parsed
end function

function Fav_LocalExists(tipo as String, id as String) as Boolean
    return Fav_LocalRead(tipo, id) <> invalid
end function

sub Fav_LocalWrite(tipo as String, id as String, dataAA as Object)
    if dataAA = invalid then dataAA = {}
    ' Sello de tiempo para poder ordenar/limitar "Mi Top 20" por
    ' antiguedad (el mas viejo es el primero en salir si se pasa de 20).
    if dataAA._addedAt = invalid then dataAA._addedAt = CreateObject("roDateTime").AsSeconds()
    Fav_EnsureDir() ' no-op silencioso si este hilo no puede (Group)
    ok = WriteAsciiFile(Fav_FilePath(tipo, id), FormatJSON(dataAA))
    if ok
        Fav_IndexAdd(tipo, id)
    else
        print "DEBUG Fav_LocalWrite - FALLO escribiendo archivo. tipo="; tipo; " id="; id
    end if
end sub

' "Borra" un favorito local: se saca del indice (asi deja de
' aparecer en cualquier listado/sync) sin necesitar roFileSystem, que
' es lo que se llamaria para de verdad eliminar el archivo -- pero
' esta funcion tambien se llama directo desde pantallas (hilo de
' render), donde roFileSystem no se puede crear. El archivo fisico
' queda huerfano en disco (inofensivo: nunca se vuelve a leer porque
' ya no esta en el indice).
sub Fav_LocalDelete(tipo as String, id as String)
    Fav_IndexRemove(tipo, id)
end sub

' Todos los favoritos locales de un tipo, como array de AAs.
function Fav_LocalListByType(tipo as String) as Object
    Fav_MigrateRegistryToFilesIfNeeded()
    result = []
    ids = Fav_ReadIndex(tipo)
    for each id in ids
        parsed = Fav_LocalRead(tipo, id)
        if parsed <> invalid then result.push(parsed)
    end for
    return result
end function

' true si NO hay ningun favorito local guardado para ese tipo.
' Es la señal para decidir si hace falta ir al servidor a sembrar.
function Fav_LocalIsEmptyForType(tipo as String) as Boolean
    Fav_MigrateRegistryToFilesIfNeeded()
    return Fav_ReadIndex(tipo).count() = 0
end function

' Borra TODOS los favoritos locales (los 3 tipos). Usar al desvincular
' el dispositivo, para no heredar favoritos del usuario anterior.
sub Fav_LocalClearAll()
    Fav_WriteIndex("canal", [])
    Fav_WriteIndex("pelicula", [])
    Fav_WriteIndex("serie", [])

    ' Tambien se reinicia el cursor/bandera de sincronizacion
    ' (FavSync) -- si no, al volver a entrar (mismo usuario u otro)
    ' la app cree que ya esta al dia y solo pide "cambios recientes"
    ' al servidor, casi nada, en vez de un resync completo. Esto
    ' causaba que los favoritos se quedaran vacios despues de
    ' cerrar sesion y volver a entrar.
    syncSec = Fav_SyncSection()
    syncKeys = syncSec.GetKeyList()
    if syncKeys <> invalid
        for each key in syncKeys
            syncSec.Delete(key)
        end for
    end if
    syncSec.Flush()

    ' Y lo mismo para los canales pendientes de resolver contra el
    ' catalogo (ver EpgGuiaScreen.brs), por la misma razon.
    pendSec = Fav_ChannelPendingSection()
    pendKeys = pendSec.GetKeyList()
    if pendKeys <> invalid
        for each key in pendKeys
            pendSec.Delete(key)
        end for
    end if
    pendSec.Flush()
end sub

' ------------------------------------------------------------
' Conversión ContentNode <-> AA para poder cachear localmente
' ------------------------------------------------------------

' Campos que nos interesa cachear para peliculas/series. Si necesitas
' mas adelante otro campo en la tarjeta de favoritos, agregalo aqui.
function Fav_VodSerieFields() as Object
    return ["id", "title", "description", "HDPosterUrl", "hdBackgroundImageUrl", _
            "rating", "releaseDate", "genre", "director", "episodeRunTime", _
            "length", "url", "StreamFormat", "ContentType"]
end function

function Fav_NodeToAA(node as Object, fields as Object) as Object
    aa = {}
    if node = invalid then return aa
    if fields = invalid then return aa
    if type(fields) <> "roArray" then return aa

    n = fields.count()
    i = 0
    while i < n
        fieldName = fields[i]
        i = i + 1
        if fieldName = invalid then goto skipField

        hasIt = false
        if type(node) = "roSGNode"
            hasIt = node.hasField(fieldName)
        end if
        if not hasIt then goto skipField

        fieldValue = node[fieldName]
        if fieldValue = invalid then goto skipField

        ' Algunos proveedores mandan el icono del canal como una imagen
        ' embebida en base64 en vez de una URL normal (strings gigantes
        ' tipo "data:image/...;base64,...."). Eso puede reventar el
        ' limite de tamaño del registro de Roku, asi que lo descartamos.
        if type(fieldValue) = "roString" or type(fieldValue) = "String"
            if Len(fieldValue) > 500 and Left(fieldValue, 5) = "data:" then goto skipField
        end if

        aa[fieldName] = fieldValue
        skipField:
    end while

    return aa
end function

function Fav_AAToNode(aa as Object) as Object
    node = CreateObject("roSGNode", "ContentNode")
    ' setFields() SOLO asigna valor a campos que YA existen en el nodo --
    ' a diferencia de addFields(), no crea campos nuevos. genre/director/
    ' episodeRunTime no son campos nativos de ContentNode (a diferencia de
    ' HDPosterUrl, que si lo es), asi que hay que crearlos primero o
    ' setFields los descarta en silencio.
    if not node.hasField("genre") then node.addFields({genre: "", director: "", episodeRunTime: ""})
    if aa <> invalid then node.setFields(aa)
    ' Salvaguarda: un favorito viejo/incompleto sin portada guardada no
    ' debe dejar la tarjeta en blanco -- se usa el generico, igual que en
    ' el resto de la app (fillMovieNode/fillSerieNode/Fav_FetchVodInfo).
    if node.HDPosterUrl = invalid or node.HDPosterUrl = ""
        node.HDPosterUrl = "pkg:/images/no-poster.jpg"
    end if
    return node
end function

' ------------------------------------------------------------
' Resolución completa desde servidor (solo se usa para SEMBRAR
' el local cuando esta vacio, no en el uso normal)
' ------------------------------------------------------------

function Fav_FetchVodInfo(id as String, su as String, u as String, p as String) as Object
    url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_vod_info&vod_id=" + id
    raw = requestData(url)
    data = ParseJSON(raw)
    if data = invalid or type(data) <> "roAssociativeArray"
        print "DEBUG Fav_FetchVodInfo - id="; id; " respuesta invalida/no-JSON. Crudo (primeros 200 chars) = "; Left(raw, 200)
        return invalid
    end if

    info = invalid
    if data.info <> invalid then info = data.info
    if info = invalid and data.movie_data <> invalid then info = data.movie_data
    if info = invalid or type(info) <> "roAssociativeArray"
        print "DEBUG Fav_FetchVodInfo - id="; id; " sin campo info/movie_data. JSON crudo (primeros 200 chars) = "; Left(raw, 200)
        return invalid
    end if

    streamId = id
    ext = "ts"
    if data.movie_data <> invalid and type(data.movie_data) = "roAssociativeArray"
        if data.movie_data.stream_id <> invalid then streamId = data.movie_data.stream_id.toStr()
        if data.movie_data.container_extension <> invalid and data.movie_data.container_extension <> ""
            ext = data.movie_data.container_extension
        end if
    end if

    aa = {}
    aa["id"] = id
    if info.name <> invalid and info.name <> "" then
        aa["title"] = info.name
    else if info.o_name <> invalid and info.o_name <> "" then
        aa["title"] = info.o_name
    else if info.title <> invalid and info.title <> "" then
        aa["title"] = info.title
    end if
    if info.plot <> invalid and info.plot <> "" then aa["description"] = info.plot
    if info.movie_image <> invalid and info.movie_image <> "" then
        aa["HDPosterUrl"] = info.movie_image
    else
        aa["HDPosterUrl"] = "pkg:/images/no-poster.jpg"
    end if
    if info.rating <> invalid then aa["rating"] = info.rating.toStr()
    if info.releasedate <> invalid then aa["releaseDate"] = info.releasedate.toStr()
    if info.genre <> invalid then aa["genre"] = info.genre
    if info.director <> invalid then aa["director"] = info.director
    aa["url"] = su + "/movie/" + u + "/" + p + "/" + streamId + "." + ext
    aa["ContentType"] = "1"
    return aa
end function

function Fav_FetchSerieInfo(id as String, su as String, u as String, p as String) as Object
    url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_series_info&series_id=" + id
    raw = requestData(url)
    data = ParseJSON(raw)
    if data = invalid or type(data) <> "roAssociativeArray"
        print "DEBUG Fav_FetchSerieInfo - id="; id; " respuesta invalida/no-JSON. Crudo (primeros 200 chars) = "; Left(raw, 200)
        return invalid
    end if
    info = data.info
    if info = invalid or type(info) <> "roAssociativeArray"
        print "DEBUG Fav_FetchSerieInfo - id="; id; " sin campo info. JSON crudo (primeros 200 chars) = "; Left(raw, 200)
        return invalid
    end if

    aa = {}
    aa["id"] = id
    if info.name <> invalid and info.name <> "" then
        aa["title"] = info.name
    else if info.o_name <> invalid and info.o_name <> "" then
        aa["title"] = info.o_name
    else if info.title <> invalid and info.title <> "" then
        aa["title"] = info.title
    end if
    if info.plot <> invalid and info.plot <> "" then aa["description"] = info.plot
    if info.cover <> invalid and info.cover <> "" then
        aa["HDPosterUrl"] = info.cover
    else
        aa["HDPosterUrl"] = "pkg:/images/no-poster.jpg"
    end if
    if info.rating <> invalid then aa["rating"] = info.rating.toStr()
    if info.releaseDate <> invalid then aa["releaseDate"] = info.releaseDate.toStr()
    if info.genre <> invalid then aa["genre"] = info.genre
    aa["ContentType"] = "2"
    return aa
end function

' Pide al servidor la lista COMPLETA de favoritos (sin filtro &tipo=,
' porque no esta confirmado que el backend lo soporte para
' peliculas/series -- solo sabemos con certeza que funciona para
' "canal"). Descarta los de canal (prefijo "ch-") y por cada uno
' intenta resolverlo primero como pelicula y si no como serie (mismo
' metodo por prueba-error que ya usaba el codigo original), cacheando
' el resultado localmente bajo el tipo correcto.
' Se usa SOLO cuando el local esta vacio para peliculas Y series.
sub Fav_SeedMovieSeriesFromServer(usuario as String, su as String, u as String, p as String)
    baseUrl = Fav_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("User-Agent", "Mozilla/5.0")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=list&user=" + usuario + "&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil())
    listData = ParseJSON(request.GetToString())
    if listData = invalid or type(listData) <> "roArray" then return

    for each fav in listData
        if type(fav) = "roAssociativeArray" and fav.cve <> invalid
            rawId = fav.cve.toStr()
            if Left(rawId, 3) <> "ch-"
                if Left(rawId, 4) = "fav-" then rawId = Mid(rawId, 5)

                info = Fav_FetchVodInfo(rawId, su, u, p)
                if info <> invalid
                    Fav_LocalWrite("pelicula", rawId, info)
                else
                    info = Fav_FetchSerieInfo(rawId, su, u, p)
                    if info <> invalid then Fav_LocalWrite("serie", rawId, info)
                end if
            end if
        end if
    end for
end sub

' ============================================================
' SINCRONIZACION ENTRE DISPOSITIVOS ("changes" incremental)
' ============================================================
' Cada usuario guarda la fecha (epoch) de su ultima sincronizacion
' exitosa. La siguiente vez, solo se piden al servidor los cambios
' posteriores a esa fecha (altas/bajas/reactivaciones hechas desde
' CUALQUIER dispositivo), en vez de traer todo el historial otra
' vez. since=0 (primera vez en este dispositivo) trae todo, asi que
' esta misma funcion reemplaza tanto al sembrado inicial como a
' las sincronizaciones posteriores.
' ============================================================

function Fav_SyncSection() as Object
    return CreateObject("roRegistrySection", "FavSync")
end function

function Fav_GetLastSync(usuario as String) as Integer
    sec = Fav_SyncSection()
    raw = sec.Read(usuario)
    if raw = invalid or raw = "" then return 0
    return raw.toInt()
end function

sub Fav_SetLastSync(usuario as String, epoch as Integer)
    sec = Fav_SyncSection()
    sec.Write(usuario, epoch.toStr())
    sec.Flush()
end sub

' Trae de golpe TODO lo que cambio (peliculas, series Y canales)
' desde la ultima sincronizacion de este dispositivo, y lo aplica
' al local: altas/reactivaciones se agregan (resolviendo su info
' completa si hace falta), bajas se borran. Se llama cada vez que
' se abre una pantalla que muestra favoritos, no solo si el local
' esta vacio, para poder enterarse de cambios hechos en otra tele.
' NOTA: esta funcion sincroniza PELICULAS y SERIES unicamente. Los
' favoritos de canal necesitan resolverse contra el catalogo completo
' de canales (titulo/icono/url) para poder guardarse localmente sin
' quedar a medias -- eso lo sigue haciendo EpgGuiaScreen.enterFavoritesMode
' por separado (ver ChannelFavoritesTask.brs). Se deja pendiente
' extender la sincronizacion incremental a canales en un siguiente paso.
' true si ya tenemos guardado localmente (como pelicula o como serie)
' un titulo real para este id -- no vacio y no el marcador generico
' "Contenido no disponible". Se usa para NO pisar un dato bueno que
' ya se capturo de la pantalla (AddFavorite/RegisterRecentlyWatched)
' con un fetch nuevo a get_vod_info que puede venir incompleto.
function Fav_LocalHasValidTitle(id as String, rowTitulo = "" as String) as Boolean
    tipo = "pelicula"
    aa = Fav_LocalRead("pelicula", id)
    if aa = invalid then
        tipo = "serie"
        aa = Fav_LocalRead("serie", id)
    end if
    if aa = invalid then return false
    if aa.title = invalid or aa.title = "" or aa.title = "Contenido no disponible" then return false
    ' No basta con tener titulo -- el "placeholder" que se guarda cuando
    ' falla la resolucion tambien trae un titulo real (el de la fila de
    ' la base de datos), asi que esta funcion decia "ya esta bien" para
    ' favoritos que en realidad nunca tuvieron portada ni URL para
    ' reproducir, y por eso nunca se volvian a intentar resolver de
    ' verdad. Ahora tambien se exige portada real (no la generica). Las
    ' peliculas ademas deben tener URL (las series se reproducen por
    ' episodio, nunca tienen URL propia, asi que no se les exige).
    if aa.HDPosterUrl = invalid or aa.HDPosterUrl = "" or aa.HDPosterUrl = "pkg:/images/no-poster.jpg" then return false
    if tipo = "pelicula" and (aa.url = invalid or aa.url = "") then return false
    ' Si el servidor manda un titulo para esta fila y NO coincide con lo
    ' que tenemos guardado, es señal de una colision de id entre el
    ' catalogo de peliculas y el de series (mismo numero, contenido
    ' distinto -- ver PASO 1 en Fav_SyncFromServer). Lo guardado es de
    ' OTRO contenido, asi que se fuerza a re-resolver en vez de darlo
    ' por valido para siempre.
    if rowTitulo <> ""
        if LCase(aa.title) <> LCase(rowTitulo) then return false
    end if
    return true
end function

sub Fav_SyncFromServer(usuario as String, su as String, u as String, p as String)
    ' El cursor de sincronizacion ("desde cuando pedir cambios") tiene
    ' que ser uno POR PERFIL (y por servidor) -- antes se compartia
    ' entre los hasta 5 perfiles de la cuenta (y entre servidores con el
    ' mismo usuario), asi que sincronizar un perfil adelantaba el
    ' cursor de TODOS los demas, y al cambiar de perfil los favoritos
    ' mas viejos de ESE perfil (con fecha anterior al cursor ya
    ' avanzado por otro perfil) simplemente dejaban de traerse -- daba
    ' la impresion de que los favoritos no se guardaban por separado.
    syncKey = usuario + "-ms-v" + Fav_CurrentVariante() + "-p" + Fav_CurrentPerfil()

    ' --- MIGRACION UNICA (recuperacion) ---
    ' La version anterior de esta funcion tenia un bug: si un favorito
    ' fallaba al resolverse (timeout momentaneo del proveedor), el
    ' cursor de sincronizacion avanzaba de todos modos, perdiendolo
    ' para siempre. Se fuerza UN resync completo (since=0) la primera
    ' vez que corre esta version corregida, para recuperar cualquier
    ' favorito que se haya perdido asi. Despues de esta unica vez, no
    ' se vuelve a repetir (se marca con una bandera en el registro).
    ' NOTA: se paso de v1 a v2 porque la bandera v1 ya se habia
    ' consumido en pruebas hechas ANTES de arreglar el bug de
    ' almacenamiento (registro -> archivos + hilo de render). Ese bug
    ' pudo haber dejado el cursor avanzado sin guardar de verdad
    ' favoritos que si estaban en el servidor -- v2 fuerza una
    ' recuperacion mas para traerlos de vuelta. v7: la bandera ahora se
    ' guarda por perfil+servidor (syncKey), no solo por usuario -- antes
    ' un perfil marcaba la migracion como hecha para TODA la cuenta, asi
    ' que un perfil nuevo (o el segundo/tercero) nunca disparaba su
    ' propio resync completo. Tambien fuerza a todos a recuperarse una
    ' vez mas ahora que el panel dejo de mezclar perfiles distintos
    ' (ver add_favorites.php: "perfil" ya no acepta el legado '0').
    migFlagKey = "migrated-fullresync-v7-" + syncKey
    migSec = Fav_SyncSection()
    migFlagVal = migSec.Read(migFlagKey)
    needsReset = (migFlagVal = invalid or migFlagVal = "")

    if not needsReset
        ' Autocuracion: la bandera vive en el registro (sobrevive al
        ' recompilar/redesplegar desde VSCode durante desarrollo), pero
        ' los favoritos viven en archivos (cachefs:/favorites, que SI
        ' se vacia al redesplegar). Si la bandera dice "ya se recupero
        ' todo" pero no hay NINGUN favorito guardado localmente (ni
        ' pelicula ni serie), es señal de que los datos se perdieron
        ' aunque la bandera diga lo contrario -- se ignora la bandera y
        ' se fuerza la recuperacion de nuevo.
        if Fav_LocalIsEmptyForType("pelicula") and Fav_LocalIsEmptyForType("serie")
            needsReset = true
            print "DEBUG Fav_SyncFromServer - la bandera decia 'ya recuperado' pero no hay ningun favorito local guardado (probable redespliegue durante desarrollo), se fuerza la recuperacion de nuevo"
        end if
    end if

    if needsReset
        print "DEBUG Fav_SyncFromServer - migracion unica: reseteando cursor para recuperar favoritos perdidos"
        Fav_SetLastSync(syncKey, 0)
        migSec.Write(migFlagKey, "1")
        migSec.Flush()
    end if

    since = Fav_GetLastSync(syncKey)

    baseUrl = Fav_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("User-Agent", "Mozilla/5.0")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=changes&user=" + usuario + "&since=" + since.toStr() + "&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil())
    resp = ParseJSON(request.GetToString())
    if resp = invalid or type(resp) <> "roAssociativeArray" or resp.rows = invalid then return

    allResolvedOk = true
    giveUpSec = Fav_SyncSection()
    ' PASO 2 (lote): todo lo que no se encuentre en el catalogo local
    ' (PASO 1) se apunta aqui en vez de preguntarle al panel de
    ' inmediato -- se resuelve TODO junto despues de este for, en un
    ' par de peticiones en vez de una por favorito.
    pendingList = []

    for each row in resp.rows
        if type(row) = "roAssociativeArray" and row.cve <> invalid
            rawId = row.cve.toStr()
            isDeleted = (row.deleted <> invalid and row.deleted.toStr() <> "0")

            if Left(rawId, 3) <> "ch-"
                cleanId = rawId
                if Left(cleanId, 4) = "fav-" then cleanId = Mid(cleanId, 5)

                if isDeleted
                    ' No sabemos con certeza si era pelicula o serie desde
                    ' aqui (filas viejas pueden traer "tipo" vacio), asi
                    ' que se intenta borrar de ambos tipos; el que no
                    ' exista simplemente no hace nada.
                    Fav_LocalDelete("pelicula", cleanId)
                    Fav_LocalDelete("serie", cleanId)
                else
                    rowTitulo = ""
                    if row.titulo <> invalid then rowTitulo = row.titulo.toStr().trim()
                    rowTipo = ""
                    if row.tipo <> invalid then rowTipo = row.tipo.toStr()

                    if Fav_LocalHasValidTitle(cleanId, rowTitulo)
                        ' Ya tenemos un titulo valido guardado local (se
                        ' capturo de la pantalla al agregar el favorito), y
                        ' coincide con lo que manda el servidor si mando algo.
                        ' No lo pisamos con un fetch nuevo que puede venir
                        ' incompleto del proveedor.
                        Fav_ClearMissTracking(giveUpSec, cleanId)
                    else
                    print "DEBUG FAVSYNC - cleanId="; cleanId; " row.titulo(crudo)="; row.titulo; " rowTitulo="; rowTitulo; " rowTipo="; rowTipo

                    giveUpKey = "giveup-" + cleanId
                    ' Ya no se respeta esta bandera aunque exista de una version
                    ' anterior -- antes dejaba favoritos rotos para siempre. Se
                    ' fuerza a false para que se reintenten de inmediato.
                    alreadyGaveUp = false

                    if alreadyGaveUp
                        ' Ya se agoto el limite de intentos antes. Si no
                        ' quedo un marcador generico guardado (giveups de
                        ' antes de este arreglo), se deja uno ahora para
                        ' que al menos aparezca en la lista. Si el propio
                        ' servidor ya tiene el titulo guardado, se usa ese
                        ' en vez del texto generico.
                        ' TAMBIEN: si ya existe un marcador generico de un
                        ' giveup viejo (title="Contenido no disponible")
                        ' pero el servidor YA tiene rowTitulo valido ahora
                        ' (llego despues), se actualiza -- antes se quedaba
                        ' atorado para siempre con el generico aunque
                        ' Recien Vistos (que no tiene este candado) ya
                        ' mostrara el titulo correcto para el mismo item.
                        needsPlaceholder = (not Fav_LocalExists("pelicula", cleanId) and not Fav_LocalExists("serie", cleanId))
                        needsRefresh = (rowTitulo <> "" and not Fav_LocalHasValidTitle(cleanId))
                        if needsPlaceholder or needsRefresh
                            placeholderTitle = "Contenido no disponible"
                            if rowTitulo <> "" then placeholderTitle = rowTitulo
                            ' Si ya existe (needsRefresh), se actualiza bajo
                            ' el MISMO tipo donde ya esta guardado, en vez
                            ' de adivinar por rowTipo y arriesgar crear un
                            ' duplicado bajo el tipo equivocado.
                            if Fav_LocalExists("pelicula", cleanId)
                                tipoToUse = "pelicula"
                            else if Fav_LocalExists("serie", cleanId)
                                tipoToUse = "serie"
                            else
                                tipoToUse = "pelicula"
                                if rowTipo = "serie" then tipoToUse = "serie"
                            end if
                            placeholder = {
                                id: cleanId,
                                title: placeholderTitle,
                                HDPosterUrl: "pkg:/images/no-poster.jpg"
                            }
                            Fav_LocalWrite(tipoToUse, cleanId, placeholder)
                        end if
                    else
                        ' --- PASO 1: buscar en el catalogo YA descargado localmente ---
                        ' Mismo criterio que ya usa Android/PC: primero se busca
                        ' el id en el catalogo local (sin tocar la red), y solo
                        ' si no aparece ahi se le pregunta en vivo al panel.
                        catTipo = "vod"
                        if rowTipo = "serie" then catTipo = "series"
                        otroTipo = "series"
                        if catTipo = "series" then otroTipo = "vod"

                        catItem = Cat_LocalFindById(usuario, catTipo, cleanId)
                        catItemOtro = Cat_LocalFindById(usuario, otroTipo, cleanId)

                        if catItem <> invalid and catItemOtro <> invalid
                            ' Colision de id: el proveedor tiene un vod_id Y un
                            ' series_id distintos que casualmente comparten el
                            ' mismo numero (pasa seguido en Xtream, son
                            ' numeraciones independientes). Sin esto, un
                            ' favorito de SERIE podia terminar guardado como
                            ' PELICULA (o al reves) si la coincidencia caia en
                            ' el catalogo que se revisa primero -- exactamente
                            ' lo que le paso a "El señor de los cielos": se
                            ' guardo como pelicula, y al abrirlo el servidor no
                            ' tenia get_vod_info para ese id (era un series_id),
                            ' asi que no mostraba portada ni reproducia nada.
                            ' Se usa el titulo que ya manda el servidor (si lo
                            ' manda) para desempatar cual de los dos es el real.
                            if rowTitulo <> ""
                                t1 = ""
                                if catItem.title <> invalid then t1 = LCase(catItem.title)
                                t2 = ""
                                if catItemOtro.title <> invalid then t2 = LCase(catItemOtro.title)
                                rt = LCase(rowTitulo)
                                if t1 <> rt and t2 = rt
                                    catItem = catItemOtro
                                    catTipo = otroTipo
                                    print "DEBUG FAVCAT - colision de id resuelta por titulo: id="; cleanId; " se usa tipo="; catTipo
                                end if
                            end if
                        else if catItem = invalid
                            ' No estaba en el catalogo adivinado por rowTipo,
                            ' pero si en el otro.
                            catItem = catItemOtro
                            catTipo = otroTipo
                        end if

                        if catItem <> invalid
                            print "DEBUG FAVCAT - encontrado en catalogo local: id="; cleanId; " tipo="; catTipo; " HDPosterUrl="; catItem.HDPosterUrl; " url="; catItem.url
                        else
                            print "DEBUG FAVCAT - NO encontrado en catalogo local: id="; cleanId; " catTipo="; catTipo
                        end if

                        if catItem <> invalid
                            tipoFinal = "pelicula"
                            ' Comparacion segura: catItem viene de ParseJSON, y
                            ' segun como haya quedado guardado el campo puede
                            ' regresar como numero en vez de texto. Comparar
                            ' String con Integer con "=" directo revienta con
                            ' "Type Mismatch" en BrightScript -- y como este
                            ' error no se atrapaba, mataba el resto del ciclo
                            ' de sincronizacion, dejando sin resolver (sin
                            ' portada, sin url) TODOS los favoritos que venian
                            ' despues del que causaba el problema.
                            ctVal = catItem.ContentType
                            ctStr = ""
                            if ctVal <> invalid
                                ctType = type(ctVal)
                                if ctType = "roString" or ctType = "String"
                                    ctStr = ctVal
                                else if ctType = "roInt" or ctType = "roInteger" or ctType = "Integer" or ctType = "roFloat" or ctType = "Float" or ctType = "roDouble" or ctType = "Double" or ctType = "roLongInteger" or ctType = "LongInteger"
                                    ctStr = ctVal.toStr()
                                end if
                            end if
                            if ctStr = "2" then tipoFinal = "serie"
                            if rowTitulo <> "" then catItem["title"] = rowTitulo
                            Fav_LocalWrite(tipoFinal, cleanId, catItem)
                            Fav_ClearMissTracking(giveUpSec, cleanId)
                            goto favResuelto
                        end if

                        ' --- PASO 2 (lote): no estaba en el catalogo local.
                        ' Se apunta para resolverlo junto con el resto de
                        ' pendientes despues de este for -- ver mas abajo.
                        pendingList.push({ id: cleanId, titulo: rowTitulo, tipo: rowTipo })
                    end if
                    end if
                end if
            end if
        end if
        favResuelto:
    end for

    ' --- PASO 2 (lote): resolver contra el panel TODO lo que no se
    ' encontro en el catalogo local, en un solo par de peticiones (via
    ' resolver.php) en vez de una peticion por favorito pendiente.
    ' Si resolver.php todavia no esta configurado en el panel, cae de
    ' vuelta al metodo viejo (uno por uno) para no perder
    ' funcionalidad mientras tanto.
    if pendingList.count() > 0
        if Fav_ResolverApiBase() <> ""
            pendingIds = []
            for each pend in pendingList
                pendingIds.push(pend.id)
            end for

            batchMovies = Fav_ResolveIdsBatch(pendingIds, "2", su, u, p)
            moviesById = {}
            for each mv in batchMovies
                mvId = ""
                if mv.stream_id <> invalid then mvId = mv.stream_id.toStr()
                if mvId <> "" then moviesById[mvId] = mv
            end for

            ' Se consulta series para TODOS los pendientes (no solo los
            ' que no aparecieron en peliculas) -- a proposito, para
            ' poder detectar colisiones de id: en Xtream, vod_id y
            ' series_id son numeraciones independientes que pueden
            ' coincidir por casualidad (mismo numero, contenido
            ' DISTINTO). Si solo se buscara en series lo que "falto" en
            ' peliculas, una serie cuyo id choca con una pelicula no
            ' relacionada se quedaria pegada a esa pelicula equivocada
            ' (titulo correcto por el rowTitulo, pero url/portada de
            ' otro contenido -- causa exactamente un error de
            ' reproduccion "datos malformados").
            batchSeries = Fav_ResolveIdsBatch(pendingIds, "3", su, u, p)
            seriesById = {}
            for each sr in batchSeries
                srId = ""
                if sr.series_id <> invalid then srId = sr.series_id.toStr()
                if srId <> "" then seriesById[srId] = sr
            end for

            print "DEBUG Fav_SyncFromServer - PASO2 en lote: "; pendingList.count(); " pendientes, "; moviesById.Count(); " encontrados como pelicula, "; seriesById.Count(); " encontrados como serie"

            for each pend in pendingList
                cleanId = pend.id
                rowTitulo = pend.titulo
                rowTipo = pend.tipo

                movieHit = invalid
                if moviesById.DoesExist(cleanId) then movieHit = moviesById[cleanId]
                serieHit = invalid
                if seriesById.DoesExist(cleanId) then serieHit = seriesById[cleanId]

                if movieHit <> invalid and serieHit <> invalid
                    ' Colision de id: aparecio en AMBOS catalogos. Se usa
                    ' el titulo que ya manda el servidor (si lo manda)
                    ' para desempatar cual de los dos es el real; si no
                    ' hay titulo o no coincide con ninguno, se prefiere
                    ' pelicula por default (mismo orden que ya usaba el
                    ' metodo directo: primero get_vod_info, luego
                    ' get_series_info).
                    if rowTitulo <> ""
                        mTit = ""
                        if movieHit.name <> invalid then mTit = LCase(movieHit.name)
                        sTit = ""
                        if serieHit.name <> invalid then sTit = LCase(serieHit.name)
                        rt = LCase(rowTitulo)
                        if mTit <> rt and sTit = rt
                            movieHit = invalid
                            print "DEBUG Fav_SyncFromServer - colision de id resuelta por titulo: id="; cleanId; " se usa serie"
                        end if
                    end if
                end if

                if movieHit <> invalid
                    aa = Fav_BuildAAFromBulkItem(movieHit, "pelicula", su, u, p)
                    if rowTitulo <> "" then aa["title"] = rowTitulo
                    Fav_LocalWrite("pelicula", cleanId, aa)
                    Fav_ClearMissTracking(giveUpSec, cleanId)
                else if serieHit <> invalid
                    aa = Fav_BuildAAFromBulkItem(serieHit, "serie", su, u, p)
                    if rowTitulo <> "" then aa["title"] = rowTitulo
                    Fav_LocalWrite("serie", cleanId, aa)
                    Fav_ClearMissTracking(giveUpSec, cleanId)
                else
                    ' No aparecio en el catalogo completo bajado por
                    ' resolver.php (podria ser un bug del endpoint, mala
                    ' configuracion en el panel, o simplemente que ese
                    ' item no vino en esa respuesta). En vez de darlo por
                    ' perdido de una vez, se intenta con el metodo
                    ' directo de siempre -- ese SIEMPRE debe quedar como
                    ' respaldo, para que un resolver.php roto nunca deje
                    ' peor los favoritos de lo que ya estaban.
                    info = Fav_FetchVodInfo(cleanId, su, u, p)
                    if info <> invalid
                        if rowTitulo <> "" then info["title"] = rowTitulo
                        Fav_LocalWrite("pelicula", cleanId, info)
                        Fav_ClearMissTracking(giveUpSec, cleanId)
                    else
                        info = Fav_FetchSerieInfo(cleanId, su, u, p)
                        if info <> invalid
                            if rowTitulo <> "" then info["title"] = rowTitulo
                            Fav_LocalWrite("serie", cleanId, info)
                            Fav_ClearMissTracking(giveUpSec, cleanId)
                        else
                            allResolvedOk = allResolvedOk and Fav_HandleUnresolvedFavorite(cleanId, rowTitulo, rowTipo, giveUpSec, usuario)
                        end if
                    end if
                end if
            end for
        else
            ' resolver.php no configurado todavia: metodo viejo, uno
            ' por uno (identico al que ya habia antes de este cambio).
            for each pend in pendingList
                cleanId = pend.id
                rowTitulo = pend.titulo
                rowTipo = pend.tipo

                info = Fav_FetchVodInfo(cleanId, su, u, p)
                if info <> invalid
                    if rowTitulo <> "" then info["title"] = rowTitulo
                    Fav_LocalWrite("pelicula", cleanId, info)
                    Fav_ClearMissTracking(giveUpSec, cleanId)
                else
                    info = Fav_FetchSerieInfo(cleanId, su, u, p)
                    if info <> invalid
                        if rowTitulo <> "" then info["title"] = rowTitulo
                        Fav_LocalWrite("serie", cleanId, info)
                        Fav_ClearMissTracking(giveUpSec, cleanId)
                    else
                        allResolvedOk = allResolvedOk and Fav_HandleUnresolvedFavorite(cleanId, rowTitulo, rowTipo, giveUpSec, usuario)
                    end if
                end if
            end for
        end if
    end if

    ' Se guarda el reloj del SERVIDOR (no el del dispositivo) como
    ' ultima sincronizacion, para no depender de que la hora local
    ' del Roku este bien puesta. Clave separada de canales (ver nota
    ' arriba) para no perder cambios de canal que aqui se ignoran.
    ' Si algo no se pudo resolver, el cursor NO avanza: la proxima
    ' sincronizacion vuelve a pedir este mismo lote completo, para no
    ' perder ese favorito para siempre por una falla momentanea de red.
    if allResolvedOk and resp.serverNow <> invalid
        Fav_SetLastSync(syncKey, resp.serverNow.toStr().toInt())
    end if

    ' --- RECONCILIACION LOCAL -> SERVIDOR ---
    ' Baja los cambios ya se aplicaron arriba; esto cubre el caso
    ' contrario: favoritos que el dispositivo tiene local pero el
    ' servidor no reporta (servidor perdio datos, o una alta anterior
    ' no llego a guardarse por una falla de red). Se vuelven a subir.
    Fav_ReconcileLocalToServer(usuario)
end sub

' Compara el local completo (peliculas+series) contra el estado
' actual del servidor (action=list, liviano: solo cve/tipo, no info
' completa) y vuelve a subir cualquier favorito que el local tenga
' pero el servidor no reporte -- para que el servidor sea siempre un
' respaldo fiel de lo que el dispositivo ya tiene, no solo al reves.
sub Fav_ReconcileLocalToServer(usuario as String)
    baseUrl = Fav_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("User-Agent", "Mozilla/5.0")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=list&user=" + usuario + "&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil())
    serverList = ParseJSON(request.GetToString())
    if serverList = invalid or type(serverList) <> "roArray" then return

    serverIds = {}
    for each row in serverList
        if type(row) = "roAssociativeArray" and row.cve <> invalid
            id = row.cve.toStr()
            if Left(id, 4) = "fav-" then id = Mid(id, 5)
            serverIds[id] = true
        end if
    end for

    localMovies = Fav_LocalListByType("pelicula")
    for each item in localMovies
        if item.id <> invalid and not serverIds.doesExist(item.id.toStr())
            Fav_PushToServer(usuario, item.id.toStr(), "pelicula")
        end if
    end for

    localSeries = Fav_LocalListByType("serie")
    for each item in localSeries
        if item.id <> invalid and not serverIds.doesExist(item.id.toStr())
            Fav_PushToServer(usuario, item.id.toStr(), "serie")
        end if
    end for
end sub

' Vuelve a subir un favorito puntual al servidor (upsert), usado por
' la reconciliacion local->servidor.
sub Fav_PushToServer(usuario as String, cve as String, tipo as String)
    baseUrl = Fav_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("User-Agent", "Mozilla/5.0")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=a&user=" + usuario + "&cve=" + cve + "&tipo=" + tipo + "&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil())
    request.GetToString()
    print "DEBUG Fav_ReconcileLocalToServer - re-subido al servidor: tipo="; tipo; " cve="; cve
end sub

' Avisa al servidor (add_favorites.php?action=d, borrado suave) que un
' favorito se elimino localmente por confirmarse ausente del catalogo
' (ver Fav_HandleUnresolvedFavorite). Usa el mismo endpoint/accion que
' un borrado manual, para que se propague igual al resto de
' dispositivos de la cuenta via action=changes.
sub Fav_PushDeleteToServer(usuario as String, cve as String, tipo as String)
    baseUrl = Fav_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("User-Agent", "Mozilla/5.0")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=d&user=" + usuario + "&cve=" + cve + "&tipo=" + tipo + "&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil())
    request.GetToString()
    print "DEBUG Fav_HandleUnresolvedFavorite - borrado propagado al servidor: tipo="; tipo; " cve="; cve
end sub

' ------------------------------------------------------------
' Delta de FAVORITOS DE CANAL. A diferencia de Fav_SyncFromServer
' (peliculas/series), esta NO resuelve la info completa (titulo/
' icono/url) porque el servidor no la guarda -- eso necesita
' cruzarse contra el catalogo completo de canales, que solo
' EpgGuiaScreen tiene a mano. Por eso esta funcion solo devuelve
' los ids en bruto, separados en "added" (por resolver contra el
' catalogo) y "removed" (borrado directo, no necesita catalogo).
' Usa su PROPIO cursor de sincronizacion ("-canal"), separado del
' de peliculas/series, para que no se pisen entre si.
' ------------------------------------------------------------
function Fav_ChannelDeltaFromServer(usuario as String) as Object
    result = {added: [], removed: []}

    ' Mismo motivo que en Fav_SyncFromServer: el cursor tiene que ser
    ' por perfil+servidor, si no un perfil adelanta el cursor de todos
    ' los demas y sus canales favoritos mas viejos dejan de traerse.
    syncKey = usuario + "-canal-v" + Fav_CurrentVariante() + "-p" + Fav_CurrentPerfil()
    since = Fav_GetLastSync(syncKey)

    baseUrl = Fav_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("User-Agent", "Mozilla/5.0")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=changes&user=" + usuario + "&since=" + since.toStr() + "&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil())
    resp = ParseJSON(request.GetToString())
    if resp = invalid or type(resp) <> "roAssociativeArray" or resp.rows = invalid then return result

    for each row in resp.rows
        if type(row) = "roAssociativeArray" and row.cve <> invalid
            rawId = row.cve.toStr()
            if Left(rawId, 3) = "ch-"
                chId = Mid(rawId, 4)
                if chId <> ""
                    isDeleted = (row.deleted <> invalid and row.deleted.toStr() <> "0")
                    if isDeleted
                        result.removed.push(chId)
                    else
                        result.added.push(chId)
                    end if
                end if
            end if
        end if
    end for

    if resp.serverNow <> invalid then Fav_SetLastSync(syncKey, resp.serverNow.toStr().toInt())
    return result
end function

' ------------------------------------------------------------
' Canales de favoritos pendientes de resolver contra el catalogo
' completo (ver EpgGuiaScreen.brs). Mismo limite de 3 intentos que
' ya se usa para peliculas/series: si un canal favorito no se
' encuentra en el catalogo 3 veces seguidas, se deja de intentar
' (puede que el proveedor lo haya dado de baja).
' ------------------------------------------------------------
function Fav_ChannelPendingSection() as Object
    return CreateObject("roRegistrySection", "ChannelPendingResolve")
end function

' Agrega un id de canal a la lista de pendientes (si no estaba ya).
sub Fav_ChannelPendingAdd(chId as String)
    sec = Fav_ChannelPendingSection()
    key = "pending-" + chId
    existing = sec.Read(key)
    if existing = invalid or existing = ""
        sec.Write(key, "0")
        sec.Flush()
    end if
end sub

' Todos los ids de canal aun pendientes de resolver (sin importar
' cuando se agregaron), para reintentarlos junto con los nuevos que
' traiga el delta de esta vez.
function Fav_ChannelPendingList() as Object
    sec = Fav_ChannelPendingSection()
    result = []
    keys = sec.GetKeyList()
    if keys = invalid then return result
    for each key in keys
        if Left(key, 8) = "pending-" then result.push(Mid(key, 9))
    end for
    return result
end function

sub Fav_ChannelPendingResolved(chId as String)
    sec = Fav_ChannelPendingSection()
    sec.Delete("pending-" + chId)
    sec.Flush()
end sub

' Marca un intento fallido para este canal. Al llegar a 3 intentos,
' se deja de reintentar (se quita de la lista de pendientes).
sub Fav_ChannelPendingFail(chId as String)
    MAX_RETRIES = 3
    sec = Fav_ChannelPendingSection()
    key = "pending-" + chId
    raw = sec.Read(key)
    count = 0
    if raw <> invalid and raw <> "" then count = raw.toInt()
    count = count + 1
    if count >= MAX_RETRIES
        sec.Delete(key)
        sec.Flush()
        print "DEBUG Fav_ChannelPendingFail - chId="; chId; " fallo "; count; " veces, se deja de reintentar"
    else
        sec.Write(key, count.toStr())
        sec.Flush()
        print "DEBUG Fav_ChannelPendingFail - chId="; chId; " (intento "; count; " de "; MAX_RETRIES; "), se reintentara despues"
    end if
end sub

' ------------------------------------------------------------
' Arma el ContentNode de "Mi Top 20" (peliculas+series favoritas,
' ordenadas por mas reciente, limitadas a 20) usando SOLO datos
' locales -- sin red, se puede llamar directo desde el hilo de
' render (HomeScreen.brs) para mostrar contenido real de inmediato,
' o desde una Task (HomeContentTask.brs) despues de sincronizar.
' ------------------------------------------------------------
function Fav_BuildTop20ContentNode() as Object
    content = createObject("roSGNode", "ContentNode")
    locMovies = Fav_LocalListByType("pelicula")
    locSeries = Fav_LocalListByType("serie")

    MAX_TOP = 20
    combined = []
    for each aa in locMovies
        combined.push(aa)
    end for
    for each aa in locSeries
        aa["_esSerie"] = true
        combined.push(aa)
    end for

    ' Ordenar por _addedAt descendente (mas reciente primero).
    for i = 1 to combined.count() - 1
        key = combined[i]
        keyTs = 0
        if key._addedAt <> invalid then keyTs = key._addedAt
        j = i - 1
        keepGoing = true
        while j >= 0 and keepGoing
            jTs = 0
            if combined[j]._addedAt <> invalid then jTs = combined[j]._addedAt
            if jTs < keyTs
                combined[j + 1] = combined[j]
                j = j - 1
            else
                keepGoing = false
            end if
        end while
        combined[j + 1] = key
    end for

    total = combined.count()
    if total > MAX_TOP then total = MAX_TOP

    for i = 0 to total - 1
        aa = combined[i]
        node = Fav_AAToNode(aa)
        if aa["_esSerie"] = true and not node.hasField("isSerie") then node.addFields({isSerie: true})
        content.appendChild(node)
    end for

    return content
end function


