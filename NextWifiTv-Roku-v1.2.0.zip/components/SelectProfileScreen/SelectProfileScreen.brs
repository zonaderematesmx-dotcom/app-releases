' ============================================================
' SelectProfileScreen.brs
' ============================================================
' Ver SelectProfileScreen.xml para el flujo general. Navegacion con
' izquierda/derecha entre tarjetas (mismo estilo que RegScreen.brs:
' la pantalla maneja el foco visual a mano vía onKeyEvent, y cada
' ProfileTile solo reacciona a OK porque es el nodo que de verdad
' tiene el foco de SceneGraph en ese momento).
' ============================================================

' Misma guarda "<> invalid" que ya usan Fav_CurrentVariante() y el
' resto de los LocalStore -- m.global.serverVariant se asigna en
' ConfirmUser.brs/LoginTask.xml ya avanzado el login, asi que leerlo
' directo (sin este chequeo) revienta con "Interface not a member of
' BrightScript Component" en cuanto serverVariant todavia es invalid
' (por ejemplo, si esta pantalla llegara a abrirse antes de que ese
' campo se haya terminado de asignar).
function CurrentServerVariante() as String
    if m.global <> invalid and m.global.serverVariant <> invalid and m.global.serverVariant.toStr() <> ""
        return m.global.serverVariant.toStr()
    end if
    return "0"
end function

sub init()
    m.tilesRow        = m.top.findNode("tilesRow")
    m.floatingKeyboard = m.top.findNode("floatingKeyboard")
    m.addPromptLabel  = m.top.findNode("addPromptLabel")
    m.errorLabel      = m.top.findNode("errorLabel")
    m.hintLabel       = m.top.findNode("hintLabel")
    m.colorPickerGroup = m.top.findNode("colorPickerGroup")
    m.colorSwatchRow  = m.top.findNode("colorSwatchRow")

    m.tiles = []
    m.colorSwatches = []
    m.focusIndex = 0
    m.focusColorValue = "0x00A8FFFF"
    m.pickingColor = false
    m.colorFocusIndex = 0

    m.top.setFocus(true)

    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")

    loadProfiles()
end sub

sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0x00A8FFFF"
    m.focusColorValue = fc
    for each t in m.tiles
        t.ringColor = fc
    end for
end sub

sub loadProfiles()
    m.perfilesTask = createObject("roSGNode", "PerfilesTask")
    ' Se observa "state" (siempre cambia al terminar la tarea) y NO
    ' "perfiles" directamente -- si la cuenta todavia no tiene ningun
    ' perfil creado, el campo "perfiles" llega vacio ([]) igual que su
    ' valor inicial, y sin alwaysNotify el observer nunca se dispararia,
    ' dejando la pantalla colgada. Mismo patron que ConfirmUser/
    ' LoginTask en toda la app.
    m.perfilesTask.observeField("state", "onListDone")
    m.perfilesTask.action = "list"
    m.perfilesTask.user = m.global.user
    m.perfilesTask.variante = CurrentServerVariante()
    m.perfilesTask.control = "RUN"
end sub

sub onListDone()
    if m.perfilesTask.state <> "stop" then return
    if m.perfilesTask.errorMsg <> invalid and m.perfilesTask.errorMsg <> ""
        showError(m.perfilesTask.errorMsg)
    else
        hideError()
    end if
    perfiles = m.perfilesTask.perfiles
    if perfiles = invalid then perfiles = []
    buildTiles(perfiles)
end sub

' Antes un fallo aqui (el mas comun: en el panel todavia no se guardo
' la URL de perfiles.php en "Base de datos" -> "Gestion de URLs") no
' se veia en ningun lado -- ni la lista de perfiles cargaba, ni crear
' uno nuevo hacia nada, sin ninguna pista de que estaba pasando.
sub showError(msg as String)
    if m.errorLabel = invalid then return
    m.errorLabel.text = msg
    m.errorLabel.visible = true
end sub

sub hideError()
    if m.errorLabel = invalid then return
    m.errorLabel.visible = false
end sub

' Colores de avatar, uno distinto por perfil segun su posicion en la
' lista (no segun su "numero" fijo, para que no se repita el mismo
' color aunque un perfil de en medio se haya borrado).
function avatarColors() as Object
    return ["0xE5424DFF", "0x4DA6E5FF", "0x4DE5A0FF", "0xE5C64DFF", "0xB04DE5FF", "0x274B7EFF", "0xE5824DFF"]
end function

sub buildTiles(perfiles as Object)
    for each t in m.tiles
        m.tilesRow.removeChild(t)
    end for
    m.tiles = []

    colors = avatarColors()
    idx = 0
    for each p in perfiles
        nombre = ""
        if p.nombre <> invalid then nombre = p.nombre.toStr()
        numero = 0
        ' .toStr().ToInt() en vez de asignar el valor tal cual: PDO del
        ' lado del panel puede mandar "numero" como string ("3") segun
        ' la version de PHP/MySQL, y un string no se puede asignar
        ' directo a un campo tipado "integer" del nodo (queda en 0).
        if p.numero <> invalid then numero = p.numero.toStr().ToInt()
        ' Color elegido por el usuario al crear/editar el perfil (ver
        ' perfiles.php). Si vino vacio (perfiles creados antes de poder
        ' elegir color, o dato corrupto) se cae de vuelta al ciclo por
        ' posicion de siempre.
        color = ""
        if p.color <> invalid then color = p.color.toStr()
        if color = "" then color = colors[idx mod colors.Count()]
        tile = createTile(false, numero, nombre, color)
        m.tilesRow.appendChild(tile)
        m.tiles.push(tile)
        idx = idx + 1
    end for

    if perfiles.Count() < 5
        addTile = createTile(true, 0, "Agregar", "0x2A2A2AFF")
        m.tilesRow.appendChild(addTile)
        m.tiles.push(addTile)
    end if

    layoutTiles()
    m.focusIndex = 0
    setFocusIndex(0)
end sub

function createTile(isAdd as Boolean, numero as Integer, nombre as String, color as String) as Object
    tile = createObject("roSGNode", "ProfileTile")
    tile.isAddTile = isAdd
    tile.numero = numero
    tile.label = nombre
    tile.avatarColor = color
    tile.colorHex = color
    tile.ringColor = m.focusColorValue
    if not isAdd and nombre <> ""
        tile.initial = UCase(Left(nombre, 1))
    end if
    tile.observeFieldScoped("buttonSelected", "onTileSelected")
    return tile
end function

sub layoutTiles()
    tileW = 150.0
    gap = 56.0
    n = m.tiles.Count()
    if n = 0 then return
    totalW = n * tileW + (n - 1) * gap
    startX = (1280.0 - totalW) / 2.0
    for i = 0 to n - 1
        m.tiles[i].translation = [startX + i * (tileW + gap), 0.0]
    end for
end sub

sub setFocusIndex(i as Integer)
    if m.tiles.Count() = 0 then return
    if i < 0 or i >= m.tiles.Count() then return
    m.tiles[m.focusIndex].focused = false
    m.focusIndex = i
    m.tiles[m.focusIndex].focused = true
    m.tiles[m.focusIndex].setFocus(true)
end sub

sub onTileSelected(event as Object)
    tile = event.GetRoSGNode()
    if tile = invalid then return
    if tile.isAddTile
        startAddFlow()
    else
        m.global.profileId = tile.numero.toStr()
        ' Nombre y color de avatar de este perfil, para que HomeScreen
        ' pueda mostrarlos en su barra de menu (item de "Perfil") sin
        ' tener que volver a consultar la lista de perfiles al panel.
        m.global.profileNombre = tile.label
        m.global.profileColor = tile.colorHex
        m.top.profileChosen = true
    end if
end sub

' --- Alta y edicion comparten el mismo flujo de dos pasos: escribir  ---
' --- el nombre con el teclado flotante, y luego elegir un color de   ---
' --- la paleta fija. Lo unico que cambia entre los dos es la accion  ---
' --- que se manda al final (add vs rename) y si hay un "numero" ya   ---
' --- existente que actualizar.                                      ---

sub startAddFlow()
    m.pendingAction = "add"
    m.pendingNumero = 0
    m.pendingColor  = ""
    openNameKeyboard("")
end sub

sub startEditFlow(tile as Object)
    if tile = invalid or tile.isAddTile then return
    m.pendingAction = "rename"
    m.pendingNumero = tile.numero
    m.pendingColor  = tile.colorHex
    openNameKeyboard(tile.label)
end sub

sub openNameKeyboard(prefill as String)
    if m.floatingKeyboard = invalid then return
    hideError()
    m.floatingKeyboard.text = prefill
    m.floatingKeyboard.confirmed = false
    ' unobserve primero: si el usuario abre el teclado, cancela y lo
    ' vuelve a abrir varias veces, sin esto quedarian varios observers
    ' apilados y una sola confirmacion terminaria mandando la accion
    ' repetida (una vez por cada vez que se abrio el teclado).
    m.floatingKeyboard.unobserveField("confirmed")
    m.floatingKeyboard.observeFieldScoped("confirmed", "onNameConfirmed")
    m.addPromptLabel.visible = true
    m.floatingKeyboard.visible = true
    m.floatingKeyboard.setFocus(true)
end sub

sub onNameConfirmed()
    if not m.floatingKeyboard.confirmed then return
    nombre = m.floatingKeyboard.text.Trim()
    m.floatingKeyboard.visible = false
    m.addPromptLabel.visible = false

    if nombre = ""
        if m.tiles.Count() > 0 then m.tiles[m.focusIndex].setFocus(true)
        return
    end if

    m.pendingNombre = nombre
    showColorPicker()
end sub

' --- Paso 2: elegir color (se muestra despues de confirmar el nombre) ---

sub showColorPicker()
    if m.colorPickerGroup = invalid then return

    ' Se arma la fila de muescas desde cero cada vez (igual que
    ' buildTiles() con las tarjetas de perfil), asi que primero se
    ' quitan las de la vez anterior si las hubiera.
    for each s in m.colorSwatches
        m.colorSwatchRow.removeChild(s)
    end for
    m.colorSwatches = []

    colors = avatarColors()
    preIdx = 0
    ' Si se esta editando un perfil que ya tenia color, la paleta abre
    ' con ese color ya enfocado en vez de siempre empezar en el primero.
    if m.pendingColor <> invalid and m.pendingColor <> ""
        for i = 0 to colors.Count() - 1
            if LCase(colors[i]) = LCase(m.pendingColor) then preIdx = i
        end for
    end if

    for each c in colors
        swatch = createObject("roSGNode", "ColorSwatch")
        swatch.swatchColor = c
        swatch.ringColor = m.focusColorValue
        swatch.observeFieldScoped("buttonSelected", "onColorSwatchSelected")
        m.colorSwatchRow.appendChild(swatch)
        m.colorSwatches.push(swatch)
    end for
    layoutColorSwatches()

    m.colorFocusIndex = 0
    m.pickingColor = true
    m.colorPickerGroup.visible = true
    ' Foco real de SceneGraph directo sobre la muesca (igual que
    ' setFocusIndex() ya hace con cada ProfileTile) -- asi izquierda/
    ' derecha/OK llegan de verdad, en vez de depender de que la
    ' pantalla misma (un nodo no enfocable) reciba el foco.
    setColorFocusIndex(preIdx)
end sub

sub layoutColorSwatches()
    swatchW = 74.0
    gap = 36.0
    n = m.colorSwatches.Count()
    if n = 0 then return
    totalW = n * swatchW + (n - 1) * gap
    startX = (1280.0 - totalW) / 2.0
    for i = 0 to n - 1
        m.colorSwatches[i].translation = [startX + i * (swatchW + gap), 0.0]
    end for
end sub

sub setColorFocusIndex(i as Integer)
    n = m.colorSwatches.Count()
    if n = 0 then return
    idx = i
    if idx < 0 then idx = n - 1
    if idx >= n then idx = 0
    m.colorSwatches[m.colorFocusIndex].focused = false
    m.colorFocusIndex = idx
    m.colorSwatches[m.colorFocusIndex].focused = true
    m.colorSwatches[m.colorFocusIndex].setFocus(true)
end sub

sub onColorSwatchSelected(event as Object)
    swatch = event.GetRoSGNode()
    if swatch = invalid then return
    confirmColorAndSubmit()
end sub

sub confirmColorAndSubmit()
    colors = avatarColors()
    m.pendingColor = colors[m.colorFocusIndex]
    m.pickingColor = false
    m.colorPickerGroup.visible = false
    submitProfile()
end sub

sub cancelColorPicker()
    m.pickingColor = false
    m.colorPickerGroup.visible = false
    if m.tiles.Count() > 0 then m.tiles[m.focusIndex].setFocus(true)
end sub

sub submitProfile()
    m.profileTask = createObject("roSGNode", "PerfilesTask")
    m.profileTask.observeField("state", "onProfileTaskDone")
    m.profileTask.action = m.pendingAction
    m.profileTask.user = m.global.user
    m.profileTask.variante = CurrentServerVariante()
    m.profileTask.nombre = m.pendingNombre
    m.profileTask.color = m.pendingColor
    if m.pendingAction = "rename" then m.profileTask.numero = m.pendingNumero
    m.profileTask.control = "RUN"
end sub

sub onProfileTaskDone()
    if m.profileTask.state <> "stop" then return
    ' Antes esto llamaba a loadProfiles() sin importar el resultado --
    ' si el alta/edicion fallaba (sin URL de perfiles.php configurada
    ' en el panel, ya hay 5 perfiles, sin red, etc.) el error quedaba
    ' guardado en errorMsg pero nunca se leia, asi que en pantalla "no
    ' pasaba nada".
    if m.profileTask.errorMsg <> invalid and m.profileTask.errorMsg <> ""
        showError(m.profileTask.errorMsg)
        if m.tiles.Count() > 0 then m.tiles[m.focusIndex].setFocus(true)
        return
    end if
    ' Recarga la lista completa del servidor -- mas simple y seguro
    ' que intentar mantener el estado local sincronizado a mano.
    loadProfiles()
end sub

' --- Menu de opciones (boton "Opciones" / * sobre una tarjeta ya  ---
' --- existente, no la de "Agregar") -- mismo boton que ya usa el ---
' --- resto de la app para acciones contextuales (ver "options"   ---
' --- en MoviesBrowseScreen.brs/SearchScreen.brs/etc).             ---

sub showTileOptions()
    if m.tiles.Count() = 0 then return
    tile = m.tiles[m.focusIndex]
    if tile = invalid or tile.isAddTile then return
    m.optionsTargetTile = tile

    dialog = createObject("roSGNode", "Dialog")
    dialog.title = tile.label
    dialog.message = "¿Que quieres hacer con este perfil?"
    dialog.buttons = ["Editar nombre y color", "Borrar perfil", "Cancelar"]

    scene = m.top.getScene()
    if scene = invalid then return
    scene.dialog = dialog
    dialog.observeField("buttonSelected", "onTileOptionsRespuesta")
end sub

sub onTileOptionsRespuesta()
    scene = m.top.getScene()
    if scene = invalid then return
    dialog = scene.dialog
    if dialog = invalid then return

    seleccion = dialog.buttonSelected
    dialog.close = true
    scene.dialog = invalid

    tile = m.optionsTargetTile
    if tile = invalid then return

    if seleccion = 0
        startEditFlow(tile)
    else if seleccion = 1
        confirmarBorrarPerfil(tile)
    end if
    ' seleccion = 2 ("Cancelar") o cualquier otro valor: no hacer nada.
end sub

sub confirmarBorrarPerfil(tile as Object)
    if tile = invalid or tile.isAddTile then return

    m.deleteNumero = tile.numero
    m.deleteNombre = tile.label

    dialog = createObject("roSGNode", "Dialog")
    dialog.title = "Borrar perfil"
    dialog.message = "¿Borrar el perfil " + m.deleteNombre + "? Se perdera su historial, favoritos y ajustes guardados en este servidor."
    dialog.buttons = ["Borrar", "Cancelar"]

    scene = m.top.getScene()
    if scene = invalid then return
    scene.dialog = dialog
    dialog.observeField("buttonSelected", "onBorrarPerfilRespuesta")
end sub

sub onBorrarPerfilRespuesta()
    scene = m.top.getScene()
    if scene = invalid then return
    dialog = scene.dialog
    if dialog = invalid then return

    seleccion = dialog.buttonSelected
    dialog.close = true
    scene.dialog = invalid

    if seleccion <> 0 then return

    m.deleteTask = createObject("roSGNode", "PerfilesTask")
    m.deleteTask.observeField("state", "onDeleteDone")
    m.deleteTask.action = "delete"
    m.deleteTask.user = m.global.user
    m.deleteTask.variante = CurrentServerVariante()
    m.deleteTask.numero = m.deleteNumero
    m.deleteTask.control = "RUN"
end sub

sub onDeleteDone()
    if m.deleteTask.state <> "stop" then return
    ' No hay errorMsg que revisar aqui (doDelete() en PerfilesTask.xml
    ' no lo usa -- un borrado "de mas" no es grave, y reintentar es
    ' gratis: el numero borrado nunca se reutiliza). Se recarga la
    ' lista completa igual que despues de agregar.
    loadProfiles()
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    if m.floatingKeyboard <> invalid and m.floatingKeyboard.visible then return false

    ' Nota: "OK" ya no se maneja aqui -- la muesca enfocada (ColorSwatch)
    ' tiene el foco real de SceneGraph y responde ella misma a OK
    ' (dispara buttonSelected -> onColorSwatchSelected), exactamente
    ' igual que cada ProfileTile con las tarjetas de perfil.
    if m.pickingColor
        if key = "left"
            setColorFocusIndex(m.colorFocusIndex - 1)
        else if key = "right"
            setColorFocusIndex(m.colorFocusIndex + 1)
        else if key = "back"
            cancelColorPicker()
        end if
        return true
    end if

    if key = "left"
        setFocusIndex(m.focusIndex - 1)
        return true
    else if key = "right"
        setFocusIndex(m.focusIndex + 1)
        return true
    else if key = "options"
        showTileOptions()
        return true
    end if
    return false
end function
