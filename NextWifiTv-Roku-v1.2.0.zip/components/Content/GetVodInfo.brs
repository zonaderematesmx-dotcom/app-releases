sub init()
    m.top.functionName = "go"
end sub

sub go()
    vodId = m.top.vodId
    if vodId = "" then return

    su = m.global.serverURL
    u  = m.global.user
    p  = m.global.pass

    url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_vod_info&vod_id=" + vodId

    http = CreateObject("roUrlTransfer")
    http.AddHeader("User-Agent", "Mozilla/5.0")
    http.RetainBodyOnError(true)
    http.SetUrl(url)
    http.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http.EnableHostVerification(false)
    http.EnablePeerVerification(false)
    port = CreateObject("roMessagePort")
    http.SetPort(port)

    data = ""
    httpCode = 0
    if http.AsyncGetToString()
        msg = wait(10000, port)
        if type(msg) = "roUrlEvent"
            httpCode = msg.GetResponseCode()
            if httpCode > 0 and httpCode < 400 then data = msg.GetString()
        else
            http.AsyncCancel()
        end if
    end if

    logMovieDiag("vodInfoUrl", url)
    logMovieDiag("vodInfoHttp", httpCode)
    logMovieDiag("vodInfoOk", data <> "")

    json = ParseJSON(data)
    if json = invalid then return

    result = CreateObject("roSGNode", "ContentNode")

    info = json.info
    ' Verificar que info sea un AA (objeto), no array vacio
    if info <> invalid and type(info) = "roAssociativeArray"
        if info.movie_image <> invalid and info.movie_image <> ""
            result.hdBackgroundImageUrl = info.movie_image
        end if
        if info.backdrop_path <> invalid
            bp = info.backdrop_path
            if type(bp) = "roArray" and bp.Count() > 0
                result.hdBackgroundImageUrl = bp[0]
            else if type(bp) = "roString" and bp <> ""
                result.hdBackgroundImageUrl = bp
            end if
        end if
        if info.plot <> invalid and info.plot <> ""
            result.addField("plot", "string", false)
            result.plot = info.plot
        else if info.description <> invalid and info.description <> ""
            result.addField("plot", "string", false)
            result.plot = info.description
        end if
        if info.duration_secs <> invalid
            result.length = val(info.duration_secs.toStr())
        end if
        if info.releasedate <> invalid
            result.releaseDate = info.releasedate
        end if
        if info.genre <> invalid
            result.addField("genre", "string", false)
            result.genre = info.genre
        end if
        if info.rating <> invalid
            result.rating = info.rating.toStr()
        end if
    end if

    m.top.result = result
end sub
