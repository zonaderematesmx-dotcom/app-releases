sub init()
    m.poster        = m.top.findNode("poster")
    m.title         = m.top.findNode("title")
    m.shadow        = m.top.findNode("shadow")
    m.ratingBg      = m.top.findNode("ratingBg")
    m.ratingLabel   = m.top.findNode("ratingLabel")
    m.borderTop     = m.top.findNode("borderTop")
    m.borderBottom  = m.top.findNode("borderBottom")
    m.borderLeft    = m.top.findNode("borderLeft")
    m.borderRight   = m.top.findNode("borderRight")

    m.top.observeField("focusPercent", "onFocusChanged")
    m.top.observeField("gridHasFocus", "onGridFocusChanged")

    m.title.font.size = 9

    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")
end sub

' ============================================================
' Aplica el focusColor del config remoto al borde de foco y al
' badge de rating. Se re-ejecuta si el color cambia despues.
' ============================================================
sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0x00A8FFFF"

    m.borderTop.color    = fc
    m.borderBottom.color = fc
    m.borderLeft.color   = fc
    m.borderRight.color  = fc
    m.ratingBg.color     = fc
end sub

sub onContentChanged()
    item = m.top.itemContent
    if item = invalid then return

    if item.HDPosterUrl <> invalid and item.HDPosterUrl <> ""
        m.poster.uri = item.HDPosterUrl
    else
        m.poster.uri = ""
    end if

    if item.title <> invalid and item.title <> ""
        m.title.text = item.title
    else
        m.title.text = ""
    end if

    r = item.rating
    if r <> invalid and r <> "" and r <> "0" and r <> "0.0"
        rVal = val(r)
        if rVal > 0
            m.ratingLabel.text = Str(Int(rVal * 10) / 10).trim()
            if Len(m.ratingLabel.text) > 4 then m.ratingLabel.text = Left(m.ratingLabel.text, 3)
            m.ratingBg.visible = false
            m.ratingLabel.visible = false
        else
            m.ratingBg.visible = false
            m.ratingLabel.visible = false
        end if
    else
        m.ratingBg.visible = false
        m.ratingLabel.visible = false
    end if
end sub

sub showBorder(op as Float)
    m.borderTop.opacity    = op
    m.borderBottom.opacity = op
    m.borderLeft.opacity   = op
    m.borderRight.opacity  = op
end sub

sub onFocusChanged()
    fp = m.top.focusPercent
    if fp = invalid then fp = 0
    gf = m.top.gridHasFocus
    if gf = invalid then gf = false

    if fp > 0.1 and gf
        scale = 1.0 + (fp * 0.08)
        ' Centro real del slot (82.0x180.0), para que el zoom crezca
        ' parejo hacia los 4 lados.
        m.top.scaleRotateCenter = [55.02, 82.85]
        m.top.scale = [scale, scale]
        showBorder(1.0)
        m.shadow.opacity = 0.8
    else
        m.top.scale = [1.0, 1.0]
        showBorder(0.0)
        m.shadow.opacity = 0.55
    end if
end sub

sub onGridFocusChanged()
    gf = m.top.gridHasFocus
    if gf = invalid then gf = false
    if not gf
        m.top.scale = [1.0, 1.0]
        showBorder(0.0)
        m.shadow.opacity = 0.55
    else
        onFocusChanged()
    end if
end sub
