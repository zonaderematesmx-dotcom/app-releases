' ********** Copyright 2016 Roku Corp.  All Rights Reserved. ********** 
sub Main()
    print "####################"
    print "# Start of Channel #"
    print "####################"
	

    time1 = "1616162400"
	time2  = "1616166000"
	percentage = (100/time2.toInt()) * time1.toInt()

    print "ISO String UTC: " percentage
	
	screen=CreateObject("roSGScreen")
    m.global = screen.getGlobalNode()
	scene = screen.CreateScene("MainScene")
	port = CreateObject("roMessagePort")
	screen.SetMessagePort(port)
	screen.Show()
	scene.observeField("close", port)
	
    while(true)
        msg = wait(0, port)
        msgType = type(msg)
        print "------------------"
        print "msg.getNode(): "; msg.getNode()
        print "msg.getField(): "; msg.getField()
        if msgType = "roSGNodeEvent"
            if msg.getField() = "close" and msg.getData()
                return
            end if
        end if
    end while
end sub
