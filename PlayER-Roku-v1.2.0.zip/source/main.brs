' ********** Copyright 2016 Roku Corp.  All Rights Reserved. **********
sub Main(args as dynamic)
    print "####################"
    print "# Start of Channel #"
    print "####################"


    time1 = "1616162400"
	time2  = "1616166000"
	percentage = (100/time2.toInt()) * time1.toInt()

    print "ISO String UTC: " percentage

	screen=CreateObject("roSGScreen")
    m.global = screen.getGlobalNode()
    ' Deep linking (cert 5.1) + Direct to Play (cert 5.2): campos globales
    ' que MainScene consume en showMenuList()/onDlPendingChanged(). Se
    ' agregan ANTES de CreateScene para que init() de la escena los vea
    ' ya declarados.
    m.global.addFields({ dlContentId: "", dlMediaType: "", dlPending: false })
	scene = screen.CreateScene("MainScene")
	port = CreateObject("roMessagePort")
	screen.SetMessagePort(port)
	' Deep links que llegan con la app YA corriendo (voz "reproduce X"
	' o ECP /input) sin relanzar el canal. Requiere
	' supports_input_launch=1 en el manifest.
	input = CreateObject("roInput")
	input.SetMessagePort(port)
	screen.Show()
	scene.observeField("close", port)

	' Deep link de LANZAMIENTO: contentId/mediaType en los args de Main()
	if args <> invalid
		cid = dlLinkArg(args, "contentId")
		mt  = dlLinkArg(args, "mediaType")
		if cid <> "" and mt <> ""
			m.global.dlContentId = cid
			m.global.dlMediaType = mt
			m.global.dlPending = true
			print "DEEPLINK launch args: mediaType="; mt; " contentId="; cid
		end if
	end if

    while(true)
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGNodeEvent"
            print "------------------"
            print "msg.getNode(): "; msg.getNode()
            print "msg.getField(): "; msg.getField()
            if msg.getField() = "close" and msg.getData()
                return
            end if
        else if msgType = "roInputEvent"
            ' Deep link recibido mientras la app corre (cert 5.2)
            if msg.IsInput()
                info = msg.GetInfo()
                cid = dlLinkArg(info, "contentId")
                mt  = dlLinkArg(info, "mediaType")
                if cid <> "" and mt <> ""
                    m.global.dlContentId = cid
                    m.global.dlMediaType = mt
                    m.global.dlPending = true
                    print "DEEPLINK roInput: mediaType="; mt; " contentId="; cid
                end if
            end if
        end if
    end while
end sub

' Lee contentId/mediaType de un AA (args de Main() o GetInfo() de
' roInputEvent). La capitalizacion de las claves varia segun el origen
' y el valor puede venir como string u otro tipo -> se normaliza a string.
function dlLinkArg(aa as dynamic, key as String) as string
    if aa = invalid then return ""
    v = invalid
    if aa.DoesExist(key) then v = aa[key]
    if v = invalid
        lowerKey = LCase(key)
        if aa.DoesExist(lowerKey) then v = aa[lowerKey]
    end if
    if v = invalid then return ""
    vt = type(v)
    if vt = "roString" or vt = "String" then return v
    if vt = "roInt" or vt = "roInteger" or vt = "Integer" then return v.toStr()
    if vt = "roLongInteger" or vt = "LongInteger" then return v.toStr()
    return ""
end function
