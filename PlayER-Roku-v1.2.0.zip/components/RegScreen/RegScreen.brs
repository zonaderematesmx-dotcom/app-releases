sub init()
    configureResponsiveLayout()

    m.activateButton = m.top.findNode("activateButton")
    m.status = m.top.findNode("status")
    m.usernameHint = m.top.findNode("usernameHint")
    m.passwordHint = m.top.findNode("passwordHint")
    m.usernameLine = m.top.findNode("usernameLine")
    m.passwordLine = m.top.findNode("passwordLine")
    m.loginDivider = m.top.findNode("loginDivider")
    m.loginHeading = m.top.findNode("loginHeading")
    m.loginLogo = m.top.findNode("loginLogo")
    m.mensajeBg = m.top.findNode("mensajeBg")
    m.mensajeLabel = m.top.findNode("mensajeLabel")

    m.username = ""
    m.password = ""
    m.focusIndex = 0
    m.busy = false
    m.dialog = invalid
    m.task = invalid
    m.phase = ""

    m.top.success = false

    m.activateButton.observeField("buttonSelected", "onActivateButtonSelected")

    dt = CreateObject("roDateTime").AsSeconds().ToStr()
    m.loginLogo.uri = m.global.panelURL + "/img/logo.png?ts=" + dt

    fetchMensaje()
    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")

    updateFocus()
end sub

' ============================================================
' Layout identico al ActivationScene original: disenio 1920x1080
' escalado al design resolution real del dispositivo (hd = 1280x720).
' ============================================================
sub configureResponsiveLayout()
    scene = m.top.getScene()
    if scene = invalid
        ' init corre ANTES de que MainScene nos adjunte a la escena:
        ' reintentamos en cuanto el nodo ya tenga escena.
        startLayoutTimer()
        return
    end if
    design = scene.currentDesignResolution

    ' Canal hd (manifest ui_resolutions=hd): el espacio de coordenadas
    ' real es 1280x720 aunque la TV este en 1080p.
    sw = 1280.0
    sh = 720.0

    if design <> invalid then
        if design.width <> invalid and design.width > 0 then sw = design.width
        if design.height <> invalid and design.height > 0 then sh = design.height
    end if

    scale = sw / 1920.0
    scaleY = sh / 1080.0
    if scaleY < scale then scale = scaleY

    m.top.scale = [scale, scale]
    m.top.translation = [
        Int((sw - (1920.0 * scale)) / 2),
        Int((sh - (1080.0 * scale)) / 2)
    ]
end sub

' ============================================================
' Color de marca: focusColor del config remoto (PlayER = 0xE50914).
' Nunca el rojo PlayerMX 0xE31937 -- conservamos nuestra marca.
' ============================================================
sub startLayoutTimer()
    if m.layoutTimer <> invalid then return
    timer = CreateObject("roSGNode", "Timer")
    timer.duration = 0.1
    timer.repeat = false
    timer.observeField("fire", "onLayoutTimer")
    m.layoutTimer = timer
    timer.control = "start"
end sub

sub onLayoutTimer()
    if m.layoutTimer <> invalid
        m.layoutTimer.control = "stop"
        m.layoutTimer = invalid
    end if
    configureResponsiveLayout()
end sub

function brandColor() as String
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"
    return fc
end function

sub applyBrandColor()
    fc = brandColor()
    if m.loginDivider <> invalid then m.loginDivider.color = fc
    if m.loginHeading <> invalid then m.loginHeading.color = fc
    if m.status <> invalid then m.status.color = fc
    if m.mensajeBg <> invalid then m.mensajeBg.color = fc
    updateFocus()
end sub

sub fetchMensaje()
    ' El config.json se descarga una sola vez al iniciar la app; aqui
    ' solo se lee el resultado (ver MainScene.brs/onConfigResponse).
    onMensajeDone()
    m.global.observeField("mensaje", "onMensajeDone")
end sub

sub onMensajeDone()
    msg = m.global.mensaje
    if msg = invalid then msg = ""
    if msg <> ""
        m.mensajeLabel.text = msg
        m.mensajeLabel.visible = true
        m.mensajeBg.visible = true
    else
        m.mensajeLabel.visible = false
        m.mensajeBg.visible = false
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    return handleKey(key)
end function

function handleKey(key as String) as Boolean
    if m.busy then return true

    if key = "up"
        if m.focusIndex > 0 then m.focusIndex = m.focusIndex - 1
        updateFocus()
        return true

    else if key = "down"
        if m.focusIndex < 2 then m.focusIndex = m.focusIndex + 1
        updateFocus()
        return true

    else if key = "OK"
        if m.focusIndex = 0 then
            openUsernameDialog()
        else if m.focusIndex = 1 then
            openPasswordDialog()
        else
            activateFromFields()
        end if
        return true

    else if key = "back"
        return false
    end if

    return true
end function

sub updateFocus()
    fc = brandColor()
    dimColor = "0x444444FF"
    hintOn = "0xFFFFFFFF"
    hintOff = "0x666666FF"

    if m.focusIndex = 0 then
        m.usernameLine.color = fc
        m.passwordLine.color = dimColor
        m.usernameHint.color = hintOn
        m.passwordHint.color = hintOff
        m.activateButton.setFocus(false)
        if m.top.getScene() <> invalid then m.top.setFocus(true)

    else if m.focusIndex = 1 then
        m.usernameLine.color = dimColor
        m.passwordLine.color = fc
        m.usernameHint.color = hintOff
        m.passwordHint.color = hintOn
        m.activateButton.setFocus(false)
        if m.top.getScene() <> invalid then m.top.setFocus(true)

    else
        m.usernameLine.color = dimColor
        m.passwordLine.color = dimColor
        m.usernameHint.color = hintOff
        m.passwordHint.color = hintOff
        m.activateButton.setFocus(true)
    end if
end sub

sub openUsernameDialog()
    if m.dialog <> invalid then return

    m.dialog = CreateObject("roSGNode", "KeyboardDialog")
    m.dialog.title = "Usuario"
    m.dialog.message = ["Escribe tu usuario de PlayER."]
    m.dialog.buttons = ["CONTINUAR", "CANCELAR"]
    m.dialog.text = m.username
    m.dialog.observeField("buttonSelected", "onUsernameDialogButton")

    scene = m.top.getScene()
    scene.dialog = m.dialog
    m.dialog.setFocus(true)
    if m.dialog.keyboard <> invalid then m.dialog.keyboard.setFocus(true)
end sub

sub onUsernameDialogButton(event as Object)
    if m.dialog = invalid then return
    if m.top.getScene() = invalid then return
    if m.top.getScene().dialog <> m.dialog then
        m.dialog = invalid
        return
    end if

    selected = event.getData()
    username = m.dialog.text

    if selected = 0 and username <> ""
        m.username = username
        m.usernameHint.text = username
        m.status.text = "Usuario capturado."
        m.focusIndex = 1
    else if selected = 0
        m.status.text = "Ingresa tu usuario."
        m.focusIndex = 0
    end if

    m.top.getScene().dialog = invalid
    m.dialog = invalid
    updateFocus()
end sub

sub openPasswordDialog()
    if m.dialog <> invalid then return

    m.dialog = CreateObject("roSGNode", "KeyboardDialog")
    m.dialog.title = "Contraseña"
    m.dialog.message = ["Escribe tu contraseña de PlayER."]
    m.dialog.buttons = ["CONTINUAR", "CANCELAR"]
    m.dialog.text = m.password

    if m.dialog.keyboard <> invalid and m.dialog.keyboard.textEditBox <> invalid then
        m.dialog.keyboard.textEditBox.secureMode = true
        m.dialog.keyboard.textEditBox.secureLastCharacter = true
    end if

    m.dialog.observeField("buttonSelected", "onPasswordDialogButton")

    scene = m.top.getScene()
    scene.dialog = m.dialog
    m.dialog.setFocus(true)
    if m.dialog.keyboard <> invalid then m.dialog.keyboard.setFocus(true)
end sub

sub onPasswordDialogButton(event as Object)
    if m.dialog = invalid then return
    if m.top.getScene() = invalid then return
    if m.top.getScene().dialog <> m.dialog then
        m.dialog = invalid
        return
    end if

    selected = event.getData()
    password = m.dialog.text

    if selected = 0 and password <> ""
        m.password = password
        m.passwordHint.text = "********"
        m.status.text = "Credenciales listas."
        m.focusIndex = 2
    else if selected = 0
        m.status.text = "Ingresa tu contraseña."
        m.focusIndex = 1
    end if

    m.top.getScene().dialog = invalid
    m.dialog = invalid
    updateFocus()
end sub

sub onActivateButtonSelected()
    activateFromFields()
end sub

' ============================================================
' Doble uso de la misma pantalla (identica al original):
'  - usuario + contraseña  -> validacion directa en el proveedor
'  - solo usuario (codigo) -> canje de LICENCIA en el backend
'    (la licencia devuelve las credenciales y se sigue con login)
' ============================================================
sub activateFromFields()
    if m.busy then return
    if m.username = ""
        m.focusIndex = 0
        m.status.text = "Ingresa tu usuario."
        updateFocus()
        return
    end if

    if m.password = ""
        m.busy = true
        m.phase = "license"
        m.status.text = "Validando licencia..."
        startLicenseTask(m.username)
        return
    end if

    m.busy = true
    m.phase = "login"
    m.status.text = "Conectando con PlayER..."
    startLoginTask(m.username, m.password)
end sub

sub startLicenseTask(code as String)
    if m.task <> invalid then return
    task = CreateObject("roSGNode", "LicenseTask")
    task.code = code
    task.deviceId = GetDeviceESN()
    task.observeField("state", "onTaskDone")
    m.task = task
    m.top.appendChild(task)
    task.control = "run"
end sub

sub startLoginTask(user as String, pass as String)
    if m.task <> invalid then return
    task = CreateObject("roSGNode", "LoginTask")
    task.user = user
    task.pass = pass
    task.observeField("state", "onTaskDone")
    m.task = task
    m.top.appendChild(task)
    task.control = "run"
end sub

sub onTaskDone()
    task = m.task
    if task = invalid then return
    if task.state <> "stop" then return

    phase = m.phase
    ok = false
    errorMsg = ""

    if phase = "license"
        if task.validated = true
            ' Licencia canjeada: ahora valida las credenciales que devolvio.
            licUser = task.username
            licPass = task.password
            clearTask()
            if licUser <> "" and licPass <> ""
                m.phase = "login"
                m.status.text = "Conectando con PlayER..."
                startLoginTask(licUser, licPass)
                return
            end if
            m.busy = false
            m.status.text = "No fue posible obtener tus credenciales."
            m.focusIndex = 1
            updateFocus()
            return
        end if
        ok = false
        errorMsg = task.errorMsg
        if errorMsg = invalid or errorMsg = "" then errorMsg = "Ingresa tu contraseña."
    else
        if task.validated = true
            ok = true
        else
            errorMsg = task.errorMsg
            if errorMsg = invalid or errorMsg = "" then errorMsg = "Usuario o contraseña incorrecta"
        end if
    end if

    clearTask()
    m.busy = false

    if ok
        m.status.text = "Inicio de sesión correcto. PlayER conectado."
        updateFocus()
        m.top.success = true
    else
        m.status.text = errorMsg
        if phase = "license"
            m.focusIndex = 1
        else
            m.focusIndex = 2
        end if
        updateFocus()
    end if
end sub

sub clearTask()
    if m.task = invalid then return
    task = m.task
    m.task = invalid
    task.unobserveField("state")
    if task.getParent() <> invalid then m.top.removeChild(task)
end sub
