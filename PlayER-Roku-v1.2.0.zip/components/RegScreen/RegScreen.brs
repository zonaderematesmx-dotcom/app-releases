sub init()
    m.bgImage  = m.top.findNode("bgImage")
    m.zoomAnim = m.top.findNode("zoomAnim")

    m.logoImage     = m.top.findNode("logoImage")
    m.userField     = m.top.findNode("userField")
    m.passField     = m.top.findNode("passField")
    m.userFieldRing = m.top.findNode("userFieldRing")
    m.passFieldRing = m.top.findNode("passFieldRing")
    m.userRingTop    = m.top.findNode("userRingTop")
    m.userRingBottom = m.top.findNode("userRingBottom")
    m.userRingLeft   = m.top.findNode("userRingLeft")
    m.userRingRight  = m.top.findNode("userRingRight")
    m.passRingTop    = m.top.findNode("passRingTop")
    m.passRingBottom = m.top.findNode("passRingBottom")
    m.passRingLeft   = m.top.findNode("passRingLeft")
    m.passRingRight  = m.top.findNode("passRingRight")
    m.userTextBox   = m.top.findNode("userTextEditBox")
    m.passTextBox   = m.top.findNode("passTextEditBox")
    m.userEditBox   = m.top.findNode("userEditBox")
    m.passEditBox   = m.top.findNode("passEditBox")
    m.loginButton   = m.top.findNode("loginButton")
    m.loginError    = m.top.findNode("loginError")
        m.floatingKeyboard = m.top.findNode("floatingKeyboard")
    m.mensajeBg    = m.top.findNode("mensajeBg")
    m.mensajeLabel = m.top.findNode("mensajeLabel")
    fetchMensaje()
    m.top.success     = false
    m.keyboardVisible = false
    m.activeKeyboard  = invalid
    m.focusOn         = "user"
    m.keyBoxYShown    = 800
    m.keyBoxYHidden   = 1080

    dt = CreateObject("roDateTime").AsSeconds().ToStr()
    m.bgImage.uri   = m.global.panelURL + "/img/fondo.jpg?ts=" + dt
    m.logoImage.uri = m.global.panelURL + "/img/logo.png?ts=" + dt

    m.zoomAnim.control = "start"


    m.activeForUser = true
    m.loginTask    = createObject("roSGNode", "LoginTask")
    m.loginTask.observeField("state", "onLoginDone")
    m.loginButton.observeField("buttonSelected",  "onLoginButton")

    m.userField.setFocus(true)
    setFieldFocus("user")

    ' --- Color de marca (focusColor del config.json) ---
    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")
end sub

' ============================================================
' Aplica el focusColor del config remoto a los acentos rojos
' de esta pantalla. Se re-ejecuta si el color cambia despues.
' ============================================================
sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"

    if m.mensajeBg <> invalid then m.mensajeBg.color = fc
    if m.loginError <> invalid then m.loginError.color = fc

    ' Re-tintar el campo que este actualmente enfocado
    setFieldFocus(m.focusOn)
end sub
sub onMensajeDone()
    msg = m.global.mensaje
    if msg = invalid then msg = ""
    if msg <> ""
        m.mensajeLabel.text    = msg
        m.mensajeLabel.visible = true
        m.mensajeBg.visible    = true
    else
        m.mensajeLabel.visible = false
        m.mensajeBg.visible    = false
    end if
end sub
sub setFieldFocus(which as String)
    m.focusOn = which
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"
    btnDim = "0x333333FF"

    ' Las cajas siempre usan la misma imagen base (contorno negro fijo,
    ' sin relleno -- ver images/login/user-edit.png y pass-edit.png).
    m.userEditBox.uri = "pkg:/images/login/user-edit.png"
    m.passEditBox.uri = "pkg:/images/login/pass-edit.png"

    ' Pedido explicito: el foco es un CONTORNO con el color de marca real
    ' del panel .json (no un relleno solido/semitransparente encima de
    ' todo el campo, como antes) -- mismo criterio que ya se uso en
    ' Android. userField/passField siguen existiendo solo como los nodos
    ' que reciben el foco real de SceneGraph; ya no se pintan.
    setRingColor(m.userRingTop, m.userRingBottom, m.userRingLeft, m.userRingRight, fc)
    setRingColor(m.passRingTop, m.passRingBottom, m.passRingLeft, m.passRingRight, fc)
    if m.userFieldRing <> invalid then m.userFieldRing.visible = (which = "user")
    if m.passFieldRing <> invalid then m.passFieldRing.visible = (which = "pass")

    if which = "user" or which = "pass"
        if m.loginButton <> invalid then m.loginButton.bgColor = btnDim
    else
        if m.loginButton <> invalid then m.loginButton.bgColor = fc
    end if
end sub

sub setRingColor(t as object, b as object, l as object, r as object, fc as string)
    if t <> invalid then t.color = fc
    if b <> invalid then b.color = fc
    if l <> invalid then l.color = fc
    if r <> invalid then r.color = fc
end sub


sub fetchMensaje()
    ' El config.json ya se descarga una sola vez al iniciar la app
    ' (ver MainScene.brs/onConfigResponse); aqui solo se lee el
    ' resultado, sin otra llamada de red aparte para el mensaje.
    onMensajeDone()
    m.global.observeField("mensaje", "onMensajeDone")
end sub

sub showKeyboard(forUser as Boolean)
    m.keyboardVisible = true
    m.activeForUser   = forUser

    if m.floatingKeyboard = invalid then return

    if forUser
        m.floatingKeyboard.text = m.userTextBox.text
    else
        m.floatingKeyboard.text = m.passTextBox.text
    end if

    m.floatingKeyboard.confirmed = false
    m.floatingKeyboard.observeField("confirmed", "onKbConfirmed")
    m.floatingKeyboard.observeField("text", "onKbTextChanged")
    m.floatingKeyboard.visible = true
    m.floatingKeyboard.setFocus(true)
end sub

sub onKbTextChanged()
    if m.floatingKeyboard = invalid then return
    if m.activeForUser
        m.userTextBox.text = m.floatingKeyboard.text
    else
        m.passTextBox.text = m.floatingKeyboard.text
    end if
end sub

sub onKbConfirmed()
    if m.floatingKeyboard = invalid then return
    if not m.floatingKeyboard.confirmed then return
    onKbDone()
end sub

sub onKbDone()
    if m.floatingKeyboard = invalid then return
    text = m.floatingKeyboard.text
    m.floatingKeyboard.visible = false
    m.keyboardVisible = false

    ' BUG: ocultar el teclado (visible=false) NO le quita el foco real
    ' de SceneGraph -- Roku deja que un nodo invisible siga enfocado y
    ' siga recibiendo eventos de control remoto. Si no se mueve el foco
    ' aqui a un nodo real, el teclado invisible se queda "vivo": OK/
    ' letras del control siguen llegando a LoginKeyboardCustom.onKeyEvent
    ' y, como sus observers de "text" (onKbTextChanged) siguen activos,
    ' esos caracteres se siguen escribiendo en el campo de contraseña
    ' sin que se vea ningun teclado en pantalla (justo el bug reportado:
    ' "existe el teclado pero sin verse"). setFocus(false) explicito +
    ' regresar el foco real al campo correspondiente en AMBAS ramas
    ' evita esto.
    m.floatingKeyboard.setFocus(false)

    if m.activeForUser
        m.userTextBox.text = text
        m.passField.setFocus(true)
        setFieldFocus("pass")
    else
        m.passTextBox.text = text
        ' Regresar el foco real al campo de contraseña de una vez (antes
        ' de intentar el login): si el login falla -- incluyendo el caso
        ' de usuario/contraseña en blanco, que ni siquiera llega a
        ' mostrar el dialogo de error de LoginTask -- el foco ya queda
        ' en un nodo real y visible en vez de en el teclado oculto.
        m.passField.setFocus(true)
        setFieldFocus("pass")
        m.loginTimer = createObject("roSGNode", "Timer")
        m.loginTimer.duration = 0.2
        m.loginTimer.repeat = false
        m.loginTimer.observeField("fire", "onLoginTimerFire")
        m.loginTimer.control = "start"
    end if
end sub

sub onLoginTimerFire()
    m.loginTimer.control = "stop"
    onLoginButton()
end sub

sub hideKeyboard()
    m.floatingKeyboard.visible = false
    m.floatingKeyboard.setFocus(false)
    m.keyboardVisible = false

    if m.focusOn = "pass"
        m.passField.setFocus(true)
        setFieldFocus("pass")
    else
        m.userField.setFocus(true)
        setFieldFocus("user")
    end if
end sub

sub onUserKbText(event as Object) : end sub
sub onPassKbText(event as Object) : end sub

sub onLoginButton()
    user = m.userTextBox.text.Trim()
    pass = m.passTextBox.text.Trim()
    if user = "" or pass = ""
        m.loginError.text    = "Ingresa usuario y contraseña"
        m.loginError.visible = true
        return
    end if
    m.loginError.visible = false
    m.loginLoading = m.top.findNode("loginLoading")
    m.loginLoading.visible = true
    m.loginLoading.control = "start"
    m.loginTask.user = user : m.loginTask.pass = pass
    m.loginTask.control = "RUN"
end sub

sub onLoginDone()
    if m.loginTask.state = "stop"
        if m.loginLoading <> invalid
            m.loginLoading.control = "stop"
            m.loginLoading.visible = false
        end if
        if m.loginTask.validated
            m.top.success = true
        else
            m.loginError.text    = m.loginTask.errorMsg
            m.loginError.visible = true
            m.loginButton.setFocus(true)
            setFieldFocus("none")
        end if
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    if m.keyboardVisible
        if key = "back"
            hideKeyboard()
            return true
        else if key = "OK"
            onKbDone()
            return true
        end if
        return false
    end if

    if key = "OK"
        if m.focusOn = "user" or m.userField.isInFocusChain()
            showKeyboard(true) : return true
        else if m.focusOn = "pass" or m.passField.isInFocusChain()
            showKeyboard(false) : return true
        end if
    else if key = "down"
        if m.userField.isInFocusChain()
            m.passField.setFocus(true) : setFieldFocus("pass") : return true
        else if m.passField.isInFocusChain()
            m.loginButton.setFocus(true) : setFieldFocus("none") : return true
        end if
    else if key = "up"
        if m.passField.isInFocusChain()
            m.userField.setFocus(true) : setFieldFocus("user") : return true
        else if m.loginButton.isInFocusChain()
            m.passField.setFocus(true) : setFieldFocus("pass") : return true
        end if
    end if

    return false
end function
