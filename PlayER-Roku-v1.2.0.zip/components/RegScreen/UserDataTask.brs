sub init()
    m.top.functionName = "getUserData"
end sub

sub getUserData()
    m.top.requestDone = false
    m.top.email = ""
    m.top.userName = ""

    cs = CreateObject("roChannelStore")
    port = CreateObject("roMessagePort")
    cs.SetMessagePort(port)
    cs.GetUserData()

    ' Sin timeout (0 = esperar indefinidamente): esta llamada le muestra al
    ' usuario un dialogo del sistema de Roku pidiendole permiso para
    ' compartir su correo, y el tiempo que tarde en responder depende de
    ' el, no de nosotros.
    msg = wait(0, port)

    if type(msg) = "roChannelStoreEvent"
        if msg.isRequestSucceeded()
            data = msg.GetUserData()
            if data <> invalid and data.Count() > 0
                primerPerfil = data[0]
                if primerPerfil.email <> invalid then m.top.email = primerPerfil.email
                if primerPerfil.name <> invalid then m.top.userName = primerPerfil.name
                print "DEBUG UserDataTask - correo obtenido de Roku: "; m.top.email
            else
                print "DEBUG UserDataTask - el usuario no tiene datos o no compartio nada"
            end if
        else
            print "DEBUG UserDataTask - solicitud fallida: "; msg.GetFailureReason()
        end if
    else
        print "DEBUG UserDataTask - respuesta inesperada del roChannelStore"
    end if

    m.top.requestDone = true
end sub
