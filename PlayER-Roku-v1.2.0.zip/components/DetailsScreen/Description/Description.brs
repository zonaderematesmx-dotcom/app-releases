' ********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

 'setting top interfaces
Sub Init()
  'print "Description.brs - [Init]"
  m.Title             = m.top.findNode("Title")
  m.Description       = m.top.findNode("Description")
  m.ReleaseDate       = m.top.findNode("ReleaseDate")
End Sub

' Content change handler
' All fields population
Sub OnContentChanged()
  item = m.top.content
  if item = invalid then return

  if item.title <> invalid and item.title <> "" then
    m.Title.text = item.title
  else
    m.Title.text = ""
  end if

  if item.description <> invalid and item.description <> "" then
    m.Description.text = item.description
  else
    m.Description.text = "Sin resumen disponible"
  end if

  if item.ReleaseDate <> invalid and item.ReleaseDate <> "" then
    m.ReleaseDate.text = item.ReleaseDate
  else
    m.ReleaseDate.text = ""
  end if
End Sub
