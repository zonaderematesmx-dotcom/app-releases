Function Init()
    m.top.observeField("visible",      "onVisibleChange")
    m.top.observeField("focusedChild", "onFocusedChildChange")

    m.savePositionToReg         = createObject("roSGNode", "WriteVideoPosition")
    m.savePositionToReg.section = "MovieResume"

    m.btnPlayBg      = m.top.findNode("btnPlayBg")
    m.btnPlayLabel   = m.top.findNode("btnPlayLabel")
    m.btnFavBg       = m.top.findNode("btnFavBg")
    m.btnFavLabel    = m.top.findNode("btnFavLabel")
    m.btnPlayFocusRing = m.top.findNode("btnPlayFocusRing")
    m.btnFavFocusRing  = m.top.findNode("btnFavFocusRing")
    m.focusedBtn     = 0
    m.videoPlayer    = m.top.findNode("VideoPlayer")
    updateBtnFocus()
    m.poster         = m.top.findNode("Poster")
    m.background     = m.top.findNode("Background")
    m.watchProgressBg   = m.top.findNode("watchProgressBg")
    m.watchProgressFill = m.top.findNode("watchProgressFill")
    m.fadeIn         = m.top.findNode("fadeinAnimation")
    m.fadeOut        = m.top.findNode("fadeoutAnimation")

    ' Player overlay nodes
    m.bufferingGroup = m.top.findNode("bufferingGroup")
    m.bufferingBar   = m.top.findNode("bufferingBar")
    m.playerOverlay  = m.top.findNode("playerOverlay")
    m.overlayTitle   = m.top.findNode("overlayTitle")
    m.progressFill   = m.top.findNode("progressFill")
    m.progressDot    = m.top.findNode("progressDot")
    m.timeCurrent    = m.top.findNode("timeCurrent")
    m.timeDuration   = m.top.findNode("timeDuration")
    m.audioLabel     = m.top.findNode("audioLabel")
    m.subtitleLabel  = m.top.findNode("subtitleLabel")

    ' Timers
    m.overlayTimer = m.top.findNode("overlayTimer")
    m.retryTimer   = m.top.findNode("retryTimer")
    m.seekBufferTimer = m.top.findNode("seekBufferTimer")
    m.overlayTimer.observeField("fire", "hidePlayerOverlay")
    m.retryTimer.observeField("fire",   "onRetryTimer")
    if m.seekBufferTimer <> invalid then m.seekBufferTimer.observeField("fire", "onSeekBufferTimer")

    m.videoPlayer.observeField("state",    "onVideoPlayerStateChange")
    m.videoPlayer.observeField("position", "savePosition")
    ' Ver el comentario en onBufferingStatusChange() -- forma correcta
    ' (la que usa el sample oficial de Roku rokudev/transport-control) de
    ' saber si el video YA de verdad esta listo para verse, en vez de
    ' adivinar con un timer fijo.
    m.videoPlayer.observeField("bufferingStatus", "onBufferingStatusChange")

    m.retryCount  = 0
    m.subtitlesOn = false
    m.rwRegistered = false
    ' Posicion pendiente de aplicar con seek() apenas arranque a
    ' reproducir de verdad (ver resumeSelected/onVideoPlayerStateChange) --
    ' fix real de "Continuar viendo siempre reinicia desde 0".
    m.pendingSeekPos = 0

    ' --- Barra de controles propia (igual a Android/Seasons.brs, ver el ---
    ' comentario junto a enableUI en DetailsScreen.xml). Sin anterior/
    ' siguiente aqui: esto es una pelicula suelta, no un capitulo de
    ' serie. Orden: 0=-10s 1=play/pausa 2=+10s 3=engranaje.
    m.ctrlPlayPauseLabel = m.top.findNode("ctrlPlayPauseLabel")
    m.ctrlBar = [
        m.top.findNode("ctrlSeekBackFocusRing"),
        m.top.findNode("ctrlPlayPauseFocusRing"),
        m.top.findNode("ctrlSeekFwdFocusRing"),
        m.top.findNode("gearBtnFocusRing")
    ]
    m.ctrlBarFocusIdx = 1 ' play/pausa por defecto, igual que Android (DPAD_CENTER)

    ' --- Color de marca (focusColor del config.json) ---
    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")
End Function

' ============================================================
' Aplica el focusColor del config remoto a los acentos rojos de
' esta pantalla. Se re-ejecuta si el color cambia despues.
' ============================================================
sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"
    if m.progressFill  <> invalid then m.progressFill.color  = fc
    if m.progressDot   <> invalid then m.progressDot.color   = fc
    if m.bufferingBar  <> invalid then m.bufferingBar.color  = fc
    ratingBg = m.top.findNode("detailRatingBg")
    if ratingBg <> invalid then ratingBg.color = fc

    for each rid in ["btnPlayFocusTop", "btnPlayFocusBottom", "btnPlayFocusLeft", "btnPlayFocusRight", "btnFavFocusTop", "btnFavFocusBottom", "btnFavFocusLeft", "btnFavFocusRight"]
        n = m.top.findNode(rid)
        if n <> invalid then n.color = fc
    end for

    ' Marco de foco de la barra de controles del reproductor (igual a
    ' Android/Seasons.brs: color de marca configurable, no fijo).
    for each rid in ["ctrlSeekBackFocusRing", "ctrlPlayPauseFocusRing", "ctrlSeekFwdFocusRing", "gearBtnFocusRing"]
        grp = m.top.findNode(rid)
        if grp <> invalid
            for i = 0 to grp.getChildCount() - 1
                grp.getChild(i).color = fc
            end for
        end if
    end for
end sub

' ─── Details screen visibility ───────────────────────────────────────────────

Sub onVisibleChange()
    if m.top.visible
        m.fadeIn.control = "start"
        checkFavorite()
    else
        m.fadeOut.control = "start"
        m.poster.uri      = ""
        m.background.uri  = ""
        stopAllTimers()
    end if
End Sub

sub stopAllTimers()
    m.overlayTimer.control = "stop"
    m.retryTimer.control   = "stop"
end sub

Sub onFocusedChildChange()
End Sub

Sub onVideoVisibleChange()
    if m.videoPlayer.visible = false and m.top.visible = true
        m.bufferingGroup.visible = false
        m.playerOverlay.visible  = false
        stopAllTimers()
        m.top.setFocus(true)
        m.videoPlayer.control = "stop"
    end if
End Sub

' ─── Buttons / favorites ─────────────────────────────────────────────────────

sub checkFavorite()
    m.checkFavTask = createObject("roSGNode", "CheckFavoriteTask")
    m.checkFavTask.cve = m.videoPlayer.content.id.toStr()
    m.checkFavTask.tipo = "pelicula"
    m.checkFavTask.observeField("isFavorite", "onCheckFavDone")
    m.checkFavTask.control = "RUN"
end sub

sub onCheckFavDone()
    if m.checkFavTask.isFavorite
        m.btnFavLabel.text = "★ Quitar"
        m.isFavorite = true
    else
        m.btnFavLabel.text = "★ Favorito"
        m.isFavorite = false
    end if
    m.focusedBtn = 0
    updateBtnFocus()
    m.top.setFocus(true)
end sub

sub updateBtnFocus()
    ' Boton de favoritos siempre blanco, fijo -- no cambia de color por
    ' estado ni por foco. Lo unico dinamico es el texto (onCheckFavDone/
    ' onFavToggled). El foco se indica solo con el contorno (focusRing).
    m.btnPlayBg.color    = "0x2E7D32FF"
    m.btnPlayLabel.color = "0xFFFFFFFF"

    m.btnPlayFocusRing.visible = (m.focusedBtn = 0)
    m.btnFavFocusRing.visible  = (m.focusedBtn = 1)
end sub

Sub onItemSelected()
End Sub

sub pressPlay()
    m.resume = createObject("roSGNode", "ResumeVideo")
    m.resume.section = "MovieResume"
    m.resume.cve = m.videoPlayer.content.id
    m.resume.control = "RUN"
    m.resume.observeField("state", "resume")
end sub

sub pressFav()
    m.addFavorite = createObject("roSGNode", "AddFavorite")
    m.addFavorite.cve  = m.videoPlayer.content.id
    m.addFavorite.tipo = "pelicula"
    ' Solo hace falta armar el itemJson cuando vamos a AGREGAR (si ya es
    ' favorito, esta accion lo va a quitar y el itemJson no se usa).
    if m.isFavorite <> true
        m.addFavorite.itemJson = FormatJSON(Fav_NodeToAA(m.videoPlayer.content, Fav_VodSerieFields()))
    end if
    m.addFavorite.control = "RUN"
    m.addFavorite.observeField("isFavorite", "onFavToggled")
end sub

sub onFavToggled()
    m.isFavorite = m.addFavorite.isFavorite
    if m.isFavorite
        m.btnFavLabel.text = "★ Quitar"
    else
        m.btnFavLabel.text = "★ Favorito"
    end if
end sub

' ─── Recien Vistas ────────────────────────────────────────────────────────────

' Se llama una sola vez por sesion de reproduccion, cuando el video
' realmente arranca (state="playing"), no en el click de Play, para
' no registrar contenido que nunca llego a reproducirse. El flag
' m.rwRegistered evita registros duplicados si el player oscila
' entre buffering/playing durante la misma reproduccion.
sub registerRecentlyWatched()
    if m.rwRegistered = true then return
    m.rwRegistered = true

    m.registerRW = createObject("roSGNode", "RegisterRecentlyWatched")
    m.registerRW.cve  = m.videoPlayer.content.id
    m.registerRW.tipo = "pelicula"
    m.registerRW.itemJson = FormatJSON(Fav_NodeToAA(m.videoPlayer.content, Fav_VodSerieFields()))
    m.registerRW.control = "RUN"
end sub

' ─── Resume ──────────────────────────────────────────────────────────────────

sub resume()
    print "DEBUG RESUME - m.resume.state="; m.resume.state; " m.resume.pos="; m.resume.pos; " content.length="; m.videoPlayer.content.length
    if m.resume.state <> "stop" then return

    ' El registro local (MovieResume) es SOLO de este dispositivo. Si
    ' aqui no hay nada (o es muy poco), probamos con el progreso
    ' sincronizado del servidor (WatchProgressLocalStore), que si
    ' viaja entre dispositivos -- asi "Resume" tambien funciona si
    ' viste el contenido en otro Roku.
    m.resumePos = m.resume.pos
    if m.resumePos < 3
        vodId = m.videoPlayer.content.id
        if vodId <> invalid and vodId <> ""
            wp = WP_LocalRead(vodId.toStr())
            if wp <> invalid and wp.pos <> invalid and wp.pos >= 3
                m.resumePos = wp.pos
                print "DEBUG RESUME - registro local vacio/insuficiente, usando progreso sincronizado del servidor. pos="; m.resumePos
            end if
        end if
    end if

    ' Si no tenemos una duracion valida (0/invalid), no podemos saber si
    ' ya esta en el ultimo 10% de la pelicula -- en ese caso NO bloqueamos
    ' el resume solo por falta de ese dato (antes: content.length=0 hacia
    ' que la comparacion "pos < 0" fallara siempre, y nunca se ofrecia
    ' seguir viendo sin importar que tan avanzada estuviera).
    dur = m.videoPlayer.content.length
    lenOk = true
    if dur <> invalid and dur > 0 and m.resumePos >= (dur * 0.9) then lenOk = false

    if m.resumePos >= 3 and lenOk and m.top.tipo <> 6
        print "DEBUG RESUME - mostrando dialogo, pos="; m.resumePos
        m.dialog = createObject("roSGNode", "Dialog")
        m.dialog.title = "Como deseas continuar viendo"
        m.dialog.optionsDialog = true
        m.dialog.buttons = ["Continuar viendo desde el minuto " + fmtTime(int(m.resumePos)), "Reproducir desde el inicio"]
        m.top.getScene().dialog = m.dialog
        m.dialog.observeField("buttonSelected", "resumeSelected")
    else
        print "DEBUG RESUME - NO se muestra dialogo (pos<3 o >=90% duracion o tipo=6), reproduciendo desde el inicio"
        m.pendingSeekPos = 0
        playVideo()
    end if
end sub

sub resumeSelected()
    print "DEBUG RESUMESELECTED - buttonSelected="; m.dialog.buttonSelected; " pos a aplicar="; m.resumePos
    if m.dialog.buttonSelected = 0
        m.top.content.PlayStart = m.resumePos
        ' FIX REAL de "Continuar viendo siempre reinicia desde 0":
        ' content.PlayStart no es confiable en este reproductor (se
        ' confirmo con logs que Roku lo ignora en varios casos, aunque
        ' el campo muestre el valor correcto). Lo que SI se confirmo que
        ' funciona -- porque se ve en los mismos logs -- es hacer un
        ' seek manual UNA VEZ que el video ya esta reproduciendo
        ' (m.videoPlayer.seek). Se guarda aqui la posicion pendiente;
        ' onVideoPlayerStateChange() la aplica apenas el estado pasa a
        ' "playing" (ver mas abajo).
        m.pendingSeekPos = m.resumePos
        print "DEBUG RESUMESELECTED - PlayStart asignado ANTES de playVideo(). m.top.content.PlayStart="; m.top.content.PlayStart; " pendingSeekPos="; m.pendingSeekPos
    else
        m.top.content.PlayStart = 0
        m.pendingSeekPos = 0
    end if
    playVideo()
    m.dialog.close = true
end sub

' ─── Playback ─────────────────────────────────────────────────────────────────

sub videoHeaders()
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(m.global.user + ":" + m.global.pass)
    headers = []
    headers[0] = "X-Content:" + ba.ToBase64String()
    headers[1] = "X-Roku-Reserved-Dev-Id: 132fdf0cb94f9eb9a3a0132af460b8cd"
    headers[2] = "User-Agent: Moxilla/5.0"
    m.videoPlayer.content.HttpHeaders = headers
end sub

sub playVideo()
    print "DEBUG PLAYVIDEO - seek ANTES de control=stop: "; m.videoPlayer.seek; " | content.PlayStart ANTES: "; m.top.content.PlayStart
    m.retryCount = 0
    m.rwRegistered = false
    ' Igual que en Seasons.brs (capitulos de series): este stop SOLO
    ' debe hacerse si el reproductor YA esta visible/activo (es decir,
    ' si hubiera una pelicula reproduciendose de verdad que cortar). Si
    ' es un arranque nuevo (recien seleccionada, o "Continuar viendo"),
    ' el reproductor todavia no esta visible aqui -- se confirmo que
    ' hacerle stop a un Video que nunca arranco provoca que ignore
    ' content.PlayStart y siempre arranque en 0 (por eso "Continuar
    ' viendo" siempre volvia al inicio en vez de reanudar).
    if m.videoPlayer.visible = true
        m.videoPlayer.control = "stop"
    end if
    print "DEBUG PLAYVIDEO - seek DESPUES de control=stop: "; m.videoPlayer.seek
    ' FIX REAL del bug de "Continuar viendo siempre reinicia desde 0":
    ' m.videoPlayer.content YA es el MISMO objeto que m.top.content desde
    ' que se abrio esta pantalla (ver OnContentChange -- se asigna ahi
    ' apenas se abre, antes de saber si hay que reanudar). PlayStart se
    ' pone despues (resumeSelected/resumeFromRW) sobre ESE MISMO objeto,
    ' asi que "m.videoPlayer.content = m.top.content" de aqui abajo era
    ' una reasignacion a la MISMA referencia -- SceneGraph no dispara
    ' ningun cambio real y Roku nunca vuelve a leer PlayStart, por eso
    ' siempre arrancaba en 0 aunque content.PlayStart mostrara el valor
    ' correcto en los DEBUG. Se fuerza aqui un cambio real (invalid ->
    ' el mismo objeto) para que Roku lo vuelva a leer completo.
    m.videoPlayer.content = invalid
    m.videoPlayer.content = m.top.content
    print "DEBUG PLAYVIDEO - seek DESPUES de reasignar content: "; m.videoPlayer.seek; " | videoPlayer.content.PlayStart DESPUES de reasignar: "; m.videoPlayer.content.PlayStart
    sf = m.videoPlayer.content.streamFormat
    if sf <> invalid and sf <> "" and sf <> "hls" and sf <> "mp4" and sf <> "smooth" and sf <> "mpeg-dash" and sf <> "mkv" and sf <> "ts"
        m.videoPlayer.content.streamFormat = ""
    end if
    m.videoPlayer.playbackSpeed = m.currentSpeed
    logMovieDiag("url", m.videoPlayer.content.url)
    logMovieDiag("streamFormat", m.videoPlayer.content.streamFormat)
    videoHeaders()
    m.videoPlayer.visible = true
    m.videoPlayer.setFocus(true)
    m.videoPlayer.subtitleConfig = {showSubtitles: true}
    print "DEBUG PLAYVIDEO - seek JUSTO ANTES de control=play: "; m.videoPlayer.seek; " | videoPlayer.content.PlayStart JUSTO ANTES de play: "; m.videoPlayer.content.PlayStart
    m.videoPlayer.control = "play"
    if m.overlayTitle <> invalid
        t = m.videoPlayer.content.title
        if t = invalid then t = ""
        m.overlayTitle.text = t
    end if
end sub

' ─── Video state ─────────────────────────────────────────────────────────────

Sub onVideoPlayerStateChange()
    state = m.videoPlayer.state
    if state = "buffering"
        m.bufferingGroup.visible = true
    else if state <> "playing"
        m.bufferingGroup.visible = false
    end if
    ' Pedido explicito: cuando state="playing", el "cargando" YA NO se
    ' destapa aqui (ni de inmediato, ni con un timer fijo de 1.5s como en
    ' el primer intento) -- eso fallaba en contenido que tarda mas en
    ' rebufferizar despues del seek de reanudar: se destapaba antes de
    ' tiempo, y el "buffering" real llegaba despues mostrando el mismo
    ' glitch de "arranca - vuelve a cargar - arranca bien". El fix real
    ' (igual al sample oficial de Roku rokudev/transport-control) es
    ' esperar bufferingStatus.percentage=100 (ver onBufferingStatusChange,
    ' mas abajo) antes de destapar -- aplica siempre, haya o no seek
    ' pendiente.

    if state = "playing"
        m.retryCount = 0
        m.videoPlayer.setFocus(true)
        updateTrackLabels()
        registerRecentlyWatched()
        ' Nueva reproduccion arrancando (o reintento): la barra de
        ' controles propia debe reflejar "Pausar", igual que Seasons.brs.
        updatePlayPauseLabel()
        if m.seekBufferTimer <> invalid
            m.seekBufferTimer.control = "stop"
            m.seekBufferTimer.control = "start"
        end if
        ' FIX REAL de "Continuar viendo siempre reinicia desde 0":
        ' content.PlayStart resulto no ser confiable en este reproductor.
        ' Se confirmo con los logs del usuario que un seek manual SI
        ' funciona una vez que el video ya esta reproduciendo -- se
        ' aplica aqui, apenas arranca de verdad, la posicion que se dejo
        ' pendiente en resumeSelected()/onContentChange (Continuar viendo
        ' desde Recien Vistas).
        if m.pendingSeekPos > 0
            print "DEBUG SEEKFIX(movie) - aplicando seek pendiente. pos="; m.pendingSeekPos
            m.videoPlayer.seek = m.pendingSeekPos
            m.pendingSeekPos = 0
        end if

    else if state = "finished"
        m.playerOverlay.visible = false
        m.videoPlayer.visible   = false
        m.top.setFocus(true)

    else if state = "error"
        m.playerOverlay.visible = false
        m.retryCount++
        errCode = m.videoPlayer.errorCode
        errCodeStr = ""
        if errCode <> invalid then errCodeStr = errCode.toStr()
        errMsgRaw = m.videoPlayer.errorMsg
        logMovieDiag("playErrorCode", errCodeStr)
        logMovieDiag("playErrorMsg", errMsgRaw)
        logMovieDiag("retryCount", m.retryCount)
        if m.retryCount <= 3
            m.bufferingGroup.visible = true
            m.retryTimer.control = "start"
        else
            m.retryCount = 0
            m.bufferingGroup.visible = false
            m.videoPlayer.visible    = false
            errMsg = errMsgRaw
            if errMsg = invalid or errMsg = "" then errMsg = "Could not play this content"
            dlg = createObject("roSGNode", "Dialog")
            dlg.title   = "Error de reproduccion - Diagnostico"
            dlg.message = errMsg + Chr(10) + Chr(10) + movieDiagText()
            dlg.buttons = ["OK"]
            dlg.observeField("buttonSelected", "onPlayErrorClose")
            m.playErrorDlg = dlg
            m.top.getScene().dialog = dlg
        end if
    end if
End Sub

sub onRetryTimer()
    m.videoPlayer.control = "stop"
    m.videoPlayer.content = m.top.content
    sf = m.videoPlayer.content.streamFormat
    if sf <> invalid and sf <> "" and sf <> "hls" and sf <> "mp4" and sf <> "smooth" and sf <> "mpeg-dash" and sf <> "mkv" and sf <> "ts"
        m.videoPlayer.content.streamFormat = ""
    end if
    videoHeaders()
    m.videoPlayer.control = "play"
end sub

sub onPlayErrorClose()
    m.top.getScene().dialog = invalid
    m.playErrorDlg = invalid
    m.videoPlayer.visible = false
    m.top.setFocus(true)
end sub

' ─── Progress bar ────────────────────────────────────────────────────────────

sub onProgressTimer()
    if m.playerOverlay.visible then updateProgressBar()
end sub

' Respaldo del fix de "arranca-vuelve a cargar-arranca bien" (ver el
' comentario en onVideoPlayerStateChange, rama pendingSeekPos): si Roku
' hizo el seek sin volver a avisar "buffering"/"playing" (a veces el
' salto es practicamente instantaneo), este timer destapa el "cargando"
' de todas formas. Si en ese momento Roku SI esta buffering de verdad
' (el seek si tardo), no se hace nada -- el manejo normal de estados se
' encarga de destaparlo cuando de verdad este listo.
' Ultimo respaldo si este dispositivo nunca avisa bufferingStatus (ver
' onBufferingStatusChange): despues de un tiempo generoso, destapa el
' "cargando" salvo que Roku este de verdad todavia en "buffering".
sub onSeekBufferTimer()
    if m.videoPlayer <> invalid and m.videoPlayer.state <> "buffering"
        if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
    end if
end sub

' Forma correcta (la que usa el sample oficial de Roku
' rokudev/transport-control, funcion handleBufferingStatus) de saber si
' el video YA de verdad esta listo para verse sin que se note el salto
' del seek -- en vez de adivinar con un timer fijo (que fallaba en
' capitulos/peliculas que tardan mas o menos en rebufferizar), se espera
' a que Roku avise que el buffer llego al 100%.
sub onBufferingStatusChange()
    status = m.videoPlayer.bufferingStatus
    if status <> invalid and status.percentage <> invalid and status.percentage >= 100
        if m.bufferingGroup <> invalid then m.bufferingGroup.visible = false
        if m.seekBufferTimer <> invalid then m.seekBufferTimer.control = "stop"
    end if
end sub

sub updateProgressBar()
    curPos = m.videoPlayer.position
    curDur = m.videoPlayer.duration
    if curDur = invalid or curDur <= 0 then return
    pct  = curPos / curDur
    barW = int(1174 * pct)
    m.progressFill.width      = barW
    m.progressDot.translation = [49 + barW, 496]
    m.timeCurrent.text  = fmtTime(int(curPos))
    m.timeDuration.text = fmtTime(int(curDur))
end sub

sub savePosition()
    curPos = m.videoPlayer.position
    curDur = m.videoPlayer.duration
    if m.playerOverlay.visible then updateProgressBar()
    if int(curPos) MOD 2 = 0 and curPos > 10
        m.savePositionToReg.cve = m.videoPlayer.content.id
        m.savePositionToReg.pos = curPos - 10
        m.savePositionToReg.control = "RUN"

        ' Progreso local para la barra tipo Netflix (mismo patron que Series)
        vodId = m.videoPlayer.content.id
        if vodId <> invalid and vodId <> "" and curDur <> invalid and curDur > 0
            WP_LocalWrite(vodId.toStr(), int(curPos), int(curDur))
        end if
    end if

    ' Sincronizar con servidor cada 1 min (mismo patron/intervalo que Series)
    if int(curPos) MOD 60 = 0 and curPos > 10
        vodId = m.videoPlayer.content.id
        if vodId <> invalid and vodId <> "" and curDur <> invalid and curDur > 0
            m.saveWatchProgress = createObject("roSGNode", "SaveWatchProgress")
            m.saveWatchProgress.cve = vodId.toStr()
            m.saveWatchProgress.pos = int(curPos)
            m.saveWatchProgress.duration = int(curDur)
            m.saveWatchProgress.control = "RUN"
        end if
    end if
end sub

' ─── Player overlay ──────────────────────────────────────────────────────────

sub showPlayerOverlay()
    ' Barra de controles propia (igual a Android): reemplaza la UI
    ' nativa de Roku, que quedo apagada (enableUI="false" en
    ' DetailsScreen.xml).
    if m.playerOverlay = invalid then return
    if m.overlayTitle <> invalid and m.videoPlayer.content <> invalid
        t = m.videoPlayer.content.title
        if t = invalid then t = ""
        m.overlayTitle.text = t
    end if
    updateProgressBar()
    updatePlayPauseLabel()
    m.ctrlBarFocusIdx = 1 ' foco por defecto: play/pausa, igual que Android
    updateCtrlBarFocusVisuals()
    m.playerOverlay.visible = true
    m.overlayTimer.control = "stop"
    m.overlayTimer.control = "start"
end sub

sub hidePlayerOverlay()
    m.playerOverlay.visible = false
    m.overlayTimer.control  = "stop"
end sub

' Mueve el foco entre los controles de la barra (Izquierda/Derecha).
' delta: -1 (izquierda) o +1 (derecha). Reinicia el autoocultado, igual
' que cualquier otra interaccion con la barra.
sub moveCtrlBarFocus(delta as Integer)
    if m.ctrlBar = invalid or m.ctrlBar.count() = 0 then return
    n = m.ctrlBar.count()
    m.ctrlBarFocusIdx = (m.ctrlBarFocusIdx + delta + n) MOD n
    updateCtrlBarFocusVisuals()
    m.overlayTimer.control = "stop"
    m.overlayTimer.control = "start"
end sub

sub updateCtrlBarFocusVisuals()
    if m.ctrlBar = invalid then return
    for i = 0 to m.ctrlBar.count() - 1
        ring = m.ctrlBar[i]
        if ring <> invalid then ring.visible = (i = m.ctrlBarFocusIdx)
    end for
end sub

' Activa el control actualmente enfocado (OK). Mismo orden que m.ctrlBar
' (ver Init): 0=-10s 1=play/pausa 2=+10s 3=engranaje. Sin anterior/
' siguiente aqui -- esto es una pelicula suelta, no un capitulo de serie.
sub activateFocusedControl()
    m.overlayTimer.control = "stop"
    m.overlayTimer.control = "start"
    idx = m.ctrlBarFocusIdx
    if idx = 0
        seekRelative(-10)
    else if idx = 1
        togglePlayPause()
    else if idx = 2
        seekRelative(10)
    else if idx = 3
        showControlsMenu()
    end if
end sub

' +10s/-10s, igual que los botones de Android (seekBy). Se recorta a
' [0, duracion] para no mandar el seek fuera de rango.
sub seekRelative(deltaSeconds as Integer)
    curPos = m.videoPlayer.position
    if curPos = invalid then curPos = 0
    curDur = m.videoPlayer.duration
    newPos = curPos + deltaSeconds
    if newPos < 0 then newPos = 0
    if curDur <> invalid and curDur > 0 and newPos > curDur - 1 then newPos = curDur - 1
    ' DEBUG TEMPORAL: para confirmar el valor real de posicion/duracion
    ' que ve este seek relativo, por si "adelantar" termina en un lugar
    ' equivocado. Se puede borrar despues de revisar el log.
    print "DEBUG SEEKRELATIVE(movie) - curPos="; curPos; " curDur="; curDur; " delta="; deltaSeconds; " newPos="; newPos
    m.videoPlayer.seek = newPos
    updateProgressBar()
end sub

' Play/pausa, igual que el boton central de Android (togglePlayPause).
sub togglePlayPause()
    if m.videoPlayer.state = "paused"
        m.videoPlayer.control = "resume"
    else
        m.videoPlayer.control = "pause"
    end if
    updatePlayPauseLabel()
end sub

sub updatePlayPauseLabel()
    if m.ctrlPlayPauseLabel = invalid then return
    if m.videoPlayer.state = "paused"
        m.ctrlPlayPauseLabel.text = "Reproducir"
    else
        m.ctrlPlayPauseLabel.text = "Pausar"
    end if
end sub

sub updateTrackLabels()
    tracks = m.videoPlayer.audioTracks
    if tracks <> invalid and tracks.count() > 0
        selIdx = m.videoPlayer.selectedAudioTrack
        if selIdx = invalid then selIdx = 0
        t = tracks[selIdx]
        name = ""
        if t <> invalid
            if t.language <> invalid and t.language <> "" then name = t.language
            if name = "" and t.name <> invalid and t.name <> "" then name = t.name
        end if
        if name = "" then name = "Track " + (selIdx + 1).toStr()
        m.audioLabel.text = "Audio: " + name
    else
        m.audioLabel.text = "Audio: -"
    end if
    sTracks = m.videoPlayer.subtitleTracks
    if sTracks <> invalid and sTracks.count() > 0
        if m.subtitlesOn
            m.subtitleLabel.text = "CC: On"
        else
            m.subtitleLabel.text = "CC: Off"
        end if
    else
        m.subtitleLabel.text = "CC: -"
    end if
end sub

' ─── Audio / subtitle menus ──────────────────────────────────────────────────

sub showControlsMenu()
    tracks  = m.videoPlayer.audioTracks
    sTracks = m.videoPlayer.subtitleTracks

    items = []
    items.push("Speed: " + m.speedLabels[m.speedIdx] + "  (UP/DOWN to change)")
    if tracks <> invalid and tracks.count() > 0
        items.push("Audio Tracks  (" + tracks.count().toStr() + " available)")
    end if
    if sTracks <> invalid and sTracks.count() > 0
        if m.subtitlesOn
            items.push("Subtitles: ON  (press to turn off)")
        else
            items.push("Subtitles: OFF  (press to turn on)")
        end if
    end if
    items.push("Close")

    dlg = createObject("roSGNode", "Dialog")
    dlg.title   = "Player Controls"
    dlg.buttons = items
    dlg.observeField("buttonSelected", "onControlsMenuSelected")
    m.controlsDlg = dlg
    m.top.getScene().dialog = dlg
end sub

sub onControlsMenuSelected()
    if m.controlsDlg = invalid then return
    btn = m.controlsDlg.buttonSelected
    m.top.getScene().dialog = invalid
    m.controlsDlg = invalid
    m.videoPlayer.setFocus(true)

    tracks  = m.videoPlayer.audioTracks
    sTracks = m.videoPlayer.subtitleTracks
    hasAudio = tracks <> invalid and tracks.count() > 0
    hasSubs  = sTracks <> invalid and sTracks.count() > 0

    if btn = 0
        m.videoPlayer.setFocus(true)
    else if btn = 1 and hasAudio
        showAudioMenu()
    else if btn = 1 and not hasAudio and hasSubs
        toggleSubtitles()
    else if btn = 2 and hasAudio and hasSubs
        toggleSubtitles()
    end if
end sub

sub showAudioMenu()
    tracks = m.videoPlayer.audioTracks
    if tracks = invalid or tracks.count() = 0 then return
    items = []
    for i = 0 to tracks.count() - 1
        t = tracks[i]
        name = ""
        if t.language <> invalid and t.language <> "" then name = t.language
        if name = "" and t.name <> invalid then name = t.name
        if name = "" then name = "Track " + (i + 1).toStr()
        selIdx = m.videoPlayer.selectedAudioTrack
        if selIdx = invalid then selIdx = 0
        if i = selIdx then name = name + "  ✓"
        items.push(name)
    end for
    items.push("Cancel")
    dlg = createObject("roSGNode", "Dialog")
    dlg.title   = "Select Audio Track"
    dlg.buttons = items
    dlg.observeField("buttonSelected", "onAudioSelected")
    m.audioDlg = dlg
    m.top.getScene().dialog = dlg
end sub

sub onAudioSelected()
    if m.audioDlg = invalid then return
    btn = m.audioDlg.buttonSelected
    m.top.getScene().dialog = invalid
    m.audioDlg = invalid
    tracks = m.videoPlayer.audioTracks
    if tracks = invalid then return
    if btn >= 0 and btn < tracks.count()
        m.videoPlayer.selectedAudioTrack = btn
        updateTrackLabels()
    end if
    m.videoPlayer.setFocus(true)
end sub

sub toggleSubtitles()
    sTracks = m.videoPlayer.subtitleTracks
    if sTracks = invalid or sTracks.count() = 0 then return
    if m.subtitlesOn
        m.videoPlayer.selectedSubtitleTrack = -1
        m.subtitlesOn = false
        m.subtitleLabel.text = "CC: Off"
    else
        m.videoPlayer.selectedSubtitleTrack = 0
        m.subtitlesOn = true
        m.subtitleLabel.text = "CC: On"
    end if
    m.videoPlayer.setFocus(true)
end sub

' ─── Key events ──────────────────────────────────────────────────────────────

function onKeyEvent(key as String, press as Boolean) as Boolean
    ' DEBUG TEMPORAL: para confirmar si las teclas llegan aqui de verdad
    ' mientras el video tiene el foco, o si Roku se las queda antes (a
    ' nivel nativo) y onKeyEvent nunca se llega a ejecutar. Se puede
    ' borrar despues de revisar el log.
    print "DEBUG ONKEYEVENT(movie) key="; key; " press="; press; " videoplayer.visible="; m.videoPlayer.visible; " playerOverlay.visible="; (m.playerOverlay <> invalid and m.playerOverlay.visible)
    if not press then return false

    if m.videoPlayer.visible
        if key = "back"
            m.videoPlayer.control = "stop"
            m.videoPlayer.visible = false
            hidePlayerOverlay()
            m.top.setFocus(true)
            return true
        end if
        if key = "OK"
            if m.playerOverlay <> invalid
                if m.playerOverlay.visible
                    ' Igual que Android: con la barra visible, OK activa
                    ' el control que este enfocado (no la esconde).
                    activateFocusedControl()
                else
                    showPlayerOverlay()
                end if
            end if
            return true
        else if key = "play"
            ' Boton fisico de play/pausa del control remoto (si lo
            ' tiene): pausa/reproduce directo, igual que en Android, sin
            ' necesidad de tener la barra enfocada primero.
            togglePlayPause()
            if m.playerOverlay <> invalid and m.playerOverlay.visible <> true then showPlayerOverlay()
            return true
        else if key = "rewind"
            seekRelative(-10)
            if m.playerOverlay <> invalid and m.playerOverlay.visible <> true then showPlayerOverlay()
            return true
        else if key = "fastforward"
            seekRelative(10)
            if m.playerOverlay <> invalid and m.playerOverlay.visible <> true then showPlayerOverlay()
            return true
        else if key = "left"
            ' Pedido explicito: izquierda/derecha NO deben adelantar/
            ' atrasar la linea de tiempo por su cuenta -- para eso estan
            ' los botones -10s/+10s de la barra. Si la barra esta
            ' visible, mueven el foco entre botones; si no, no hacen
            ' nada. Se devuelve true SIEMPRE (aunque no se haga nada)
            ' para que Roku no le pase la tecla a su propio trick play
            ' nativo (enableTrickPlay sigue en true solo para que el
            ' seek() que hacemos nosotros funcione -- sin este true,
            ' Roku hacia el seek el solo con izquierda/derecha aunque
            ' la barra nativa este apagada).
            if m.playerOverlay <> invalid and m.playerOverlay.visible
                moveCtrlBarFocus(-1)
            end if
            return true
        else if key = "right"
            if m.playerOverlay <> invalid and m.playerOverlay.visible
                moveCtrlBarFocus(1)
            end if
            return true
        end if
        return false
    end if

    if key = "left"
        if m.focusedBtn = 1
            m.focusedBtn = 0
            updateBtnFocus()
        end if
        return true
    end if

    if key = "right"
        if m.focusedBtn = 0
            m.focusedBtn = 1
            updateBtnFocus()
        end if
        return true
    end if

    if key = "OK"
        if m.focusedBtn = 0
            pressPlay()
        else
            pressFav()
        end if
        return true
    end if

    if key = "back"
        m.top.requestClose = true
        return true
    end if

    return false
end function

Sub OnContentChange()
    m.videoPlayer.content = m.top.content

    if m.top.content.HDPosterUrl <> invalid and m.top.content.HDPosterUrl <> ""
        m.poster.uri = m.top.content.HDPosterUrl
    end if
    if m.top.content.hdBackgroundImageUrl <> invalid and m.top.content.hdBackgroundImageUrl <> ""
        m.background.uri = m.top.content.hdBackgroundImageUrl
    end if
    vodId = m.top.content.id
    print "DEBUG OnContentChange - vodId="; vodId

    frac = 0.0
    if vodId <> invalid and vodId <> "" then frac = WP_LocalFraction(vodId.toStr())
    if frac > 0.0
        m.watchProgressBg.visible   = true
        m.watchProgressFill.visible = true
        m.watchProgressFill.width   = 213 * frac
    else
        m.watchProgressBg.visible   = false
        m.watchProgressFill.visible = false
    end if

    if vodId <> invalid and vodId <> ""
        m.detailVodTask = CreateObject("roSGNode", "GetVodInfo")
        m.detailVodTask.vodId = vodId
        m.detailVodTask.observeField("result", "onDetailVodInfo")
        m.detailVodTask.control = "RUN"
    end if

    dn = m.top.findNode("DetailTitle")
    if dn <> invalid then dn.text = m.top.content.title

    ratingBg  = m.top.findNode("detailRatingBg")
    ratingLbl = m.top.findNode("detailRating")
    if ratingBg <> invalid
        ' Rating oculto por diseno (ver DetailsScreen.xml): se deja
        ' esta funcion sin togglear visible=true nunca, para no
        ' pisar el visible=false del XML.
        ratingBg.visible  = false
        ratingLbl.visible = false
    end if

    metaLbl = m.top.findNode("DetailMeta")
    if metaLbl <> invalid
        meta = ""
        rd = m.top.content.releaseDate
        if rd <> invalid and rd <> "" then meta = Left(rd, 4)
        ln = m.top.content.length
        if ln <> invalid and ln > 0
            if meta <> "" then meta = meta + "  ·  "
            meta = meta + int(ln / 60).toStr() + " min"
        end if
        metaLbl.text = meta
    end if

    genreLbl = m.top.findNode("DetailGenre")
    if genreLbl <> invalid
        g = m.top.content.genre
        if g <> invalid and g <> "" then genreLbl.text = g else genreLbl.text = ""
    end if

    descLbl = m.top.findNode("DetailDescription")
    if descLbl <> invalid
        d = m.top.content.description
        if d <> invalid and d <> "" then descLbl.text = d else descLbl.text = "Sin resumen disponible"
    end if

    m.top.tipo = m.videoPlayer.content.ContentType

    ' "Continuar viendo" desde Recien Vistas (ver HomeScreen.brs):
    ' resumeFromRW se puso ANTES de asignar "content" (arriba en esta
    ' misma funcion), asi que ya esta disponible aqui. Si viene puesto
    ' (>= 0), el usuario ya confirmo que si en el dialogo de Home --
    ' se reproduce de una vez desde ese punto, sin pasar por esta
    ' pagina ni volver a preguntar (pressPlay() SI volveria a preguntar,
    ' por eso no se reusa aqui).
    if m.top.resumeFromRW >= 0
        m.top.content.PlayStart = m.top.resumeFromRW
        ' Ver el comentario en resumeSelected()/onVideoPlayerStateChange:
        ' PlayStart no es confiable aqui, se aplica con seek() apenas
        ' arranque a reproducir de verdad.
        m.pendingSeekPos = m.top.resumeFromRW
        m.top.resumeFromRW = -1
        playVideo()
    end if
End Sub

sub onDetailVodInfo()
    result = m.detailVodTask.result
    if result = invalid then
        print "DEBUG onDetailVodInfo - result es invalid"
        return
    end if
    print "DEBUG onDetailVodInfo - hdBackgroundImageUrl="; result.hdBackgroundImageUrl
    print "DEBUG onDetailVodInfo - plot="; result.plot
    print "DEBUG onDetailVodInfo - description="; result.description
    if result.hdBackgroundImageUrl <> invalid and result.hdBackgroundImageUrl <> ""
        m.background.uri = result.hdBackgroundImageUrl
    end if
    descLbl = m.top.findNode("DetailDescription")
    if descLbl <> invalid
        print "DEBUG descLbl.text actual="; descLbl.text
        d = ""
        if result.hasField("plot") and result.plot <> invalid and result.plot <> ""
            d = result.plot
        end if
        print "DEBUG descripcion a poner="; d
        if d <> "" then descLbl.text = d
    else
        print "DEBUG DetailDescription node no encontrado"
    end if
end sub

' ─── Helpers ─────────────────────────────────────────────────────────────────

function fmtTime(secs as Integer) as String
    h = int(secs / 3600)
    mn = int((secs mod 3600) / 60)
    s  = secs mod 60
    if h > 0 then return h.toStr() + ":" + zp(mn) + ":" + zp(s)
    return mn.toStr() + ":" + zp(s)
end function

function zp(n as Integer) as String
    if n < 10 then return "0" + n.toStr()
    return n.toStr()
end function

Function ContentList2SimpleNode(contentList as Object, nodeType = "ContentNode" as String) as Object
    result = createObject("roSGNode", nodeType)
    if result <> invalid
        for each itemAA in contentList
            item = createObject("roSGNode", nodeType)
            item.setFields(itemAA)
            result.appendChild(item)
        end for
    end if
    return result
End Function
