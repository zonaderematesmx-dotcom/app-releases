sub init()
    m.bg  = m.top.findNode("btnBg")
    m.lbl = m.top.findNode("btnLabel")

    m.top.observeField("text", "onTextChange")
    m.top.observeField("bgColor", "onBgColorChange")

    onTextChange()
    onBgColorChange()
end sub

sub onTextChange()
    m.lbl.text = m.top.text
end sub

sub onBgColorChange()
    m.bg.color = m.top.bgColor
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press and key = "OK"
        ' alwaysNotify="true" en el campo hace que el observer se dispare
        ' aunque el valor booleano no cambie de true a false.
        m.top.buttonSelected = not m.top.buttonSelected
        return true
    end if
    return false
end function
