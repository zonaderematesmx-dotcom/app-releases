sub init()
    m.top.functionName = "go"
end sub

' Devuelve el primer valor de la lista que sea un string no vacio
' (ignora invalid, tipos que no sean string, y arreglos/objetos vacios
' que algunos paneles mandan en vez de omitir el campo). Se usa para
' revisar varios nombres de campo posibles de la imagen del capitulo
' sin repetir el mismo chequeo de tipo/vacio para cada uno.
function FirstNonEmptyStr(candidates as Object) as Object
    for each c in candidates
        if c <> invalid and (type(c) = "roString" or type(c) = "String") and c <> ""
            return c
        end if
    end for
    return invalid
end function

 sub go()
    content = createObject("roSGNode", "ContentNode")
    episode = jsonCapitulos(m.top.season)

    if episode <> invalid then
        for i = 0 to episode.count() - 1
            seasons = content.createChild("ContentNode")
            
            ' Requisitos mínimos obligatorios (id, title, etc.)
            if episode[i].id <> invalid then
                seasons.id = episode[i].id.toStr()
            end if

            if episode[i].title <> invalid then
                seasons.title = cleanEpisodeTitle(episode[i].title)
            end if

            if episode[i].episode_num <> invalid then
                seasons.episodeNumber = "E" + episode[i].episode_num.toStr()
            end if

            if episode[i].container_extension <> invalid and episode[i].id <> invalid then
                ext = LCase(episode[i].container_extension)
                ' Use direct_source if server provides it, otherwise build standard Xtream URL
                if episode[i].direct_source <> invalid and episode[i].direct_source <> ""
                    seasons.url = episode[i].direct_source
                else
                    seasons.url = m.global.serverURL + m.global.play + episode[i].id.toStr() + "." + ext
                end if
                if ext = "m3u8" then
                    seasons.streamFormat = "hls"
                else if ext = "mpd" then
                    seasons.streamFormat = "mpeg-dash"
                else if ext = "mkv" then
                    seasons.streamFormat = "mkv"
                end if
                seasons.contentType = "episode"
            end if

            ' Imagen del episodio (con respaldo a la portada de la serie).
            ' Se hace AQUI, fuera del bloque de "info", porque muchos
            ' proveedores mandan "info": [] (arreglo vacio en vez de
            ' objeto) y antes eso hacia que el respaldo nunca corriera,
            ' dejando el capitulo sin imagen del todo.
            ' Se revisan VARIAS ubicaciones posibles del campo, en orden
            ' de mas a menos comun -- no todos los paneles Xtream mandan
            ' "movie_image" dentro de "info": algunos lo ponen directo en
            ' el objeto del episodio, y otros usan "cover"/"still_path"
            ' (estilo TMDB) en vez de "movie_image". Sin esto, un
            ' capitulo que SI trae su propia miniatura (solo que en un
            ' campo distinto al que se revisaba antes) se veia igual que
            ' uno sin imagen, y terminaba mostrando la portada de la
            ' serie o el generico en su lugar.
            img = invalid
            if episode[i].info <> invalid and type(episode[i].info) = "roAssociativeArray" then
                img = FirstNonEmptyStr([episode[i].info.movie_image, episode[i].info.cover, episode[i].info.cover_big, episode[i].info.still_path])
            end if
            if img = invalid or img = ""
                img = FirstNonEmptyStr([episode[i].movie_image, episode[i].cover, episode[i].still_path])
            end if
            if img <> invalid and img <> ""
                seasons.shortDescriptionLine1 = img
                print "[GE] img=" + img
            else if m.top.seriesCover <> invalid and m.top.seriesCover <> ""
                seasons.shortDescriptionLine1 = m.top.seriesCover
                print "[GE] img=<sin imagen, usando seriesCover>"
            else
                print "[GE] img=<sin imagen> (episode_num="; episode[i].episode_num; ")"
            end if

            ' Validar que info exista
            print "[GE] info type=" + type(episode[i].info)
           if episode[i].info <> invalid and type(episode[i].info) = "roAssociativeArray" then

                if episode[i].info.duration_secs <> invalid then
                    ds = episode[i].info.duration_secs
                    if type(ds) = "roInt" or type(ds) = "roInteger" or type(ds) = "Integer" then
                        seasons.length = ds
                    else if type(ds) = "roString" or type(ds) = "String" then
                        seasons.length = val(ds)
                    end if
                end if

                if episode[i].info.plot <> invalid and (type(episode[i].info.plot) = "roString" or type(episode[i].info.plot) = "String") and episode[i].info.plot.len() > 0 then
                    seasons.description = episode[i].info.plot
                end if

                if episode[i].info.releasedate <> invalid and (type(episode[i].info.releasedate) = "roString" or type(episode[i].info.releasedate) = "String") and episode[i].info.releasedate.len() > 0 then
                    seasons.releaseDate = episode[i].info.releasedate
                end if

                if episode[i].info.season <> invalid then
                    s = episode[i].info.season
                    if type(s) = "roInt" or type(s) = "roInteger" or type(s) = "Integer" then
                        ' "titleSeason" NO es un campo estandar de ContentNode --
                        ' asignarlo con notacion de punto (seasons.titleSeason=)
                        ' puede quedarse sin efecto en silencio (Roku exige
                        ' AddFields()/AddField() para campos nuevos que no
                        ' existen ya en el nodo). Esto rompia en silencio la
                        ' funcion de "Continuar viendo" desde Recien Vistas:
                        ' el campo se perdia al reconstruir el capitulo
                        ' (ver RW_EpisodeAAToNode), y sin saber la temporada
                        ' arriba/abajo, el aviso de siguiente capitulo, y el
                        ' avance automatico se quedaban sin funcionar.
                        seasons.AddFields({titleSeason: "S" + s.toStr()})
                    end if
                end if

            end if
        end for
    end if

    m.top.content = content
end sub



function jsonCapitulos(season As String) As Object
    url = m.global.serverURL + m.global.episode + m.top.cve
    print "Episodios Url = "; url
    data = requestData(url)
    json = ParseJSON(data)
    if json = invalid then return {}
    if json.episodes = invalid then return {}
    eps = json.episodes
    if type(eps) = "roAssociativeArray"
        ' Intento 1: match exacto
        result = eps[season]
        if result <> invalid and type(result) = "roArray" and result.Count() > 0 then return result
        ' Intento 2: season como entero
        seasonInt = val(season)
        seasonStr = seasonInt.toStr()
        if seasonStr <> season
            result = eps[seasonStr]
            if result <> invalid and type(result) = "roArray" and result.Count() > 0 then return result
        end if
        ' Intento 3: buscar primera key cuyo val() coincida - retornar inmediatamente al primer match
        for each key in eps
            if val(key) = seasonInt
                result = eps[key]
                if result <> invalid and type(result) = "roArray" then return result
            end if
        end for
    else if type(eps) = "roArray"
        idx = val(season)
        if idx >= 0 and idx < eps.Count()
            return eps[idx]
        end if
    end if
    return {}
End Function

' Strip "Series Name - S01E02 - " prefix that Xtream servers prepend to episode titles
function cleanEpisodeTitle(t as String) as String
    ' Look for the pattern " - SxxExx - " and return everything after it
    i = 1
    tLen = Len(t)
    while i <= tLen - 6
        if Mid(t, i, 3) = " - "
            rest = Mid(t, i + 3)
            ' Check if rest starts with SxxExx pattern
            if Len(rest) > 3 and UCase(Left(rest, 1)) = "S"
                j = 2
                while j <= Len(rest) and Mid(rest, j, 1) >= "0" and Mid(rest, j, 1) <= "9"
                    j = j + 1
                end while
                if j > 2 and j <= Len(rest) and UCase(Mid(rest, j, 1)) = "E"
                    k = j + 1
                    while k <= Len(rest) and Mid(rest, k, 1) >= "0" and Mid(rest, k, 1) <= "9"
                        k = k + 1
                    end while
                    if k > j + 1 and Mid(rest, k, 3) = " - "
                        cleaned = Mid(rest, k + 3)
                        if cleaned <> "" then return cleaned
                    end if
                end if
            end if
        end if
        i = i + 1
    end while
    return t
end function
