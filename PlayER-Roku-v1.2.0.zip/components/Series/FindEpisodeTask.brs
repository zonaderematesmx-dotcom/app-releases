' ============================================================
' FindEpisodeTask.brs
' ============================================================
' Ver FindEpisodeTask.xml. Mismo endpoint que usa GetEpisodes.brs
' (get_series_info), pero en vez de filtrar por una temporada
' (m.top.season) revisa TODAS las que vengan en la respuesta,
' buscando el capitulo cuyo id coincide con m.top.episodeId. El
' mapeo de campos al ContentNode resultante es el mismo que ya usa
' GetEpisodes.brs por cada capitulo (se duplica aqui a proposito, en
' vez de compartir el archivo, para no juntar dos "init()"/"go()" con
' nombres iguales en el mismo componente Task).
' ============================================================

sub init()
    m.top.functionName = "go"
end sub

sub go()
    targetId = m.top.episodeId
    if targetId = invalid or targetId = ""
        m.top.result = invalid
        return
    end if

    url = m.global.serverURL + m.global.episode + m.top.cve
    data = requestData(url)
    json = ParseJSON(data)
    ' OJO: "if json = invalid or json.episodes = invalid" (como estaba
    ' antes) es peligroso en BrightScript -- "or" NO hace evaluacion de
    ' cortocircuito, asi que SIEMPRE evalua los dos lados. Si json
    ' resultaba invalid (respuesta vacia/mal formada del servidor, algo
    ' bastante comun en esta llamada de red), "json.episodes" tronaba
    ' con un error de tipo (dereferenciar un campo de invalid), la
    ' tarea entera se moria a medias SIN llegar nunca a poner
    ' m.top.result -- entonces onRWEpisodeFound() nunca se disparaba y
    ' "Si, continuar"/"Ver desde el inicio" se quedaban sin hacer nada
    ' (pantalla congelada). Separado en dos "if" para que el primero
    ' salga ANTES de intentar leer ".episodes" de un json invalido.
    if json = invalid
        m.top.result = invalid
        return
    end if
    if json.episodes = invalid
        m.top.result = invalid
        return
    end if

    found = FindEpisodeInJson(json.episodes, targetId)
    if found = invalid
        m.top.result = invalid
        return
    end if

    node = createObject("roSGNode", "ContentNode")

    if found.id <> invalid then node.id = found.id.toStr()
    if found.title <> invalid then node.title = FE_CleanEpisodeTitle(found.title)
    if found.episode_num <> invalid then node.episodeNumber = "E" + found.episode_num.toStr()

    if found.container_extension <> invalid and found.id <> invalid
        ext = LCase(found.container_extension)
        if found.direct_source <> invalid and found.direct_source <> ""
            node.url = found.direct_source
        else
            node.url = m.global.serverURL + m.global.play + found.id.toStr() + "." + ext
        end if
        if ext = "m3u8" then
            node.streamFormat = "hls"
        else if ext = "mpd" then
            node.streamFormat = "mpeg-dash"
        else if ext = "mkv" then
            node.streamFormat = "mkv"
        end if
        node.contentType = "episode"
    end if

    img = invalid
    if found.info <> invalid and type(found.info) = "roAssociativeArray" then
        img = found.info.movie_image
    end if
    if img <> invalid and (type(img) = "roString" or type(img) = "String") and img <> ""
        node.shortDescriptionLine1 = img
    else if m.top.seriesCover <> invalid and m.top.seriesCover <> ""
        node.shortDescriptionLine1 = m.top.seriesCover
    end if

    if found.info <> invalid and type(found.info) = "roAssociativeArray" then
        if found.info.duration_secs <> invalid
            ds = found.info.duration_secs
            if type(ds) = "roInt" or type(ds) = "roInteger" or type(ds) = "Integer"
                node.length = ds
            else if type(ds) = "roString" or type(ds) = "String"
                node.length = val(ds)
            end if
        end if
        if found.info.plot <> invalid and (type(found.info.plot) = "roString" or type(found.info.plot) = "String") and found.info.plot.len() > 0
            node.description = found.info.plot
        end if
        if found.info.releasedate <> invalid and (type(found.info.releasedate) = "roString" or type(found.info.releasedate) = "String") and found.info.releasedate.len() > 0
            node.releaseDate = found.info.releasedate
        end if
        if found.info.season <> invalid
            s = found.info.season
            if type(s) = "roInt" or type(s) = "roInteger" or type(s) = "Integer"
                ' Ver el comentario en GetEpisodes.brs: "titleSeason" no es
                ' un campo estandar de ContentNode, hay que crearlo con
                ' AddFields() o la asignacion se pierde en silencio.
                node.AddFields({titleSeason: "S" + s.toStr()})
            end if
        end if
    end if

    m.top.result = node
end sub

' "episodes" puede venir como AA con una key por temporada ("1", "2",
' ...) cada una con un roArray de capitulos, o (proveedores raros) ya
' como un roArray plano -- mismo par de formas que ya contempla
' jsonCapitulos() en GetEpisodes.brs, solo que aqui se revisan TODAS
' las temporadas en vez de una sola.
function FindEpisodeInJson(episodes as Object, targetId as String) as Object
    if type(episodes) = "roAssociativeArray"
        for each seasonKey in episodes
            arr = episodes[seasonKey]
            if type(arr) = "roArray"
                for each ej in arr
                    if ej.id <> invalid and ej.id.toStr() = targetId
                        return ej
                    end if
                end for
            end if
        end for
    else if type(episodes) = "roArray"
        for each ej in episodes
            if ej.id <> invalid and ej.id.toStr() = targetId
                return ej
            end if
        end for
    end if
    return invalid
end function

' Copia exacta de cleanEpisodeTitle() en GetEpisodes.brs (ver ahi para
' el detalle del patron "Nombre de Serie - SxxExx - Titulo").
function FE_CleanEpisodeTitle(t as String) as String
    i = 1
    tLen = Len(t)
    while i <= tLen - 6
        if Mid(t, i, 3) = " - "
            rest = Mid(t, i + 3)
            if Len(rest) > 3 and UCase(Left(rest, 1)) = "S"
                j = 2
                while j <= Len(rest) and Mid(rest, j, 1) >= "0" and Mid(rest, j, 1) <= "9"
                    j = j + 1
                end while
                if j > 2 and j <= Len(rest) and UCase(Mid(rest, j, 1)) = "E"
                    k = j + 1
                    while k <= Len(rest) and Mid(rest, k, 1) >= "0" and Mid(rest, k, 1) <= "9"
                        k = k + 1
                    end while
                    if k > j + 1 and Mid(rest, k, 3) = " - "
                        cleaned = Mid(rest, k + 3)
                        if cleaned <> "" then return cleaned
                    end if
                end if
            end if
        end if
        i = i + 1
    end while
    return t
end function
