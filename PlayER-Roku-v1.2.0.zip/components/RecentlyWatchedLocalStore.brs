' ============================================================
' RecentlyWatchedLocalStore.brs
' Fuente de verdad LOCAL para "Recien Vistas" (peliculas + series
' mezcladas, ordenadas por fecha de visto, tope de 18).
' Mismo patron que FavoritesLocalStore.brs, se incluye como
' <script> extra en los componentes/Tasks que lo necesiten
' (junto a generalUtils.brs y FavoritesLocalStore.brs, ya que
' reutiliza Fav_NodeToAA/Fav_AAToNode/Fav_FetchVodInfo/Fav_FetchSerieInfo).
'
' Formato de guardado: roRegistrySection("RecentlyWatched")
'   key   = "rv-<usuario>-<tipo>-<id>"   tipo: "pelicula" | "serie"
'   value = JSON del objeto completo + campos "tipo" y "viewedAt"
'           (epoch en segundos, usado para ordenar y podar)
'
' El <usuario> en la key es el mismo valor que se manda al servidor
' (m.global.user, = user_tv en el registro "datos_tv"). Esto aisla
' el historial de cada cuenta que use el dispositivo: si se
' desvincula y se vincula otra cuenta, UnlinkTask no borra este
' registro, pero como las keys llevan el usuario, la cuenta nueva
' simplemente no ve las keys de la cuenta vieja (quedan huerfanas,
' sin mostrarse nunca, en vez de filtrarse a la cuenta equivocada).
' ============================================================

' Limite de items en "Recien Vistas". Como funcion en vez de Const:
' el rsg_version de este proyecto (1.3) no soporta la palabra clave
' Const en archivos .brs de componentes.
' Devuelve la URL de recientes.php que llego del config.json
' (m.global.urlRecientes, editable desde el panel en "Base de datos").
' Ya no trae ningun link fijo en el codigo.
function RW_ApiBase() as String
    if m.global <> invalid and m.global.urlRecientes <> invalid then
        return m.global.urlRecientes
    end if
    return ""
end function

function RW_Limit() as Integer
    return 20
end function

function RW_Section() as Object
    return CreateObject("roRegistrySection", "RecentlyWatched")
end function

' Usuario Xtream actualmente logueado (m.global.user). Si por algun
' motivo no esta disponible (m.global no expuesto en este scope,
' o aun no se ha logueado), cae a "unknown" en vez de reventar; en
' ese caso simplemente no aislaria nada, pero nunca deberia pasar
' en la practica ya que loadRecentlyWatched()/RegisterRecentlyWatched
' ya validan que haya usuario antes de llamar a estas funciones.
function RW_CurrentUser() as String
    ' Mismo arreglo que WP_CurrentUser: m.global.user puede no estar
    ' poblado todavia justo al reabrir la app ya logueada de antes,
    ' causando una llave distinta ("rv-unknown-...") a la usada
    ' originalmente. Se usa la lectura directa del registro, que ya
    ' esta disponible desde antes en el arranque.
    u = "unknown"
    raw = getStrValFromReg("user_tv", "datos_tv")
    if raw <> invalid and raw <> ""
        u = raw
    else if m.global <> invalid and m.global.user <> invalid and m.global.user <> ""
        u = m.global.user
    end if

    ' Se agrega la variante de servidor actual: el mismo usuario puede
    ' autenticar en mas de un servidor de "serverURLs" (config.json), y
    ' el historial de "recien vistas" (con poster/url) corresponde a
    ' contenido de un servidor especifico -- mismo motivo que
    ' Cat_SafeUsuario en CategoriesLocalStore.brs.
    return u + "-v" + RW_SafeVariante() + "-p" + RW_SafeProfile()
end function

function RW_SafeVariante() as String
    if m.global <> invalid and m.global.serverVariant <> invalid and m.global.serverVariant.toStr() <> ""
        return m.global.serverVariant.toStr()
    end if
    return "0"
end function

' Perfil actual (hasta 5 por cuenta+servidor) -- mismo motivo y patron
' que RW_SafeVariante(): sin esto, todos los perfiles de una cuenta
' compartirian el mismo historial de "recien vistas".
function RW_SafeProfile() as String
    if m.global <> invalid and m.global.profileId <> invalid and m.global.profileId.toStr() <> ""
        return m.global.profileId.toStr()
    end if
    return "0"
end function

function RW_LocalKey(tipo as String, id as String) as String
    return "rv-" + RW_CurrentUser() + "-" + tipo + "-" + id
end function

' ------------------------------------------------------------
' Datos del CAPITULO (no de la serie) que se guardan junto con el
' registro de "Recien Vistos" de una serie, para poder alimentar el
' reproductor DIRECTO desde Home ("Continuar viendo") sin tener que
' volver a buscar el capitulo por red -- esa busqueda por red (un
' Task aparte que revisaba todas las temporadas) a veces no volvia,
' y la pantalla se quedaba trabada sin reproducir nada. Todos estos
' son campos NATIVOS de ContentNode (los mismos que ya llena
' GetEpisodes.brs por cada capitulo), asi que se pueden asignar de
' vuelta a un ContentNode nuevo con un simple setFields(), sin
' necesitar addFields().
' ------------------------------------------------------------
function RW_EpisodeFields() as Object
    return ["id", "title", "episodeNumber", "url", "streamFormat", "contentType", _
            "shortDescriptionLine1", "length", "description", "releaseDate", "titleSeason"]
end function

' Reconstruye el ContentNode del capitulo a partir de la AA guardada
' por RW_EpisodeFields()/Fav_NodeToAA. Deliberadamente NO reusa
' Fav_AAToNode (esa agrega genre/director/episodeRunTime y un poster
' de respaldo, pensados para tarjetas de pelicula/serie -- aqui solo
' hace falta lo minimo para que el reproductor pueda arrancar).
'
' Si el ultimo capitulo se vio por ultima vez en Android, este JSON
' NUNCA trae "url" (Android arma su propia URL con id+ext, ver
' EpisodeCache en LocalModels.kt -- Android manda id/title/ext, no
' url). Sin esto, playRWSerieDirect() se rendia y mandaba a la lista
' de capitulos en vez de reproducir directo. Se arma la URL con la
' MISMA formula que ya usa GetEpisodes.brs para cualquier capitulo
' normal (serverURL + play + id + "." + ext), usando "ext" si vino
' (Android) o derivandola de streamFormat si no.
function RW_EpisodeAAToNode(aa as Object) as Object
    node = CreateObject("roSGNode", "ContentNode")
    if aa <> invalid and type(aa) = "roAssociativeArray" then
        node.setFields(aa)
        ' "titleSeason" NO es un campo estandar de ContentNode -- setFields()
        ' (igual que la notacion de punto) se queda sin efecto en silencio
        ' para campos que el nodo no tiene ya definidos. Sin esto, un
        ' capitulo reconstruido aqui (para "Continuar viendo" desde Recien
        ' Vistas) SIEMPRE perdia su temporada, y Seasons.brs/playDirectEpisode
        ' nunca podia cargar la lista de capitulos en segundo plano -- por
        ' eso arriba/abajo, el aviso de "siguiente capitulo", y el avance
        ' automatico al terminar se quedaban sin funcionar en ese flujo.
        if aa.titleSeason <> invalid and aa.titleSeason <> ""
            node.AddFields({titleSeason: aa.titleSeason})
        end if
        if (node.url = invalid or node.url = "") and aa.id <> invalid and aa.id.toStr() <> ""
            ext = ""
            if aa.ext <> invalid and aa.ext.toStr() <> "" then
                ext = LCase(aa.ext.toStr())
            else if aa.streamFormat <> invalid
                sf = aa.streamFormat.toStr()
                if sf = "hls" then ext = "m3u8"
                if sf = "mpeg-dash" then ext = "mpd"
                if sf = "mkv" then ext = "mkv"
            end if
            ' Mismo respaldo por defecto que ya usa Android
            ' (XtreamClient.seriesStreamUrl) cuando no se conoce la
            ' extension real: "ts", no "mp4".
            if ext = "" then ext = "ts"
            if m.global <> invalid and m.global.serverURL <> invalid and m.global.play <> invalid and m.global.serverURL <> "" and m.global.play <> ""
                node.url = m.global.serverURL + m.global.play + aa.id.toStr() + "." + ext
                if ext = "m3u8" then
                    node.streamFormat = "hls"
                else if ext = "mpd" then
                    node.streamFormat = "mpeg-dash"
                else if ext = "mkv" then
                    node.streamFormat = "mkv"
                end if
            end if
        end if
    end if
    return node
end function

function RW_LocalRead(tipo as String, id as String) as Object
    sec = RW_Section()
    raw = sec.Read(RW_LocalKey(tipo, id))
    if raw = invalid or raw = "" then return invalid
    parsed = ParseJSON(raw)
    if parsed = invalid or type(parsed) <> "roAssociativeArray" then return invalid
    return parsed
end function

' Escribe/actualiza un item como "recien visto" y marca viewedAt = ahora.
' Si el item ya existia, su fecha se refresca (sube al tope al ordenar).
' Despues de escribir, poda la lista local al limite (RW_Limit()).
sub RW_LocalWrite(tipo as String, id as String, dataAA as Object)
    if dataAA = invalid then dataAA = {}
    dataAA["tipo"] = tipo
    dataAA["id"] = id
    ' Si ya viene con viewedAt (p.ej. sembrando desde servidor con la
    ' fecha real del "fecha" de MySQL), se respeta esa fecha. Si no,
    ' es un registro nuevo (recien reproducido) y se usa "ahora".
    if dataAA.viewedAt = invalid then dataAA["viewedAt"] = RW_NowEpoch()

    sec = RW_Section()
    sec.Write(RW_LocalKey(tipo, id), FormatJSON(dataAA))
    sec.Flush()

    RW_TrimToLimit(RW_Limit())
end sub

sub RW_LocalDelete(tipo as String, id as String)
    sec = RW_Section()
    sec.Delete(RW_LocalKey(tipo, id))
    sec.Flush()
end sub

' Todos los "recien vistos" locales del usuario ACTUAL (peliculas +
' series mezcladas), sin ordenar. Las keys de otras cuentas que
' hayan usado este mismo dispositivo se ignoran (no se borran, solo
' no se muestran).
function RW_LocalListAll() as Object
    result = []
    sec = RW_Section()
    prefix = "rv-" + RW_CurrentUser() + "-"
    keys = sec.GetKeyList()
    if keys = invalid then return result
    for each key in keys
        if Left(key, Len(prefix)) = prefix
            raw = sec.Read(key)
            if raw <> invalid and raw <> ""
                parsed = ParseJSON(raw)
                if parsed <> invalid and type(parsed) = "roAssociativeArray"
                    result.push(parsed)
                end if
            end if
        end if
    end for
    return result
end function

' Todos los "recien vistos", ordenados por viewedAt DESC (mas reciente
' primero) y recortados al limite indicado (por defecto 20, ver RW_Limit()).
function RW_LocalListAllSorted(limit = 20 as Integer) as Object
    items = RW_LocalListAll()
    if items.count() <= 1 then return items

    ' Insertion sort descendente por viewedAt (misma tecnica que
    ' sortByAdded en HomeContentTask.brs).
    for i = 1 to items.count() - 1
        key = items[i]
        keyTs = RW_ItemTs(key)
        j = i - 1
        while j >= 0 and RW_ItemTs(items[j]) < keyTs
            items[j + 1] = items[j]
            j = j - 1
        end while
        items[j + 1] = key
    end for

    if items.count() > limit
        trimmed = []
        for i = 0 to limit - 1
            trimmed.push(items[i])
        end for
        return trimmed
    end if
    return items
end function

function RW_ItemTs(item as Object) as Integer
    if item = invalid or item.viewedAt = invalid then return 0
    v = item.viewedAt
    if type(v) = "roString" or type(v) = "String" then return val(v)
    return v
end function

' true si el usuario actual NO tiene ningun "recien visto" local
' guardado (senal para decidir si hace falta ir al servidor a sembrar).
function RW_LocalIsEmpty() as Boolean
    sec = RW_Section()
    prefix = "rv-" + RW_CurrentUser() + "-"
    keys = sec.GetKeyList()
    if keys = invalid then return true
    for each key in keys
        if Left(key, Len(prefix)) = prefix then return false
    end for
    return true
end function

' Poda el local al limite indicado: si hay mas de N, borra los mas
' viejos hasta quedar exactamente en N. Se llama automaticamente
' despues de cada RW_LocalWrite para que el registro no crezca sin
' limite (a diferencia de favoritos, aqui se escribe en CADA
' reproduccion, no solo cuando el usuario lo pide a mano).
sub RW_TrimToLimit(limit as Integer)
    sorted = RW_LocalListAllSorted(999999)
    if sorted.count() <= limit then return
    sec = RW_Section()
    for i = limit to sorted.count() - 1
        old = sorted[i]
        if old.tipo <> invalid and old.id <> invalid
            sec.Delete(RW_LocalKey(old.tipo, old.id))
        end if
    end for
    sec.Flush()
end sub

' Borra TODO el historial local de "recien vistos". Usar al
' desvincular el dispositivo, para no heredar historial del usuario
' anterior (mismo criterio que Fav_LocalClearAll).
' Borra TODO el historial local de "recien vistos" de TODAS las
' cuentas guardadas en este dispositivo (no solo la actual). Ya no
' es necesario llamarlo al desvincular para el aislamiento entre
' cuentas (las keys llevan el usuario, se aislan solas), pero queda
' disponible como "borrado total" si alguna vez hace falta limpiar
' el registro completo (p.ej. un boton de "Restablecer" en Ajustes).
sub RW_LocalClearAll()
    sec = RW_Section()
    keys = sec.GetKeyList()
    if keys = invalid then return
    for each key in keys
        sec.Delete(key)
    end for
    sec.Flush()
end sub

function RW_NowEpoch() as Integer
    return CreateObject("roDateTime").AsSeconds()
end function

' Convierte un datetime de MySQL ("YYYY-MM-DD HH:MM:SS", como lo
' manda recientes.php) a epoch. Si no se puede parsear, devuelve 0
' (el item cae al final al ordenar, no rompe nada).
function RW_MysqlDateToEpoch(mysqlDate as String) as Integer
    if mysqlDate = invalid or mysqlDate = "" then return 0
    iso = mysqlDate.Replace(" ", "T") + "Z"
    dt = CreateObject("roDateTime")
    ' FromISO8601String no devuelve valor (es Void) en esta version de
    ' BrightScript, asi que no se puede leer un "ok" de su retorno.
    ' Si el parseo falla, roDateTime se queda en su valor por defecto
    ' (epoch 0 / fecha actual segun plataforma); para no meter un
    ' timestamp basura al ordenar, se valida el AsSeconds() resultante.
    dt.FromISO8601String(iso)
    secs = dt.AsSeconds()
    if secs = invalid or secs <= 0 then return 0
    return secs
end function

' ------------------------------------------------------------
' Resolucion completa desde servidor (solo se usa para SEMBRAR
' el local cuando esta vacio, no en el uso normal). Reutiliza
' Fav_FetchVodInfo / Fav_FetchSerieInfo de FavoritesLocalStore.brs,
' que ya resuelven un id a un AA completo pintable.
' ------------------------------------------------------------
sub RW_SeedFromServer(usuario as String, su as String, u as String, p as String)
    baseUrl = RW_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=list&user=" + usuario + "&variante=" + RW_SafeVariante() + "&perfil=" + RW_SafeProfile())
    listData = ParseJSON(request.GetToString())
    if listData = invalid or type(listData) <> "roArray" then return

    for each row in listData
        if type(row) = "roAssociativeArray" and row.cve <> invalid and row.tipo <> invalid
            rawId = row.cve.toStr()
            tipo = row.tipo

            info = invalid
            if tipo = "serie"
                info = Fav_FetchSerieInfo(rawId, su, u, p)
            else
                info = Fav_FetchVodInfo(rawId, su, u, p)
            end if

            if info <> invalid
                if row.fecha <> invalid
                    info["viewedAt"] = RW_MysqlDateToEpoch(row.fecha.toStr())
                end if
                RW_LocalWrite(tipo, rawId, info)
            end if
        end if
    end for
end sub

' ============================================================
' SINCRONIZACION ENTRE DISPOSITIVOS ("changes" incremental)
' Mismo patron que Fav_SyncFromServer/Fav_ReconcileLocalToServer
' en FavoritesLocalStore.brs, adaptado a que "Recien Vistas" tiene
' un tope de 18 y va podando lo viejo (la poda tambien se sincroniza:
' si algo salio del top 18 en el servidor, sale en todos lados).
' ============================================================

function RW_SyncSection() as Object
    return CreateObject("roRegistrySection", "RWSync")
end function

function RW_GetLastSync(usuario as String) as Integer
    sec = RW_SyncSection()
    raw = sec.Read(usuario)
    if raw = invalid or raw = "" then return 0
    return raw.toInt()
end function

sub RW_SetLastSync(usuario as String, epoch as Integer)
    sec = RW_SyncSection()
    sec.Write(usuario, epoch.toStr())
    sec.Flush()
end sub

' Baja lo que cambio desde la ultima sincronizacion (altas y podas/
' borrados) y lo aplica al local. Igual que en favoritos: si un id
' falla al resolver, no se pierde -- se reintenta hasta 3 veces y
' despues se deja de insistir (sin bloquear el cursor de los demas).
' Se llama SIEMPRE que se carga "Recien Vistas", no solo si el local
' esta vacio.
' true si ya tenemos guardado localmente (con el tipo reportado por
' el servidor) un titulo real para este id -- no vacio y no el
' marcador generico. Evita pisar un dato bueno ya capturado de la
' pantalla (RegisterRecentlyWatched) con un fetch nuevo a
' get_vod_info/get_series_info que puede venir incompleto.
function RW_LocalHasValidTitle(tipo as String, id as String) as Boolean
    aa = RW_LocalRead(tipo, id)
    if aa = invalid then return false
    if aa.title = invalid or aa.title = "" or aa.title = "Contenido no disponible" then return false
    return true
end function

' Ni el catalogo/panel (via resolver.php o el metodo viejo) resolvio
' este item. Si nuestro propio servidor YA tenia el titulo guardado,
' se deja un marcador visible con ese titulo (mejor que dejarlo
' invisible). Si ni eso, se cuenta el intento y, a los 3 fallidos, se
' deja de reintentar para siempre (mismo criterio que ya tenia esta
' funcion antes de agrupar las peticiones). Regresa false si hay que
' reintentar en la siguiente sincronizacion (no avanzar el cursor).
function RW_HandleUnresolvedItem(tipo as String, rawId as String, rowTitulo as String, rowFecha as Dynamic, finalLastEp as Dynamic, finalLastEpData as Dynamic, giveUpSec as Object) as Boolean
    if rowTitulo <> ""
        placeholder = {
            id: rawId,
            title: rowTitulo,
            HDPosterUrl: "pkg:/images/no-poster.jpg"
        }
        if rowFecha <> invalid then placeholder["viewedAt"] = rowFecha.toStr().toInt()
        if finalLastEp <> invalid then placeholder["lastEpisodeId"] = finalLastEp
        if finalLastEpData <> invalid then placeholder["lastEpisodeData"] = finalLastEpData
        RW_LocalWrite(tipo, rawId, placeholder)
        giveUpSec.Delete("failcount-" + rawId)
        return true
    end if

    MAX_RETRIES = 3
    failKey = "failcount-" + rawId
    failCountRaw = giveUpSec.Read(failKey)
    failCount = 0
    if failCountRaw <> invalid and failCountRaw <> "" then failCount = failCountRaw.toInt()
    failCount = failCount + 1

    if failCount >= MAX_RETRIES
        giveUpKey = "giveup-" + rawId
        giveUpSec.Write(giveUpKey, "1")
        giveUpSec.Delete(failKey)
        giveUpSec.Flush()
        print "DEBUG RW_SyncFromServer - id="; rawId; " fallo "; failCount; " veces, se deja de reintentar"
        return true
    else
        giveUpSec.Write(failKey, failCount.toStr())
        giveUpSec.Flush()
        print "DEBUG RW_SyncFromServer - no se pudo resolver id="; rawId; " (intento "; failCount; " de "; MAX_RETRIES; "), se reintentara despues"
        return false
    end if
end function

sub RW_SyncFromServer(usuario as String, su as String, u as String, p as String)
    ' El cursor de sincronizacion tiene que ser uno POR PERFIL (y por
    ' servidor) -- antes se compartia entre los hasta 5 perfiles de la
    ' cuenta, asi que sincronizar un perfil adelantaba el cursor de
    ' todos los demas, y los "recien vistos" mas viejos de otro perfil
    ' (con fecha anterior al cursor ya avanzado) dejaban de traerse. Se
    ' usa esta misma clave (en vez de "usuario" a secas) tanto para el
    ' cursor como para la bandera de migracion de abajo.
    syncKey = usuario + "-v" + RW_SafeVariante() + "-p" + RW_SafeProfile()

    ' --- MIGRACION UNICA (recuperacion) ---
    ' Mismo mecanismo que ya se aplico en Favoritos: se fuerza UN
    ' resync completo (since=0) la primera vez que corre esta version,
    ' por si el cursor se quedo atorado en algun punto (de pruebas
    ' viejas, cambios de throttle, etc.) y nunca mas se recuperaban
    ' items reales que si estan en el servidor. Despues de esta unica
    ' vez, no se vuelve a repetir (bandera en el registro). v2: la
    ' bandera (y el cursor) ahora se guardan por perfil+servidor
    ' (syncKey), no solo por usuario -- antes un perfil marcaba la
    ' migracion como hecha para TODA la cuenta, asi que un perfil nuevo
    ' nunca disparaba su propio resync completo. Tambien fuerza a todos
    ' a recuperarse una vez mas ahora que el panel dejo de mezclar
    ' perfiles distintos (ver recientes.php: "perfil" ya no acepta el
    ' legado '0').
    migFlagKey = "migrated-fullresync-v2-" + syncKey
    migSec = RW_SyncSection()
    migFlagVal = migSec.Read(migFlagKey)
    if migFlagVal = invalid or migFlagVal = ""
        print "DEBUG RW_SyncFromServer - migracion unica: reseteando cursor para recuperar recien vistos perdidos"
        RW_SetLastSync(syncKey, 0)
        migSec.Write(migFlagKey, "1")
        migSec.Flush()
    end if

    since = RW_GetLastSync(syncKey)

    baseUrl = RW_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=changes&user=" + usuario + "&since=" + since.toStr() + "&variante=" + RW_SafeVariante() + "&perfil=" + RW_SafeProfile())
    resp = ParseJSON(request.GetToString())
    if resp = invalid or type(resp) <> "roAssociativeArray" or resp.rows = invalid then return

    allResolvedOk = true
    giveUpSec = RW_SyncSection()
    ' Igual que en Favoritos: lo que no se pueda dar por valido local
    ' se apunta aqui (separado por tipo, porque aqui el tipo SI se
    ' conoce con certeza desde el servidor) para resolverlo todo junto
    ' despues de este for, en vez de una peticion por item.
    pendingMovies = []
    pendingSeries = []

    for each row in resp.rows
        if type(row) = "roAssociativeArray" and row.cve <> invalid
            rawId = row.cve.toStr()
            tipo = row.tipo
            if tipo = invalid or tipo = "" then tipo = "pelicula"
            isDeleted = (row.deleted <> invalid and row.deleted.toStr() <> "0")

            if isDeleted
                RW_LocalDelete(tipo, rawId)
            else
                if RW_LocalHasValidTitle(tipo, rawId)
                    ' Ya tenemos un titulo valido guardado local. No lo
                    ' pisamos con un fetch nuevo que puede venir incompleto.
                    ' Si a este registro le falta lastEpisodeId (se creo
                    ' antes de que el servidor guardara ese dato) pero el
                    ' servidor ya lo tiene ahora, se rellena nada mas ese
                    ' campo sin tocar el resto. Mismo criterio para
                    ' lastEpisodeData (los datos completos del capitulo
                    ' para "Continuar viendo" directo, ver
                    ' Seasons.brs/registerRecentlyWatched y
                    ' HomeScreen.brs/playRWSerieDirect) -- si a este
                    ' dispositivo le falta y el servidor ya lo tiene
                    ' (porque otro dispositivo vio esta serie), se rellena
                    ' aqui tambien.
                    existingLocal = invalid
                    localChanged = false
                    if row.lastEpisodeId <> invalid and row.lastEpisodeId.toStr().trim() <> ""
                        existingLocal = RW_LocalRead(tipo, rawId)
                        if existingLocal <> invalid and (existingLocal.lastEpisodeId = invalid or existingLocal.lastEpisodeId = "")
                            existingLocal["lastEpisodeId"] = row.lastEpisodeId.toStr().trim()
                            localChanged = true
                        end if
                    end if
                    if row.lastEpisodeData <> invalid and row.lastEpisodeData.toStr().trim() <> ""
                        if existingLocal = invalid then existingLocal = RW_LocalRead(tipo, rawId)
                        if existingLocal <> invalid and (existingLocal.lastEpisodeData = invalid or existingLocal.lastEpisodeData = "")
                            existingLocal["lastEpisodeData"] = row.lastEpisodeData.toStr()
                            localChanged = true
                        end if
                    end if
                    if localChanged and existingLocal <> invalid
                        RW_LocalWrite(tipo, rawId, existingLocal)
                    end if
                    giveUpSec.Delete("failcount-" + rawId)
                else
                rowTitulo = ""
                if row.titulo <> invalid then rowTitulo = row.titulo.toStr().trim()
                print "DEBUG RWSYNC - rawId="; rawId; " tipo="; tipo; " row.titulo(crudo)="; row.titulo; " rowTitulo="; rowTitulo

                giveUpKey = "giveup-" + rawId
                alreadyGaveUp = (giveUpSec.Read(giveUpKey) <> invalid and giveUpSec.Read(giveUpKey) <> "")

                if not alreadyGaveUp
                    ' El lastEpisodeId (que capitulo fue el ultimo visto)
                    ' ahora si se guarda en el servidor (columna
                    ' last_episode_id en recientes.php) -- asi un
                    ' dispositivo nuevo, sin nada local, tambien puede
                    ' saber cual capitulo mostrar en la barra de avance.
                    ' Si el servidor todavia no lo tiene (filas viejas,
                    ' antes de este cambio), se cae al que ya hubiera
                    ' local para no perder lo que ya funcionaba.
                    rowLastEp = ""
                    if row.lastEpisodeId <> invalid then rowLastEp = row.lastEpisodeId.toStr().trim()
                    finalLastEp = invalid
                    existingLocal = invalid
                    if rowLastEp <> ""
                        finalLastEp = rowLastEp
                    else
                        existingLocal = RW_LocalRead(tipo, rawId)
                        if existingLocal <> invalid and existingLocal.lastEpisodeId <> invalid and existingLocal.lastEpisodeId <> ""
                            finalLastEp = existingLocal.lastEpisodeId
                        end if
                    end if

                    ' Mismo criterio que finalLastEp, pero para el JSON
                    ' completo del capitulo (lastEpisodeData), asi el
                    ' "Continuar viendo" directo tambien funciona cuando
                    ' este item se tuvo que resolver por resolver.php/metodo
                    ' viejo (no tenia titulo valido local todavia).
                    rowLastEpData = ""
                    if row.lastEpisodeData <> invalid then rowLastEpData = row.lastEpisodeData.toStr().trim()
                    finalLastEpData = invalid
                    if rowLastEpData <> ""
                        finalLastEpData = rowLastEpData
                    else
                        if existingLocal = invalid then existingLocal = RW_LocalRead(tipo, rawId)
                        if existingLocal <> invalid and existingLocal.lastEpisodeData <> invalid and existingLocal.lastEpisodeData <> ""
                            finalLastEpData = existingLocal.lastEpisodeData
                        end if
                    end if

                    pendEntry = { id: rawId, titulo: rowTitulo, fecha: row.fecha, lastEp: finalLastEp, lastEpData: finalLastEpData }
                    if tipo = "serie"
                        pendingSeries.push(pendEntry)
                    else
                        pendingMovies.push(pendEntry)
                    end if
                end if
                end if
            end if
        end if
    end for

    ' --- Resolver TODO lo pendiente, en lote (via resolver.php) si
    ' esta configurado; si no, cae al metodo viejo (uno por uno). ---
    if pendingMovies.count() > 0 or pendingSeries.count() > 0
        if Fav_ResolverApiBase() <> ""
            if pendingMovies.count() > 0
                idsM = []
                for each pm in pendingMovies
                    idsM.push(pm.id)
                end for
                batchM = Fav_ResolveIdsBatch(idsM, "2", su, u, p)
                byIdM = {}
                for each mv in batchM
                    mvId = ""
                    if mv.stream_id <> invalid then mvId = mv.stream_id.toStr()
                    if mvId <> "" then byIdM[mvId] = mv
                end for
                for each pm in pendingMovies
                    if byIdM.DoesExist(pm.id)
                        aa = Fav_BuildAAFromBulkItem(byIdM[pm.id], "pelicula", su, u, p)
                        if pm.titulo <> "" then aa["title"] = pm.titulo
                        if pm.fecha <> invalid then aa["viewedAt"] = pm.fecha.toStr().toInt()
                        if pm.lastEp <> invalid then aa["lastEpisodeId"] = pm.lastEp
                        if pm.lastEpData <> invalid then aa["lastEpisodeData"] = pm.lastEpData
                        RW_LocalWrite("pelicula", pm.id, aa)
                        giveUpSec.Delete("failcount-" + pm.id)
                    else
                        ' No aparecio en el lote de resolver.php: se
                        ' intenta con el metodo directo de siempre antes
                        ' de darlo por perdido, para que un resolver.php
                        ' roto o mal configurado nunca deje peor los
                        ' recien vistos de lo que ya estaban.
                        info = Fav_FetchVodInfo(pm.id, su, u, p)
                        if info <> invalid
                            if pm.titulo <> "" then info["title"] = pm.titulo
                            if pm.fecha <> invalid then info["viewedAt"] = pm.fecha.toStr().toInt()
                            if pm.lastEp <> invalid then info["lastEpisodeId"] = pm.lastEp
                            if pm.lastEpData <> invalid then info["lastEpisodeData"] = pm.lastEpData
                            RW_LocalWrite("pelicula", pm.id, info)
                            giveUpSec.Delete("failcount-" + pm.id)
                        else
                            allResolvedOk = allResolvedOk and RW_HandleUnresolvedItem("pelicula", pm.id, pm.titulo, pm.fecha, pm.lastEp, pm.lastEpData, giveUpSec)
                        end if
                    end if
                end for
            end if

            if pendingSeries.count() > 0
                idsS = []
                for each ps in pendingSeries
                    idsS.push(ps.id)
                end for
                batchS = Fav_ResolveIdsBatch(idsS, "3", su, u, p)
                byIdS = {}
                for each sr in batchS
                    srId = ""
                    if sr.series_id <> invalid then srId = sr.series_id.toStr()
                    if srId <> "" then byIdS[srId] = sr
                end for
                for each ps in pendingSeries
                    if byIdS.DoesExist(ps.id)
                        aa = Fav_BuildAAFromBulkItem(byIdS[ps.id], "serie", su, u, p)
                        if ps.titulo <> "" then aa["title"] = ps.titulo
                        if ps.fecha <> invalid then aa["viewedAt"] = ps.fecha.toStr().toInt()
                        if ps.lastEp <> invalid then aa["lastEpisodeId"] = ps.lastEp
                        if ps.lastEpData <> invalid then aa["lastEpisodeData"] = ps.lastEpData
                        RW_LocalWrite("serie", ps.id, aa)
                        giveUpSec.Delete("failcount-" + ps.id)
                    else
                        info = Fav_FetchSerieInfo(ps.id, su, u, p)
                        if info <> invalid
                            if ps.titulo <> "" then info["title"] = ps.titulo
                            if ps.fecha <> invalid then info["viewedAt"] = ps.fecha.toStr().toInt()
                            if ps.lastEp <> invalid then info["lastEpisodeId"] = ps.lastEp
                            if ps.lastEpData <> invalid then info["lastEpisodeData"] = ps.lastEpData
                            RW_LocalWrite("serie", ps.id, info)
                            giveUpSec.Delete("failcount-" + ps.id)
                        else
                            allResolvedOk = allResolvedOk and RW_HandleUnresolvedItem("serie", ps.id, ps.titulo, ps.fecha, ps.lastEp, ps.lastEpData, giveUpSec)
                        end if
                    end if
                end for
            end if
        else
            ' resolver.php no configurado todavia: metodo viejo, uno
            ' por uno (identico al que ya habia antes de este cambio).
            for each pm in pendingMovies
                info = Fav_FetchVodInfo(pm.id, su, u, p)
                if info <> invalid
                    if pm.titulo <> "" then info["title"] = pm.titulo
                    if pm.fecha <> invalid then info["viewedAt"] = pm.fecha.toStr().toInt()
                    if pm.lastEp <> invalid then info["lastEpisodeId"] = pm.lastEp
                    if pm.lastEpData <> invalid then info["lastEpisodeData"] = pm.lastEpData
                    RW_LocalWrite("pelicula", pm.id, info)
                    giveUpSec.Delete("failcount-" + pm.id)
                else
                    allResolvedOk = allResolvedOk and RW_HandleUnresolvedItem("pelicula", pm.id, pm.titulo, pm.fecha, pm.lastEp, pm.lastEpData, giveUpSec)
                end if
            end for
            for each ps in pendingSeries
                info = Fav_FetchSerieInfo(ps.id, su, u, p)
                if info <> invalid
                    if ps.titulo <> "" then info["title"] = ps.titulo
                    if ps.fecha <> invalid then info["viewedAt"] = ps.fecha.toStr().toInt()
                    if ps.lastEp <> invalid then info["lastEpisodeId"] = ps.lastEp
                    if ps.lastEpData <> invalid then info["lastEpisodeData"] = ps.lastEpData
                    RW_LocalWrite("serie", ps.id, info)
                    giveUpSec.Delete("failcount-" + ps.id)
                else
                    allResolvedOk = allResolvedOk and RW_HandleUnresolvedItem("serie", ps.id, ps.titulo, ps.fecha, ps.lastEp, ps.lastEpData, giveUpSec)
                end if
            end for
        end if
    end if

    if allResolvedOk and resp.serverNow <> invalid
        RW_SetLastSync(syncKey, resp.serverNow.toStr().toInt())
    end if

    ' --- RECONCILIACION LOCAL -> SERVIDOR ---
    ' Si el local tiene "recien vistos" que el servidor no reporta
    ' (servidor perdio datos, o una alta anterior no se guardo por
    ' una falla de red), se vuelven a subir.
    RW_ReconcileLocalToServer(usuario)
end sub

sub RW_ReconcileLocalToServer(usuario as String)
    baseUrl = RW_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=list&user=" + usuario + "&variante=" + RW_SafeVariante() + "&perfil=" + RW_SafeProfile())
    serverList = ParseJSON(request.GetToString())
    if serverList = invalid or type(serverList) <> "roArray" then return

    serverIds = {}
    for each row in serverList
        if type(row) = "roAssociativeArray" and row.cve <> invalid
            serverIds[row.cve.toStr()] = true
        end if
    end for

    localItems = RW_LocalListAll()
    for each item in localItems
        if item.id <> invalid and item.tipo <> invalid and not serverIds.doesExist(item.id.toStr())
            RW_PushToServer(usuario, item.id.toStr(), item.tipo, item)
        end if
    end for
end sub

' item (opcional) es la AA local completa, para que al re-subir un
' "recien visto" que el servidor no tenia (perdio datos, o fallo de
' red en la subida original) no se pierdan el titulo ni los datos del
' ultimo capitulo (lastEpisodeId/lastEpisodeData) que ya se tenian
' localmente -- mismos campos que ya manda RegisterRecentlyWatched.
sub RW_PushToServer(usuario as String, cve as String, tipo as String, item = invalid as Object)
    baseUrl = RW_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")

    tituloParam = ""
    lastEpParam = ""
    lastEpDataParam = ""
    if item <> invalid
        if item.title <> invalid and item.title <> "" then tituloParam = GU_UrlEncode(item.title.toStr())
        if item.lastEpisodeId <> invalid and item.lastEpisodeId <> "" then lastEpParam = item.lastEpisodeId.toStr()
        if item.lastEpisodeData <> invalid and item.lastEpisodeData <> "" then lastEpDataParam = GU_UrlEncode(item.lastEpisodeData.toStr())
    end if

    request.SetUrl(baseUrl + "?action=a&user=" + usuario + "&cve=" + cve + "&tipo=" + tipo + "&titulo=" + tituloParam + "&lastEpisodeId=" + lastEpParam + "&lastEpisodeData=" + lastEpDataParam + "&variante=" + RW_SafeVariante() + "&perfil=" + RW_SafeProfile())
    request.GetToString()
    print "DEBUG RW_ReconcileLocalToServer - re-subido al servidor: tipo="; tipo; " cve="; cve
end sub
