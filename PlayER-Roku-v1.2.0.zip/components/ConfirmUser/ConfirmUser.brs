sub init() 
    m.top.functionName = "go"

end sub

sub go()
    dt = CreateObject("roDateTime")
    
    ' Comprobar el usuario con la URL que funcione
    todobien = comprueba_usuario()
    
    if todobien.message <> invalid then m.top.message = todobien.message else m.top.message = ""
    if todobien.status <> invalid then m.top.status = todobien.status else m.top.status = ""
    if todobien.auth <> invalid then m.top.auth = todobien.auth.toStr() else m.top.auth = "0"
    if todobien.max_connections <> invalid then m.top.max_connections = todobien.max_connections.toStr() else m.top.max_connections = ""
    if todobien.active_cons <> invalid then m.top.active_cons = todobien.active_cons.toStr() else m.top.active_cons = ""
    if todobien.username <> invalid then m.global.user = todobien.username
    if todobien.password <> invalid then m.global.pass = todobien.password

    if todobien.exp_date <> invalid and todobien.exp_date <> "" and todobien.exp_date <> "0"
        RegWrite("exp_date", todobien.exp_date.toStr(), "IPTV_PC")
        dt.fromSeconds(todobien.exp_date.toInt())
        m.global.expire = dt.AsDateStringNoParam()
    end if

    if m.top.status = "Banned" then
        'delStrValToReg("user_tv", "datos_tv")
        'delStrValToReg("pass_tv", "datos_tv")
    end if
end sub

function UrlEncode(s as dynamic) as string
    t = CreateObject("roUrlTransfer")
    return t.Escape(s)
end function

function comprueba_usuario() As Object
    user = getStrValFromReg("user_tv", "datos_tv")
    pass = getStrValFromReg("pass_tv", "datos_tv") 
    if user = "" and pass = "" then
        user = "empty"
        pass = "empty" 
    end if

    ' --- MODO DEMO ---
    ' Si el usuario escribe exactamente "demo"/"demo", no se toca el
    ' servidor Xtream real para nada: se marca m.global.serverURL como
    ' "DEMO" (EpgGetContent.brs revisa esto y sirve un canal de prueba
    ' publico en vez de pedirle canales al proveedor). Cualquier otra
    ' combinacion de usuario/contraseña sigue el flujo normal de abajo.
    if user = "demo" and pass = "demo"
        print "DEBUG comprueba_usuario - modo DEMO activado"
        m.global.serverURL = "DEMO"
        m.global.serverVariant = "demo"
        demoResponse = {}
        demoResponse.auth = "1"
        demoResponse.username = "demo"
        demoResponse.password = "demo"
        demoResponse.status = "Active"
        demoResponse.exp_date = ""
        demoResponse.max_connections = "1"
        demoResponse.active_cons = "0"
        return demoResponse
    end if

    ' Obtener los serverURLs desde una URL remota
    serverURLs = obtenerServerURLsRemotos()

    print "Server URLs: "; serverURLs

    ' ============================================================
    ' "Variante pegajosa" (mismo criterio que ya usa Android en
    ' SplashActivity.attemptAutoLoginOrGoToLogin): la variante de ESTE
    ' servidor se calcula por POSICION dentro de "serverURLs" (ver
    ' NormalizeServerList en generalUtils.brs) cuando el panel no manda
    ' un campo "variante" explicito por servidor. El problema: antes,
    ' Roku recalculaba esa posicion DESDE CERO en cada apertura de la
    ' app, asi que si el panel alguna vez reordena/agrega/quita un
    ' servidor de "serverURLs", el MISMO servidor de siempre le toca
    ' con una variante distinta a partir de ese momento -- y como
    ' favoritos/recientes/progreso/perfiles quedan guardados con la
    ' variante de cuando se creo cada fila, esto separa (sin que se
    ' note) los datos de este dispositivo de los que ya tenia antes, y
    ' de los que use cualquier OTRO dispositivo (ej. Android) que SI
    ' haya quedado "pegado" a la variante original por venir de una
    ' sesion guardada. Sintoma exacto: "lo que hago en un dispositivo
    ' no aparece en el otro" aun con la cuenta/perfil correctos.
    '
    ' Arreglo: igual que Android, se prueba PRIMERO el servidor+variante
    ' de la ULTIMA sesion exitosa (guardado en el registro), y solo si
    ' ese ya no responde/autentica se recurre a la lista fresca de
    ' config.json. Asi la variante de un servidor que sigue activo se
    ' queda fija para siempre en este dispositivo, sin importar que el
    ' panel reordene su lista -- mismo comportamiento, mismo resultado,
    ' en Android y en Roku.
    ' ============================================================
    ' MIGRACION UNICA: la primera version de esta "variante pegajosa"
    ' se instalo ANTES de corregir manifest/panel_url (que todavia
    ' apuntaba a la carpeta vieja "Appmiavision" en vez de
    ' "Appmiaevolution"), asi que a quien ya haya abierto la app una
    ' vez con esa version le pudo quedar guardada una variante SACADA
    ' del config.json VIEJO -- y con el "pegajoso" a secas, eso se
    ' quedaria fijo para siempre aunque panel_url ya este bien. Se
    ' limpia una sola vez para forzar un escaneo fresco (ya contra la
    ' carpeta correcta) la proxima vez que esto corra.
    if getStrValFromReg("sticky_variant_reset_v2", "datos_tv") = ""
        delStrValToReg("server_tv", "datos_tv")
        delStrValToReg("variante_tv", "datos_tv")
        saveStrValToReg("sticky_variant_reset_v2", "1", "datos_tv")
    end if

    savedUrl     = getStrValFromReg("server_tv", "datos_tv")
    savedVariant = getStrValFromReg("variante_tv", "datos_tv")

    candidates = []
    if savedUrl <> ""
        v = "0"
        if savedVariant <> "" then v = savedVariant
        candidates.push({ variante: v, url: savedUrl })
    end if
    for each srv in serverURLs
        yaEsta = false
        for each c in candidates
            if c.url = srv.url then yaEsta = true
        end for
        if not yaEsta then candidates.push(srv)
    end for

    response = {}
    serverConnected = false

    ' Intentar cada servidor y parar al primero que autentica correctamente
    for each srv in candidates
        url = srv.url
        urlToCheck = url + "/player_api.php?username=" + UrlEncode(user) + "&password=" + UrlEncode(pass)
        print "Intentando conectar a: "; urlToCheck
        data = requestData(urlToCheck)

        if data <> invalid and data <> ""
            json = ParseJSON(data)

            if json <> invalid and json.user_info <> invalid
                ' Solo aceptar si auth = 1 (usuario válido en este servidor)
                authVal = json.user_info.auth
                if authVal <> invalid and authVal.toStr() = "1"
                    response = json.user_info
                    m.global.serverURL = url
                    ' Variante (1,2,3...) del servidor que autentico,
                    ' independiente de su URL -- ver NormalizeServerList en
                    ' generalUtils.brs. Aisla el cache local por servidor.
                    m.global.serverVariant = srv.variante
                    serverConnected = true
                    print "Servidor correcto encontrado: "; url
                    ' Se guarda para que la PROXIMA apertura pruebe este
                    ' mismo servidor+variante primero (ver comentario de
                    ' "variante pegajosa" arriba).
                    saveStrValToReg("server_tv", url, "datos_tv")
                    saveStrValToReg("variante_tv", srv.variante, "datos_tv")
                    exit for  ' Parar al primer servidor que autentica correctamente
                else
                    print "Servidor responde pero usuario no autenticado: "; url
                end if
            else
                print "No se pudo obtener info valida de: "; url
            end if
        else
            print "No se pudo conectar a: "; url
        end if
    next

    if serverConnected
        return response
    else
        print "No se pudo autenticar en ningun servidor"
        return {}
    end if
end function

' Función para obtener los serverURLs desde una fuente remota
function obtenerServerURLsRemotos() As Object
    url = m.global.panelURL + "/config.json"
    request = CreateObject("roUrlTransfer")
    request.SetUrl(url)

    if LCase(Left(url, 6)) = "https:" then
        request.SetCertificatesFile("common:/certs/ca-bundle.crt")
        request.InitClientCertificates()
        request.EnableHostVerification(true)
        request.EnablePeerVerification(true)
    end if
    
    data = request.GetToString()
    
    print "Respuesta de la URL remota: "; data
    
    if data <> invalid and data <> ""
        json = ParseJSON(data)
        if json <> invalid and json.serverURLs <> invalid
            print "Server URLs recibidas: "; json.serverURLs
            return NormalizeServerList(json.serverURLs)
        else
            print "No valid serverURLs list found in response."
            return []
        end if
    else
        print "Error: Response is empty or could not be retrieved."
        return []
    end if
end function
