sub init()
  'print "GetContent.brs - [init]"
  m.top.functionName = "go"
end sub

sub go()
    categoriesContent = createObject("roSGNode", "ContentNode")
    itemsContent = createObject("roSGNode", "ContentNode")

    categories = getCategories()

    if categories <> invalid and categories.count() > 0 then
        for each cat in categories
            newCat = categoriesContent.createChild("ContentNode")
            newCat.id = cat.category_id
            newCat.title = cat.category_name
        end for
    end if

    m.top.categories = categories

    if m.top.cat <> "" then
        getItemsJson(itemsContent, m.top.cat)
        RegWrite(m.global.catGet, m.top.cat, "CatID")

    else if RegRead(m.global.catGet, "CatID") <> invalid and RegRead(m.global.catGet, "CatID") <> "" then
        catID = RegRead(m.global.catGet, "CatID")
        getItemsJson(itemsContent, catID)
        m.top.cat = catID

    else if categories <> invalid and categories.count() > 0 then
        firstCatID = categories[0].category_id
        getItemsJson(itemsContent, firstCatID)
        m.top.cat = firstCatID
    end if

    m.top.categoriesNode = categoriesContent
    m.top.itemsNode = itemsContent
    m.top.contentSet = true
end sub

Function getCategories() As Object
    url = m.global.serverURL + m.global.row
    'print "Url = " + url
    data = requestData(url)
	json = ParseJSON(data)
    if json <> invalid then
        return json
    else
        return []
    end if
End Function
sub getItemsJson(parent As Object, categoria As String)
    url = m.global.serverURL + m.global.items + categoria

    data = requestData(url)
    json = ParseJSON(data)

    if json <> invalid then

        if m.global.serie = "true" then
            for i = 0 to json.count()-1
                itemcontent = parent.createChild("ContentNode")
                itemcontent.id = gcSafeStr(json[i].series_id)
                itemcontent.ContentType = "2"
                itemcontent.title = json[i].name

                if json[i].plot <> invalid and json[i].plot <> "" then
                    itemcontent.description = json[i].plot
                else if json[i].description <> invalid and json[i].description <> "" then
                    itemcontent.description = json[i].description
                else
                    itemcontent.description = ""
                end if

                if json[i].releasedate <> invalid then itemcontent.releaseDate = json[i].releasedate
                if json[i].cover <> invalid and json[i].cover <> "" then
                    itemcontent.HDPosterUrl = json[i].cover
                else
                    itemcontent.HDPosterUrl = "pkg:/images/no-poster.jpg"
                end if
                if json[i].rating <> invalid then itemcontent.rating = json[i].rating
            end for
        else
            for i = 0 to json.count()-1
                itemcontent = parent.createChild("ContentNode")
                itemcontent.id = gcSafeStr(json[i].stream_id)
                itemcontent.ContentType = "1"
                itemcontent.title = json[i].name

                if json[i].plot <> invalid and json[i].plot <> "" then
                    itemcontent.description = json[i].plot
                else if json[i].description <> invalid and json[i].description <> "" then
                    itemcontent.description = json[i].description
                else
                    itemcontent.description = ""
                end if

                if json[i].releasedate <> invalid then itemcontent.releaseDate = json[i].releasedate

                ext = "ts"
                if json[i].container_extension <> invalid then ext = json[i].container_extension
                itemcontent.url = m.global.serverURL + m.global.play + gcSafeStr(json[i].stream_id) + "." + ext

                if json[i].backdrop_path <> invalid and type(json[i].backdrop_path) = "roArray" and json[i].backdrop_path.Count() > 0 then
                    itemcontent.hdBackgroundImageUrl = json[i].backdrop_path[0]
                else if json[i].backdrop_path <> invalid and type(json[i].backdrop_path) = "roString" and json[i].backdrop_path <> "" then
                    itemcontent.hdBackgroundImageUrl = json[i].backdrop_path
                end if

                if json[i].stream_icon <> invalid and json[i].stream_icon <> "" then
                    itemcontent.HDPosterUrl = json[i].stream_icon
                else
                    itemcontent.HDPosterUrl = "pkg:/images/no-poster.jpg"
                end if
                if json[i].duration_secs <> invalid then itemcontent.length = json[i].duration_secs
                if json[i].rating <> invalid then itemcontent.rating = json[i].rating
                if json[i].container_extension <> invalid then itemcontent.StreamFormat = json[i].container_extension
            end for
        end if

    end if
end sub

' Convierte a String de forma segura. Se define aqui mismo (en vez de
' depender del <script> de generalUtils.brs) porque en este componente
' esa funcion no se estaba resolviendo en tiempo de ejecucion (crash
' "Function is not defined in component's namespace" / func_name_resolver
' failed resolving 'safestr'), sin importar que el .xml sí la incluyera.
Function gcSafeStr(val As Dynamic) As String
    if val = invalid then return ""
    t = type(val)
    if t = "roString" or t = "String" then return val
    if t = "roInt" or t = "roInteger" or t = "Integer" then return val.toStr()
    if t = "roFloat" or t = "Float" then return val.toStr()
    if t = "roDouble" or t = "Double" then return val.toStr()
    if t = "roLongInteger" or t = "LongInteger" then return val.toStr()
    return ""
End Function
