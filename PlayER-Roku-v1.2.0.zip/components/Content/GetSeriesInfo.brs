sub init()
    m.top.functionName = "go"
end sub

sub go()
    seriesId = m.top.seriesId
    if seriesId = "" then return

    su = m.global.serverURL
    u  = m.global.user
    p  = m.global.pass

    url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_series_info&series_id=" + seriesId

    http = CreateObject("roUrlTransfer")
    http.SetUrl(url)
    http.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http.EnableHostVerification(false)
    http.EnablePeerVerification(false)
    data = http.GetToString()

    json = ParseJSON(data)
    if json = invalid then return

    result = CreateObject("roSGNode", "ContentNode")

    info = json.info
    if info = invalid then return
    if type(info) <> "roAssociativeArray" then return

    ' backdrop_path = array con la imagen panoramica
    if info.backdrop_path <> invalid
        bp = info.backdrop_path
        if type(bp) = "roArray" and bp.Count() > 0
            result.hdBackgroundImageUrl = bp[0]
        else if type(bp) = "roString" and bp <> ""
            result.hdBackgroundImageUrl = bp
        end if
    end if
    ' movie_image como segunda opcion (igual que PurpleTV)
    if result.hdBackgroundImageUrl = "" or result.hdBackgroundImageUrl = invalid
        if info.movie_image <> invalid and info.movie_image <> ""
            result.hdBackgroundImageUrl = info.movie_image
        end if
    end if
    ' cover_big como tercera opcion
    if result.hdBackgroundImageUrl = "" or result.hdBackgroundImageUrl = invalid
        if info.cover_big <> invalid and info.cover_big <> ""
            result.hdBackgroundImageUrl = info.cover_big
        end if
    end if

    m.top.result = result
end sub
