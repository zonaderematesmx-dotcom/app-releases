sub init()
    'print "[GetContentMovies.brs] - init"
    m.top.functionName = "go"
  end sub
  
  sub go()
    moviesContent = createObject("roSGNode", "ContentNode")
    
    if m.top.cat <> "" then  
      getMoviesJson(moviesContent, m.top.cat)
    else 
      ' Handle error or no category provided
    end if
    
    m.top.moviesNode = moviesContent
    m.top.contentSet = true
  end sub
  
  sub getMoviesJson(parent As Object, categoria As String)
    url = m.global.serverURL + m.global.moviesAPI + categoria
    'print "Movies URL Get= "; url
    data = requestData(url) 
    json = ParseJSON(data)
    if json <> invalid then
      for i = 0 to json.count()-1
        movie = parent.createChild("ContentNode")
        if json[i].stream_id <> invalid then movie.id = json[i].stream_id.toStr()
        if json[i].name <> invalid then movie.title = json[i].name
        ' Description: plot o description
        if json[i].plot <> invalid and json[i].plot <> "" then
            movie.description = json[i].plot
        else if json[i].description <> invalid and json[i].description <> "" then
            movie.description = json[i].description
        end if
        if json[i].releasedate <> invalid then movie.releaseDate = json[i].releasedate
        if json[i].stream_icon <> invalid then movie.hdPosterURL = json[i].stream_icon
        if json[i].rating <> invalid then movie.rating = json[i].rating.toStr()
        if json[i].genre <> invalid then movie.genre = json[i].genre
        if json[i].container_extension <> invalid then movie.streamFormat = json[i].container_extension
        ' URL de reproducción
        ext = "ts"
        if json[i].container_extension <> invalid and json[i].container_extension <> "" then ext = json[i].container_extension
        if json[i].stream_id <> invalid then
            movie.url = m.global.serverURL + "/movie/" + m.global.user + "/" + m.global.pass + "/" + json[i].stream_id.toStr() + "." + ext
        end if
        ' Duración en segundos
        if json[i].duration_secs <> invalid then
            ds = json[i].duration_secs
            if type(ds) = "roInt" or type(ds) = "roInteger" or type(ds) = "Integer" then
                movie.length = ds
            else if type(ds) = "roString" or type(ds) = "String" then
                movie.length = val(ds)
            end if
        end if
        ' Backdrop para hero
        if json[i].backdrop_path <> invalid
            bp = json[i].backdrop_path
            if type(bp) = "roArray" and bp.Count() > 0
                movie.hdBackgroundImageUrl = bp[0]
            else if type(bp) = "roString" and bp <> ""
                movie.hdBackgroundImageUrl = bp
            end if
        end if
      end for
    else
      ' Handle JSON parsing error
    end if
  End sub
  