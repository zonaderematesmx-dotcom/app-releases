sub Init()
    m.rowBg = m.top.FindNode("rowBg")
    m.rowContent = m.top.FindNode("rowContent")
    m.focusBg = m.top.FindNode("focusBg")
    m.liveDotGroup = m.top.FindNode("liveDotGroup")
    m.liveDot0 = m.top.FindNode("liveDot0")
    m.liveDot1 = m.top.FindNode("liveDot1")
    m.liveDot2 = m.top.FindNode("liveDot2")
    m.liveDotPulseAnim = m.top.FindNode("liveDotPulseAnim")
    m.chLogo = m.top.FindNode("chLogo")
    m.chName = m.top.FindNode("chName")
    m.epgNow = m.top.FindNode("epgNow")
    m.epgLater = m.top.FindNode("epgLater")
    m.favStar = m.top.FindNode("favStar")

    m.channelsRealFocus = true
    if m.global.hasField("epgChannelsRealFocus") then m.channelsRealFocus = m.global.epgChannelsRealFocus
    m.global.observeField("epgChannelsRealFocus", "onRealFocusChange")

    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")
end sub

sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"
    m.focusBg.color = fc
    if m.liveDot0 <> invalid then m.liveDot0.color = fc
    if m.liveDot1 <> invalid then m.liveDot1.color = fc
    if m.liveDot2 <> invalid then m.liveDot2.color = fc

end sub

sub onContentChange()
    item = m.top.itemContent
    if item = invalid then return
    if item.HDPosterUrl <> invalid and item.HDPosterUrl <> "" then
        m.chLogo.uri = item.HDPosterUrl
    else
        m.chLogo.uri = "pkg:/images/no-poster.jpg"
    end if
    if item.title <> invalid then m.chName.text = item.title



    isPlayingNow = false
    if item.hasField("isPlayingNow") then isPlayingNow = item.isPlayingNow
    if m.liveDotGroup <> invalid then
        m.liveDotGroup.visible = isPlayingNow
        if isPlayingNow
            if m.liveDotPulseAnim <> invalid then m.liveDotPulseAnim.control = "start"
        else
            if m.liveDotPulseAnim <> invalid then m.liveDotPulseAnim.control = "stop"
            m.liveDotGroup.opacity = 1.0 ' reset por si se reutiliza esta fila para otro canal
        end if
    end if

    isFav = false
    if item.hasField("isFavorite") then isFav = item.isFavorite
    if m.favStar <> invalid then
        if isFav
            m.favStar.text = "★"
            m.favStar.visible = true
        else
            m.favStar.text = ""
            m.favStar.visible = false
        end if
    end if
end sub

sub onRealFocusChange()
    m.channelsRealFocus = m.global.epgChannelsRealFocus
    updateFocusVisual()
end sub

sub onFocusChange()
    updateFocusVisual()
end sub

' Combina 2 cosas distintas:
' - m.top.focusPercent: si ESTA fila es la que el MarkupList trae marcada
'   internamente (esto Roku lo calcula solo, sin importar si la lista
'   tiene el foco real del control remoto).
' - m.channelsRealFocus: si ChannelList tiene el foco REAL en este momento
'   (lo maneja EpgGuiaScreen.brs via m.global.epgChannelsRealFocus).
' rowBg (el fondo gris) NUNCA se toca -- vive AFUERA de rowContent y su
' transparencia es siempre la misma. Solo rowContent (foco, logo, texto,
' estrella) sube a opacidad completa (1.0, solido) cuando el foco es
' real; si no, se queda exactamente igual que siempre (0.60).
sub updateFocusVisual()
    if m.top.focusPercent > 0.5 then
        m.focusBg.visible = true
        m.chName.color = "0xFFFFFFFF"
        if m.channelsRealFocus
            m.rowContent.opacity = 1.0 ' foco real: rectangulo y texto solidos
        else
            m.rowContent.opacity = 0.60 ' aun no es foco real: igual que siempre
        end if
    else
        m.focusBg.visible = false
        m.chName.color = "0xE5E5E5FF"
        m.rowContent.opacity = 0.60
    end if
end sub
