' ============================================================
' SearchChannelsTask.brs
' Dos modos, mismo Task:
'  - m.top.query   -> busqueda por texto via buscador.php
'  - m.top.ids     -> resolucion por lote de una lista de ids via
'                     resolver.php (favoritos de canal pendientes que
'                     no se encontraron en lo ya cacheado local)
' Ambos son el mismo tipo de endpoint propio (mismo hosting que el
' resto de los PHP de la app), asi que se comparte el mismo parseo de
' respuesta.
'
' Por que un Task para esto y no seguir usando EpgGetContent con
' cat="__all__": esa ruta vieja hacia UNA peticion HTTP POR CADA
' CATEGORIA para armar la lista completa antes de poder buscar/
' resolver -- con muchas categorias, eso es lento (decenas de
' peticiones seguidas). buscador.php/resolver.php hacen UNA sola
' peticion a get_live_streams (todo el catalogo de una vez) y filtran
' del lado del servidor, devolviendo ya listo solo lo que hace falta.
' ============================================================

sub init()
    m.top.functionName = "go"
end sub

sub go()
    resultsNode = createObject("roSGNode", "ContentNode")

    su = m.global.serverURL
    u  = m.global.user
    p  = m.global.pass

    if su = "" or su = "DEMO" or u = "" or p = ""
        m.top.resultsNode = resultsNode
        m.top.searchDone = true
        return
    end if

    idsArr = m.top.ids
    url = ""

    if type(idsArr) = "roArray" and idsArr.count() > 0
        ' --- Modo resolucion por lote (favoritos de canal pendientes) ---
        apiBase = m.global.urlResolver
        if apiBase = ""
            m.top.resultsNode = resultsNode
            m.top.searchDone = true
            return
        end if
        idsStr = ""
        for each idVal in idsArr
            if idsStr <> "" then idsStr = idsStr + ","
            idsStr = idsStr + idVal
        end for
        url = apiBase + "?username=" + GU_UrlEncode(u) + "&password=" + GU_UrlEncode(p) + "&ids=" + GU_UrlEncode(idsStr) + "&tipoid=1&baseurl=" + GU_UrlEncode(su)
        print "DEBUG SearchChannelsTask - resolviendo por lote: "; idsArr.count(); " id(s)"
    else
        ' --- Modo busqueda por texto ---
        query = m.top.query
        if query = invalid then query = ""
        query = query.Trim()
        apiBase = m.global.urlBuscador
        if apiBase = "" or query = ""
            m.top.resultsNode = resultsNode
            m.top.searchDone = true
            return
        end if
        url = apiBase + "?username=" + GU_UrlEncode(u) + "&password=" + GU_UrlEncode(p) + "&search=" + GU_UrlEncode(query) + "&tipoid=1&baseurl=" + GU_UrlEncode(su)
        print "DEBUG SearchChannelsTask - buscando: "; query
    end if

    data = requestData(url, 15000)

    if data <> invalid and data <> ""
        json = ParseJSON(data)
        if type(json) = "roArray"
            for each channel in json
                if type(channel) = "roAssociativeArray"
                    itemcontent = resultsNode.createChild("ContentNode")

                    streamId = ""
                    if channel.doesExist("stream_id") and channel.stream_id <> invalid then
                        streamId = safeStr(channel.stream_id)
                    end if
                    itemcontent.id = streamId

                    if channel.doesExist("stream_type") and channel.stream_type <> invalid then
                        itemcontent.ContentType = safeStr(channel.stream_type)
                    end if

                    if channel.doesExist("name") and channel.name <> invalid then
                        itemcontent.title = channel.name
                    else
                        itemcontent.title = "Channel"
                    end if

                    if channel.doesExist("stream_icon") and channel.stream_icon <> invalid and channel.stream_icon <> "" then
                        itemcontent.HDPosterUrl = channel.stream_icon
                    end if

                    ' buscador.php/resolver.php ya arman la url completa
                    ' lista para reproducir (url_reproduccion), armada con
                    ' el mismo baseurl/usuario/clave que se le mando. Si
                    ' por algo no viniera, se arma igual que el resto de
                    ' la app como respaldo (sin depender de m.global.play,
                    ' que otras pantallas van cambiando segun el contexto).
                    if channel.doesExist("url_reproduccion") and channel.url_reproduccion <> invalid and channel.url_reproduccion <> ""
                        itemcontent.url = channel.url_reproduccion
                    else if streamId <> ""
                        itemcontent.url = su + "/live/" + u + "/" + p + "/" + streamId + ".ts"
                    end if

                    itemcontent.shortdescriptionline1 = ""
                    itemcontent.shortdescriptionline2 = ""
                end if
            end for
        end if
        print "DEBUG SearchChannelsTask - resultados = "; resultsNode.getChildCount()
    else
        print "DEBUG SearchChannelsTask - sin respuesta (revisar urlBuscador/urlResolver en el panel)"
    end if

    m.top.resultsNode = resultsNode
    m.top.searchDone = true
end sub

Function safeStr(val As Dynamic) As String
    if val = invalid then return ""
    t = type(val)
    if t = "roString" or t = "String" then return val
    if t = "roInt" or t = "roInteger" or t = "Integer" then return val.toStr()
    if t = "roFloat" or t = "Float" then return val.toStr()
    if t = "roDouble" or t = "Double" then return val.toStr()
    if t = "roLongInteger" or t = "LongInteger" then return val.toStr()
    return ""
End Function
