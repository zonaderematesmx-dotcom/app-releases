sub init()
    m.top.functionName = "go"
end sub

sub go()
    results = {}
    ids = m.top.channelIds
    if ids = invalid then
        m.top.results = results
        m.top.contentSet = true
        return
    end if
    if type(ids) <> "roAssociativeArray" then
        m.top.results = results
        m.top.contentSet = true
        return
    end if
    if m.global.epg = invalid or m.global.epg = "" then
        m.top.results = results
        m.top.contentSet = true
        return
    end if

    for each idx in ids
        sid = ids[idx]
        if sid <> invalid and sid <> "" then
            url = m.global.serverURL + m.global.epg + sid + "&limit=2"
            raw = fastReq(url)
            nw = ""
            lt = ""
            if raw <> "" then
                js = ParseJSON(raw)
                if type(js) = "roAssociativeArray" then
                    if js.doesExist("epg_listings") and type(js.epg_listings) = "roArray" then
                        li = js.epg_listings
                        if li.count() > 0 and type(li[0]) = "roAssociativeArray" then
                            if li[0].doesExist("title") and li[0].title <> invalid and li[0].title <> "" then
                                nw = b64(li[0].title)
                            end if
                        end if
                        if li.count() > 1 and type(li[1]) = "roAssociativeArray" then
                            if li[1].doesExist("title") and li[1].title <> invalid and li[1].title <> "" then
                                lt = b64(li[1].title)
                            end if
                        end if
                    end if
                end if
            end if
            results[idx] = { "now": nw, "later": lt }
        end if
    end for

    m.top.results = results
    m.top.contentSet = true
end sub

function fastReq(url as String) as String
    http = createObject("roUrlTransfer")
    http.RetainBodyOnError(true)
    port = createObject("roMessagePort")
    http.setPort(port)
    if Instr(1, url, "https://") > 0 then
        http.setCertificatesFile("common:/certs/ca-bundle.crt")
        http.InitClientCertificates()
        http.enablehostverification(false)
        http.enablepeerverification(false)
    end if
    http.setUrl(url)
    if http.AsyncGetToString() then
        msg = wait(3000, port)
        if type(msg) = "roUrlEvent" then
            if msg.getresponsecode() > 0 and msg.getresponsecode() < 400 then
                return msg.getstring()
            end if
        end if
        http.asynccancel()
    end if
    return ""
end function

Function b64(s As Dynamic) As String
    if s = invalid or s = "" then return ""
    if type(s) <> "roString" and type(s) <> "String" then return ""
    ba = createObject("roByteArray")
    ba.fromBase64String(s)
    r = ba.ToAsciiString()
    if r <> invalid then return r
    return s
End Function
