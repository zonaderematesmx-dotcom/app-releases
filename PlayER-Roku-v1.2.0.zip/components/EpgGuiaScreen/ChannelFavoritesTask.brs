' ChannelFavoritesTask
' Habla con add_favorites.php reusando la tabla "favoritos" existente,
' pero usando el prefijo "ch-" en la columna "cve" (tipo="canal") para
' que nunca choque con los ids de peliculas/series que ya se guardan ahi.

sub init()
    m.top.functionName = "execute"
end sub

sub execute()
    act = m.top.favAction
    if act = "add"
        doAddOrRemove("a")
    else if act = "remove"
        doAddOrRemove("d")
    else if act = "delta"
        doDelta()
    else
        doList()
    end if
    m.top.doneFlag = true
end sub

function favApiBase() as String
    if m.global <> invalid and m.global.urlFavoritos <> invalid then
        return m.global.urlFavoritos
    end if
    return ""
end function

function favUser() as String
    u = getStrValFromReg("user_tv", "datos_tv")
    if u = invalid then return ""
    return u
end function

' Corre Fav_ChannelDeltaFromServer (que crea un roUrlTransfer) AQUI,
' dentro del hilo propio de este Task -- es la unica forma segura en
' Roku de hacer peticiones de red desde una pantalla que no es un Task
' (crear roUrlTransfer directo en el render thread de una Scene truena).
sub doDelta()
    u = favUser()
    if u = ""
        m.top.deltaAdded = []
        m.top.deltaRemoved = []
        return
    end if
    result = Fav_ChannelDeltaFromServer(u)
    added = result.added
    removed = result.removed
    if added = invalid then added = []
    if removed = invalid then removed = []
    m.top.deltaAdded = added
    m.top.deltaRemoved = removed

    ' Reconciliacion LOCAL -> SERVIDOR (mismo patron que Fav_ReconcileLocalToServer
    ' para peliculas/series): si el servidor perdio datos que el local ya
    ' tenia (o una alta anterior no se guardo por una falla de red), se
    ' vuelven a subir, para que el servidor sea siempre un respaldo fiel.
    reconcileChannelsToServer(u)
end sub

sub reconcileChannelsToServer(u as String)
    ' &variante=/&perfil= -- sin esto, esta reconciliacion revisaba
    ' TODOS los canales favoritos de la cuenta en CUALQUIER servidor y
    ' perfil, asi que nunca "veia" faltante lo que en realidad si
    ' faltaba (y de paso, un doList() posterior sembraria canales de
    ' otros perfiles como si fueran de este). Mismo criterio que ya usa
    ' Fav_ChannelDeltaFromServer.
    url = favApiBase() + "?action=list&user=" + u + "&tipo=canal&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil()
    data = requestData(url)
    json = ParseJSON(data)

    serverIds = {}
    if json <> invalid and type(json) = "roArray"
        for each row in json
            if type(row) = "roAssociativeArray" and row.cve <> invalid
                cve = row.cve
                if Left(cve, 3) = "ch-"
                    chId = Mid(cve, 4)
                    if chId <> "" then serverIds[chId] = true
                end if
            end if
        end for
    end if

    locChannels = Fav_LocalListByType("canal")
    for each item in locChannels
        if item.id <> invalid and not serverIds.doesExist(item.id.toStr())
            pushChannelToServer(u, item.id.toStr())
        end if
    end for
end sub

sub pushChannelToServer(u as String, chId as String)
    cve = "ch-" + chId
    url = favApiBase() + "?action=a&user=" + u + "&cve=" + cve + "&tipo=canal&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil()
    requestData(url)
    print "DEBUG ChannelFavoritesTask.reconcileChannelsToServer - re-subido al servidor: chId="; chId
end sub

sub doList()
    result = {}

    ' --- LOCAL PRIMERO ---
    ' Si ya tenemos favoritos de canal guardados localmente, los
    ' devolvemos directo, sin tocar la red.
    if not Fav_LocalIsEmptyForType("canal")
        locales = Fav_LocalListByType("canal")
        for each item in locales
            if item <> invalid and item.id <> invalid and item.id <> ""
                result[item.id] = true
            end if
        end for
        print "DEBUG ChannelFavoritesTask.doList - servido desde LOCAL, total = "; result.count()
        m.top.favIds = result
        return
    end if

    ' --- LOCAL VACIO: sembramos desde el servidor ---
    u = favUser()
    print "DEBUG ChannelFavoritesTask.doList - local vacio, consultando servidor. usuario = "; u
    if u = ""
        print "DEBUG ChannelFavoritesTask.doList - usuario vacio, abortando"
        m.top.favIds = result
        return
    end if

    ' &variante=/&perfil= -- sin esto, un perfil nuevo (o cualquiera
    ' cuyo cache local todavia este vacio) sembraba con los canales
    ' favoritos de CUALQUIER perfil/servidor de la cuenta, no solo los
    ' suyos.
    url = favApiBase() + "?action=list&user=" + u + "&tipo=canal&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil()
    print "DEBUG ChannelFavoritesTask.doList - url = "; url
    data = requestData(url)
    print "DEBUG ChannelFavoritesTask.doList - respuesta cruda = "; data
    json = ParseJSON(data)

    if json <> invalid and type(json) = "roArray"
        for each row in json
            if type(row) = "roAssociativeArray" and row.cve <> invalid
                cve = row.cve
                if Left(cve, 3) = "ch-"
                    chId = Mid(cve, 4)
                    if chId <> "" then result[chId] = true
                    ' OJO: aqui NO escribimos al local. Solo tenemos el id
                    ' (el endpoint "list" no trae titulo/icono/url), y si
                    ' escribieramos un objeto a medias, Fav_LocalListByType
                    ' ("canal") lo reportaria como "listo para mostrar" sin
                    ' estarlo. El sembrado con datos COMPLETOS lo hace
                    ' EpgGuiaScreen (enterFavoritesMode), que si tiene
                    ' acceso al catalogo completo de canales para resolver
                    ' titulo/icono/url de cada favorito.
                end if
            end if
        end for
    end if

    print "DEBUG ChannelFavoritesTask.doList - total canales favoritos encontrados (servidor) = "; result.count()
    m.top.favIds = result
end sub

sub doAddOrRemove(action as String)
    u = favUser()
    chId = m.top.cve
    print "DEBUG ChannelFavoritesTask.doAddOrRemove - action="; action; " usuario="; u; " chId="; chId
    if u = "" or chId = ""
        print "DEBUG ChannelFavoritesTask.doAddOrRemove - usuario o chId vacio, abortando"
        return
    end if

    ' Local primero (optimista), igual que AddFavorite para peliculas/series.
    tituloParam = ""
    if action = "a"
        itemAA = {}
        rawJson = m.top.itemJson
        if rawJson <> invalid and rawJson <> ""
            parsed = ParseJSON(rawJson)
            if parsed <> invalid and type(parsed) = "roAssociativeArray" then itemAA = parsed
        end if
        itemAA["id"] = chId
        Fav_LocalWrite("canal", chId, itemAA)
        ' ANTES esto no se mandaba nunca -- el canal se guardaba en el
        ' servidor SIN nombre (columna titulo vacia), igual que ya hace
        ' AddFavorite.xml para peliculas/series. Sin esto, otro
        ' dispositivo que sincroniza este canal antes de tener su
        ' propio catalogo descargado lo muestra en blanco/generico.
        if itemAA.title <> invalid and itemAA.title <> "" then tituloParam = GU_UrlEncode(itemAA.title)
    else
        Fav_LocalDelete("canal", chId)
    end if

    cve = "ch-" + chId
    ' &variante=/&perfil= -- sin esto, agregar o quitar un canal de
    ' favoritos afectaba la fila COMPARTIDA en '0' en vez de la de este
    ' perfil/servidor, mezclandose con los demas perfiles de la cuenta.
    url = favApiBase() + "?action=" + action + "&user=" + u + "&cve=" + cve + "&variante=" + Fav_CurrentVariante() + "&perfil=" + Fav_CurrentPerfil()
    if action = "a" then url = url + "&tipo=canal&titulo=" + tituloParam
    print "DEBUG ChannelFavoritesTask.doAddOrRemove - url = "; url

    resp = requestData(url)
    print "DEBUG ChannelFavoritesTask.doAddOrRemove - respuesta servidor = "; resp
end sub
