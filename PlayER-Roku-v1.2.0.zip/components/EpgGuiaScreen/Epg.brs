sub init()
    m.top.functionName = "go"
end sub

sub go()
    m.top.title = ""
    m.top.start = ""
    m.top.end = ""
    m.top.next = ""
    m.top.nextStart = ""
    m.top.nextEnd = ""
    m.top.progress = 0

    if m.top.cve = invalid or m.top.cve = "" then
        m.top.contentSet = true
        return
    end if

    if m.global.epg = invalid or m.global.epg = "" then
        m.top.contentSet = true
        return
    end if

    url = m.global.serverURL + m.global.epg + m.top.cve + "&limit=3"
    data = requestData(url)

    if data = invalid or data = "" then
        m.top.contentSet = true
        return
    end if

    json = ParseJSON(data)
    if type(json) <> "roAssociativeArray" then
        m.top.contentSet = true
        return
    end if

    if not json.doesExist("epg_listings") or type(json.epg_listings) <> "roArray" then
        m.top.contentSet = true
        return
    end if

    listings = json.epg_listings

    ' NOW
    if listings.count() > 0 and type(listings[0]) = "roAssociativeArray" then
        e = listings[0]
        if e.doesExist("title") and e.title <> invalid and e.title <> "" then
            m.top.title = decodeB64(e.title)
        end if
        if e.doesExist("start") and e.start <> invalid then
            m.top.start = utcToLocal(e.start)
        end if
        if e.doesExist("end") and e["end"] <> invalid then
            m.top.end = utcToLocal(e["end"])
        end if
    end if

    ' NEXT
    if listings.count() > 1 and type(listings[1]) = "roAssociativeArray" then
        e2 = listings[1]
        if e2.doesExist("title") and e2.title <> invalid and e2.title <> "" then
            m.top.next = decodeB64(e2.title)
        end if
        if e2.doesExist("start") and e2.start <> invalid then
            m.top.nextStart = utcToLocal(e2.start)
        end if
        if e2.doesExist("end") and e2["end"] <> invalid then
            m.top.nextEnd = utcToLocal(e2["end"])
        end if
    end if

    m.top.contentSet = true
end sub

' Convert UTC time string "2025-02-12 23:00:00" to local time string
function utcToLocal(utcStr as String) as String
    if utcStr = invalid or utcStr = "" then return ""
    
    ' Parse UTC string into roDateTime
    ' Format: "YYYY-MM-DD HH:MM:SS"
    parts = utcStr.split(" ")
    if parts.count() < 2 then return utcStr
    
    dateParts = parts[0].split("-")
    timeParts = parts[1].split(":")
    if dateParts.count() < 3 or timeParts.count() < 3 then return utcStr
    
    ' Build seconds from epoch using roDateTime
    ' Set UTC time, then convert to local
    dt = createObject("roDateTime")
    
    ' Use roDateTime to handle the conversion
    ' We need to calculate epoch seconds from the UTC date
    ' Simple approach: set from ISO string
    isoStr = dateParts[0] + "-" + dateParts[1] + "-" + dateParts[2] + "T" + timeParts[0] + ":" + timeParts[1] + ":" + timeParts[2] + "Z"
    dt.FromISO8601String(isoStr)
    dt.ToLocalTime()
    
    ' Format back as readable string
    lhr = dt.GetHours()
    lmn = dt.GetMinutes()
    
    mnStr = lmn.toStr()
    if lmn < 10 then mnStr = "0" + lmn.toStr()
    
    ap = "AM"
    h = lhr
    if lhr = 0 then
        h = 12
    else if lhr = 12 then
        ap = "PM"
    else if lhr > 12 then
        h = lhr - 12
        ap = "PM"
    end if
    
    return h.toStr().Trim() + ":" + mnStr + " " + ap
end function

Function decodeB64(s As Dynamic) As String
    if s = invalid or s = "" then return ""
    if type(s) <> "roString" and type(s) <> "String" then return ""
    ba = createObject("roByteArray")
    ba.fromBase64String(s)
    r = ba.ToAsciiString()
    if r <> invalid then return r
    return s
End Function

Function displayBase64(result As String) As Object
    return decodeB64(result)
End Function
