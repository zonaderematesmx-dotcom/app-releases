sub init()
  m.top.functionName = "go"
end sub

' Categoria y canal de prueba usados en modo DEMO, para no depender de
' ningun servidor Xtream real. La URL es un stream HLS publico de
' pruebas (Apple bipbop), pensado justo para esto.
sub buildDemoContent(categoriesContent as Object, itemsContent as Object)
  demoCat = categoriesContent.createChild("ContentNode")
  demoCat.id = "demo"
  demoCat.title = "Prueba"

  demoChannel = itemsContent.createChild("ContentNode")
  demoChannel.id = "demo-1"
  demoChannel.ContentType = "live"
  demoChannel.title = "Canal de prueba"
  demoChannel.url = "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8"
  demoChannel.shortdescriptionline1 = ""
  demoChannel.shortdescriptionline2 = ""
end sub

sub go()
  categoriesContent = createObject("roSGNode", "ContentNode")
  itemsContent = createObject("roSGNode", "ContentNode")

  ' --- MODO DEMO: sin red, siempre el mismo canal de prueba ---
  if m.global.serverURL = "DEMO"
    buildDemoContent(categoriesContent, itemsContent)
    m.top.categories = []
    m.top.categoriesNode = categoriesContent
    m.top.itemsNode = itemsContent
    m.top.cat = "demo"
    m.top.title = "Prueba"
    m.top.contentSet = true
    return
  end if

  ' ===== MODO BÚSQUEDA: cargar todos los canales de todas las categorías =====
  if m.top.cat = "__all__" then
    catList = m.top.catList
    if type(catList) = "roArray" then
      for each catId in catList
        if catId <> invalid and catId <> "" then
          loadChannels(itemsContent, catId)
        end if
      end for
    end if
    m.top.itemsNode = itemsContent
    m.top.contentSet = true
    return
  end if

  ' -- 1. Categories (1 HTTP request) --
  cats = getCategories()
  m.top.categories = cats

  if type(cats) = "roArray" then
    for i = 0 to cats.count() - 1
      if type(cats[i]) = "roAssociativeArray" then
        newCat = categoriesContent.createChild("ContentNode")
        if cats[i].doesExist("category_id") and cats[i].category_id <> invalid then
          newCat.id = safeStr(cats[i].category_id)
        end if
        if cats[i].doesExist("category_name") and cats[i].category_name <> invalid then
          newCat.title = safeStr(cats[i].category_name)
        end if
      end if
    end for
  end if

  ' -- 2. Pick which category to load --
  selectedCat = ""
  selectedTitle = ""

  if m.top.cat <> invalid and m.top.cat <> "" then
    selectedCat = m.top.cat
    selectedTitle = m.top.title
    if selectedTitle = invalid then selectedTitle = ""
  else if RegRead(m.global.catGet, "CatID") <> invalid and RegRead(m.global.catGet, "CatID") <> "" then
    selectedCat = RegRead(m.global.catGet, "CatID")
    selectedTitle = RegRead(m.global.catGet, "CatTITLE")
    if selectedTitle = invalid then selectedTitle = ""
  else if type(cats) = "roArray" and cats.count() > 0 and type(cats[0]) = "roAssociativeArray" then
    if cats[0].doesExist("category_id") and cats[0].category_id <> invalid then
      selectedCat = safeStr(cats[0].category_id)
    end if
    if cats[0].doesExist("category_name") and cats[0].category_name <> invalid then
      selectedTitle = safeStr(cats[0].category_name)
    end if
  end if

  m.top.cat = selectedCat
  m.top.title = selectedTitle

  if selectedCat <> "" then
    RegWrite(m.global.catGet, selectedCat, "CatID")
    RegWrite(m.global.catGet, selectedTitle, "CatTITLE")
  end if

  ' -- 3. Channels for that category (1 HTTP request) --
  if selectedCat <> "" then
    loadChannels(itemsContent, selectedCat)
  end if

  ' -- 4. DONE. No EPG here. EPG loads separately per-focused-channel. --
  m.top.categoriesNode = categoriesContent
  m.top.itemsNode = itemsContent
  m.top.contentSet = true
end sub


Function getCategories() As Object
  url = m.global.serverURL + m.global.row
  print "EpgGetContent: categories "; url
  data = requestData(url)
  if data <> invalid and data <> "" then
    json = ParseJSON(data)
    if type(json) = "roArray" then return json
  end if
  return []
End Function


sub loadChannels(parent As Object, categoria As String)
  url = m.global.serverURL + m.global.items + categoria
  print "EpgGetContent: channels "; url
  data = requestData(url)

  if data = invalid or data = "" then return

  json = ParseJSON(data)
  if type(json) <> "roArray" then return

  json = sortChannelsByName(json)

  for each channel in json
    if type(channel) = "roAssociativeArray" then
      itemcontent = parent.createChild("ContentNode")

      streamId = ""
      if channel.doesExist("stream_id") and channel.stream_id <> invalid then
        streamId = safeStr(channel.stream_id)
      end if
      itemcontent.id = streamId

      if channel.doesExist("stream_type") and channel.stream_type <> invalid then
        itemcontent.ContentType = safeStr(channel.stream_type)
      end if

      if channel.doesExist("name") and channel.name <> invalid then
        itemcontent.title = channel.name
      else
        itemcontent.title = "Channel"
      end if

      if channel.doesExist("stream_icon") and channel.stream_icon <> invalid and channel.stream_icon <> "" then
        itemcontent.HDPosterUrl = channel.stream_icon
      end if

      if streamId <> "" then
        itemcontent.url = m.global.serverURL + m.global.play + streamId + ".ts"
      end if

      itemcontent.shortdescriptionline1 = ""
      itemcontent.shortdescriptionline2 = ""
    end if
  end for

  print "EpgGetContent: loaded "; parent.getChildCount(); " channels"
End sub


' -- Helpers --

' Ordena los canales alfabeticamente por nombre (insensible a
' mayusculas). El proveedor los manda en su propio orden (num interno
' del panel), sin esto quedaban tal cual venian.
Function channelNameOf(channel As Object) As String
    if channel.name = invalid then return ""
    return LCase(channel.name.toStr())
End Function

Function mergeChannelsByName(left As Object, right As Object) As Object
    result = []
    i = 0
    j = 0
    while i < left.count() and j < right.count()
        if channelNameOf(left[i]) <= channelNameOf(right[j])
            result.push(left[i])
            i = i + 1
        else
            result.push(right[j])
            j = j + 1
        end if
    end while
    while i < left.count()
        result.push(left[i])
        i = i + 1
    end while
    while j < right.count()
        result.push(right[j])
        j = j + 1
    end while
    return result
End Function

Function sortChannelsByName(items As Object) As Object
    if items = invalid or items.count() <= 1 then return items
    mid = items.count() \ 2
    left = []
    right = []
    for i = 0 to mid - 1
        left.push(items[i])
    end for
    for i = mid to items.count() - 1
        right.push(items[i])
    end for
    left = sortChannelsByName(left)
    right = sortChannelsByName(right)
    return mergeChannelsByName(left, right)
End Function

Function safeStr(val As Dynamic) As String
  if val = invalid then return ""
  t = type(val)
  if t = "roString" or t = "String" then return val
  if t = "roInt" or t = "roInteger" or t = "Integer" then return val.toStr()
  if t = "roFloat" or t = "Float" then return val.toStr()
  if t = "roDouble" or t = "Double" then return val.toStr()
  if t = "roLongInteger" or t = "LongInteger" then return val.toStr()
  return ""
End Function
