sub init()
    m.loading       = m.top.findNode("LoadingIndicator")
    m.logoImage     = m.top.findNode("logoImage")
    m.searchQuery   = m.top.findNode("searchQuery")
    m.moviesLabel   = m.top.findNode("moviesResultLabel")
    m.moviesGrid    = m.top.findNode("moviesResultGrid")
    m.seriesLabel   = m.top.findNode("seriesResultLabel")
    m.seriesGrid    = m.top.findNode("seriesResultGrid")
    m.focusedTitle  = m.top.findNode("focusedItemTitle")
    m.noResults     = m.top.findNode("noResultsLabel")
    m.detailsScreen = m.top.findNode("DetailsScreen")
    m.seasons       = m.top.findNode("Seasons")

    ' Fondo desde tu servidor
    m.bgImage = m.top.findNode("bgImage")
    dt = CreateObject("roDateTime").AsSeconds().ToStr()
    m.bgImage.uri = m.global.panelURL + "/img/fondo.jpg?ts=" + dt

    ' Observers
    m.moviesGrid.observeField("itemFocused", "onMovieFocused")
    m.seriesGrid.observeField("itemFocused", "onSeriesFocused")
    m.moviesGrid.observeField("itemSelected", "onMovieSelected")
    m.seriesGrid.observeField("itemSelected", "onSerieSelected")
    m.detailsScreen.observeField("requestClose", "onRequestClose")

    m.focusZone  = "movies"
    m.searchText = ""
    m.moviesDone = false
    m.seriesDone = false

    m.navFocusedIndex = 0  ' Search es indice 0
    m.activeNavIndex = 0   ' esta pantalla siempre representa "Buscar"
    m.totalNavItems = 7
    m.profileAvatarBg      = m.top.findNode("profileAvatarBg")
    m.profileAvatarInitial = m.top.findNode("profileAvatarInitial")
    GU_FillProfileNavItem(m.profileAvatarBg, m.profileAvatarInitial, m.top.findNode("navLabel6"))

    ' Logo
    dt = CreateObject("roDateTime").AsSeconds().ToStr()
    m.logoImage.uri = m.global.panelURL + "/img/logo.png?ts=" + dt

    m.loading.control = "stop"
    m.searchKeyboard = m.top.findNode("searchKeyboard")
    m.top.observeField("focusedChild", "onFocusedChildChange")
    m.keyboardReady = false

    ' --- Color de marca (focusColor del config.json) ---
    m.hintKeyboard = m.top.findNode("hintKeyboard")
    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")
end sub

' ============================================================
' Aplica el focusColor del config remoto al hint rojo y se
' vuelve a llamar automaticamente si el color cambia despues.
' ============================================================
sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"
    if m.hintKeyboard <> invalid then m.hintKeyboard.color = fc
    updateNavHighlight()
end sub

' ── Teclado Personalizado ────────────────────────────────────────────────────

sub showCustomKeyboard()
    if m.searchKeyboard = invalid
        m.searchKeyboard = m.top.findNode("searchKeyboard")
    end if
    if m.searchKeyboard = invalid then return
    m.searchKeyboard.text = ""
    m.searchKeyboard.confirmed = false
    m.searchKeyboard.observeField("text", "onKeyboardTextChanged")
    m.searchKeyboard.observeField("confirmed", "onKeyboardConfirmed")
    m.searchKeyboard.observeField("goUp", "onKeyboardGoUp")
    m.searchKeyboard.visible = true
    m.searchKeyboard.setFocus(true)
end sub

sub onKeyboardTextChanged()
    if m.searchKeyboard = invalid then return
    if m.searchQuery <> invalid
        m.searchQuery.text = chr(34) + m.searchKeyboard.text.trim() + chr(34)
    end if
end sub

sub onKeyboardGoUp()
    if m.searchKeyboard = invalid then return
    if not m.searchKeyboard.goUp then return
    m.searchKeyboard.goUp = false
    m.searchKeyboard.visible = false
    m.searchKeyboard.unobserveField("text")
    m.searchKeyboard.unobserveField("confirmed")
    m.searchKeyboard.unobserveField("goUp")
    m.focusZone = "nav"
    m.navFocusedIndex = 0
    updateNavHighlight()
    ' Dar foco al nodo del item de nav activo para que onKeyEvent funcione
    navNode = m.top.findNode("navBg" + m.navFocusedIndex.toStr())
    if navNode <> invalid
        navNode.setFocus(true)
    else
        m.top.setFocus(true)
    end if
end sub

sub onKeyboardConfirmed()
    if m.searchKeyboard = invalid then return
    if not m.searchKeyboard.confirmed then return
    hideCustomKeyboard()
end sub

sub hideCustomKeyboard()
    if m.searchKeyboard = invalid then return
    searchText = m.searchKeyboard.text.trim()
    m.searchKeyboard.visible = false
    m.searchKeyboard.unobserveField("text")
    m.searchKeyboard.unobserveField("confirmed")
    m.searchKeyboard.unobserveField("goUp")
    if searchText <> ""
        m.searchText = searchText
        m.searchQuery.text = chr(34) + m.searchText + chr(34)
        doSearch()
    end if
    restoreFocusToGrid()
end sub

' ── Search ────────────────────────────────────────────────────────────────────

sub doSearch()
    m.moviesLabel.visible = false
    m.moviesGrid.visible  = false
    m.seriesLabel.visible = false
    m.seriesGrid.visible  = false
    m.noResults.visible   = false
    m.focusedTitle.visible = false
    m.moviesDone = false
    m.seriesDone = false
    m.loading.control = "start"

    m.moviesTask = createObject("roSGNode", "HomeContentTask")
    m.moviesTask.taskType    = "searchMovies"
    m.moviesTask.searchQuery = m.searchText
    m.moviesTask.observeField("contentResults", "onMoviesDone")
    m.moviesTask.control = "RUN"

    m.seriesTask = createObject("roSGNode", "HomeContentTask")
    m.seriesTask.taskType    = "searchSeries"
    m.seriesTask.searchQuery = m.searchText
    m.seriesTask.observeField("contentResults", "onSeriesDone")
    m.seriesTask.control = "RUN"
end sub

sub onMoviesDone()
    m.moviesDone = true
    content = m.moviesTask.contentResults
    if content <> invalid and content.getChildCount() > 0
        m.moviesGrid.content  = content
        m.moviesGrid.visible  = true
        m.moviesLabel.visible = true
    end if
    checkBothDone()
end sub

sub onSeriesDone()
    m.seriesDone = true
    content = m.seriesTask.contentResults
    if content <> invalid and content.getChildCount() > 0
        m.seriesGrid.content  = content
        m.seriesGrid.visible  = true
        m.seriesLabel.visible = true
    end if
    checkBothDone()
end sub

sub checkBothDone()
    if not m.moviesDone or not m.seriesDone then return
    m.loading.control = "stop"
    if m.moviesGrid.visible
        m.moviesGrid.setFocus(true)
        m.focusZone = "movies"
    else if m.seriesGrid.visible
        m.seriesGrid.setFocus(true)
        m.focusZone = "series"
    else
        m.noResults.text    = "No results found for " + chr(34) + m.searchText + chr(34)
        m.noResults.visible = true
        showCustomKeyboard()
    end if
end sub

' ── Item selection ────────────────────────────────────────────────────────────

sub onMovieSelected()
    idx     = m.moviesGrid.itemSelected
    content = m.moviesGrid.content.getChild(idx)
    if content = invalid then return
    m.focusZone = "movies"
    m.global.play = "/movie/" + m.global.user + "/" + m.global.pass + "/"
    m.detailsScreen.content = content
    m.detailsScreen.visible = true
    m.detailsScreen.setFocus(true)
end sub

sub onSerieSelected()
    idx     = m.seriesGrid.itemSelected
    content = m.seriesGrid.content.getChild(idx)
    if content = invalid then return
    m.focusZone = "series"
    m.global.play    = "/series/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie   = "true"
    m.global.episode = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series_info&series_id="
    m.seasons.content = content
    m.seasons.visible = true
    m.seasons.setFocus(true)
end sub

' ── Focus guard ───────────────────────────────────────────────────────────────

sub onFocusedChildChange()
    ' Primera vez que la pantalla recibe foco: mostrar teclado
    if not m.keyboardReady
        m.keyboardReady = true
        showCustomKeyboard()
        return
    end if

    ' Guard: si el teclado está visible, no dejar que nada más le robe el foco
    if m.searchKeyboard <> invalid and m.searchKeyboard.visible
        if not m.searchKeyboard.isInFocusChain()
            m.searchKeyboard.setFocus(true)
        end if
        return
    end if
    if m.detailsScreen.visible and not m.detailsScreen.isInFocusChain()
        m.detailsScreen.setFocus(true)
        return
    end if
    if m.seasons.visible and not m.seasons.isInFocusChain()
        m.seasons.setFocus(true)
    end if
end sub

' ── Close details ─────────────────────────────────────────────────────────────

sub onRequestClose()
    if m.detailsScreen.requestClose <> true then return
    m.detailsScreen.visible = false
    restoreFocusToGrid()
end sub

sub restoreFocusToGrid()
    if m.moviesGrid.visible
        m.moviesGrid.setFocus(true)
        m.focusZone = "movies"
    else if m.seriesGrid.visible
        m.seriesGrid.setFocus(true)
        m.focusZone = "series"
    end if
end sub

' ── Key events ────────────────────────────────────────────────────────────────


sub updateNavHighlight()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"
    navIds = ["navBg0", "navBg1", "navBg2", "navBg3", "navBg4", "navBg5", "navBg6"]
    labelIds = ["navLabel0", "navLabel1", "navLabel2", "navLabel3", "navLabel4", "navLabel5", "navLabel6"]
    for i = 0 to m.totalNavItems - 1
        bg = m.top.findNode(navIds[i])
        lbl = m.top.findNode(labelIds[i])
        if bg <> invalid and lbl <> invalid
            if i = m.navFocusedIndex
                bg.color = fc
                bg.opacity = 0.8
                lbl.color = "0xFFFFFFFF"
            else if i = m.activeNavIndex
                bg.color = fc
                bg.opacity = 0.5
                lbl.color = "0xFFFFFFFF"
            else
                bg.color = "0x00000000"
                bg.opacity = 0.0
                lbl.color = "0xAAAAAAFF"
            end if
        end if
    end for
end sub
function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    ' DetailsScreen/Seasons no manejan left/right (solo up/down/OK/back),
    ' asi que esas teclas rebotan hacia aca al no ser consumidas. Sin
    ' este guard, izquierda/derecha terminaban moviendo el menu superior
    ' de SearchScreen que quedo "atras" (invisible pero con foco robado
    ' via navNode.setFocus), y un OK posterior activaba esa seleccion
    ' del menu en vez de Play/Favoritos de la pantalla que se ve.
    ' back/options se dejan pasar porque esas pantallas ya las manejan
    ' por su cuenta (back cierra via requestClose; options se deja
    ' bubbling a proposito, mismo criterio que ya tenia este archivo).
    if m.detailsScreen <> invalid and m.detailsScreen.visible
        if key <> "back" and key <> "options" then return true
    end if
    if m.seasons <> invalid and m.seasons.visible
        if key <> "back" and key <> "options" then return true
    end if

    ' Si el teclado esta visible, solo manejar back; todo lo demas va al teclado
    if m.searchKeyboard <> invalid and m.searchKeyboard.visible
        if key = "back"
            m.searchKeyboard.visible = false
            m.searchKeyboard.unobserveField("text")
            m.searchKeyboard.unobserveField("confirmed")
            m.searchKeyboard.unobserveField("goUp")
            m.focusZone = "nav"
            m.navFocusedIndex = 0
            updateNavHighlight()
            navNode = m.top.findNode("navBg" + m.navFocusedIndex.toStr())
            if navNode <> invalid then navNode.setFocus(true) else m.top.setFocus(true)
            return true
        end if
        ' Redirigir foco al teclado si se perdió (p.ej. lo robó el grid u otro nodo)
        if not m.searchKeyboard.isInFocusChain()
            m.searchKeyboard.setFocus(true)
        end if
        return false
    end if

    if key = "back"
        if m.seasons.visible
            m.seasons.visible = false
            restoreFocusToGrid()
            return true
        end if
        return false
    end if

    if key = "options"
        if m.detailsScreen.visible or m.seasons.visible then return false
        showCustomKeyboard()
        return true
    end if

    if key = "down"
        ' Desde el menú de navegación bajar al grid o reabrir teclado
        if m.focusZone = "nav"
            if m.moviesGrid.visible or m.seriesGrid.visible
                restoreFocusToGrid()
            else
                showCustomKeyboard()
            end if
            return true
        end if
        ' Entre grids: movies → series
        if m.moviesGrid.visible and m.seriesGrid.visible and m.focusZone = "movies"
            m.seriesGrid.setFocus(true)
            m.focusZone = "series"
            return true
        end if
    end if
    if key = "up"
        if m.focusZone = "series" and m.moviesGrid.visible
            m.moviesGrid.setFocus(true)
            m.focusZone = "movies"
            return true
        else if m.focusZone = "movies" or m.focusZone = "series"
            ' Subir al menu de navegacion
            m.focusZone = "nav"
            updateNavHighlight()
            navNode = m.top.findNode("navBg" + m.navFocusedIndex.toStr())
            if navNode <> invalid then navNode.setFocus(true) else m.top.setFocus(true)
            return true
        end if
    end if

    if key = "left" and m.searchKeyboard.visible = false
        if m.navFocusedIndex > 0
            m.navFocusedIndex = m.navFocusedIndex - 1
        else
            m.navFocusedIndex = m.totalNavItems - 1
        end if
        updateNavHighlight()
        navNode = m.top.findNode("navBg" + m.navFocusedIndex.toStr())
        if navNode <> invalid then navNode.setFocus(true)
        return true
    else if key = "right" and m.searchKeyboard.visible = false
        if m.navFocusedIndex < m.totalNavItems - 1
            m.navFocusedIndex = m.navFocusedIndex + 1
        else
            m.navFocusedIndex = 0
        end if
        updateNavHighlight()
        navNode = m.top.findNode("navBg" + m.navFocusedIndex.toStr())
        if navNode <> invalid then navNode.setFocus(true)
        return true
    else if key = "OK"
        if m.navFocusedIndex = 0
            return true
        else if m.navFocusedIndex = 1
            m.top.menuItemSelected = 5
        else if m.navFocusedIndex = 2
            m.top.menuItemSelected = 1
        else if m.navFocusedIndex = 3
            m.top.menuItemSelected = 2
        else if m.navFocusedIndex = 4
            m.top.menuItemSelected = 0
        else if m.navFocusedIndex = 5
            m.top.menuItemSelected = 3
        else if m.navFocusedIndex = 6
            GU_ShowChangeProfileDialog(m.top, -2) ' Perfil
        end if
        return true
    end if

    return false
end function

' ── Título al deslizar ────────────────────────────────────────────────────────

sub onMovieFocused()
    if m.focusedTitle = invalid then return
    idx = m.moviesGrid.itemFocused
    if idx < 0 then return

    content = m.moviesGrid.content.getChild(idx)
    if content <> invalid and content.title <> invalid
        m.focusedTitle.text = content.title
        m.focusedTitle.visible = true
    end if
end sub

sub onSeriesFocused()
    if m.focusedTitle = invalid then return
    idx = m.seriesGrid.itemFocused
    if idx < 0 then return

    content = m.seriesGrid.content.getChild(idx)
    if content <> invalid and content.title <> invalid
        m.focusedTitle.text = content.title
        m.focusedTitle.visible = true
    end if
end sub