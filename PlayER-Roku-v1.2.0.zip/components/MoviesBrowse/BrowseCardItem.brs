sub init()
    m.poster        = m.top.findNode("poster")
    m.title         = m.top.findNode("title")
    m.shadow        = m.top.findNode("shadow")
    m.ratingBg      = m.top.findNode("ratingBg")
    m.ratingLabel   = m.top.findNode("ratingLabel")
    m.borderTop     = m.top.findNode("borderTop")
    m.borderBottom  = m.top.findNode("borderBottom")
    m.borderLeft    = m.top.findNode("borderLeft")
    m.borderRight   = m.top.findNode("borderRight")
    m.shimmerClip   = m.top.findNode("shimmerClip")
    m.shimmerAnim   = m.top.findNode("shimmerAnim")
    m.shimmerTimeout = m.top.findNode("shimmerTimeout")
    m.shimmerTimeout.observeField("fire", "onShimmerTimeout")
    m.shimmer       = m.top.findNode("shimmer")
    m.watchProgressBg   = m.top.findNode("watchProgressBg")
    m.watchProgressFill = m.top.findNode("watchProgressFill")

    m.top.observeField("focusPercent", "onFocusChanged")
    m.top.observeField("gridHasFocus", "onGridFocusChanged")
    m.poster.observeField("loadStatus", "onPosterLoadStatusChanged")

    m.title.font.size = 11

    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")
end sub

' ============================================================
' Shimmer: mientras el Poster esta cargando (o aun no se le ha
' asignado nada), se muestra la franja de brillo animada en vez del
' cardBg estatico. En cuanto el Poster termina (ready o failed, ya
' sea con la imagen real o con el generico de no-poster/failedBitmap),
' se oculta y se detiene la animacion.
' ============================================================
sub showShimmer()
    if m.shimmerClip.visible then return
    m.shimmerClip.visible = true
    m.shimmerAnim.control = "start"
    m.shimmerTimeout.control = "start"
end sub

sub hideShimmer()
    if not m.shimmerClip.visible then return
    m.shimmerAnim.control = "stop"
    m.shimmerTimeout.control = "stop"
    m.shimmerClip.visible = false
end sub

sub onShimmerTimeout()
    hideShimmer()
end sub

sub onPosterLoadStatusChanged()
    status = m.poster.loadStatus
    if status = "ready" or status = "failed"
        hideShimmer()
    else
        showShimmer()
    end if
end sub

' ============================================================
' Aplica el focusColor del config remoto al borde de foco y al
' badge de rating. Se re-ejecuta si el color cambia despues.
' ============================================================
sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"

    m.borderTop.color    = fc
    m.borderBottom.color = fc
    m.borderLeft.color   = fc
    m.borderRight.color  = fc
    m.ratingBg.color     = fc
    m.shimmer.blendColor = fc
end sub

sub onContentChanged()
    item = m.top.itemContent
    if item = invalid then return

    if item.HDPosterUrl <> invalid and item.HDPosterUrl <> ""
        if m.poster.uri <> item.HDPosterUrl
            ' Solo si de verdad va a cargar algo nuevo. Si esta tarjeta
            ' se reciclo y le toco la MISMA url que ya tenia, Roku no
            ' dispara un nuevo loadStatus (ya la tiene lista), y el
            ' shimmer se quedaria encendido para siempre si lo
            ' mostraramos aqui sin condicion.
            showShimmer()
            m.poster.uri = item.HDPosterUrl
        end if
    else
        hideShimmer()
        m.poster.uri = ""
    end if

    if item.title <> invalid and item.title <> ""
        m.title.text = item.title
    else
        m.title.text = ""
    end if

    r = item.rating
    if r <> invalid and r <> "" and r <> "0" and r <> "0.0"
        rVal = val(r)
        if rVal > 0
            m.ratingLabel.text = Str(Int(rVal * 10) / 10).trim()
            if Len(m.ratingLabel.text) > 4 then m.ratingLabel.text = Left(m.ratingLabel.text, 3)
            m.ratingBg.visible = false
            m.ratingLabel.visible = false
        else
            m.ratingBg.visible = false
            m.ratingLabel.visible = false
        end if
    else
        m.ratingBg.visible = false
        m.ratingLabel.visible = false
    end if

    ' Barra de "visto" -- SOLO para items de Recien Vistas (marcados con
    ' showProgress=true desde HomeContentTask.loadRecentlyWatched). En
    ' las demas filas del Home (Peliculas/Series Recien Agregadas, Mi
    ' Top 20) este componente se reutiliza pero showProgress no viene
    ' marcado, asi que la barra nunca se muestra ahi.
    frac = 0.0
    if item.showProgress = true
        if item.isSerie = true
            if item.lastEpisodeId <> invalid and item.lastEpisodeId <> ""
                frac = WP_LocalFraction(item.lastEpisodeId.toStr())
            end if
        else if item.id <> invalid and item.id <> ""
            frac = WP_LocalFraction(item.id.toStr())
        end if
    end if
    print "DEBUG BROWSECARD - title="; item.title; " showProgress="; item.showProgress; " isSerie="; item.isSerie; " lastEpisodeId="; item.lastEpisodeId; " id="; item.id; " frac="; frac
    if frac > 0.0
        m.watchProgressBg.visible   = true
        m.watchProgressFill.visible = true
        m.watchProgressFill.width   = 103.3 * frac
    else
        m.watchProgressBg.visible   = false
        m.watchProgressFill.visible = false
    end if
end sub

sub showBorder(op as Float)
    m.borderTop.opacity    = op
    m.borderBottom.opacity = op
    m.borderLeft.opacity   = op
    m.borderRight.opacity  = op
end sub

sub onFocusChanged()
    fp = m.top.focusPercent
    if fp = invalid then fp = 0
    gf = m.top.gridHasFocus
    if gf = invalid then gf = false

    if fp > 0.1 and gf
        scale = 1.0 + (fp * 0.08)
        ' Centro real del slot (123.3x183.3), no del recorte de portada.
        ' Así el zoom crece parejo hacia los 4 lados en vez de sesgarse
        ' hacia una esquina y comerse el margen del borde de foco.
        m.top.scaleRotateCenter = [61.65, 91.65]
        m.top.scale = [scale, scale]
        showBorder(1.0)
        m.shadow.opacity = 0.8
    else
        m.top.scale = [1.0, 1.0]
        showBorder(0.0)
        m.shadow.opacity = 0.55
    end if
end sub

sub onGridFocusChanged()
    gf = m.top.gridHasFocus
    if gf = invalid then gf = false
    if not gf
        m.top.scale = [1.0, 1.0]
        showBorder(0.0)
        m.shadow.opacity = 0.55
    else
        onFocusChanged()
    end if
end sub
