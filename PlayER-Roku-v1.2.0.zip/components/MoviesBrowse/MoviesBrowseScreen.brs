function init()
    m.loading = m.top.findNode("LoadingIndicator")
    m.logoImage = m.top.findNode("logoImage")
    m.profileAvatarBg      = m.top.findNode("profileAvatarBg")
    m.profileAvatarInitial = m.top.findNode("profileAvatarInitial")
    m.heroBgFront = m.top.findNode("heroBgFront")
    m.heroBgBack = m.top.findNode("heroBgBack")
    m.heroInfoGroup = m.top.findNode("heroInfoGroup")

    ' Pedido explicito: el fondo de esta pantalla (Peliculas/Series) ya
    ' no debe ser la imagen de marca del panel (panelURL/img/fondo.jpg,
    ' la misma que usa el login y Home), debe quedar NEGRO solido.
    ' baseBg (Poster) ya no recibe ningun uri, asi que queda transparente
    ' y se ve el Rectangle negro que esta debajo de el en el XML
    ' (baseBgBlack). El carrusel de backdrops (heroBgBack/heroBgFront)
    ' sigue dibujandose encima, igual que antes, cuando hay uno disponible.
    m.baseBg = m.top.findNode("baseBg")
    m.heroInfoGroup.visible = false
    m.heroTitle = m.top.findNode("heroTitle")
    m.heroRating = m.top.findNode("heroRating")
    m.heroRatingBg = m.top.findNode("heroRatingBg")
    m.heroRatingIcon = m.top.findNode("heroRatingIcon")
    m.heroYearIcon  = m.top.findNode("heroYearIcon")
    m.heroDurIcon   = m.top.findNode("heroDurIcon")
    m.heroYear = m.top.findNode("heroYear")
    m.heroDesc     = m.top.findNode("heroDesc")
    m.heroGenre    = m.top.findNode("heroGenre")
    m.heroDuration = m.top.findNode("heroDuration")
    m.heroFadeOut  = m.top.findNode("heroFadeOut")
    m.heroFadeIn = m.top.findNode("heroFadeIn")
    m.heroFadeOut.observeField("state", "onHeroCrossfadeComplete")
    m.heroLastUri = ""
    m.heroLastVodId = ""
    m.vodInfoTask = invalid
    m.seriesInfoTask = invalid
    m.backdropCache = {}  ' cache: vodId -> backdropUrl

    ' Carrusel automatico del fondo (reemplaza el fondo-por-foco de
    ' antes, ver loadHeroCarouselSource/showHeroCarouselSlide mas
    ' abajo): los 2 titulos mas recientes de este tipo (peliculas o
    ' series, segun m.top.serie), rotando cada 10s con zoom continuo,
    ' igual que Home y que Android.
    m.heroCarouselTimer = m.top.findNode("heroCarouselTimer")
    m.heroZoomLoop      = m.top.findNode("heroZoomLoop")
    m.heroCarouselTimer.observeField("fire", "onHeroCarouselTimerFire")
    m.heroCarouselItems = []
    m.heroCarouselIndex = -1
    m.heroCarouselTasks = []

    ' Nav highlight
    m.navBgs = []
    m.navLabels = []
    m.totalNavItems = 7
    for i = 0 to m.totalNavItems - 1
        m.navBgs.push(m.top.findNode("navBg" + i.toStr()))
        m.navLabels.push(m.top.findNode("navLabel" + i.toStr()))
    end for
    m.navFocusedIndex = -1
    GU_FillProfileNavItem(m.profileAvatarBg, m.profileAvatarInitial, m.navLabels[6])
    ' Highlight current screen (Movies=2, Series=3)
    m.currentScreenNav = 2

    m.MAX_VISIBLE_ROWS = 2
    m.catLabels = []
    m.catHints = []  ' "Preciona REPLAY para ver categoría" -- va siempre junto con catLabel
    m.catCounts = []  ' mantenido por compatibilidad pero vacío
    m.catGrids = []
    for i = 0 to 2  ' 3 filas: 0,1 visibles + 2 preload
        m.catLabels.push(m.top.findNode("catLabel" + i.toStr()))
        m.catHints.push(m.top.findNode("catHint" + i.toStr()))
        m.catCounts.push(invalid)  ' nodos eliminados del XML
        grid = m.top.findNode("catGrid" + i.toStr())
        ' Pedido explicito: el fondo ya NO sigue el foco de las
        ' categorias (ver carrusel automatico arriba), por eso ya no se
        ' observa "itemFocused" hacia onGridItemFocused (queda sin
        ' usar, definida por si algo mas la llamara pero nada la conecta ya).
        grid.observeField("itemSelected", "onGridItemSelected")
        m.catGrids.push(grid)
    end for
    m.rowsWrapper    = m.top.findNode("rowsWrapper")
    m.rowFadeBottom  = m.top.findNode("rowFadeBottom")
    m.scrollAnimDown = m.top.findNode("scrollAnimDown")
    m.scrollAnimUp   = m.top.findNode("scrollAnimUp")
    m.scrollInterpDown = m.top.findNode("scrollInterpDown")
    m.scrollInterpUp   = m.top.findNode("scrollInterpUp")
    m.scrollAnimDown.observeField("state", "onScrollDone")
    m.scrollAnimUp.observeField("state", "onScrollDone")
    m.wrapperY = 0   ' posición Y actual del wrapper
    m.isScrolling = false
    m.pendingDirection = 0
    m.rowCurrentCatId = ["", "", ""]  ' catId actualmente asignado a cada fila física

    m.detailsScreen = m.top.findNode("DetailsScreen")
    m.detailsScreen.observeField("requestClose", "onDetailsRequestClose")
    m.detailsScreen.observeField("visible", "onOverlayVisibleChanged")
    m.seasons = m.top.findNode("Seasons")
    m.seasons.observeField("visible", "onOverlayVisibleChanged")
    m.catFullScreen = m.top.findNode("catFullScreen")
    m.catFullTitle = m.top.findNode("catFullTitle")
    m.catFullGrid = m.top.findNode("catFullGrid")
    m.catFullBackHint = m.top.findNode("catFullBackHint")
    fcInit = m.global.focusColor
    if fcInit = invalid or fcInit = "" then fcInit = "0xE50914FF"
    m.catFullGrid.focusBitmapBlendColor = fcInit
    if m.catFullBackHint <> invalid then m.catFullBackHint.color = fcInit
    m.catFullGrid.observeField("itemSelected", "onFullGridItemSelected")

    m.categories = invalid
    m.categoryContents = {}
    m.focusZone = "grid"
    m.focusedRowIndex = 0
    m.scrollOffset = 0
    m.pendingOpenItem = invalid
    m.pinDlg = invalid
    m.pinWrongDlg = invalid
    m.totalCategories = 0

    m.top.observeField("serie", "onSerieChanged")
    loadRemoteAssets()
    m.categoriesLoadStarted = false
    m.top.observeField("focusedChild", "OnFocusedChildChange")

    ' --- Color de marca (focusColor del config.json) ---
    m.global.observeField("focusColor", "onFocusColorChanged")
end function

sub onFocusColorChanged()
    if m.navFocusedIndex >= 0
        updateNavHighlight()
    end if
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"
    if m.catFullGrid <> invalid then m.catFullGrid.focusBitmapBlendColor = fc
    if m.catFullBackHint <> invalid then m.catFullBackHint.color = fc
end sub

sub onSerieChanged()
    if m.top.serie
        m.currentScreenNav = 3 ' Series
    else
        m.currentScreenNav = 2 ' Movies
    end if
    showCurrentScreenNav()

    ' m.top.serie llega DESPUES de createObject() (MainScene lo asigna
    ' luego de crear el nodo), asi que loadCategories() no puede
    ' llamarse desde init() -- ahi todavia tendria el valor por
    ' default. Se dispara aqui, la primera vez que este observer
    ' corre, cuando el valor ya es el real.
    if not m.categoriesLoadStarted
        m.categoriesLoadStarted = true
        loadCategories()
        loadHeroCarouselSource()
    end if
end sub

sub showCurrentScreenNav()
    ' Sin highlight - todo apagado igual que Home
    for i = 0 to m.totalNavItems - 1
        m.navBgs[i].color = "0x00000000"
        m.navBgs[i].opacity = 0.0
        m.navLabels[i].color = "0xAAAAAAFF"
    end for
end sub

sub updateNavHighlight()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"
    for i = 0 to m.totalNavItems - 1
        if i = m.navFocusedIndex
            m.navBgs[i].color = fc
            m.navBgs[i].opacity = 0.8
            m.navLabels[i].color = "0xFFFFFFFF"
        else if i = m.currentScreenNav
            m.navBgs[i].color = fc
            m.navBgs[i].opacity = 0.5
            m.navLabels[i].color = "0xFFFFFFFF"
        else
            m.navBgs[i].color = "0x00000000"
            m.navBgs[i].opacity = 0.0
            m.navLabels[i].color = "0xAAAAAAFF"
        end if
    end for
end sub

sub clearNavHighlight()
    for i = 0 to m.totalNavItems - 1
        m.navBgs[i].color = "0x00000000"
        m.navBgs[i].opacity = 0.0
        m.navLabels[i].color = "0xAAAAAAFF"
    end for
    m.navFocusedIndex = -1
end sub

sub goToNav()
    for i = 0 to m.MAX_VISIBLE_ROWS - 1
        m.catGrids[i].setFocus(false)
    end for
    m.focusZone = "nav"
    m.navFocusedIndex = m.currentScreenNav
    updateNavHighlight()
    m.top.setFocus(true)
end sub

sub loadRemoteAssets()
    dt = CreateObject("roDateTime").AsSeconds().ToStr()
    m.logoImage.uri = m.global.panelURL + "/img/logo.png?ts=" + dt
end sub

Sub OnFocusedChildChange()
    if m.top.hasFocus()
        if m.focusZone = "grid" and m.focusedRowIndex >= 0 and m.focusedRowIndex < m.MAX_VISIBLE_ROWS
            m.catGrids[m.focusedRowIndex].setFocus(true)
        end if
    end if
End Sub

function safeStr(val as dynamic) as string
    if val = invalid then return ""
    vt = type(val)
    if vt = "roString" or vt = "String" then return val
    if vt = "roInt" or vt = "roInteger" or vt = "Integer" then return val.toStr()
    if vt = "roFloat" or vt = "Float" then return str(int(val)).trim()
    if vt = "roDouble" or vt = "Double" then return str(int(val)).trim()
    if vt = "roLongInteger" or vt = "LongInteger" then return val.toStr()
    return ""
end function

' tipo/usuario usados para leer y escribir el cache local de
' categorias (CategoriesLocalStore.brs). "tipo" depende de si esta
' pantalla esta en modo Peliculas o Series (m.top.serie).
function catTipoActual() as String
    if m.top.serie then return "series"
    return "vod"
end function

function catUsuarioActual() as String
    return getStrValFromReg("user_tv", "datos_tv")
end function

sub loadCategories()
    ' 1) Si hay cache local (de una sesion anterior o de un sync
    ' previo), pintar de inmediato -- el cliente no espera red.
    huboCacheLocal = loadCategoriesFromLocalCache()
    if not huboCacheLocal
        m.loading.control = "start"
    end if

    ' 2) Refrescar nombres de categoria contra el servidor (rapido,
    ' un solo request) -- detecta categorias nuevas/eliminadas.
    m.catTask = CreateObject("roSGNode", "GetContent")
    m.catTask.observeField("contentSet", "onCategoriesLoaded")
    m.catTask.cat = ""
    m.catTask.control = "RUN"

    ' 3) Sincronizacion COMPLETA (nombres + contenido de cada
    ' categoria) en segundo plano y en silencio. Nunca bloquea ni
    ' interrumpe lo que el cliente ya esta viendo/navegando.
    startCategoriesBackgroundSync()
end sub

' Pinta desde el cache local en disco (cachefs) si existe. Devuelve
' true si encontro y pinto algo, false si no habia cache todavia
' (primera vez que se usa la app, por ejemplo).
function loadCategoriesFromLocalCache() as Boolean
    tipo = catTipoActual()
    usuario = catUsuarioActual()
    idx = Cat_LocalReadIndex(usuario, tipo)
    if idx = invalid or idx.categories = invalid or idx.categories.count() = 0 then return false

    m.categories = idx.categories
    m.totalCategories = m.categories.count()
    m.scrollOffset = 0
    m.focusedRowIndex = 0
    m.wrapperY = 0
    m.rowsWrapper.translation = [0, 0]

    ' Precargar en RAM el contenido cacheado de las primeras filas
    ' visibles (las demas se cargan bajo demanda igual que siempre,
    ' via preloadAhead/loadCategoryContentForRow).
    for i = 0 to 2
        if i < m.totalCategories
            catId = safeStr(m.categories[i].category_id)
            if not m.categoryContents.DoesExist(catId)
                items = Cat_LocalReadCategoryItems(usuario, tipo, catId)
                if items <> invalid
                    m.categoryContents[catId] = Cat_ItemsToContentNode(items)
                end if
            end if
        end if
    end for

    displayVisibleRows()
    m.loading.control = "stop"
    if m.catGrids[0].content <> invalid and m.catGrids[0].content.getChildCount() > 0
        m.catGrids[0].setFocus(true)
    end if
    return true
end function

' Dispara la sync completa (nombres + contenido de TODAS las
' categorias) en un Task aparte. Se llama una vez por entrada a la
' pantalla; si ya hay una corriendo, no se duplica.
sub startCategoriesBackgroundSync()
    if m.catsSyncTask <> invalid and m.catsSyncTask.control = "RUN" then return
    task = CreateObject("roSGNode", "CategoriesSyncTask")
    task.isSerie = m.top.serie
    task.observeField("syncComplete", "onCategoriesBackgroundSyncDone")
    task.control = "RUN"
    m.catsSyncTask = task
end sub

' La sync ya escribio todo en disco (CategoriesLocalStore). Aqui solo
' refrescamos en RAM (m.categoryContents) las categorias que el
' cliente NO esta viendo ahora mismo -- las visibles se quedan tal
' cual hasta que el cliente se aleje de ellas, para que la
' actualizacion nunca se note ni interrumpa su navegacion actual.
sub onCategoriesBackgroundSyncDone()
    if m.categories = invalid then return
    tipo = catTipoActual()
    usuario = catUsuarioActual()

    for i = 0 to m.totalCategories - 1
        catId = safeStr(m.categories[i].category_id)
        filaVisibleAhora = false
        for row = 0 to 2
            if m.scrollOffset + row = i then filaVisibleAhora = true
        end for

        if not filaVisibleAhora
            items = Cat_LocalReadCategoryItems(usuario, tipo, catId)
            if items <> invalid
                m.categoryContents[catId] = Cat_ItemsToContentNode(items)
            end if
        end if
        ' Si esta visible ahora, no se toca: se refresca sola la
        ' proxima vez que esa categoria deje de estar en pantalla
        ' (mismo criterio que ya usan onPreloadDone/handleRowLoaded
        ' para nunca pisar un grid con contenido ya asignado).
    end for
end sub

sub onCategoriesLoaded()
    huboCategoriasAntes = (m.categories <> invalid and m.totalCategories > 0)

    if m.catTask.categories <> invalid
        ' Filtrar adultas y bloqueadas (nuevo API parental)
        pcTipo = "vod"
        if m.top.serie then pcTipo = "series"
        filtered = []
        if m.catTask.categories <> invalid
            for each catItem in m.catTask.categories
                catName = ""
                if catItem.category_name <> invalid then catName = catItem.category_name
                catId = PC_id(catItem.category_id)
                if not PC_isAdultName(catName) and not PC_isCatBlocked(catId, pcTipo)
                    filtered.push(catItem)
                end if
            end for
        end if
        m.categories = filtered
        m.totalCategories = m.categories.count()
        ' NOTA: aqui ya NO se escribe a CategoriesLocalStore -- esta
        ' funcion corre en el hilo de RENDER (MoviesBrowseScreen es un
        ' Group), y roFileSystem (usado por Cat_LocalWriteIndex) solo
        ' se puede crear en hilos MAIN o TASK. El indice de categorias
        ' se sigue guardando bien desde CategoriesSyncTask (que si es
        ' un Task) al terminar la sync completa.
    end if

    if not huboCategoriasAntes
        ' No habia cache local pintado todavia (primera vez que se
        ' usa la app, o cache vacio): comportamiento igual que antes,
        ' pintar desde cero.
        m.scrollOffset = 0
        m.focusedRowIndex = 0
        m.wrapperY = 0
        m.rowsWrapper.translation = [0, 0]
        displayVisibleRows()
        m.loading.control = "stop"
        if m.catGrids[0].content <> invalid and m.catGrids[0].content.getChildCount() > 0
            m.catGrids[0].setFocus(true)
        end if
    end if
    ' Si ya habia cache local pintado, el cliente ya esta navegando --
    ' no se toca scroll ni foco. m.categories ya quedo actualizado
    ' arriba para que fullscreen/scrolls futuros usen la lista fresca.
    preloadCategories()
end sub

sub preloadCategories()
    ' Precargar desde scrollOffset+2 hasta scrollOffset+6
    preloadAhead(m.scrollOffset)
end sub

sub preloadAhead(fromIdx as Integer)
    if m.categories = invalid then return
    startI = fromIdx + 2
    endI   = fromIdx + 7
    if endI >= m.totalCategories then endI = m.totalCategories - 1
    for i = startI to endI
        catId = safeStr(m.categories[i].category_id)
        if not m.categoryContents.DoesExist(catId)
            taskKey = "preTask_" + catId
            if m[taskKey] = invalid
                task = CreateObject("roSGNode", "HomeContentTask")
                task.taskType = "categoryItems"
                task.categoryId = catId
                task.rowIndex = i
                task.isSerie = m.top.serie
                task.observeField("contentResults", "onPreloadDone")
                task.control = "RUN"
                m[taskKey] = task
            end if
        end if
    end for
end sub

sub onPreloadDone()
    if m.categories = invalid then return
    for i = 0 to m.totalCategories - 1
        catId = safeStr(m.categories[i].category_id)
        taskKey = "preTask_" + catId
        task = m[taskKey]
        if task <> invalid and task.contentResults <> invalid and type(task.contentResults) = "roSGNode"
            if not m.categoryContents.DoesExist(catId)
                m.categoryContents[catId] = task.contentResults
                ' Si esta categoría está visible ahora, actualizar la fila
                for row = 0 to 2
                    if m.scrollOffset + row = i
                        grid = m.catGrids[row]
                        ' Solo asignar si el grid está vacío - nunca sobreescribir content existente
                        if grid.content = invalid or grid.content.getChildCount() = 0
                            grid.content = task.contentResults
                            if row < m.MAX_VISIBLE_ROWS
                                grid.visible = true
                                m.catLabels[row].visible = true
                                m.catHints[row].visible = true
                                catIdx2 = m.scrollOffset + row
                                if catIdx2 < m.totalCategories and m.categories <> invalid
                                    ' Pedido explicito: solo el nombre, sin el conteo de items.
                                    m.catLabels[row].text = m.categories[catIdx2].category_name
                                end if
                            end if
                        else
                            ' Ya tiene content, nada que actualizar en el label
                            ' (solo el nombre, ya se puso arriba).
                        end if
                    end if
                end for
            end if
            m[taskKey] = invalid
        end if
    end for
end sub

' El degradado inferior vive por encima de todo (declarado al final del
' XML para quedar sobre las portadas) -- pero eso tambien lo pone
' encima de Detalles/Temporadas (incluyendo el reproductor de video).
' Se oculta mientras cualquiera de esos este abierto.
sub onOverlayVisibleChanged()
    overlayOpen = false
    if m.detailsScreen <> invalid and m.detailsScreen.visible then overlayOpen = true
    if m.seasons <> invalid and m.seasons.visible then overlayOpen = true

    if overlayOpen
        if m.rowFadeBottom <> invalid then m.rowFadeBottom.visible = false
    else
        displayVisibleRows()
    end if
end sub

sub displayVisibleRows()
    for i = 0 to 2
        catIdx = m.scrollOffset + i
        if catIdx < m.totalCategories and m.categories <> invalid
            cat = m.categories[catIdx]
            catId = safeStr(cat.category_id)
            m.catGrids[i].visible = (i < m.MAX_VISIBLE_ROWS)
            m.catLabels[i].visible = (i < m.MAX_VISIBLE_ROWS)
            m.catHints[i].visible = (i < m.MAX_VISIBLE_ROWS)

            ' Solo reasignar si la categoría realmente cambió
            if m.rowCurrentCatId[i] <> catId
                m.rowCurrentCatId[i] = catId
                if m.categoryContents.DoesExist(catId)
                    cn = m.categoryContents[catId]
                    m.catGrids[i].content = cn
                    ' Pedido explicito: solo el nombre de la categoria, sin
                    ' el conteo de items (antes: "(418) VOD - AVENTURA").
                    m.catLabels[i].text = cat.category_name
                else
                    m.catGrids[i].content = invalid
                    m.catLabels[i].text = cat.category_name
                    loadCategoryContentForRow(catId, i)
                end if
            end if
        else
            if m.rowCurrentCatId[i] <> ""
                m.rowCurrentCatId[i] = ""
                m.catLabels[i].visible = false
                m.catHints[i].visible = false
                m.catGrids[i].visible = false
                m.catGrids[i].content = invalid
            end if
        end if
    end for
    preloadAhead(m.scrollOffset)

    ' Degradado de abajo: solo visible si hay una categoria mas
    ' despues de las 2 que se ven ahora (mismo criterio que en Home).
    if m.rowFadeBottom <> invalid
        overlayOpen = false
        if m.detailsScreen <> invalid and m.detailsScreen.visible then overlayOpen = true
        if m.seasons <> invalid and m.seasons.visible then overlayOpen = true
        m.rowFadeBottom.visible = ((m.scrollOffset + m.MAX_VISIBLE_ROWS) < m.totalCategories) and not overlayOpen
    end if
end sub

sub displayVisibleRowsAnimated(direction as Integer)
    if m.isScrolling
        m.pendingDirection = direction
        return
    end if
    m.isScrolling = true
    m.pendingDirection = 0

    ' El wrapper siempre parte de Y=0, animamos 252.3px (distancia real
    ' entre filas)
    m.rowsWrapper.translation = [0, 0]
    if direction = 1  ' scroll DOWN: wrapper sube (-252.3)
        m.scrollInterpDown.keyValue = [[0, 0], [0, -252.3]]
        m.scrollAnimDown.control = "start"
    else  ' scroll UP: wrapper baja (+252.3)
        m.scrollInterpUp.keyValue = [[0, 0], [0, 252.3]]
        m.scrollAnimUp.control = "start"
    end if
end sub

sub onScrollDone()
    if m.scrollAnimDown.state = "stopped" or m.scrollAnimUp.state = "stopped"
        m.isScrolling = false
        ' Resetear wrapper a Y=0 y recargar filas con nuevo scrollOffset
        m.wrapperY = 0
        m.rowsWrapper.translation = [0, 0]
        displayVisibleRows()
        if m.pendingDirection <> 0
            dir = m.pendingDirection
            m.pendingDirection = 0
            displayVisibleRowsAnimated(dir)
        end if
    end if
end sub

sub loadCategoryContentForRow(catId as String, rowIdx as Integer)
    ' Si esta fila ya tenia una tarea corriendo de una categoria por la
    ' que el usuario ya paso (se desplazo rapido antes de que
    ' terminara), se cancela primero. Sin esto, las tareas huerfanas se
    ' iban acumulando y competian por red/CPU con la tarea de la
    ' categoria donde el usuario si se quedo, haciendo que a veces esa
    ' no alcanzara a terminar de cargar.
    prevTask = m["rowTask" + rowIdx.toStr()]
    if prevTask <> invalid
        prevTask.unobserveField("contentResults")
        prevTask.control = "stop"
    end if

    task = CreateObject("roSGNode", "HomeContentTask")
    task.taskType = "categoryItems"
    task.categoryId = catId
    task.rowIndex = rowIdx
    task.isSerie = m.top.serie
    task.observeField("contentResults", "onRowContentLoaded_" + rowIdx.toStr())
    task.control = "RUN"
    m["rowTask" + rowIdx.toStr()] = task
    m["rowTaskCatId" + rowIdx.toStr()] = catId  ' guardar catId al lanzar
end sub

sub onRowContentLoaded_0()
    handleRowLoaded(0)
end sub
sub onRowContentLoaded_1()
    handleRowLoaded(1)
end sub
sub onRowContentLoaded_2()
    handleRowLoaded(2)
end sub

sub handleRowLoaded(rowIdx as Integer)
    task = m["rowTask" + rowIdx.toStr()]
    if task = invalid then return
    newContent = task.contentResults
    catId = m["rowTaskCatId" + rowIdx.toStr()]
    if catId = invalid or catId = "" then return
    if newContent = invalid then return

    ' Siempre guardar en cache
    m.categoryContents[catId] = newContent

    ' Si la fila ya no muestra esta categoría, no tocar el grid
    if m.rowCurrentCatId[rowIdx] <> catId then return

    grid = m.catGrids[rowIdx]

    ' Si el grid ya tiene content (fue asignado desde caché), no volver a asignar
    ' Eso causa el parpadeo/recarga visual
    if grid.content <> invalid and grid.content.getChildCount() > 0 then
        ' Pedido explicito: solo el nombre, sin el conteo de items -- el
        ' nombre ya quedo puesto por displayVisibleRows(), nada que
        ' actualizar aqui.
        return
    end if

    ' Grid vacío - asignar por primera vez (sin parpadeo porque estaba vacío)
    grid.content = newContent

    if rowIdx < m.MAX_VISIBLE_ROWS and m.categories <> invalid
        catIdx = m.scrollOffset + rowIdx
        if catIdx < m.totalCategories
            m.catLabels[rowIdx].text = m.categories[catIdx].category_name
        end if
    end if

    if rowIdx = m.focusedRowIndex and newContent.getChildCount() > 0
        if not (grid.hasFocus() or grid.isInFocusChain())
            ' Si esta fila (la que deberia tener el foco) nunca llego a
            ' tenerlo, es porque se entro a esta categoria SIN cache
            ' local (cuenta nueva, o primera vez con este tipo) y el
            ' contenido tardo en llegar por red -- displayVisibleRows()
            ' dejo el grid vacio (content=invalid) en ese momento, asi
            ' que loadCategoriesFromLocalCache()/onCategoriesLoaded()
            ' nunca pudieron darle setFocus(true) (esas funciones solo
            ' enfocan si YA hay contenido). Sin este respaldo, el
            ' control remoto se quedaba sin responder (ningun nodo
            ' tenia el foco). Solo se roba el foco si el usuario sigue
            ' en la zona de grids -- si ya se movio al menu de arriba o
            ' abrio la vista de pantalla completa mientras esto
            ' cargaba, no se le quita el foco de donde este ahora.
            if m.focusZone = "grid"
                grid.setFocus(true)
            end if
        end if
    end if
end sub

sub onGridItemFocused()
    for i = 0 to m.MAX_VISIBLE_ROWS - 1
        grid = m.catGrids[i]
        if grid.hasFocus() or grid.isInFocusChain()
            idx = grid.itemFocused
            if grid.content <> invalid and idx >= 0 and idx < grid.content.getChildCount()
                updateHeroFromItem(grid.content.getChild(idx))
            end if
            exit for
        end if
    end for
end sub

sub updateHeroFromItem(item as Object)
    if item = invalid then return
    m.heroInfoGroup.visible = false

    ' Título sin año
    titulo = item.title
    if titulo = invalid then titulo = ""
    parenIdx = Instr(1, titulo, " (")
    if parenIdx > 1 then titulo = Left(titulo, parenIdx - 1)
    m.heroTitle.text = UCase(titulo)

    m.heroRating.visible = false
    m.heroRatingIcon.visible = false
    m.heroRatingBg.visible = false
    m.heroRating.text = ""
    m.heroYearIcon.visible = false
    m.heroYear.text = ""
    m.heroDurIcon.visible = false
    if m.heroDuration <> invalid then m.heroDuration.text = ""
    if m.heroGenre <> invalid then m.heroGenre.text = ""
    m.heroDesc.text = ""

    m.heroInfoGroup.visible = true

    vodId = item.id
    if vodId = invalid then vodId = ""

    ' Series: revisar cache primero
    if m.top.serie
        ' 1. Cache
        if vodId <> "" and m.backdropCache.DoesExist(vodId)
            cachedUri = m.backdropCache[vodId]
            if cachedUri <> m.heroLastUri
                m.heroLastUri = cachedUri
                m.heroBgBack.uri = cachedUri
                m.heroFadeOut.control = "start"
                m.heroFadeIn.control = "start"
            end if
            return
        end if
        ' 2. Si ya tiene backdrop en nodo usarlo
        if item.hdBackgroundImageUrl <> invalid and item.hdBackgroundImageUrl <> ""
            newUri = item.hdBackgroundImageUrl
            if vodId <> "" then m.backdropCache[vodId] = newUri
            if newUri <> m.heroLastUri
                m.heroLastUri = newUri
                m.heroBgBack.uri = newUri
                m.heroFadeOut.control = "start"
                m.heroFadeIn.control = "start"
            end if
            return
        end if
        ' Respaldo: la portada, guardada para usarse SOLO si
        ' get_series_info confirma que no hay fondo dedicado (ver
        ' onSeriesInfoResult). No se muestra de inmediato aqui -- eso
        ' causaba un "flash" feo (portada -> fondo real) en cada serie
        ' que no traia el fondo ya en la lista.
        m.heroPosterFallback = ""
        if item.HDPosterUrl <> invalid and item.HDPosterUrl <> ""
            m.heroPosterFallback = item.HDPosterUrl
        end if
        ' 3. Llamar get_series_info para obtener backdrop
        if vodId <> "" and vodId <> m.heroLastVodId
            m.heroLastVodId = vodId
            if m.seriesInfoTask <> invalid
                m.seriesInfoTask.control = "stop"
                m.seriesInfoTask = invalid
            end if
            m.seriesInfoTask = CreateObject("roSGNode", "GetSeriesInfo")
            m.seriesInfoTask.seriesId = vodId
            m.seriesInfoTask.observeField("result", "onSeriesInfoResult")
            m.seriesInfoTask.control = "RUN"
        end if
        return
    end if

    ' 1. Revisar cache primero - si ya se cargo antes mostrar directo
    if vodId <> "" and m.backdropCache.DoesExist(vodId)
        cachedUri = m.backdropCache[vodId]
        if cachedUri <> m.heroLastUri
            m.heroLastUri = cachedUri
            m.heroBgBack.uri = cachedUri
            m.heroFadeOut.control = "start"
            m.heroFadeIn.control = "start"
        end if
        return
    end if

    ' 2. Solo para peliculas
    if vodId <> "" and vodId <> m.heroLastVodId
        m.heroLastVodId = vodId
        if m.vodInfoTask <> invalid
            m.vodInfoTask.control = "stop"
            m.vodInfoTask = invalid
    m.seriesInfoTask = invalid
        end if
        m.vodInfoTask = CreateObject("roSGNode", "GetVodInfo")
        m.vodInfoTask.vodId = vodId
        m.vodInfoTask.observeField("result", "onVodInfoResult")
        m.vodInfoTask.control = "RUN"
    end if
end sub

sub onVodInfoResult()
    result = m.vodInfoTask.result
    if result = invalid then return
    vodId = m.heroLastVodId
    if result.hdBackgroundImageUrl <> invalid and result.hdBackgroundImageUrl <> ""
        newUri = result.hdBackgroundImageUrl
        ' Guardar en cache para proxima vez
        if vodId <> ""
            m.backdropCache[vodId] = newUri
        end if
        ' Actualizar el ContentNode para que quede guardado en el grid
        for i = 0 to m.MAX_VISIBLE_ROWS - 1
            grid = m.catGrids[i]
            if grid.content <> invalid
                for j = 0 to grid.content.getChildCount() - 1
                    node = grid.content.getChild(j)
                    if node.id = vodId
                        node.hdBackgroundImageUrl = newUri
                        exit for
                    end if
                end for
            end if
        end for
        ' Mostrar backdrop ahora
        if newUri <> m.heroLastUri
            m.heroLastUri = newUri
            m.heroBgBack.uri = newUri
            m.heroFadeOut.control = "start"
            m.heroFadeIn.control = "start"
        end if
    end if
end sub

sub onSeriesInfoResult()
    result = m.seriesInfoTask.result
    if result = invalid then return
    vodId = m.seriesInfoTask.seriesId
    if result.hdBackgroundImageUrl <> invalid and result.hdBackgroundImageUrl <> ""
        newUri = result.hdBackgroundImageUrl
        if vodId <> "" then m.backdropCache[vodId] = newUri
        ' Guardar en ContentNode
        for i = 0 to m.MAX_VISIBLE_ROWS - 1
            grid = m.catGrids[i]
            if grid.content <> invalid
                for j = 0 to grid.content.getChildCount() - 1
                    node = grid.content.getChild(j)
                    if node.id = vodId
                        node.hdBackgroundImageUrl = newUri
                        exit for
                    end if
                end for
            end if
        end for
        ' Solo actualizar si sigue siendo el enfocado
        if vodId = m.heroLastVodId
            if newUri <> m.heroLastUri
                m.heroLastUri = newUri
                m.heroBgBack.uri = newUri
                m.heroFadeOut.control = "start"
                m.heroFadeIn.control = "start"
            end if
        end if
    else if vodId = m.heroLastVodId and m.heroPosterFallback <> invalid and m.heroPosterFallback <> "" and m.heroPosterFallback <> m.heroLastUri
        ' El servidor confirma que esta serie no tiene fondo dedicado:
        ' se usa la portada como ultimo recurso (unica transicion aqui,
        ' no hay "flash" porque es la primera vez que se toca el fondo
        ' para este item).
        m.heroLastUri = m.heroPosterFallback
        m.heroBgBack.uri = m.heroPosterFallback
        m.heroFadeOut.control = "start"
        m.heroFadeIn.control = "start"
    end if
end sub

sub onHeroCrossfadeComplete()
    if m.heroFadeOut.state = "stopped"
        m.heroBgFront.uri = m.heroBgBack.uri
        m.heroBgFront.opacity = 1.0
        m.heroBgBack.opacity = 0.0
        ' La imagen que acaba de quedar al frente arranca su propio
        ' zoom continuo de 10s (se detiene y reinicia en cada cambio de
        ' diapositiva, ver setHeroCarouselUri).
        if m.heroZoomLoop <> invalid
            m.heroZoomLoop.control = "stop"
            m.heroZoomLoop.control = "start"
        end if
    end if
end sub

' ============================================================
' Carrusel automatico del fondo de esta pantalla (Peliculas o Series,
' segun m.top.serie) -- reemplaza el sistema anterior de "fondo sigue
' al foco" (updateHeroFromItem/onGridItemFocused, que ya no se
' conecta a nada). Esta pantalla no tiene su propia fila de "Recien
' Agregados" como Home -- se reutiliza el mismo HomeContentTask
' (taskType "recentMovies"/"recentSeries") para pedir los 2 titulos
' mas recientes de este tipo.
' ============================================================

sub loadHeroCarouselSource()
    task = CreateObject("roSGNode", "HomeContentTask")
    if m.top.serie
        task.taskType = "recentSeries"
    else
        task.taskType = "recentMovies"
    end if
    task.observeField("contentResults", "onHeroCarouselSourceLoaded")
    task.control = "RUN"
    m.heroCarouselSourceTask = task
end sub

sub onHeroCarouselSourceLoaded()
    if m.heroCarouselSourceTask = invalid then return
    content = m.heroCarouselSourceTask.contentResults
    if content = invalid then return

    isSerieNow = m.top.serie
    items = []
    for i = 0 to 1
        if i < content.getChildCount()
            items.push({ node: content.getChild(i), isSerie: isSerieNow })
        end if
    end for

    m.heroCarouselItems = items
    if items.count() = 0 then return

    m.heroCarouselIndex = 0
    showHeroCarouselSlide(0)
    if m.heroCarouselTimer <> invalid then m.heroCarouselTimer.control = "start"
end sub

sub onHeroCarouselTimerFire()
    if m.heroCarouselItems = invalid or m.heroCarouselItems.count() = 0 then return
    nextIdx = (m.heroCarouselIndex + 1) mod m.heroCarouselItems.count()
    m.heroCarouselIndex = nextIdx
    showHeroCarouselSlide(nextIdx)
end sub

sub showHeroCarouselSlide(idx as Integer)
    if m.heroCarouselItems = invalid or idx < 0 or idx >= m.heroCarouselItems.count() then return
    entry = m.heroCarouselItems[idx]
    item = entry.node
    if item = invalid then return

    ' Pedido explicito: regresar el titulo del backdrop mostrado (se
    ' actualiza de una vez con la diapositiva, sin esperar a que
    ' termine de cargar/confirmarse el backdrop).
    applyHeroTitleFor(item)

    uri = heroCarouselBackdropUriFor(item)
    if uri = ""
        ' Sin backdrop todavia en el nodo: pedirlo al servidor (mismo
        ' GetVodInfo/GetSeriesInfo que ya se usaba antes para esto) y
        ' mostrar esta diapositiva en cuanto llegue la respuesta.
        fetchHeroCarouselBackdrop(item, entry.isSerie, idx)
        return
    end if

    setHeroCarouselUri(uri)
end sub

' Mismo criterio que el updateHeroFromItem de antes (ver mas abajo, ya
' sin usar): titulo sin el "(año)" del final, en mayusculas. El resto
' de heroInfoGroup (rating/año/duracion/genero/descripcion) nunca tuvo
' datos reales en esta pantalla -- se deja oculto igual que ya quedaba
' antes, solo se muestra el titulo, en la misma posicion que usa
' Android (ver MoviesBrowseScreen.xml, heroTitle).
sub applyHeroTitleFor(item as Object)
    if item = invalid then return
    titulo = item.title
    if titulo = invalid then titulo = ""
    parenIdx = Instr(1, titulo, " (")
    if parenIdx > 1 then titulo = Left(titulo, parenIdx - 1)
    m.heroTitle.text = UCase(titulo)

    m.heroRating.visible = false
    m.heroRatingIcon.visible = false
    m.heroRatingBg.visible = false
    m.heroRating.text = ""
    m.heroYearIcon.visible = false
    m.heroYear.text = ""
    m.heroDurIcon.visible = false
    if m.heroDuration <> invalid then m.heroDuration.text = ""
    if m.heroGenre <> invalid then m.heroGenre.text = ""
    m.heroDesc.text = ""

    m.heroInfoGroup.visible = true
end sub

' Pedido explicito: se estaba mostrando la PORTADA en vez del backdrop
' real -- esta funcion regresaba HDPosterUrl/streamIcon de inmediato
' cuando el nodo no traia hdBackgroundImageUrl ya cargado, y los items
' de "recien agregados" casi nunca lo traen (eso requiere consultar
' get_vod_info/get_series_info aparte). Ahora SOLO reporta un backdrop
' ya confirmado; si no hay, showHeroCarouselSlide pide el real al
' servidor (fetchHeroCarouselBackdrop) y la portada queda solo como
' ultimo recurso, SOLO si el servidor confirma que no hay backdrop
' dedicado (ver onHeroCarouselBackdropResult).
function heroCarouselBackdropUriFor(item as Object) as String
    if item = invalid then return ""
    if item.hdBackgroundImageUrl <> invalid and item.hdBackgroundImageUrl <> "" then return item.hdBackgroundImageUrl
    return ""
end function

function heroCarouselPosterFallbackFor(item as Object) as String
    if item = invalid then return ""
    if item.HDPosterUrl <> invalid and item.HDPosterUrl <> "" and item.HDPosterUrl <> "pkg:/images/no-poster.jpg" then return item.HDPosterUrl
    if item.streamIcon <> invalid and item.streamIcon <> "" and item.streamIcon <> "pkg:/images/no-poster.jpg" then return item.streamIcon
    return ""
end function

sub setHeroCarouselUri(uri as String)
    if uri = "" or uri = m.heroLastUri then return
    m.heroLastUri = uri
    if m.heroZoomLoop <> invalid then m.heroZoomLoop.control = "stop"
    m.heroBgBack.uri = uri
    m.heroFadeOut.control = "start"
    m.heroFadeIn.control = "start"
end sub

sub fetchHeroCarouselBackdrop(item as Object, isSerie as Boolean, idx as Integer)
    vodId = item.id
    if vodId = invalid or vodId = ""
        ' Sin id no se puede consultar al servidor -- unico caso en que
        ' se usa la portada de una vez, sin esperar nada.
        setHeroCarouselUri(heroCarouselPosterFallbackFor(item))
        return
    end if
    if isSerie
        task = CreateObject("roSGNode", "GetSeriesInfo")
        task.seriesId = vodId
    else
        task = CreateObject("roSGNode", "GetVodInfo")
        task.vodId = vodId
    end if
    task.addFields({ carouselIdx: idx, carouselPosterFallback: heroCarouselPosterFallbackFor(item) })
    task.observeField("result", "onHeroCarouselBackdropResult")
    if m.heroCarouselTasks = invalid then m.heroCarouselTasks = []
    m.heroCarouselTasks.push(task)
    task.control = "RUN"
end sub

sub onHeroCarouselBackdropResult(event as Object)
    task = event.getRoSGNode()
    if task = invalid then return
    result = task.result
    idx = task.carouselIdx
    posterFallback = task.carouselPosterFallback
    if posterFallback = invalid then posterFallback = ""

    uri = ""
    if result <> invalid and result.hdBackgroundImageUrl <> invalid and result.hdBackgroundImageUrl <> "" then uri = result.hdBackgroundImageUrl

    if uri <> "" and m.heroCarouselItems <> invalid and idx >= 0 and idx < m.heroCarouselItems.count()
        entry = m.heroCarouselItems[idx]
        if entry <> invalid and entry.node <> invalid then entry.node.hdBackgroundImageUrl = uri
    end if

    ' El servidor confirma que este titulo no tiene backdrop dedicado:
    ' AHORA si se usa la portada, como ultimo recurso.
    if uri = "" then uri = posterFallback
    if uri = "" then return

    ' Solo se pinta ahora si el carrusel sigue en (o esta a punto de
    ' mostrar) precisamente esta diapositiva.
    if idx = m.heroCarouselIndex then setHeroCarouselUri(uri)
end sub

sub onGridItemSelected()
    for i = 0 to m.MAX_VISIBLE_ROWS - 1
        grid = m.catGrids[i]
        if grid.hasFocus()
            idx = grid.itemSelected
            if grid.content <> invalid and idx >= 0 and idx < grid.content.getChildCount()
                openItem(grid.content.getChild(idx))
            end if
            exit for
        end if
    end for
end sub

sub onFullGridItemSelected()
    idx = m.catFullGrid.itemSelected
    if m.catFullGrid.content <> invalid and idx >= 0 and idx < m.catFullGrid.content.getChildCount()
        openItem(m.catFullGrid.content.getChild(idx))
    end if
end sub

sub openItem(item as Object)
    if item = invalid then return
    catIdx = m.scrollOffset + m.focusedRowIndex
    if catIdx >= 0 and m.categories <> invalid and catIdx < m.totalCategories
        cat     = m.categories[catIdx]
        catId   = PC_id(cat.category_id)
        catName = ""
        if cat.category_name <> invalid then catName = cat.category_name
        pcTipo = "vod"
        if m.top.serie then pcTipo = "series"
        if PC_isCatBlocked(catId, pcTipo)
            m.pendingOpenItem = item
            showParentalPin()
            return
        end if
    end if
    doOpenItem(item)
end sub

sub showParentalPin()
    dlg = createObject("roSGNode", "StandardKeyboardDialog")
    dlg.title   = "Control Parental"
    dlg.message = "Enter PIN to access this content"
    dlg.buttons = ["OK", "Cancel"]
    dlg.observeField("buttonSelected", "onParentalPinResult")
    m.pinDlg = dlg
    m.top.getScene().dialog = dlg
end sub

sub onParentalPinResult()
    if m.pinDlg = invalid then return
    btn  = m.pinDlg.buttonSelected
    text = m.pinDlg.text.trim()
    m.top.getScene().dialog = invalid
    m.pinDlg = invalid

    if btn <> 0
        ' Cancel
        m.pendingOpenItem = invalid
        return
    end if

    stored = PC_getPin()
    if stored = "" then stored = "0000"

    if text = stored
        if m.pendingOpenItem <> invalid
            item = m.pendingOpenItem
            m.pendingOpenItem = invalid
            doOpenItem(item)
        end if
    else
        dlg2 = createObject("roSGNode", "StandardMessageDialog")
        dlg2.title   = "Control Parental"
        dlg2.message = "PIN Incorrecto"
        dlg2.buttons = ["Volver a Intentar", "Cancelar"]
        dlg2.observeField("buttonSelected", "onPinWrongResult")
        m.pinWrongDlg = dlg2
        m.top.getScene().dialog = dlg2
    end if
end sub

sub onPinWrongResult()
    if m.pinWrongDlg = invalid then return
    btn = m.pinWrongDlg.buttonSelected
    m.top.getScene().dialog = invalid
    m.pinWrongDlg = invalid
    if btn = 0
        showParentalPin()   ' Try again
    else
        m.pendingOpenItem = invalid
    end if
end sub

sub doOpenItem(item as Object)
    if item = invalid then return
    if m.top.serie
        m.seasons.content = item
        m.seasons.visible = true
        m.seasons.setFocus(true)
    else
        resetMovieDiag(item)
        m.detailsScreen.content = item
        m.detailsScreen.visible = true
        m.detailsScreen.setFocus(true)
    end if
end sub

sub openCategoryFullScreen()
    catIdx = m.scrollOffset + m.focusedRowIndex
    if catIdx >= m.totalCategories or m.categories = invalid then return
    cat = m.categories[catIdx]
    catId = safeStr(cat.category_id)
    m.catFullTitle.text = cat.category_name
    if m.categoryContents.DoesExist(catId)
        cn = m.categoryContents[catId]
        ' PosterGrid (nativo) NO lee "title" para el texto de abajo del
        ' poster -- usa ShortDescriptionLine1. Nuestros nodos solo traen
        ' "title" (para el grid custom BrowseCardItem de arriba), asi
        ' que se copia aqui para que el titulo si aparezca en pantalla
        ' completa.
        for i = 0 to cn.getChildCount() - 1
            node = cn.getChild(i)
            if (node.ShortDescriptionLine1 = invalid or node.ShortDescriptionLine1 = "") and node.title <> invalid
                node.ShortDescriptionLine1 = node.title
            end if
        end for
        m.catFullGrid.content = cn
    end if
    m.catFullScreen.visible = true
    m.catFullGrid.setFocus(true)
    m.focusZone = "fullscreen"
end sub

sub closeCategoryFullScreen()
    m.catFullScreen.visible = false
    m.focusZone = "grid"
    m.catGrids[m.focusedRowIndex].setFocus(true)
end sub

sub onDetailsRequestClose()
    if m.detailsScreen = invalid then return
    m.detailsScreen.visible = false
    if m.focusZone = "fullscreen"
        m.catFullGrid.setFocus(true)
    else
        m.catGrids[m.focusedRowIndex].setFocus(true)
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    ' Bloquear navegacion cuando el video esta activo
    if m.detailsScreen <> invalid and m.detailsScreen.videoPlayerVisible = true
        if key = "back"
            m.detailsScreen.videoPlayerVisible = false
        end if
        return true
    end if
    if m.seasons <> invalid and m.seasons.videoPlayerVisible = true
        if key = "back"
            m.seasons.videoPlayerVisible = false
        end if
        return true
    end if

    if key = "options"
        if m.detailsScreen <> invalid and m.detailsScreen.visible then return false
        if m.seasons <> invalid and m.seasons.visible then return false
        if m.focusZone = "fullscreen" then closeCategoryFullScreen()
        return false
    end if

    if key = "back"
        if m.detailsScreen <> invalid and m.detailsScreen.visible = true
            if m.detailsScreen.videoPlayerVisible = true
                m.detailsScreen.videoPlayerVisible = false
            else
                m.detailsScreen.visible = false
                if m.focusZone = "fullscreen"
                    m.catFullGrid.setFocus(true)
                else
                    m.catGrids[m.focusedRowIndex].setFocus(true)
                end if
            end if
            return true
        end if
        if m.seasons <> invalid and m.seasons.visible = true
            if m.seasons.videoPlayerVisible = true
                m.seasons.videoPlayerVisible = false
            else
                m.seasons.visible = false
                if m.focusZone = "fullscreen"
                    m.catFullGrid.setFocus(true)
                else
                    m.catGrids[m.focusedRowIndex].setFocus(true)
                end if
            end if
            return true
        end if
        if m.focusZone = "fullscreen"
            closeCategoryFullScreen()
            return true
        end if
        return false
    end if

    if m.focusZone = "fullscreen"
        return false
    end if

    if m.focusZone = "nav"
        if key = "right"
            if m.navFocusedIndex < m.totalNavItems - 1
                m.navFocusedIndex = m.navFocusedIndex + 1
            else
                m.navFocusedIndex = 0
            end if
            updateNavHighlight()
            return true
        else if key = "left"
            if m.navFocusedIndex > 0
                m.navFocusedIndex = m.navFocusedIndex - 1
            else
                m.navFocusedIndex = m.totalNavItems - 1
            end if
            updateNavHighlight()
            return true
        else if key = "down"
            clearNavHighlight()
            m.focusZone = "grid"
            m.catGrids[m.focusedRowIndex].setFocus(true)
            return true
        else if key = "OK"
            ' 0=Search 1=Home 2=Movies 3=Series 4=LiveTV 5=Settings
            if m.navFocusedIndex = 0
                m.top.menuItemSelected = 4 ' Search
            else if m.navFocusedIndex = 1
                m.top.menuItemSelected = 5 ' Home
            else if m.navFocusedIndex = 2
                m.top.menuItemSelected = 1 ' Movies
            else if m.navFocusedIndex = 3
                m.top.menuItemSelected = 2 ' Series
            else if m.navFocusedIndex = 4
                m.top.menuItemSelected = 0 ' LiveTV
            else if m.navFocusedIndex = 5
                m.top.menuItemSelected = 3 ' Settings
            else if m.navFocusedIndex = 6
                GU_ShowChangeProfileDialog(m.top, -2) ' Perfil
            end if
            return true
        end if
        return true
    end if

    if m.focusZone = "grid"
        if key = "down"
            ' La fila con foco siempre esta arriba (indice 0). Cualquier
            ' "abajo" desliza una categoria, nunca solo mueve el foco
            ' dentro de la ventana de 2 filas (igual que en Home).
            if m.scrollOffset + 1 < m.totalCategories
                if not m.isScrolling
                    m.catGrids[m.focusedRowIndex].setFocus(false)
                    m.scrollOffset = m.scrollOffset + 1
                    m.focusedRowIndex = 0
                    displayVisibleRowsAnimated(1)
                    m.catGrids[0].setFocus(true)
                end if
            end if
            return true
        else if key = "up"
            if m.scrollOffset > 0
                if not m.isScrolling
                    m.catGrids[m.focusedRowIndex].setFocus(false)
                    m.scrollOffset = m.scrollOffset - 1
                    m.focusedRowIndex = 0
                    displayVisibleRowsAnimated(-1)
                    m.catGrids[0].setFocus(true)
                end if
                return true
            end if
            goToNav()
            return true
        else if key = "replay"
            openCategoryFullScreen()
            return true
        end if
    end if
    return false
end function
