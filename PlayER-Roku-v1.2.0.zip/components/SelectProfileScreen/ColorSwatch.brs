' ============================================================
' ColorSwatch.brs
' ============================================================
' Mismo patron exacto que ProfileTile.brs: un Group focusable con un
' "ring" (aro) que solo se hace visible cuando el nodo tiene el foco,
' y un "fill" (el color de verdad) siempre visible encima. OK dispara
' buttonSelected (alwaysNotify) para que la pantalla padre reaccione;
' todo lo demas (izquierda/derecha/atras) se deja sin manejar para que
' burbujee hacia SelectProfileScreen.brs, exactamente como ya sucede
' con cada ProfileTile.
' ============================================================

sub init()
    m.ring = m.top.findNode("ring")
    m.fill = m.top.findNode("fill")

    m.top.observeField("swatchColor", "onSwatchColorChange")
    m.top.observeField("ringColor", "onRingColorChange")
    m.top.observeField("focused", "onFocusedChange")

    onSwatchColorChange()
    onRingColorChange()
    onFocusedChange()
end sub

sub onSwatchColorChange()
    m.fill.color = m.top.swatchColor
end sub

sub onRingColorChange()
    m.ring.color = m.top.ringColor
end sub

sub onFocusedChange()
    m.ring.visible = m.top.focused
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press and key = "OK"
        ' alwaysNotify="true" en el campo hace que el observer se dispare
        ' aunque el valor booleano no cambie de true a false.
        m.top.buttonSelected = not m.top.buttonSelected
        return true
    end if
    return false
end function
