sub init()
    m.ring         = m.top.findNode("ring")
    m.avatarBg     = m.top.findNode("avatarBg")
    m.initialLabel = m.top.findNode("initialLabel")
    m.nameLabel    = m.top.findNode("nameLabel")
    m.plusV        = m.top.findNode("plusV")
    m.plusH        = m.top.findNode("plusH")

    m.top.observeField("label", "onLabelChange")
    m.top.observeField("initial", "onInitialChange")
    m.top.observeField("avatarColor", "onAvatarColorChange")
    m.top.observeField("ringColor", "onRingColorChange")
    m.top.observeField("isAddTile", "onIsAddTileChange")
    m.top.observeField("focused", "onFocusedChange")

    onLabelChange()
    onInitialChange()
    onAvatarColorChange()
    onRingColorChange()
    onIsAddTileChange()
    onFocusedChange()
end sub

sub onLabelChange()
    m.nameLabel.text = m.top.label
end sub

sub onInitialChange()
    m.initialLabel.text = m.top.initial
end sub

sub onAvatarColorChange()
    m.avatarBg.color = m.top.avatarColor
end sub

sub onRingColorChange()
    m.ring.color = m.top.ringColor
end sub

sub onIsAddTileChange()
    isAdd = m.top.isAddTile
    m.initialLabel.visible = not isAdd
    m.plusV.visible = isAdd
    m.plusH.visible = isAdd
end sub

sub onFocusedChange()
    m.ring.visible = m.top.focused
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press and key = "OK"
        ' alwaysNotify="true" en el campo hace que el observer se dispare
        ' aunque el valor booleano no cambie de true a false.
        m.top.buttonSelected = not m.top.buttonSelected
        return true
    end if
    return false
end function
