' ********** Copyright 2016 Roku Corp.  All Rights Reserved. **********
' MODIFICADO: el spinner son 3 circulos reales (imagen circular +
' blendColor) que toman el focusColor del config.json. Antes eran
' Rectangle con cornerRadius, pero Roku no soporta ese campo en
' Rectangle, asi que se veian como cuadrados en vez de circulos.

sub init()
  m.dot1 = m.top.findNode("dot1")
  m.dot2 = m.top.findNode("dot2")
  m.dot3 = m.top.findNode("dot3")
  m.dotsGroup = m.top.findNode("dotsGroup")
  m.pulseAnimation = m.top.findNode("pulseAnimation")
  m.text = m.top.findNode("text")
  m.fadeAnimation = m.top.findNode("fadeAnimation")
  m.loadingIndicatorGroup = m.top.findNode("loadingIndicatorGroup")
  m.loadingGroup = m.top.findNode("loadingGroup")
  m.background = m.top.findNode("background")

  m.textHeight = 0
  m.textPadding = 0

  ' Tamaño fijo de los circulos y separacion entre ellos
  m.dotSize = 14.0
  m.dotGap  = 10.0

  ' --- Color de marca (focusColor del config.json) ---
  applyBrandColor()
  m.global.observeField("focusColor", "applyBrandColor")

  updateLayout()
  startAnimation()
end sub

' ============================================================
' Aplica el focusColor del config remoto a los 3 circulos. Se
' re-ejecuta si el color cambia despues (por si el config llega
' tarde respecto a cuando se crea este LoadingIndicator).
' ============================================================
sub applyBrandColor()
  fc = m.global.focusColor
  if fc = invalid or fc = "" then fc = "0xE50914FF"
  if m.dot1 <> invalid then m.dot1.blendColor = fc
  if m.dot2 <> invalid then m.dot2.blendColor = fc
  if m.dot3 <> invalid then m.dot3.blendColor = fc
end sub

sub updateLayout()
  ' check for parent node and set observers
  if m.top.getParent() <> invalid
      m.top.getParent().observeField("width", "updateLayout")
      m.top.getParent().observeField("height", "updateLayout")
  end if
  componentWidth = getComponentWidth()
  componentHeight = getComponentHeight()

  m.text.width = componentWidth - m.textPadding * 2
  m.background.width = componentWidth
  m.background.height = componentHeight

  if m.top.centered
      m.top.translation = [(getParentWidth() - componentWidth) / 2, (getParentHeight() - componentHeight) / 2]
  end if

  dotsWidth  = (m.dotSize * 3) + (m.dotGap * 2)
  dotsHeight = m.dotSize

  loadingGroupWidth  = max(dotsWidth, m.text.width)
  loadingGroupHeight = dotsHeight + m.textHeight

  ' position loading group, dots and text at the center
  m.loadingGroup.translation = [(componentWidth - loadingGroupWidth) / 2, (componentHeight - loadingGroupHeight) / 2]
  m.dotsGroup.translation = [(loadingGroupWidth - dotsWidth) / 2, 0]
  m.text.translation = [0, dotsHeight + m.top.spacing]
end sub


sub onTextChange()
  prevTextHeight = m.textHeight
  if m.top.text = ""
    m.textHeight = 0
  else
    m.textHeight = m.text.localBoundingRect().height + m.top.spacing
  end if
  if m.textHeight <> prevTextHeight
    updatelayout()
  end if
end sub


sub onBackgroundImageChange()
  if m.top.backgroundUri <> ""
    previousBackground = m.background
    m.background = m.top.findNode("backgroundImage")
    m.background.opacity = previousBackground.opacity
    m.background.translation = previousBackground.translation
    m.background.width = previousBackground.width
    m.background.height = previousBackground.height
    m.background.uri = m.top.backgroundUri
    previousBackground.visible = false
  end if
end sub


sub onBackgroundOpacityChange()
  if m.background <> invalid
    m.background.opacity = m.top.backgroundOpacity
  end if
end sub


sub onTextPaddingChange()
  if m.top.textPadding > 0
    m.textPadding = m.top.textPadding
  else
    m.textPadding = 0
  end if
  updateLayout()
end sub


sub onControlChange()
  if m.top.control = "start"
    ' opacity could be set to 0 by fade animation so restore it
    m.loadingIndicatorGroup.opacity = 1
    startAnimation()
  else if m.top.control = "stop"
    ' if there is fadeInterval set, fully dispose component before stopping pulse animation
    if m.top.fadeInterval > 0
      m.fadeAnimation.duration = m.top.fadeInterval
      m.fadeAnimation.observeField("state", "onFadeAnimationStateChange")
      m.fadeAnimation.control = "start"
    else
      stopAnimation()
    end if
  end if
end sub


sub onFadeAnimationStateChange()
  if m.fadeAnimation.state = "stopped"
    stopAnimation()
  end if
end sub


function getComponentWidth() as Float
  if m.top.width = 0
    ' use parent's width
    return getParentWidth()
  else
    return m.top.width
  end if
end function


function getComponentHeight() as Float
  if m.top.height = 0
    ' use parent's height
    return getParentHeight()
  else
    return m.top.height
  end if
end function


function getParentWidth() as Float
  if m.top.getParent() <> invalid and m.top.getParent().width <> invalid then
    return  m.top.getParent().width
  else
    return 1270
  end if
end function


function getParentHeight() as Float
  if m.top.getParent() <> invalid and m.top.getParent().height <> invalid then
    return m.top.getParent().height
  else
    return 720
  end if
end function


sub startAnimation()
  ' don't start animation on devices that don't support it
  m.model = createObject("roDeviceInfo").getModel()
  'Get the first character of the model number. Anything less than a 4 corresponds to a device not suited to animations.
  first = Left(m.model, 1).trim()
  if first <> invalid and first.Len() = 1
    firstAsInt = val(first, 10)
    if (firstAsInt) > 3
      m.pulseAnimation.control = "start"
      m.top.state = "running"
    end if
  end if
end sub


sub stopAnimation()
  m.pulseAnimation.control = "stop"
  m.top.state = "stopped"
end sub


function max(a as Float, b as Float) as Float
  if a > b
    return a
  else
    return b
  end if
end function
