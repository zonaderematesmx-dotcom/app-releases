sub init()
    m.top.panelSize = "wide"
    m.top.focusable = true
    m.top.hasNextPanel = false
    m.top.isFullScreen = false
    m.top.leftOnly = false
    m.top.createNextPanelOnItemFocus = false
    m.top.selectButtonMovesPanelForward = false
    m.top.optionsAvailable = false

    m.pinWidget = m.top.findNode("PinEntry")
    m.lbl = m.top.findNode("lbl")
    m.lblSuccess = m.top.findNode("lblSuccess")
    
    m.pinWidget.observeField("pin","confirmPin")
    m.confirmPin = createObject("roSGNode", "PinTask")
    m.confirmPin.tipo = "1"
    m.confirmPin.observeField("state","confirmed")
end sub

sub confirmPin() 
    if m.pinWidget.pin.len() = 4 then
        m.confirmPin.pin = m.pinWidget.pin
        m.confirmPin.control = "RUN"
        m.busy = createObject("roSGNode", "StandardProgressDialog")
        m.top.getScene().dialog = m.busy
    end if
end sub

sub confirmed()
    if m.confirmPin.state = "stop" then 
        m.busy.close = true
        if m.confirmPin.result and m.confirmPin.tipo = "2" then
            m.lbl.text = "Enter Current PIN"
            m.confirmPin.tipo = "1"
            m.pinWidget.pin = ""
            m.confirmPin.result = false
            m.lblSuccess.text = "PIN changed successfully"
        else if m.confirmPin.result then
            m.lbl.text = "Enter New PIN"
            m.confirmPin.tipo = "2"
            m.pinWidget.pin = ""
            m.lblSuccess.text = ""
        else
            m.lbl.text = "Incorrect PIN, try again"
            m.confirmPin.tipo = "1"
            m.pinWidget.pin = ""
            m.lblSuccess.text = ""
        end if
    end if
end sub
