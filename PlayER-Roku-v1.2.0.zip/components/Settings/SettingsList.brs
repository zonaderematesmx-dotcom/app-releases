sub init()
  m.top.panelSize = "narrow"
  m.top.focusable = true
  m.top.hasNextPanel = false
  m.top.isFullScreen = false
  m.top.leftOnly = true
  m.top.nextPanel = createObject("roSGNode","Account")
  m.top.createNextPanelOnItemFocus = true
  m.top.selectButtonMovesPanelForward = true
  m.top.optionsAvailable = false
  m.top.overhangTitle = "Settings"
  m.top.list = m.top.findNode("settingsList")
  m.top.list.observeField("itemSelected", "changePin")
  m.top.observeField("createNextPanelIndex","createNextPanel")
end sub

sub createNextPanel()
    'print "createNextPanelIndex: "; m.top.createNextPanelIndex
    if m.top.createNextPanelIndex = 0 then ' Configuration
        m.top.nextPanel = createObject("roSGNode","Account")
        m.buttons = m.top.nextPanel.findNode("buttons")
        m.top.hasNextPanel = true
        m.top.selectButtonMovesPanelForward = true
    else if m.top.createNextPanelIndex = 1 then ' Change Pin
        m.top.nextPanel = createObject("roSGNode","ChangePin")
        m.pinWidget = m.top.nextPanel.findNode("pinEntry")
        m.top.hasNextPanel = true
        m.top.selectButtonMovesPanelForward = true
    end if
end sub

sub changePin()
    if m.top.list.itemSelected = 1 then
        ''print m.top.nextPanel.hasFocus()
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
  result = false
  'print "In SettingsList.brs onKeyEvent. Key pressed: ";key;" - Press: "; press
  if press then
    if key = "right" or key = "OK"
        if m.top.createNextPanelIndex = 0
            m.buttons.setFocus(true)
        else if m.top.createNextPanelIndex = 1
            m.pinWidget.setFocus(true)
        end if
    end if
  end if
  'print "Handled event: "; result
  return result
end function