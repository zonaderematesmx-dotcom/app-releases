sub init()
    m.dot   = m.top.findNode("stateDot")
    m.title = m.top.findNode("catTitle")
    m.prevContent = invalid
end sub

' El MarkupList reutiliza instancias de este componente al hacer scroll,
' asi que cada vez que le llega un itemContent nuevo hay que dejar de
' escuchar el nodo anterior antes de engancharse al nuevo.
sub onItemContentChanged()
    if m.prevContent <> invalid
        m.prevContent.unobserveField("bloqueado")
    end if

    content = m.top.itemContent
    if content = invalid then return
    m.prevContent = content

    m.title.text = content.title
    pintarEstado(content.bloqueado)

    ' Se escucha el campo directamente en el ContentNode: cuando
    ' SettingsScreen.brs alterna "bloqueado" al presionar OK, este
    ' item se repinta solo, sin necesidad de recargar toda la lista.
    content.observeField("bloqueado", "onBloqueadoChanged")
end sub

sub onBloqueadoChanged(evento as Object)
    pintarEstado(evento.getData())
end sub

sub pintarEstado(bloqueado as Object)
    if bloqueado = true
        m.dot.color = "0xE74C3CFF" ' rojo: categoria bloqueada
    else
        m.dot.color = "0x2ECC40FF" ' verde: categoria disponible
    end if
end sub

' focusPercent ya no se usa: el unico indicador de foco es
' catFocusIndicator (la barra deslizante), no un cambio de color del
' texto (evita el "doble foco" con dos animaciones desincronizadas).
