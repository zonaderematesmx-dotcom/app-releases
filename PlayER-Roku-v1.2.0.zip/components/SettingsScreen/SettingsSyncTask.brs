sub init()
    m.top.functionName = "execute"
end sub

function ajustesApiBase() as String
    if m.global <> invalid and m.global.urlAjustes <> invalid then
        return m.global.urlAjustes
    end if
    return ""
end function

function ajustesUser() as String
    u = getStrValFromReg("user_tv", "datos_tv")
    if u = invalid then return ""
    return u
end function

' Variante de servidor actual, para mandarla como "&variante=" al
' panel (ajustes.php) -- mismo motivo que en FavoritesLocalStore.brs/
' RecentlyWatchedLocalStore.brs/WatchProgressLocalStore.brs: el mismo
' usuario puede autenticar en mas de un servidor, y los ajustes
' (control parental, categorias bloqueadas, etc.) pueden depender del
' catalogo de un servidor especifico.
function ajustesVariante() as String
    if m.global <> invalid and m.global.serverVariant <> invalid and m.global.serverVariant.toStr() <> ""
        return m.global.serverVariant.toStr()
    end if
    return "0"
end function

' Perfil actual (hasta 5 por cuenta+servidor) -- mismo motivo y patron
' que ajustesVariante(): sin esto, todos los perfiles de una cuenta
' compartirian los mismos ajustes (PIN, control parental, etc) en el
' servidor.
function ajustesPerfil() as String
    if m.global <> invalid and m.global.profileId <> invalid and m.global.profileId.toStr() <> ""
        return m.global.profileId.toStr()
    end if
    return "0"
end function

sub execute()
    accion = m.top.accion
    if accion = "pull"
        doPull()
    else if accion = "push"
        doPush()
    end if
    m.top.listo = true
end sub

' ------------------------------------------------------------
' Corre SIEMPRE que se entra a Ajustes (ya no solo la primera vez).
' Por cada ajuste que reporte el servidor, compara su fecha contra
' la ultima fecha local conocida: si el servidor tiene algo mas
' nuevo, se aplica local. Al final, reconcilia el sentido contrario:
' cualquier ajuste que el dispositivo tenga con valor propio pero
' el servidor no reporte, se vuelve a subir (ver reconcile()).
' ------------------------------------------------------------
sub doPull()
    u = ajustesUser()
    if u = ""
        print "DEBUG SettingsSyncTask.doPull - usuario vacio, abortando"
        return
    end if

    url = ajustesApiBase() + "?action=list&user=" + u + "&variante=" + ajustesVariante() + "&perfil=" + ajustesPerfil()
    print "DEBUG SettingsSyncTask.doPull - url = "; url
    data = requestData(url)
    json = ParseJSON(data)

    serverClaves = {}

    if json <> invalid and type(json) = "roArray"
        for each row in json
            if type(row) = "roAssociativeArray" and row.clave <> invalid
                clave = row.clave
                serverClaves[clave] = true

                valor = ""
                if row.valor <> invalid then valor = row.valor
                serverTs = 0
                if row.fecha <> invalid then serverTs = row.fecha.toStr().toInt()

                localTs = Set_GetSyncTs(clave)
                if serverTs > localTs
                    Set_LocalSet(clave, valor)
                    Set_SetSyncTs(clave, serverTs)
                    print "DEBUG SettingsSyncTask.doPull - aplicado desde servidor: clave="; clave
                end if
            end if
        end for
        print "DEBUG SettingsSyncTask.doPull - "; json.count(); " ajustes revisados desde el servidor"
    else
        print "DEBUG SettingsSyncTask.doPull - servidor sin ajustes previos (usuario/dispositivo nuevo)"
    end if

    Set_LocalMarcarSembrado()
    reconcileLocalToServer(u, serverClaves)
end sub

' Cualquier ajuste que el dispositivo tenga con un valor propio pero
' el servidor no haya reportado en absoluto (nunca llego a subirse,
' p.ej. por una falla de red al guardar) se vuelve a subir.
sub reconcileLocalToServer(u as String, serverClaves as Object)
    for each clave in Set_AllClaves()
        if not serverClaves.doesExist(clave)
            valor = Set_LocalGet(clave)
            if valor <> invalid and valor <> ""
                print "DEBUG SettingsSyncTask.reconcileLocalToServer - re-subiendo clave="; clave
                pushClave(u, clave, valor)
            end if
        end if
    end for
end sub

sub doPush()
    u     = ajustesUser()
    clave = m.top.clave
    valor = m.top.valor
    if u = "" or clave = ""
        print "DEBUG SettingsSyncTask.doPush - usuario o clave vacios, abortando"
        return
    end if
    pushClave(u, clave, valor)
end sub

' Sube una clave/valor al servidor y marca la fecha local como
' "recien sincronizada" (ahora), usada tanto por doPush() como por
' la reconciliacion en doPull().
sub pushClave(u as String, clave as String, valor as String)
    url = ajustesApiBase() + "?action=set&user=" + u + "&clave=" + clave + "&valor=" + UrlEncodeSimple(valor) + "&variante=" + ajustesVariante() + "&perfil=" + ajustesPerfil()
    print "DEBUG SettingsSyncTask.pushClave - url = "; url
    resp = requestData(url)
    print "DEBUG SettingsSyncTask.pushClave - clave="; clave; " respuesta="; resp
    Set_SetSyncTs(clave, CreateObject("roDateTime").AsSeconds())
end sub

function UrlEncodeSimple(s as String) as String
    ut = CreateObject("roUrlTransfer")
    return ut.Escape(s)
end function
