sub init()
    m.dot   = m.top.findNode("statusDot")
    m.title = m.top.findNode("itemTitle")
end sub

' El ancho/alto los define itemSize en el MarkupList padre; no se
' necesita reposicionar nada al cambiar, pero se deja el hook por si
' en el futuro se decide hacer el layout proporcional al tamaño real.
sub onSizeChanged()
end sub

sub onItemContentChanged()
    content = m.top.itemContent
    if content = invalid then return

    m.title.text = content.title

    if content.doesExist("activo")
        m.dot.visible = true
        if content.activo = true
            m.dot.color = "0x2ECC40FF" ' verde: activo / prendido
        else
            m.dot.color = "0xE74C3CFF" ' rojo: inactivo / apagado
        end if
        ' Corre el titulo para dejar espacio al punto
        m.title.translation = [34.7, 11.7]
    else
        m.dot.visible = false
        m.title.translation = [10.0, 11.7]
    end if
end sub

' focusPercent ya no se usa: el unico indicador de foco es la barra
' deslizante (focusIndicator), no un cambio de color del texto. Tenerlo
' aqui tambien creaba un "doble foco" (dos animaciones desincronizadas:
' la barra y el texto cambiaban en momentos distintos).
