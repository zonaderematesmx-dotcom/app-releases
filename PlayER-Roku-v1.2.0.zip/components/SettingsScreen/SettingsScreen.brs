sub init()
    m.menu         = m.top.findNode("settingsMenu")
    m.titulo       = m.top.findNode("infoTitle")
    m.desc         = m.top.findNode("infoDesc")
    m.formatoActual = m.top.findNode("formatoActual")
    m.cuenta       = m.top.findNode("infoAccount")
    m.unlink       = m.top.findNode("unlinkGroup")
    m.pinPanel     = m.top.findNode("pinPanel")
    m.pinMsg       = m.top.findNode("pinMensaje")
    m.pinErr       = m.top.findNode("pinError")
    m.pinTecl      = m.top.findNode("pinTeclado")
    m.checkGroup   = m.top.findNode("checkGroup")
    m.checklist    = m.top.findNode("catChecklist")
    m.tarea        = invalid
    m.catTarea     = invalid
    m.catTipo      = ""
    m.accion       = ""
    m.cargandoCats = false
    m.tareasSync   = [] ' referencias vivas a los pushes en curso (ver sincronizarAjuste)

    ' --- Indicador de foco deslizante (reemplaza list_selection.png) ---
    m.focusIndicator = m.top.findNode("focusIndicator")
    m.focusSlideAnim = m.top.findNode("focusSlideAnim")
    m.focusYInterp   = m.top.findNode("focusYInterp")
    m.menuBg         = m.top.findNode("menuBg")
    m.bounceAnim     = m.top.findNode("bounceAnim")
    m.bounceInterp   = m.top.findNode("bounceInterp")
    m.menuBgBaseXY   = [53.3, 80.0]
    m.itemStepY      = 46.6 ' itemSize.y (43.3) + itemSpacing.y (3.3)
    m.itemBaseY      = 46.7 ' offset del MarkupList dentro de menuBg

    ' --- Indicador de foco del checklist de categorias (mismo patron) ---
    m.catFocusIndicator = m.top.findNode("catFocusIndicator")
    m.catFocusSlideAnim = m.top.findNode("catFocusSlideAnim")
    m.catFocusYInterp   = m.top.findNode("catFocusYInterp")
    m.catItemStepY      = 42.0 ' itemSize.y (40) + itemSpacing.y (2)

    ' --- Centrado dinamico del PinPad ---
    m.pinCenterTimer = m.top.findNode("pinCenterTimer")
    m.pinCenterTimer.observeField("fire", "onPinCenterTimer")

    m.checklist.observeField("itemSelected", "alSeleccionCategoria")
    m.checklist.observeField("itemFocused", "alFocusearCategoria")
    m.pinTecl.observeField("pin", "alIngresarPin")

    ' --- Color de marca (focusColor del config.json) ---
    m.navBg5        = m.top.findNode("navBg5")
    m.menuTitleLbl  = m.top.findNode("menuTitleLbl")
    m.unlinkTitleLbl = m.top.findNode("unlinkTitleLbl")
    applyBrandColor()
    m.global.observeField("focusColor", "applyBrandColor")

    ' Item de "Perfil" de la barra de arriba -- solo informativo aqui
    ' (ver comentario en SettingsScreen.xml/nav6).
    GU_FillProfileNavItem(m.top.findNode("profileAvatarBg"), m.top.findNode("profileAvatarInitial"), m.top.findNode("navLbl6"))

    ' ============================================================
    ' Sincronizacion de ajustes con el servidor (bidireccional, ver
    ' SettingsSyncTask.brs/SettingsLocalStore.brs): siempre se
    ' consulta al entrar a esta pantalla, no solo la primera vez,
    ' para que un cambio hecho en otro dispositivo se refleje aqui.
    ' El menu se arma DESPUES de que la sincronizacion termine, para
    ' que ya refleje el estado real (activo/inactivo, categorias
    ' bloqueadas, etc.)
    ' ============================================================
    m.syncPull = createObject("roSGNode", "SettingsSyncTask")
    m.syncPull.observeField("listo", "onSembradoListo")
    m.syncPull.accion = "pull"
    m.syncPull.control = "RUN"
end sub

sub onSembradoListo()
    continuarInicioAjustes()
end sub

' ============================================================
' Todo lo que antes iba al final de init(): depende de que los
' ajustes locales ya esten resueltos (sembrados desde el servidor
' o ya existentes de antes).
' ============================================================
sub continuarInicioAjustes()
    usr = m.global.user
    exp = m.global.expire
    if usr = invalid or usr = "" then usr = getStrValFromReg("user_tv", "datos_tv")
    if usr = invalid then usr = ""
    if exp = invalid or exp = ""
        ' Intentar calcular desde el registro
        expSecs = RegRead("exp_date", "IPTV_PC")
        if expSecs <> invalid and expSecs <> "" and expSecs <> "0"
            dt = CreateObject("roDateTime")
            dt.fromSeconds(expSecs.toInt())
            exp = dt.AsDateStringNoParam()
            m.global.expire = exp
        else
            exp = "No disponible"
        end if
    end if
    m.datoscuenta = "Usuario: " + usr + chr(10) + "Expira: " + exp

    cargarMenu()
    loadRemoteAssets()

    m.menu.observeField("itemFocused",  "alFocusear")
    m.menu.observeField("itemSelected", "alSeleccionar")
    if m.global.settingsAuth = true then
        m.menu.visible = true
        activarZonaMenu()
    else
        m.menu.visible = false
        m.accion = "entrar_settings"
        m.initTimer = m.top.findNode("initTimer")
        m.initTimer.observeField("fire", "onInitTimer")
        m.initTimer.control = "start"
    end if
end sub

' ============================================================
' Aplica el focusColor del config remoto a los acentos rojos
' de esta pantalla. Se re-ejecuta si el color cambia despues.
' ============================================================
sub applyBrandColor()
    fc = m.global.focusColor
    if fc = invalid or fc = "" then fc = "0xE50914FF"

    if m.navBg5 <> invalid then m.navBg5.color = fc
    if m.menuTitleLbl <> invalid then m.menuTitleLbl.color = fc
    if m.unlinkTitleLbl <> invalid then m.unlinkTitleLbl.color = fc
    if m.formatoActual <> invalid then m.formatoActual.color = fc
    if m.pinErr <> invalid then m.pinErr.color = fc
    if m.focusIndicator <> invalid then m.focusIndicator.color = fc
    if m.catFocusIndicator <> invalid then m.catFocusIndicator.color = fc
end sub

sub loadRemoteAssets()
    logoImage = m.top.findNode("logoImage")
    if logoImage = invalid then return
    dt = CreateObject("roDateTime").AsSeconds().ToStr()
    logoImage.uri = m.global.panelURL + "/img/logo.png?ts=" + dt
end sub

' ============================================================
' Determina si el PIN actual es distinto al de fabrica (0000).
' Se usa solo para pintar el punto verde/rojo del item "Cambiar PIN".
' ============================================================
function pinEsPersonalizado() as Boolean
    pinGuardado = RegRead("lock", "IPTV_PC")
    if pinGuardado = invalid or pinGuardado = "" then pinGuardado = RegRead("betotun_pin", "BETOTUN")
    if pinGuardado = invalid or pinGuardado = "" then pinGuardado = "0000"
    return pinGuardado <> "0000"
end function

sub cargarMenu()
    bloqueado = RegRead("betotun_activo", "BETOTUN")
    if bloqueado = "1" then
        etiqueta = "Control Parental: Activo"
        detalle  = "Contenido Adulto Bloqueado. Presiona OK para Desactivar."
    else
        etiqueta = "Control Parental: Inactivo"
        detalle  = "Contenido Adulto Desbloqueado. Presiona OK para Activar."
    end if

    contenido = createObject("roSGNode", "ContentNode")

    ' Nota: ya no se asignan campos "icon" ni "list_selection*".
    ' El componente SettingListItem ya no usa imagenes: dibuja el
    ' titulo como texto y, si el item trae el campo "activo", un
    ' punto verde (true) o rojo (false) en vez del icono.

    a = contenido.createChild("listFields")
    a.title       = "Mi Cuenta"
    a.description = "Información de tu Cuenta"

    b = contenido.createChild("listFields")
    b.title       = etiqueta
    b.description = detalle
    b.AddFields({ activo: (bloqueado = "1") })

    c = contenido.createChild("listFields")
    c.title       = "Cambiar PIN"
    c.description = "Cambia tu PIN por Defecto: 0000"
    c.AddFields({ activo: pinEsPersonalizado() })

    d = contenido.createChild("listFields")
    d.title       = "Bloquear Peliculas"
    d.description = "Select Movie categories to block."

    e = contenido.createChild("listFields")
    e.title       = "Bloquear Series"
    e.description = "Select Series categories to block."

    f = contenido.createChild("listFields")
    f.title       = "Bloquear Television"
    f.description = "Select Live TV categories to block."

    ' =====================================================
    ' Formato de Video
    ' =====================================================
    formatoItem = contenido.createChild("listFields")
    formatoItem.title       = "Formato de Video"
    formatoItem.description = "Elige entre TS o HLS según tu conexión."

    g = contenido.createChild("listFields")
    g.title       = "Desvincular Cuenta"
    g.description = "Eliminar Cuenta del Dispositivo"

    h = contenido.createChild("listFields")
    h.title       = "Salir de Ajustes"
    h.description = "Regresar al Home"

    m.menu.content = contenido
end sub

sub ocultarTodo()
    m.titulo.text        = ""
    m.desc.text          = ""
    m.cuenta.text        = ""
    m.cuenta.visible     = false
    m.unlink.visible     = false
    m.pinPanel.visible   = false
    m.pinErr.visible     = false
    m.pinErr.text        = ""
    m.checkGroup.visible = false
    m.catTipo            = ""
end sub

' ============================================================
' Mueve el indicador de foco (barra deslizante) a la posicion
' del item enfocado, animado. Reemplaza el swap manual de fondos
' por item que antes hacian list_selection / list_selection_focus.
' ============================================================
sub moverFocusIndicator(idx as Integer)
    if m.focusIndicator = invalid then return
    targetY = m.itemBaseY + (idx * m.itemStepY)
    startXY = m.focusIndicator.translation
    m.focusYInterp.keyValue = [[26.7, startXY[1]], [26.7, targetY]]
    m.focusSlideAnim.control = "stop"
    m.focusSlideAnim.control = "start"
end sub

' ============================================================
' Pequeño "rebote" del indicador de foco al intentar pasar del
' primer o ultimo item. direction = -1 (tope de arriba) / 1 (tope
' de abajo). Solo anima focusIndicator: la lista y sus items NUNCA
' se mueven de su posicion.
' ============================================================
sub bounceMenu(idxBorde as Integer, direction as Integer)
    if m.bounceAnim = invalid then return
    edgeY = m.itemBaseY + (idxBorde * m.itemStepY)
    overshoot = 6.0 * direction
    m.bounceInterp.keyValue = [[26.7, edgeY], [26.7, edgeY + overshoot], [26.7, edgeY]]
    m.bounceAnim.control = "stop"
    m.bounceAnim.control = "start"
end sub

sub alFocusear(evento as Object)
    idx = evento.getData()
    ocultarTodo()
    moverFocusIndicator(idx)

    nodo = m.menu.content.getChild(idx)
    if nodo = invalid then return
    m.titulo.text = nodo.title
    m.desc.text   = nodo.description
    if nodo.title = "Formato de Video"
        fmt = m.global.streamFormat
        if fmt = invalid or fmt = "" then fmt = RegRead("stream_format", "IPTV_PC")
        if fmt = invalid or fmt = "" then fmt = "ts"
        if fmt = "m3u8" then fmt = "HLS (m3u8)" else fmt = "TS"
        m.formatoActual.text = "Actualmente reproduces en formato: " + fmt
        m.formatoActual.visible = true
    else
        m.formatoActual.visible = false
    end if

    if idx = 0 then
        m.cuenta.text    = m.datoscuenta
        m.cuenta.visible = true
    end if
    if idx = 3 then
        activo = RegRead("betotun_activo", "BETOTUN")
        if activo = "1" then
            m.catTipo = "vod"
            cargarChecklist("get_vod_categories", "vod")
        else
            m.desc.text = "Primero Activa Contro Parental"
        end if
    end if
    if idx = 4 then
        activo = RegRead("betotun_activo", "BETOTUN")
        if activo = "1" then
            m.catTipo = "series"
            cargarChecklist("get_series_categories", "series")
        else
            m.desc.text = "Primero Activa Contro Parental"
        end if
    end if
    if idx = 5 then
        activo = RegRead("betotun_activo", "BETOTUN")
        if activo = "1" then
            m.catTipo = "live"
            cargarChecklist("get_live_categories", "live")
        else
            m.desc.text = "Primero Activa Contro Parental"
        end if
    end if

    if idx = 6 then
        ' No mostramos nada en el panel derecho, solo el título y descripción
    end if

    if idx = 7 then
        m.unlink.visible = true
    end if
end sub

sub alSeleccionar(evento as Object)
    idx = evento.getData()

    if idx = 1 then
        activo = RegRead("betotun_activo", "BETOTUN")
        if activo = "1" then
            m.accion = "desactivar"
            mostrarPinPad("Ingresa PIN para Desactivar")
        else
            m.accion = "activar"
            mostrarPinPad("Ingresa PIN para Activar")
        end if
    end if

    if idx = 2 then
        m.accion = "verificar_pin"
        mostrarPinPad("Ingresa PIN Actual")
    end if

    if idx = 3 then
        if m.checkGroup.visible then
            activarZonaChecklist()
        end if
    end if

    if idx = 4 then
        if m.checkGroup.visible then
            activarZonaChecklist()
        end if
    end if

    if idx = 5 then
        if m.checkGroup.visible then
            activarZonaChecklist()
        end if
    end if

    ' =====================================================
    ' Formato de Video (posición 6)
    ' =====================================================
    if idx = 6 then
        mostrarDialogoFormato()
        return
    end if

    if idx = 7 then
        m.accion = "desvincular"
        mostrarPinPad("Ingresar PIN para Desvincular")
    end if

    if idx = 8 then
        m.top.menuItemSelected = -1
    end if
end sub

sub cargarChecklist(accion as String, tipo as String)
    if m.catTarea <> invalid then m.catTarea.control = "STOP"
    tarea = createObject("roSGNode", "AllCatLoaderTask")
    tarea.action = accion
    tarea.observeField("cats", "alCargarCats")
    tarea.control = "RUN"
    m.catTarea     = tarea
    m.catTipoTarea = tipo
end sub

sub alCargarCats()
    if m.catTarea = invalid then return
    if m.catTipoTarea <> m.catTipo then return

    cats = m.catTarea.cats
    if cats = invalid then cats = []

    bloqueadas = PC_getBlocked(m.catTipo)
    estados    = []

    cn = createObject("roSGNode", "ContentNode")

    idx = 0
    while idx < cats.count()
        gato = cats[idx]
        nombre = ""
        if gato.category_name <> invalid then nombre = gato.category_name
        cid = PC_id(gato.category_id)
        estaBloqueada = bloqueadas.DoesExist(cid)

        nodo = cn.createChild("ContentNode")
        nodo.title = nombre
        nodo.AddFields({ bloqueado: estaBloqueada })
        estados.push(estaBloqueada)

        idx = idx + 1
    end while

    m.catEstados         = estados
    m.checklist.content  = cn
    m.checkGroup.visible = true
    if m.catFocusIndicator <> invalid then
        m.catFocusIndicator.translation = [0.0, 0.0]
        m.catFocusIndicator.opacity     = 0.35
    end if
end sub

' ============================================================
' Igual que moverFocusIndicator() pero para el checklist de
' categorias (panel derecho). Tambien usa el color del servidor
' (ver applyBrandColor) en vez de un icono distinto por fila.
' ============================================================
sub alFocusearCategoria(evento as Object)
    idx = evento.getData()
    moverFocusIndicatorCategoria(idx)
end sub

sub moverFocusIndicatorCategoria(idx as Integer)
    if m.catFocusIndicator = invalid then return
    targetY = idx * m.catItemStepY
    startXY = m.catFocusIndicator.translation
    m.catFocusYInterp.keyValue = [[0.0, startXY[1]], [0.0, targetY]]
    m.catFocusSlideAnim.control = "stop"
    m.catFocusSlideAnim.control = "start"
end sub

' ============================================================
' Le dan foco a un panel (menu izquierdo o checklist de categorias
' a la derecha) y, de paso, atenuan el indicador del panel que
' se queda sin foco, para que siempre sea claro cual de los dos
' esta activo en este momento.
' ============================================================
sub activarZonaMenu()
    m.menu.setFocus(true)
    if m.focusIndicator    <> invalid then m.focusIndicator.opacity    = 1.0
    if m.catFocusIndicator <> invalid then m.catFocusIndicator.opacity = 0.35
end sub

sub activarZonaChecklist()
    m.checklist.setFocus(true)
    if m.catFocusIndicator <> invalid then m.catFocusIndicator.opacity = 1.0
    if m.focusIndicator    <> invalid then m.focusIndicator.opacity    = 0.35
end sub

' ============================================================
' Empuja UN ajuste al servidor. Quien la llama ya debe haber escrito
' el valor LOCAL antes (RegWrite / PC_saveBlocked), asi la UI nunca
' espera a la red: el push es "fire and forget", igual que
' ChannelFavoritesTask.doAddOrRemove con los favoritos.
' Se guarda una referencia en m.tareasSync para que el Task no se
' recolecte (garbage collector) antes de terminar su peticion HTTP.
' ============================================================
sub sincronizarAjuste(clave as String, valor as String)
    t = createObject("roSGNode", "SettingsSyncTask")
    t.accion = "push"
    t.clave  = clave
    t.valor  = valor
    t.control = "RUN"
    if m.tareasSync = invalid then m.tareasSync = []
    m.tareasSync.push(t)
end sub

' ============================================================
' Se dispara con OK sobre una fila del checklist de categorias.
' Antes esto lo resolvia el CheckList nativo solo (marcaba el
' checkbox y disparaba checkedState); ahora que el checklist es un
' MarkupList propio (para poder pintar el punto rojo/verde en vez
' de un icono), el toggle se hace aqui a mano.
' ============================================================
sub alSeleccionCategoria(evento as Object)
    idx = evento.getData()
    if m.catTarea = invalid then return
    cats = m.catTarea.cats
    if cats = invalid then return
    if idx < 0 or idx >= cats.count() then return
    if m.catEstados = invalid or idx >= m.catEstados.count() then return

    nuevoEstado = not m.catEstados[idx]
    m.catEstados[idx] = nuevoEstado

    nodo = m.checklist.content.getChild(idx)
    if nodo <> invalid then nodo.bloqueado = nuevoEstado

    guardarEstadosCategorias()
end sub

sub guardarEstadosCategorias()
    cats = m.catTarea.cats
    if cats = invalid then return
    if m.catEstados = invalid then return

    nuevasBloqueadas = {}
    idx = 0
    while idx < cats.count()
        if m.catEstados[idx] then
            cid = PC_id(cats[idx].category_id)
            if cid <> "" then nuevasBloqueadas[cid] = true
        end if
        idx = idx + 1
    end while
    PC_saveBlocked(m.catTipo, nuevasBloqueadas)

    ' IMPORTANTE: PC_saveBlocked (ParentalControl.brs) guarda las
    ' categorias bloqueadas como un ARREGLO JSON (ej. ["12","34"]),
    ' no como objeto. Hay que mandar exactamente el mismo formato al
    ' servidor, o un dispositivo nuevo que siembre desde ahi (ver
    ' SettingsSyncTask.doPull) terminaria con PC_getBlocked()
    ' descartando el valor por no ser un roArray.
    ids = []
    for each k in nuevasBloqueadas
        ids.push(k)
    end for
    sincronizarAjuste("pc_" + m.catTipo, FormatJSON(ids))
end sub

sub mostrarPinPad(mensaje as String)
    ocultarTodo()
    m.pinMsg.text      = mensaje
    m.pinErr.text      = ""
    m.pinErr.visible   = false
    m.pinTecl.pin      = ""
    m.pinPanel.visible = true
    m.pinTecl.setFocus(true)
    ' Se espera un frame a que el PinPad se renderice para poder
    ' leer su ancho real y centrarlo (ver onPinCenterTimer).
    m.pinCenterTimer.control = "start"
end sub

' ============================================================
' Centra el PinPad horizontalmente dentro de infoBg usando su
' ancho real (boundingRect), en vez de una translation fija
' calculada a mano que se descuadra si el widget nativo cambia
' de tamaño entre versiones de firmware.
' ============================================================
sub onPinCenterTimer()
    if m.pinTecl = invalid then return
    rect = m.pinTecl.boundingRect()
    if rect = invalid or rect.width = invalid or rect.width <= 0 then return

    anchoInfoBg  = 700.0
    offsetPanelX = 50.0 ' translation.x de pinPanel dentro de infoBg
    centroX = (anchoInfoBg - rect.width) / 2.0
    m.pinTecl.translation = [centroX - offsetPanelX, 66.7]
end sub

sub alIngresarPin()
    ingresado = m.pinTecl.pin
    if ingresado = invalid then return
    if ingresado.len() < 4 then return

    pinGuardado = RegRead("lock", "IPTV_PC")
    if pinGuardado = invalid or pinGuardado = "" then pinGuardado = RegRead("betotun_pin", "BETOTUN")
    if pinGuardado = invalid or pinGuardado = "" then pinGuardado = "0000"

    accionActual = m.accion

    if accionActual = "entrar_settings" then
        if ingresado = pinGuardado then
            m.accion = ""
            m.global.settingsAuth = true
            ocultarTodo()
            m.menu.visible = true
            activarZonaMenu()
        else
            m.pinTecl.pin    = ""
            m.pinErr.text    = "PIN Incorrecto"
            m.pinErr.visible = true
        end if
    end if
    if accionActual = "activar" then
        if ingresado = pinGuardado then
            m.accion = ""
            RegWrite("betotun_activo", "1", "BETOTUN")
            sincronizarAjuste("betotun_activo", "1")
            tarea = createObject("roSGNode", "PCActivateTask")
            tarea.observeField("done", "betotunTareaLista")
            tarea.control = "RUN"
            m.tarea = tarea
            ocultarTodo()
            m.titulo.text = "Control Parental Activo"
            m.desc.text   = "Bloqueando Categorias de Adulto..."
        else
            m.pinTecl.pin    = ""
            m.pinErr.text    = "PIN Incorrecto, Vuelve a Intentar"
            m.pinErr.visible = true
        end if
    end if

    if accionActual = "desactivar" then
        if ingresado = pinGuardado then
            m.accion = ""
            RegWrite("betotun_activo", "0", "BETOTUN")
            sincronizarAjuste("betotun_activo", "0")
            RegDelete("pc_vod",    "IPTV_PC")
            RegDelete("pc_series", "IPTV_PC")
            RegDelete("pc_live",   "IPTV_PC")
            sincronizarAjuste("pc_vod", "[]")
            sincronizarAjuste("pc_series", "[]")
            sincronizarAjuste("pc_live", "[]")
            ocultarTodo()
            cargarMenu()
            m.titulo.text = "Control Parental Desactivado"
            m.desc.text   = "Contenido de Adulto Desbloqueado"
            activarZonaMenu()
        else
            m.pinTecl.pin    = ""
            m.pinErr.text    = "PIN Incorrecto, Vuelve a Intentar"
            m.pinErr.visible = true
        end if
    end if

    if accionActual = "verificar_pin" then
        if ingresado = pinGuardado then
            m.accion = "nuevo_pin"
            m.pinTecl.pin    = ""
            m.pinMsg.text    = "Ingresa tu Nuevo PIN"
            m.pinErr.text    = ""
            m.pinErr.visible = false
        else
            m.pinTecl.pin    = ""
            m.pinErr.text    = "PIN Incorrecto, Vuelve a Intentar"
            m.pinErr.visible = true
        end if
    end if

    if accionActual = "nuevo_pin" then
        m.accion = ""
        RegWrite("lock",        ingresado, "IPTV_PC")
        RegWrite("betotun_pin", ingresado, "BETOTUN")
        sincronizarAjuste("pin", ingresado)
        ocultarTodo()
        cargarMenu() ' refresca el punto verde/rojo de "Cambiar PIN"
        m.titulo.text = "PIN Actualizado"
        m.desc.text   = "Tu Nuevo PIN se Actualizo"
        activarZonaMenu()
    end if

    if accionActual = "desvincular" then
        if ingresado = pinGuardado then
            m.accion = ""
            ' IMPORTANTE: limpiar el cache ANTES de borrar user_tv/pass_tv
            ' del registro. Fav_LocalClearAll() (y el resto de LocalStores)
            ' identifican de quien es el cache leyendo user_tv -- si se
            ' borra primero, Fav_LocalClearAll() ya no sabe de quien limpiar
            ' y termina limpiando el cache de "unknown" en vez del de la
            ' cuenta que se esta desvinculando.
            ' (Con el cache ya separado por usuario+servidor esto ya no es
            ' estrictamente necesario para que la cuenta siguiente no
            ' herede datos -- eso ya lo garantiza la separacion -- pero se
            ' conserva para no dejar basura de la cuenta desvinculada.)
            Fav_LocalClearAll()
            delStrValToReg("user_tv", "datos_tv")
            delStrValToReg("pass_tv", "datos_tv")
            m.top.unlinked = true
        else
            m.pinTecl.pin    = ""
            m.pinErr.text    = "PIN Incorrecto, Vuelve a Intentar"
            m.pinErr.visible = true
        end if
    end if
end sub

sub betotunTareaLista()
    if m.tarea = invalid then return
    m.tarea = invalid
    cargarMenu()
    m.titulo.text = "Control Parental Activado"
    m.desc.text   = "Categorias de Adulto Bloqueadas Exitosamente"
    activarZonaMenu()
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press then
        if key = "back" then
            if m.pinPanel.visible = true then
                if m.accion = "entrar_settings" then
                    m.top.menuItemSelected = -1
                    return true
                end if
                ocultarTodo()
                m.accion = ""
                activarZonaMenu()
                return true
            end if
            if m.checkGroup.visible = true then
                ocultarTodo()
                activarZonaMenu()
                return true
            end if
            if m.menu.hasFocus() then
                m.top.menuItemSelected = -1
                return true
            end if
        end if
        if key = "left" then
            if m.checklist.hasFocus() then
                activarZonaMenu()
                return true
            end if
        end if
        ' --- Tope arriba/abajo con rebote, sin wrap infinito ---
        if key = "up" or key = "down" then
            if m.menu.hasFocus() and m.menu.content <> invalid then
                idxActual = m.menu.itemFocused
                total = m.menu.content.getChildCount()
                if key = "up" and idxActual = 0 then
                    bounceMenu(0, -1)
                    return true
                end if
                if key = "down" and idxActual = total - 1 then
                    bounceMenu(total - 1, 1)
                    return true
                end if
            end if
        end if
    end if
    return false
end function

sub onInitTimer()
    mostrarPinPad("Ingresa PIN 0000 por Defecto")
end sub


' =====================================================
' FUNCIONES PARA "Formato de Video" (TS / HLS)
' =====================================================

sub mostrarDialogoFormato()
    dialog = createObject("roSGNode", "Dialog")
    dialog.title = "Formato de Video"
    dialog.message = "Selecciona el formato de reproducción:"
    dialog.buttons = ["TS (Recomendado)", "HLS (m3u8)"]

    scene = m.top.getScene()
    if scene <> invalid then
        scene.dialog = dialog
    else
        m.top.dialog = dialog
    end if

    dialog.observeField("buttonSelected", "onFormatoSeleccionado")
end sub


sub onFormatoSeleccionado()
    scene = m.top.getScene()
    if scene = invalid then return

    dialog = scene.dialog
    if dialog = invalid then return

    seleccion = dialog.buttonSelected

    if seleccion = 0 then
        RegWrite("stream_format", "ts", "IPTV_PC")
        sincronizarAjuste("stream_format", "ts")
        m.global.streamFormat = "ts"
        m.desc.text = "✅ Formato cambiado a: TS"
        m.formatoActual.text = "Actualmente reproduces en formato: TS"
        m.formatoActual.visible = true
    else if seleccion = 1 then
        RegWrite("stream_format", "m3u8", "IPTV_PC")
        sincronizarAjuste("stream_format", "m3u8")
        m.global.streamFormat = "m3u8"
        m.desc.text = "✅ Formato cambiado a: HLS (m3u8)"
        m.formatoActual.text = "Actualmente reproduces en formato: HLS (m3u8)"
        m.formatoActual.visible = true
    end if

    dialog.close = true
    scene.dialog = invalid
end sub
