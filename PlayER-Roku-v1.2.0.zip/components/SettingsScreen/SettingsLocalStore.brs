' ============================================================
' SettingsLocalStore.brs
' ============================================================
' Mismo espiritu que FavoritesLocalStore.brs, pero para Ajustes.
' NO inventa un esquema de registro nuevo: usa las MISMAS
' secciones/llaves que ya usan ParentalControl.brs y ChangePin.brs,
' asi esos archivos siguen funcionando exactamente igual sin tocarlos:
'
'   Seccion "IPTV_PC":  lock, pc_vod, pc_series, pc_live, stream_format
'   Seccion "BETOTUN":  betotun_activo, betotun_pin
'
' Lo que agrega esta capa:
'   - Set_RegMap(clave)      -> a que seccion/llave real corresponde
'                                cada "clave" logica de ajuste
'   - Set_LocalGet/LocalSet  -> lectura/escritura generica por clave,
'                                usada por SettingsSyncTask para
'                                sembrar/enviar al servidor
'   - Set_LocalYaSembrado    -> bandera de "ya se intento traer los
'                                ajustes del servidor en este Roku"
' ============================================================

function Set_RegMap(clave as String) as Object
    if clave = "pin"             then return { seccion: "IPTV_PC", llave: "lock" }
    if clave = "betotun_activo"  then return { seccion: "BETOTUN", llave: "betotun_activo" }
    if clave = "betotun_pin"     then return { seccion: "BETOTUN", llave: "betotun_pin" }
    if clave = "pc_vod"          then return { seccion: "IPTV_PC", llave: "pc_vod" }
    if clave = "pc_series"       then return { seccion: "IPTV_PC", llave: "pc_series" }
    if clave = "pc_live"         then return { seccion: "IPTV_PC", llave: "pc_live" }
    if clave = "stream_format"   then return { seccion: "IPTV_PC", llave: "stream_format" }
    return invalid
end function

function Set_LocalGet(clave as String) as Object
    mapa = Set_RegMap(clave)
    if mapa = invalid then return invalid
    return RegRead(mapa.llave, mapa.seccion)
end function

sub Set_LocalSet(clave as String, valor as String)
    mapa = Set_RegMap(clave)
    if mapa = invalid then return
    RegWrite(mapa.llave, valor, mapa.seccion)
end sub

' Bandera propia (seccion nueva, no choca con nada existente): indica
' que este dispositivo ya intento sembrar sus ajustes desde el
' servidor (haya encontrado algo o no). Evita repetir la consulta al
' servidor cada vez que se entra a Ajustes.
function Set_LocalYaSembrado() as Boolean
    v = RegRead("ajustes_sembrados", "IPTV_SETTINGS")
    return v = "1"
end function

sub Set_LocalMarcarSembrado()
    RegWrite("ajustes_sembrados", "1", "IPTV_SETTINGS")
end sub

' ------------------------------------------------------------
' Fecha (epoch) del ultimo valor CONOCIDO como sincronizado de cada
' ajuste. Vive en una seccion propia y separada -- no toca el
' formato real de guardado de cada valor (ParentalControl.brs y
' ChangePin.brs lo siguen leyendo tal cual, sin enterarse de esto).
' Se usa para decidir, al sincronizar, si el valor del servidor es
' mas nuevo que el local o al reves.
' ------------------------------------------------------------
function Set_GetSyncTs(clave as String) as Integer
    v = RegRead(clave, "SettingsSync")
    if v = invalid or v = "" then return 0
    return v.toInt()
end function

sub Set_SetSyncTs(clave as String, epoch as Integer)
    RegWrite(clave, epoch.toStr(), "SettingsSync")
end sub

' Lista fija de todas las claves de ajuste que existen hoy (debe
' reflejar las mismas que Set_RegMap conoce). Se usa para la
' reconciliacion local->servidor: revisar si el dispositivo tiene
' algun valor guardado que el servidor no tenga registrado.
function Set_AllClaves() as Object
    return ["pin", "betotun_activo", "betotun_pin", "pc_vod", "pc_series", "pc_live", "stream_format"]
end function
