sub init()
    m.top.functionName = "execute"
end sub

sub execute()
    tt = m.top.taskType

    ' Asegura la carpeta de favoritos una vez por corrida de este Task,
    ' pero SOLO cuando de verdad hace falta (taskType=favorites) -- no
    ' hay motivo para que Recien Agregadas/Banners/etc dependan de
    ' esto. (hilo TASK: aqui SI se puede crear roFileSystem/
    ' CreateDirectory, a diferencia de las pantallas Group que tambien
    ' leen/escriben favoritos -- ver la nota al inicio de
    ' FavoritesLocalStore.brs).
    if tt = "favorites" then Fav_EnsureDir()

    if tt = "banners"
        loadBanners()
    else if tt = "recentMovies"
        loadRecentMovies()
    else if tt = "recentSeries"
        loadRecentSeries()
    else if tt = "categoryItems"
        loadCategoryItems()
    else if tt = "searchMovies"
        searchMovies()
    else if tt = "searchSeries"
        searchSeries()
    else if tt = "fastSearch"
        fastSearch()
    else if tt = "favorites"
        loadFavorites()
    else if tt = "recentlyWatched"
        loadRecentlyWatched()
    else if tt = "progress"
        loadProgress()
    else if tt = "deepLinkMovie"
        deepLinkMovie()
    else if tt = "deepLinkSeries"
        deepLinkSeries()
    else if tt = "deepLinkLive"
        deepLinkLive()
    end if
end sub

function safeStr(val as dynamic) as string
    if val = invalid then return ""
    vt = type(val)
    if vt = "roString" or vt = "String" then return val
    if vt = "roInt" or vt = "roInteger" or vt = "Integer" then return val.toStr()
    if vt = "roFloat" or vt = "Float" then return str(int(val)).trim()
    if vt = "roDouble" or vt = "Double" then return str(int(val)).trim()
    if vt = "roLongInteger" or vt = "LongInteger" then return val.toStr()
    return ""
end function

sub setBackdrop(node as Object, item as Object)
    if item.backdrop_path <> invalid
        bpType = type(item.backdrop_path)
        if bpType = "roArray" and item.backdrop_path.Count() > 0
            node.hdBackgroundImageUrl = item.backdrop_path[0]
        else if bpType = "roString" or bpType = "String"
            if item.backdrop_path <> "" then node.hdBackgroundImageUrl = item.backdrop_path
        end if
    end if
end sub

sub setDescription(node as Object, item as Object)
    if item.plot <> invalid and item.plot <> ""
        node.description = item.plot
    else if item.description <> invalid and item.description <> ""
        node.description = item.description
    else
        node.description = ""
    end if
end sub

sub setDuration(node as Object, item as Object)
    if item.duration_secs <> invalid
        durType = type(item.duration_secs)
        if durType = "roInt" or durType = "roInteger" or durType = "Integer"
            node.length = item.duration_secs
        else if durType = "roString" or durType = "String"
            node.length = val(item.duration_secs)
        end if
    end if
end sub

sub fillMovieNode(node as Object, item as Object, su as String, u as String, p as String)
    sid = safeStr(item.stream_id)
    node.id = sid
    node.ContentType = "1"
    ' El catalogo del proveedor (get_vod_streams) a veces trae "name"
    ' vacio/ausente para algun titulo especifico de forma intermitente
    ' (inestabilidad del lado de ellos, no cada vez). Si pasa, usamos
    ' el titulo que ya tengamos guardado localmente (de favoritos o
    ' recien vistos) antes de dejarlo en blanco.
    if item.name <> invalid and item.name <> ""
        node.title = item.name
    else
        localTitle = ""
        aa = Fav_LocalRead("pelicula", sid)
        if aa <> invalid and aa.title <> invalid and aa.title <> "" then localTitle = aa.title
        if localTitle <> "" then
            node.title = localTitle
        end if
    end if
    setDescription(node, item)
    ext = "ts"
    if item.container_extension <> invalid and item.container_extension <> "" then ext = item.container_extension
    node.url = su + "/movie/" + u + "/" + p + "/" + sid + "." + ext
    if item.stream_icon <> invalid and item.stream_icon <> "" then
        node.HDPosterUrl = item.stream_icon
    else
        node.HDPosterUrl = "pkg:/images/no-poster.jpg"
    end if
    if item.rating <> invalid then node.rating = safeStr(item.rating)
    if item.container_extension <> invalid
        extLower = LCase(item.container_extension)
        if extLower = "m3u8" then node.StreamFormat = "hls"
        if extLower = "mpd" then node.StreamFormat = "mpeg-dash"
    end if
    if item.releasedate <> invalid then node.releaseDate = safeStr(item.releasedate)
    setBackdrop(node, item)
    setDuration(node, item)
    if not node.hasField("genre") then node.addFields({genre: "", director: "", episodeRunTime: ""})
    if item.genre <> invalid then node.genre = item.genre
    if item.director <> invalid then node.director = item.director
    if item.episode_run_time <> invalid then node.episodeRunTime = safeStr(item.episode_run_time)
end sub

sub fillSerieNode(node as Object, item as Object)
    node.id = safeStr(item.series_id)
    node.ContentType = "2"
    if item.name <> invalid and item.name <> ""
        node.title = item.name
    else
        localTitle = ""
        aa = Fav_LocalRead("serie", safeStr(item.series_id))
        if aa <> invalid and aa.title <> invalid and aa.title <> "" then localTitle = aa.title
        if localTitle <> "" then node.title = localTitle
    end if
    setDescription(node, item)
    if item.releasedate <> invalid then node.releaseDate = safeStr(item.releasedate)
    if item.cover <> invalid and item.cover <> "" then
        node.HDPosterUrl = item.cover
    else
        node.HDPosterUrl = "pkg:/images/no-poster.jpg"
    end if
    if item.rating <> invalid then node.rating = safeStr(item.rating)
    if not node.hasField("genre") then node.addFields({genre: "", director: "", episodeRunTime: ""})
    if item.genre <> invalid then node.genre = item.genre
    if item.episode_run_time <> invalid then node.episodeRunTime = safeStr(item.episode_run_time)
    setBackdrop(node, item)
end sub

sub loadBanners()
    urls = []
    urls.push(m.global.panelURL + "/img/ads.jpg")
    m.top.bannerResults = urls
end sub

sub loadCategoryItems()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass
    catId = m.top.categoryId
    isSerie = m.top.isSerie

    if su = "" or u = "" or p = "" or catId = ""
        m.top.contentResults = content
        return
    end if

    if isSerie
        url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_series&category_id=" + catId
    else
        url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_vod_streams&category_id=" + catId
    end if

    itemsJson = ParseJSON(requestData(url))
    if itemsJson <> invalid and type(itemsJson) = "roArray"
        itemsJson = sortByAdded(itemsJson)
        mx = itemsJson.count()
        for i = 0 to mx - 1
            node = content.createChild("ContentNode")
            if isSerie
                fillSerieNode(node, itemsJson[i])
            else
                fillMovieNode(node, itemsJson[i], su, u, p)
            end if
        end for
    end if
    m.top.contentResults = content
end sub

sub loadRecentMovies()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass

    if su = "" or u = "" or p = ""
        m.top.contentResults = content
        return
    end if

    itemsJson = ParseJSON(requestData(su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_vod_streams", 30000))

    if itemsJson = invalid or type(itemsJson) <> "roArray" or itemsJson.count() = 0
        print "DEBUG loadRecentMovies - primer intento fallo o respuesta no es array, reintentando..."
        itemsJson = ParseJSON(requestData(su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_vod_streams", 30000))
    end if

    if itemsJson = invalid or type(itemsJson) <> "roArray" or itemsJson.count() = 0
        print "DEBUG loadRecentMovies - servidor no devolvio un array valido, se muestra vacio"
        m.top.contentResults = content
        return
    end if

    itemsJson = sortByAdded(itemsJson)

    count = 0
    for each item in itemsJson
        if count >= 20 then exit for
        node = content.createChild("ContentNode")
        fillMovieNode(node, item, su, u, p)
        count = count + 1
    end for

    m.top.contentResults = content
end sub

sub searchMovies()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass
    query = LCase(m.top.searchQuery)

    if su = "" or u = "" or p = "" or query = ""
        m.top.contentResults = content
        return
    end if

    vodUrl = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_vod_streams"
    allJson = ParseJSON(requestData(vodUrl, 30000))

    if allJson = invalid or type(allJson) <> "roArray" or allJson.count() = 0
        print "DEBUG searchMovies - primer intento fallo, reintentando..."
        allJson = ParseJSON(requestData(vodUrl, 30000))
    end if

    if allJson <> invalid and type(allJson) = "roArray"
        found = 0
        for i = 0 to allJson.count() - 1
            if found >= 50 then exit for
            if allJson[i].name <> invalid
                itemName = allJson[i].name
                if not PC_isAdultName(itemName)
                    if Instr(1, LCase(itemName), query) > 0
                        node = content.createChild("ContentNode")
                        fillMovieNode(node, allJson[i], su, u, p)
                        found = found + 1
                    end if
                end if
            end if
        end for
    end if
    m.top.contentResults = content
end sub

sub searchSeries()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass
    query = LCase(m.top.searchQuery)

    if su = "" or u = "" or p = "" or query = ""
        m.top.contentResults = content
        return
    end if

    seriesUrl = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_series"
    allJson = ParseJSON(requestData(seriesUrl, 30000))

    if allJson = invalid or type(allJson) <> "roArray" or allJson.count() = 0
        print "DEBUG searchSeries - primer intento fallo, reintentando..."
        allJson = ParseJSON(requestData(seriesUrl, 30000))
    end if

    if allJson <> invalid and type(allJson) = "roArray"
        found = 0
        for i = 0 to allJson.count() - 1
            if found >= 50 then exit for
            if allJson[i].name <> invalid
                itemName = allJson[i].name
                if not PC_isAdultName(itemName)
                    if Instr(1, LCase(itemName), query) > 0
                        node = content.createChild("ContentNode")
                        fillSerieNode(node, allJson[i])
                        found = found + 1
                    end if
                end if
            end if
        end for
    end if
    m.top.contentResults = content
end sub

' ============================================================
' DEEP LINKING (cert 5.1/5.2): resuelve un contentId+mediaType que
' llega de Roku Search/voz/ECP a un nodo de contenido listo para
' DetailsScreen/Seasons/EPG. Reutiliza fillMovieNode/fillSerieNode
' para que el nodo quede IDENTICO al de un click normal en Browse.
' ============================================================

' mediaType=movie -> get_vod_info (info + movie_data) aplanado
sub deepLinkMovie()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass
    id = m.top.deepLinkId

    if su = "" or u = "" or p = "" or id = ""
        m.top.contentResults = content
        return
    end if

    url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_vod_info&vod_id=" + id
    json = ParseJSON(requestData(url, 30000))
    if json = invalid
        json = ParseJSON(requestData(url, 30000))
    end if

    if json <> invalid and type(json) = "roAssociativeArray"
        item = {}
        if json.info <> invalid and type(json.info) = "roAssociativeArray"
            for each k in json.info
                item[k] = json.info[k]
            end for
        end if
        if json.movie_data <> invalid and type(json.movie_data) = "roAssociativeArray"
            for each k in json.movie_data
                item[k] = json.movie_data[k]
            end for
        end if
        if item.stream_id = invalid or item.stream_id = "" then item.stream_id = id
        node = content.createChild("ContentNode")
        fillMovieNode(node, item, su, u, p)
    end if

    m.top.contentResults = content
end sub

' mediaType=series/season/episode -> get_series_info (series_info)
sub deepLinkSeries()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass
    id = m.top.deepLinkId

    if su = "" or u = "" or p = "" or id = ""
        m.top.contentResults = content
        return
    end if

    url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_series_info&series_id=" + id
    json = ParseJSON(requestData(url, 30000))
    if json = invalid
        json = ParseJSON(requestData(url, 30000))
    end if

    if json <> invalid and type(json) = "roAssociativeArray"
        item = {}
        if json.series_info <> invalid and type(json.series_info) = "roAssociativeArray"
            for each k in json.series_info
                item[k] = json.series_info[k]
            end for
        else
            ' fallback: algunos proveedores devuelven el objeto plano
            for each k in json
                if k <> "episodes" then item[k] = json[k]
            end for
        end if
        if item.series_id = invalid or item.series_id = "" then item.series_id = id
        node = content.createChild("ContentNode")
        fillSerieNode(node, item)
    end if

    m.top.contentResults = content
end sub

' mediaType=live: escribe en registry la categoria (CatID/CatTITLE) y el
' canal (LastChannelID) para que EpgGuiaScreen abra SOBRE ese canal y lo
' reproduzca (onContentLoaded -> playChannel). Devuelve 1 hijo solo si el
' canal existe; 0 hijos = contentId invalido -> MainScene muestra error.
sub deepLinkLive()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass
    id = m.top.deepLinkId
    catGet = m.global.catGet
    if catGet = invalid or catGet = "" then catGet = "CatLiveTV"

    if id <> "" then RegWrite(catGet, id, "LastChannelID")

    if su <> "" and u <> "" and p <> "" and id <> ""
        liveUrl = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_live_streams"
        json = ParseJSON(requestData(liveUrl, 30000))
        if json = invalid then json = ParseJSON(requestData(liveUrl, 30000))

        catId = ""
        if json <> invalid and type(json) = "roArray"
            for each ch in json
                if type(ch) = "roAssociativeArray" and ch.stream_id <> invalid
                    if safeStr(ch.stream_id) = id
                        catId = safeStr(ch.category_id)
                        node = content.createChild("ContentNode")
                        node.id = id
                        node.ContentType = "live"
                        if ch.name <> invalid then node.title = ch.name
                        exit for
                    end if
                end if
            end for
        end if

        if catId <> ""
            catsUrl = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_live_categories"
            cats = ParseJSON(requestData(catsUrl, 30000))
            catTitle = ""
            if cats <> invalid and type(cats) = "roArray"
                for each c in cats
                    if type(c) = "roAssociativeArray" and c.category_id <> invalid
                        if safeStr(c.category_id) = catId
                            catTitle = safeStr(c.category_name)
                            exit for
                        end if
                    end if
                end for
            end if
            RegWrite(catGet, catId, "CatID")
            RegWrite(catGet, catTitle, "CatTITLE")
        end if
    end if

    m.top.contentResults = content
end sub

' ============================================================
' Busqueda rapida de peliculas Y series en UNA sola peticion, via
' buscador.php (mismo endpoint propio que ya se uso para el buscador
' de canales -- ver SearchChannelsTask.brs). Con tipoid=0 el PHP
' pregunta a get_vod_streams Y get_series de una vez y filtra por
' nombre del lado del servidor, devolviendo ya listo solo lo que
' coincide -- en vez del metodo viejo (searchMovies/searchSeries),
' que bajaba el catalogo COMPLETO de peliculas y el de series enteros
' al Roku (dos peticiones pesadas) para filtrar ahi mismo.
'
' Los items que regresa el PHP traen los mismos campos crudos de
' Xtream (name, stream_id/series_id, stream_icon, plot, genre, etc. --
' el PHP solo les agrega tipoid/url_reproduccion encima), asi que se
' arman con las mismas fillMovieNode/fillSerieNode de siempre, sin
' perder ningun dato respecto al metodo viejo.
sub fastSearch()
    moviesContent = createObject("roSGNode", "ContentNode")
    seriesContent = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u  = m.global.user
    p  = m.global.pass
    apiBase = m.global.urlBuscador
    query = m.top.searchQuery
    if query = invalid then query = ""
    query = query.Trim()

    if apiBase = "" or su = "" or su = "DEMO" or u = "" or p = "" or query = ""
        m.top.moviesResults = moviesContent
        m.top.seriesResults = seriesContent
        m.top.searchComplete = true
        return
    end if

    url = apiBase + "?username=" + GU_UrlEncode(u) + "&password=" + GU_UrlEncode(p) + "&search=" + GU_UrlEncode(query) + "&tipoid=0&baseurl=" + GU_UrlEncode(su)
    allJson = ParseJSON(requestData(url, 30000))

    if allJson = invalid or type(allJson) <> "roArray" or allJson.count() = 0
        print "DEBUG fastSearch - primer intento fallo, reintentando..."
        allJson = ParseJSON(requestData(url, 30000))
    end if

    if allJson <> invalid and type(allJson) = "roArray"
        foundMovies = 0
        foundSeries = 0
        for i = 0 to allJson.count() - 1
            item = allJson[i]
            if type(item) = "roAssociativeArray" and item.name <> invalid
                if not PC_isAdultName(item.name)
                    itemTipoid = safeStr(item.tipoid)
                    if itemTipoid = "2" and foundMovies < 50
                        node = moviesContent.createChild("ContentNode")
                        fillMovieNode(node, item, su, u, p)
                        foundMovies = foundMovies + 1
                    else if itemTipoid = "3" and foundSeries < 50
                        node = seriesContent.createChild("ContentNode")
                        fillSerieNode(node, item)
                        foundSeries = foundSeries + 1
                    end if
                end if
            end if
        end for
    end if

    m.top.moviesResults = moviesContent
    m.top.seriesResults = seriesContent
    m.top.searchComplete = true
end sub

sub loadFavorites()
    print "DEBUG loadFavorites - iniciando"
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass

    if su = "" or u = "" or p = ""
        print "DEBUG loadFavorites - credenciales vacias"
        m.top.contentResults = content
        return
    end if

    ' --- SINCRONIZAR con el servidor (trae solo lo que cambio desde
    ' otros dispositivos desde la ultima vez, es rapido) y despues
    ' servir desde local, que ya queda al dia. ---
    usuario = getStrValFromReg("user_tv", "datos_tv")
    print "DEBUG loadFavorites - sincronizando con servidor. usuario="; usuario
    Fav_SyncFromServer(usuario, su, u, p)

    content = Fav_BuildTop20ContentNode()

    print "DEBUG loadFavorites - total cargados = "; content.getChildCount()
    m.top.contentResults = content
end sub

' ============================================================
' "Recien Vistas": peliculas y series mezcladas, ordenadas por
' fecha de visto (mas reciente primero), tope de 18. Mismo patron
' local-primero/sembrar-si-vacio que loadFavorites().
' ============================================================
sub loadRecentlyWatched()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass

    if su = "" or u = "" or p = ""
        m.top.contentResults = content
        return
    end if

    usuario = getStrValFromReg("user_tv", "datos_tv")
    print "DEBUG loadRecentlyWatched - sincronizando con servidor. usuario="; usuario
    RW_SyncFromServer(usuario, su, u, p)
    items = RW_LocalListAllSorted(RW_Limit())

    for each aa in items
        node = Fav_AAToNode(aa)
        if aa.tipo = "serie"
            if not node.hasField("isSerie") then node.addFields({isSerie: true})
        end if
        if not node.hasField("showProgress") then node.addFields({showProgress: true})
        if aa.lastEpisodeId <> invalid and aa.lastEpisodeId <> ""
            node.addFields({lastEpisodeId: aa.lastEpisodeId.toStr()})
        else if not node.hasField("lastEpisodeId")
            node.addFields({lastEpisodeId: ""})
        end if
        ' Datos completos del capitulo (ver Seasons.brs/registerRecentlyWatched
        ' y HomeScreen.brs/playRWSerieDirect) -- mismo motivo que lastEpisodeId
        ' arriba, setFields() no crea campos nuevos por su cuenta.
        if aa.lastEpisodeData <> invalid and aa.lastEpisodeData <> ""
            node.addFields({lastEpisodeData: aa.lastEpisodeData.toStr()})
        else if not node.hasField("lastEpisodeData")
            node.addFields({lastEpisodeData: ""})
        end if
        print "DEBUG LOADRW - aa.tipo="; aa.tipo; " aa.lastEpisodeId(crudo)="; aa["lastEpisodeId"]; " node.isSerie="; node.isSerie; " node.showProgress="; node.showProgress; " node.lastEpisodeId="; node.lastEpisodeId
        content.appendChild(node)
    end for

    print "DEBUG loadRecentlyWatched - total = "; content.getChildCount()
    m.top.contentResults = content
end sub

' ============================================================
' Sincroniza el AVANCE ("seguir viendo") contra el servidor
' (WatchProgressLocalStore.brs). ESTO FALTABA POR COMPLETO: la
' funcion WP_SyncFromServer ya existia, completa y probada (mismo
' patron que favoritos/recien vistos), pero nada en toda la app la
' llamaba -- WP_LocalRead/WP_LocalFraction (HomeScreen, DetailsScreen,
' Seasons, EpisodesListItem, BrowseCardItem) SOLO leian el cache local
' de este dispositivo, asi que el avance guardado desde CUALQUIER otro
' dispositivo (Android, u otro Roku) nunca se descargaba -- por mas
' que el servidor si lo tuviera. No hace falta devolver contenido
' (a diferencia de loadFavorites/loadRecentlyWatched): esta funcion
' solo necesita CORRER para refrescar el cache local en disco/registro
' que las pantallas ya leen directo.
' ============================================================
sub loadProgress()
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass
    if su = "" or u = "" or p = "" then return

    usuario = getStrValFromReg("user_tv", "datos_tv")
    print "DEBUG loadProgress - sincronizando avance con servidor. usuario="; usuario
    WP_SyncFromServer(usuario)
end sub

sub loadRecentSeries()
    content = createObject("roSGNode", "ContentNode")
    su = m.global.serverURL
    u = m.global.user
    p = m.global.pass

    if su = "" or u = "" or p = ""
        m.top.contentResults = content
        return
    end if

    seriesUrl = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_series"
    itemsJson = ParseJSON(requestData(seriesUrl, 30000))

    if itemsJson = invalid or type(itemsJson) <> "roArray" or itemsJson.count() = 0
        print "DEBUG loadRecentSeries - primer intento fallo, reintentando..."
        itemsJson = ParseJSON(requestData(seriesUrl, 30000))
    end if

    if itemsJson = invalid or type(itemsJson) <> "roArray" or itemsJson.count() = 0
        m.top.contentResults = content
        return
    end if

    filtered = []
    for each item in itemsJson
        filtered.push(item)
    end for

    filtered = sortByAdded(filtered)

    count = 0
    for each item in filtered
        if count >= 20 then exit for
        node = content.createChild("ContentNode")
        fillSerieNode(node, item)
        count = count + 1
    end for

    m.top.contentResults = content
end sub

' NOTA: antes esto era un insertion sort O(n^2). Con categorias de
' 1000+ items eso solo (sin contar red ni creacion de nodos) ya tomaba
' varios segundos. Se reemplazo por merge sort O(n log n), mismo
' resultado, mucho mas rapido en categorias grandes.
'
' Criterio de "mas reciente" = ID (stream_id/series_id), NO "added".
' El campo "added" de Xtream es notoriamente poco confiable en varios
' proveedores (algunos lo ponen una sola vez al importar el catalogo
' completo y nunca lo vuelven a actualizar por item, dejando todo con
' fechas viejas o iguales). El ID en cambio es autoincremental en la
' inmensa mayoria de paneles Xtream: el numero mas alto SIEMPRE es lo
' mas nuevo, sin depender de que el proveedor mantenga bien esa otra
' fecha. "added"/"last_modified" quedan solo de respaldo, por si el
' item no trajera id por algun motivo raro.
function addedOfItem(item as Object) as Integer
    idVal = item.stream_id
    if idVal = invalid then idVal = item.series_id
    if idVal <> invalid
        t = type(idVal)
        if t = "roString" or t = "String" then return val(idVal)
        if t = "roInt" or t = "roInteger" or t = "Integer" then return idVal
    end if
    if item.added <> invalid
        t = type(item.added)
        if t = "roString" or t = "String" then return val(item.added)
        if t = "roInt" or t = "roInteger" or t = "Integer" then return item.added
    end if
    if item.last_modified <> invalid
        t = type(item.last_modified)
        if t = "roString" or t = "String" then return val(item.last_modified)
        if t = "roInt" or t = "roInteger" or t = "Integer" then return item.last_modified
    end if
    return 0
end function

function mergeByAddedItem(left as Object, right as Object) as Object
    result = []
    i = 0
    j = 0
    while i < left.count() and j < right.count()
        if addedOfItem(left[i]) >= addedOfItem(right[j])
            result.push(left[i])
            i = i + 1
        else
            result.push(right[j])
            j = j + 1
        end if
    end while
    while i < left.count()
        result.push(left[i])
        i = i + 1
    end while
    while j < right.count()
        result.push(right[j])
        j = j + 1
    end while
    return result
end function

function sortByAdded(items as Object) as Object
    if items = invalid or items.count() <= 1 then return items
    mid = items.count() \ 2
    left = []
    right = []
    for i = 0 to mid - 1
        left.push(items[i])
    end for
    for i = mid to items.count() - 1
        right.push(items[i])
    end for
    left = sortByAdded(left)
    right = sortByAdded(right)
    return mergeByAddedItem(left, right)
end function
