' ============================================================
' ParentalControl.brs - Sistema Parental Control completo
' Patron: registry key "lock" = PIN, default "0000"
'         registry key "pc_vod"    = JSON array de category_ids bloqueados
'         registry key "pc_series" = JSON array de category_ids bloqueados
'         registry key "pc_live"   = JSON array de category_ids bloqueados
' ============================================================

' Seccion del registry
function PC_section() as String
    return "IPTV_PC"
end function

' ---- PIN ----
function PC_getPin() as String
    v = RegRead("lock", PC_section())
    if v = invalid or v = "" then return "0000"
    return v
end function

function PC_setPin(pin as String)
    RegWrite("lock", pin, PC_section())
end function

function PC_verifyPin(input as String) as Boolean
    return input = PC_getPin()
end function

function PC_hasCustomPin() as Boolean
    return PC_getPin() <> "0000"
end function

' ---- CATEGORIAS BLOQUEADAS ----
' tipo: "vod" | "series" | "live"
function PC_getBlocked(tipo as String) as Object
    key = "pc_" + tipo
    raw = RegRead(key, PC_section())
    if raw = invalid or raw = "" then return {}
    arr = ParseJSON(raw)
    result = {}
    if arr = invalid then return result
    if type(arr) <> "roArray" then return result
    for each idVal in arr
        id = ""
        t = type(idVal)
        if t = "roString" or t = "String" then id = idVal
        if t = "roInt" or t = "roInteger" or t = "Integer" then id = idVal.toStr()
        if id <> "" then result[id] = true
    end for
    return result
end function

function PC_saveBlocked(tipo as String, blockedMap as Object)
    ids = []
    for each k in blockedMap
        ids.push(k)
    end for
    key = "pc_" + tipo
    RegWrite(key, FormatJSON(ids), PC_section())
end function

function PC_isCatBlocked(catId as String, tipo as String) as Boolean
    if catId = "" or catId = "0" then return false
    blocked = PC_getBlocked(tipo)
    return blocked.DoesExist(catId)
end function

' Normaliza category_id a string sin importar tipo
function PC_id(val as Dynamic) as String
    if val = invalid then return ""
    t = type(val)
    if t = "roString"      or t = "String"      then return val.trim()
    if t = "roInt"         or t = "roInteger"   then return val.toStr()
    if t = "Integer"                             then return val.toStr()
    if t = "roFloat"       or t = "Float"       then return Int(val).toStr()
    if t = "roLongInteger" or t = "LongInteger" then return val.toStr()
    return ""
end function

' Filtro de palabras adultas - array estatico, creado una sola vez por llamada
' No usar en loops - llamar PC_isAdultName() que es mas eficiente
function PC_adultKeywords() as Object
    return ["xxx","porn","porno","adult","adulto","adultos","erotic","erotica",
            "hentai","18+","+18","x-rated","brazzers","nude","nudity",
            "hardcore","softcore","milf","sex ","sexo "]
end function

function PC_isAdultName(name as String) as Boolean
    if name = invalid or name = "" then return false
    lower = LCase(name)
    for each w in PC_adultKeywords()
        if Instr(1, lower, w) > 0 then return true
    end for
    return false
end function
