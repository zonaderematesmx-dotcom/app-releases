' ============================================================
' MainScene.brs - CON VIDEO INTRO + VALIDACION DE VIGENCIA (fecha)
' ============================================================
' - Reproduce video intro horizontal al abrir la app
' - No se puede saltar (Back bloqueado durante el intro)
' - En paralelo descarga config.json y valida vigencia.fecha
' - Si la fecha ya vencio, la app se bloquea y se cierra sola,
'   sin importar si el video intro ya termino o no
' - Al terminar ambas cosas (intro + validacion) -> flujo normal
'   (login o home), solo si NO esta vencida
' ============================================================

sub init()
    
    m.top.SetFocus(true)

    ' ============================================================
    ' MEMORY MONITOR - Para warnings 7 al 11 de Roku
    ' ============================================================
    m.appMemoryMonitor = CreateObject("roAppMemoryMonitor")
    m.appMemoryMonitor.EnableMemoryWarningEvent(true)

    m.deviceInfo = CreateObject("roDeviceInfo")
    m.deviceInfo.EnableLowGeneralMemoryEvent(true)

    m.appMemoryMonitor.GetMemoryLimitPercent()
    m.appMemoryMonitor.GetChannelMemoryLimit()
    m.appMemoryMonitor.GetChannelAvailableMemory()

    m.LoadingIndicator = m.top.findNode("MainLoadingIndicator")

    ' Leer URL base del panel desde el manifest
    appInfo = CreateObject("roAppInfo")
    panelURL = appInfo.GetValue("panel_url")
    if panelURL = invalid or panelURL = "" then panelURL = ""
    if Right(panelURL, 1) = "/" then panelURL = Left(panelURL, Len(panelURL) - 1)

    ' ============================================================
    ' CONFIG REMOTO (config.json) - colores, servidores y vigencia
    ' JSON esperado: { "serverURLs": [...], "vigencia": {"variante":"...", "fecha":"YYYY-MM-DD"},
    '                  "focusColor": "0x...", "backgroundColor": "0x..." }
    ' IMPORTANTE: la descarga se hace en ConfigTask (hilo Task),
    ' NUNCA aqui directamente: roUrlTransfer no puede crearse en
    ' el hilo de render (Scene), solo en MAIN o en un Task.
    ' ============================================================
    m.defaultFocusColor = "0xE50914FF"
    m.defaultBgColor    = "0x141414FF"

    m.top.backgroundColor = m.defaultBgColor

    m.global.addFields({
        serverURL: "", row: "", items: "", info: "", play: "", 
        user: "", pass: "", expire: "", serie: "", epg: "", 
        catGet: "", catSet: "", episode: "", settingsAuth: false, 
        panelURL: panelURL,
        focusColor: m.defaultFocusColor,
        backgroundColor: m.defaultBgColor,
        serverURLs: [],
        mensaje: "",
        urlFavoritos: "",
        urlRecientes: "",
        urlProgreso: "",
        urlAjustes: "",
        urlBuscador: "",
        urlResolver: "",
        urlPerfiles: "https://tanex-streaming-1.onrender.com/roku/perfiles.php",
        ' Variante del servidor autenticado (1,2,3... segun config.json).
        ' FALTABA declararlo aqui -- sin este campo pre-declarado en
        ' m.global, TODAS las asignaciones "m.global.serverVariant = ..."
        ' en ConfirmUser.brs y en Tasks/LoginTask.xml fallaban en
        ' silencio (Roku solo imprime un WARNING, nunca un error/crash):
        ' "Tried to set nonexistent field 'servervariant' of a 'Node'
        ' node". Por eso m.global.serverVariant se quedaba SIEMPRE en
        ' invalid, y CurrentServerVariante() (SelectProfileScreen.brs)
        ' caia siempre a su fallback "0", sin importar a que servidor
        ' se autenticara el usuario realmente. Esto es lo que hacia que
        ' favoritos/recientes/progreso de Roku nunca coincidieran con
        ' los de Android (que si calculaba bien su variante): quedaban
        ' guardados/leidos bajo variante distinta en el servidor.
        serverVariant: "0",
        ' Perfil actual (hasta 5 por cuenta+servidor) elegido en
        ' SelectProfileScreen justo despues del login -- ver
        ' ShowProfileSelect/onProfileChosen mas abajo. "0" = todavia sin
        ' elegir/legado, mismo default que perfiles.php.
        profileId: "0",
        ' Nombre y color de avatar del perfil elegido (ver
        ' SelectProfileScreen.brs/onTileSelected) -- para mostrarlos en
        ' la barra de menu de HomeScreen (ver HomeScreen.brs, item de
        ' perfil) sin tener que volver a pedirle la lista al panel.
        profileNombre: "",
        profileColor: "",
        movieDiag: {}
    })

    ' Disparar la descarga del config en background (no bloquea el arranque)
    configUrl = appInfo.GetValue("config_url")
    if configUrl <> invalid and configUrl <> ""
        m.configTask = CreateObject("roSGNode", "ConfigTask")
        m.configTask.observeField("response", "onConfigResponse")
        m.configTask.uri = configUrl
        m.configTask.control = "RUN"
    end if

    m.homeVisible = false
    m.homeScreen = invalid
    ' Beacons de certificacion (Roku: "Measuring app performance").
    ' AppLaunchComplete se dispara UNA vez, cuando Home queda visible y
    ' con foco (showMenuList). AppDialogInitiate/Complete se emparejan
    ' alrededor de las pantallas que esperan input ANTES del Home
    ' (login RegScreen y selector de perfiles), ver fireDialog* abajo.
    m.launchBeaconFired = false
    m.dialogBeaconOpen = false
    ' Deep linking (cert 5.1/5.2): overlay de Details/Seasons abierto por
    ' handleDeepLink(), task de resolucion y dialogo de error por
    ' contentId invalido. dlPending lo escribe main.brs (args de Main o
    ' roInputEvent) y este observer lo consume apenas sea posible.
    m.dlDetails = invalid
    m.dlSeasons = invalid
    m.dlTask = invalid
    m.dlLiveTask = invalid
    m.dlErrorDialog = invalid
    m.global.observeField("dlPending", "onDlPendingChanged")
    m.spGroup = m.top.findNode("spGroup")
    m.spPad   = m.top.findNode("spPad")
    m.spMsg   = m.top.findNode("spMsg")
    m.spErr   = m.top.findNode("spErr")

    ' === Referencia al video intro ===
    m.introVideo = m.top.findNode("IntroVideo")
    m.introPlaying = false
    m.goLaunched = false

    ' === NUEVO: sincronizacion fecha/intro ===
    m.introFinished = false
    m.configArrived = false
    m.appExpired = false

    m.configTimeout = m.top.findNode("configTimeout")
    m.configTimeout.observeField("fire", "onConfigTimeout")
    m.configTimeout.control = "start"

    ' Iniciar con el video intro
    playIntroVideo()
end sub

' ============================================================
' Se dispara cuando ConfigTask termina de descargar config.json
' Aqui SI es seguro usar ParseJSON (no crea roUrlTransfer, no
' tiene la restriccion de hilo MAIN|TASK)
' ============================================================
sub onConfigResponse()
    raw = m.configTask.response
    if raw = invalid or raw = "" then
        print "onConfigResponse: respuesta vacia, se mantienen colores por defecto"
        m.configArrived = true
        m.configTimeout.control = "stop"
        tryLaunch()
        return
    end if

    json = ParseJSON(raw)
    if json = invalid then
        print "onConfigResponse: JSON invalido"
        m.configArrived = true
        m.configTimeout.control = "stop"
        tryLaunch()
        return
    end if

    focusColor = SafeColor(json.focusColor, m.defaultFocusColor)
    bgColor    = SafeColor(json.backgroundColor, m.defaultBgColor)

    m.global.focusColor = focusColor
    m.global.backgroundColor = bgColor
    m.top.backgroundColor = bgColor

    ' El MainLoadingIndicator se crea ANTES que este init() corra
    ' (los hijos se inicializan antes que el padre en SceneGraph), asi
    ' que su propio "m.global.observeField(focusColor, ...)" interno
    ' se registro cuando el campo aun no existia y Roku descarta ese
    ' registro silenciosamente. Por eso se le aplica el color aqui
    ' directamente, a la fuerza, en vez de confiar en ese observer.
    if m.LoadingIndicator <> invalid
        d1 = m.LoadingIndicator.findNode("dot1")
        d2 = m.LoadingIndicator.findNode("dot2")
        d3 = m.LoadingIndicator.findNode("dot3")
        if d1 <> invalid then d1.blendColor = focusColor
        if d2 <> invalid then d2.blendColor = focusColor
        if d3 <> invalid then d3.blendColor = focusColor
    end if

    if json.serverURLs <> invalid and type(json.serverURLs) = "roArray"
        m.global.serverURLs = json.serverURLs
    end if

    ' ============================================================
    ' NUEVO: links de los 4 PHP propios (favoritos/recientes/progreso/
    ' ajustes), editables desde el panel en la seccion "Base de datos".
    ' Si el JSON no trae "phpUrls" o falta alguna clave, se conserva
    ' el valor por defecto ya puesto en addFields() arriba.
    ' ============================================================
    if json.phpUrls <> invalid and type(json.phpUrls) = "roAssociativeArray"
        pu = json.phpUrls
        if pu.favoritos <> invalid and pu.favoritos.toStr().Trim() <> "" then m.global.urlFavoritos = pu.favoritos
        if pu.recientes <> invalid and pu.recientes.toStr().Trim() <> "" then m.global.urlRecientes = pu.recientes
        if pu.progreso  <> invalid and pu.progreso.toStr().Trim()  <> "" then m.global.urlProgreso  = pu.progreso
        if pu.ajustes   <> invalid and pu.ajustes.toStr().Trim()   <> "" then m.global.urlAjustes   = pu.ajustes
        if pu.buscador  <> invalid and pu.buscador.toStr().Trim()  <> "" then m.global.urlBuscador  = pu.buscador
        if pu.resolver  <> invalid and pu.resolver.toStr().Trim()  <> "" then m.global.urlResolver  = pu.resolver
        if pu.perfiles  <> invalid and pu.perfiles.toStr().Trim()  <> "" then m.global.urlPerfiles  = pu.perfiles
    end if

    ' Mensaje de aviso (login/home): aparece con su rectangulo solo si
    ' el JSON trae la clave "mensaje" con texto; si no viene o viene
    ' vacia, se manda "" y las pantallas lo ocultan solas.
    msg = ""
    if json.mensaje <> invalid then msg = json.mensaje.toStr().Trim()
    m.global.mensaje = msg

    ' ============================================================
    ' NUEVO: validar vigencia (json.vigencia.fecha)
    ' El campo "variante" dentro de vigencia se ignora a proposito,
    ' solo importa la fecha.
    ' ============================================================
    vigenciaFecha = invalid
    if json.vigencia <> invalid and type(json.vigencia) = "roAssociativeArray"
        vigenciaFecha = json.vigencia.fecha
    end if
    m.appExpired = IsAppExpired(vigenciaFecha)

    ' ============================================================
    ' AVISO DE VERSION desde config.json (controlado desde el panel):
    ' si la version activa del panel es MAYOR que la del manifest,
    ' se antepone al mensaje del banner usando el mecanismo visual que
    ' ya existe (sin UI nueva). El panel es quien decide el texto
    ' publicandolo como version activa de la marca player_roku.
    ' ============================================================
    if json.version <> invalid and type(json.version) = "roAssociativeArray"
        ver = json.version
        if ver.name <> invalid and ver.name.toStr().Trim() <> ""
            appInfo2 = CreateObject("roAppInfo")
            curVer = appInfo2.GetVersion()
            if IsNewerVersion(ver.name.toStr().Trim(), curVer)
                aviso = "Nueva version " + ver.name.toStr().Trim() + " disponible"
                if m.global.mensaje <> "" then
                    m.global.mensaje = aviso + "  -  " + m.global.mensaje
                else
                    m.global.mensaje = aviso
                end if
            end if
        end if
    end if

    m.configArrived = true
    m.configTimeout.control = "stop"
    tryLaunch()
end sub

' Compara dos versiones "x.y.z": true si newV es estrictamente mayor
' que curV (se ignoran partes faltantes o no numericas).
function IsNewerVersion(newV as String, curV as String) as Boolean
    a = newV.Split(".")
    b = curV.Split(".")
    for i = 0 to 2
        na = 0
        nb = 0
        if a.Count() > i then na = a[i].Trim().ToInt()
        if b.Count() > i then nb = b[i].Trim().ToInt()
        if na > nb then return true
        if na < nb then return false
    end for
    return false
end function

' ============================================================
' Compara vigencia.fecha (formato "YYYY-MM-DD") contra la fecha
' actual del dispositivo. Retorna true si ya vencio.
' La app sigue funcionando durante todo el dia indicado en
' "fecha" y se bloquea a partir del dia siguiente (23:59:59 del
' dia limite, en UTC).
' ============================================================
function IsAppExpired(fecha as Dynamic) as Boolean
    if fecha = invalid or fecha = "" then return false ' sin fecha = no restringe
    if type(fecha) <> "String" then return false

    ' Validar formato basico "YYYY-MM-DD" (10 caracteres, guiones en posicion)
    if Len(fecha) <> 10 or Mid(fecha, 5, 1) <> "-" or Mid(fecha, 8, 1) <> "-"
        print "IsAppExpired: formato de fecha invalido -> "; fecha
        return false
    end if

    limite = CreateObject("roDateTime")
    limite.FromISO8601String(fecha + "T23:59:59Z") ' no retorna valor, solo modifica "limite"

    ' Si el parseo interno fallo, roDateTime suele quedar en epoch (1970-01-01, AsSeconds() muy bajo)
    if limite.AsSeconds() < 1000000000 ' antes del año ~2001, algo salio mal
        print "IsAppExpired: no se pudo parsear la fecha -> "; fecha
        return false
    end if

    ahora = CreateObject("roDateTime")
    ahora.Mark() ' fecha/hora actual del dispositivo

    return ahora.AsSeconds() > limite.AsSeconds()
end function

' ============================================================
' Se dispara si config.json no respondio dentro del tiempo
' limite (Timer "configTimeout", 8s por defecto).
' Politica actual: fail-open (se permite continuar).
' Para fail-closed, cambia la linea marcada abajo.
' ============================================================
sub onConfigTimeout()
    print "onConfigTimeout: config.json no respondio a tiempo, se permite continuar"
    ' Para bloquear la app cuando el servidor no responde a tiempo,
    ' descomenta la siguiente linea (fail-closed):
    ' m.appExpired = true
    m.configArrived = true
    tryLaunch()
end sub

' ============================================================
' REPRODUCE VIDEO INTRO (No se puede saltar)
' ============================================================
sub playIntroVideo()
    if m.introVideo = invalid then
        m.introFinished = true
        tryLaunch()
        return
    end if

    videoUrl = "pkg:/videos/intro.mp4"
    print "=== Reproduciendo Video Intro: "; videoUrl

    content = createObject("roSGNode", "ContentNode")
    content.url = videoUrl
    content.streamFormat = "mp4"

    m.introVideo.content = content     ' <- Esta linea es clave
    m.introVideo.visible = true
    m.introVideo.setFocus(true)
    m.introVideo.control = "play"
    m.introPlaying = true

    m.introVideo.observeField("state", "onIntroVideoState")
end sub

sub onIntroVideoState()
    if m.introVideo = invalid then return

    state = m.introVideo.state
    print "Intro Video State: "; state

    if state = "finished" or state = "error"
        m.introPlaying = false
        m.introVideo.control = "stop"
        m.introVideo.content = invalid
        m.introVideo.visible = false
        m.introVideo.unobserveField("state")

        m.introFinished = true
        tryLaunch()
    end if
end sub

' ============================================================
' NUEVO: unico punto de entrada al flujo normal de la app.
' Solo avanza cuando el intro termino Y config.json ya
' respondio (o hizo timeout). Si la vigencia esta vencida,
' corta el flujo y muestra el mensaje de bloqueo.
' ============================================================
sub tryLaunch()
    if not m.introFinished or not m.configArrived then return
    if m.goLaunched then return
    m.goLaunched = true

    if m.appExpired
        ShowExpiredApp()
        return
    end if

    go()
end sub

' ============================================================
' NUEVO: pantalla de bloqueo por vigencia vencida.
' Se cierra sola despues de unos segundos.
' ============================================================
sub ShowExpiredApp()
    bg = m.top.createChild("Rectangle")
    bg.width = 1280
    bg.height = 720
    bg.color = "0x141414FF"

    msg = m.top.createChild("Label")
    msg.text = "Esta aplicación ya no está disponible." + chr(10) + "Contacta a soporte para renovar tu servicio."
    msg.horizAlign = "center"
    msg.vertAlign = "center"
    msg.width = 1000
    msg.translation = [140, 300]
    msg.font = "font:LargeSystemFont"

    m.expiredTimer = m.top.createChild("Timer")
    m.expiredTimer.duration = 6
    m.expiredTimer.repeat = false
    m.expiredTimer.observeField("fire", "onExpiredTimeout")
    m.expiredTimer.control = "start"
end sub

sub onExpiredTimeout()
    m.top.close = true
end sub

sub go()
    m.confirm = createObject("roSGNode", "ConfirmUser")
    m.confirm.control = "RUN"
    m.confirm.observeField("state", "done")
    m.clock = m.top.findNode("clock")
    m.clock.observeField("fire", "updateTime")
end sub

sub ShowLinkScreen()
    m.regScreen = createObject("roSGNode", "RegScreen")
    m.top.appendChild(m.regScreen)
    m.regScreen.setFocus(true)
    m.regscreen.observeField("success", "onRegistrationSuccess")
    fireDialogInitiate()
end sub

' === Beacons AppDialog (cert 3.2 / doc "Measuring app performance") ===
sub fireDialogInitiate()
    if m.dialogBeaconOpen then return
    m.dialogBeaconOpen = true
    m.top.signalBeacon("AppDialogInitiate")
end sub

sub fireDialogComplete()
    if not m.dialogBeaconOpen then return
    m.dialogBeaconOpen = false
    m.top.signalBeacon("AppDialogComplete")
end sub

sub onRegistrationSuccess()
    if m.regScreen <> invalid
        m.top.removeChild(m.regScreen)
        m.regScreen = invalid
    end if
    fireDialogComplete()
    m.clock.duration = 420
    m.clock.repeat = true
    m.clock.control = "start"
    ShowProfileSelect()
end sub

sub done()
    if m.confirm.state <> "stop" then return
    m.loadingIndicator.control = "stop"
    if m.confirm.state = "stop"
        if m.confirm.auth = "1"
            m.clock.duration = 420
            m.clock.repeat = true
            m.clock.control = "start"
            if m.confirm.status = "Disabled"
                hideHomeScreen()
                m.clock.repeat = false
                m.clock.control = "stop"
                m.rowlist = m.top.createChild("Disabled")
                m.rowlist.setFocus(true)
                m.global.info = "1"
            elseif m.confirm.status = "Banned"
                hideHomeScreen()
                m.clock.repeat = false
                m.clock.control = "stop"
                m.rowlist = m.top.createChild("Banned")
                m.rowlist.setFocus(true)
                m.global.info = "1"
            elseif m.confirm.status = "Expired"
                hideHomeScreen()
                m.clock.repeat = false
                m.clock.control = "stop"
                m.rowlist = m.top.createChild("Expired")
                m.rowlist.setFocus(true)
                m.global.info = "1"
            elseif m.confirm.status = "Active"
                ShowProfileSelect()
            end if
        else
            ' Autenticacion fallida: siempre mostrar pantalla de login
            ShowLinkScreen()
        end if
    end if
end sub

' ============================================================
' Pantalla de "¿Quien esta viendo?" -- se muestra despues de un login
' exitoso (tanto el automatico de ConfirmUser como el manual desde
' RegScreen) y ANTES de showMenuList()/Home, para que el dispositivo
' sepa con cual de los hasta 5 perfiles de la cuenta esta viendo cada
' quien (ver m.global.profileId, SelectProfileScreen.brs, perfiles.php).
' ============================================================
sub ShowProfileSelect()
    m.profileScreen = createObject("roSGNode", "SelectProfileScreen")
    m.top.appendChild(m.profileScreen)
    m.profileScreen.setFocus(true)
    m.profileScreen.observeField("profileChosen", "onProfileChosen")
    fireDialogInitiate()
end sub

sub onProfileChosen()
    if m.profileScreen = invalid then return
    if not m.profileScreen.profileChosen then return
    m.top.removeChild(m.profileScreen)
    m.profileScreen.unobserveField("profileChosen")
    m.profileScreen = invalid
    fireDialogComplete()
    showMenuList()
end sub

sub showMenuList()
    if m.regScreen <> invalid
        m.clock.duration = 420
        m.clock.repeat = true
        m.clock.control = "start"
        m.dialog = createObject("roSGNode", "Dialog")
        m.dialog.title = "Felicidades"
        m.dialog.optionsDialog = true
        m.dialog.message = "Has vinculado exitosamente tu cuenta"
        m.dialog.buttons = ["OK"]
        m.dialog.observeField("buttonSelected", "showExitButton")
        m.top.dialog = m.dialog
        m.top.removeChild(m.regScreen)
        m.regScreen = invalid
        fireDialogComplete()
    end if
    if m.homeScreen = invalid
        m.homeScreen = createObject("roSGNode", "HomeScreen")
        m.homeScreen.observeField("menuItemSelected", "onHomeMenuSelected")
        m.top.appendChild(m.homeScreen)
    end if
    m.homeScreen.visible = true
    m.homeVisible = true
    m.homeScreen.setFocus(true)
    ' Cert 3.2: beacon obligatorio, se dispara cuando Home queda
    ' renderizado y operativo (una sola vez por sesion).
    if not m.launchBeaconFired
        m.launchBeaconFired = true
        m.top.signalBeacon("AppLaunchComplete")
    end if
    ' Deep link pendiente desde el lanzamiento (cert 5.1): recien aqui
    ' Home existe y puede abrir el contenido (o mostrar el error y
    ' quedarse en Home si el contentId no existe en el catalogo).
    if m.global.dlPending = true then handleDeepLink()
end sub

sub hideHomeScreen()
    if m.homeScreen <> invalid
        m.homeScreen.visible = false
    end if
    m.homeVisible = false
end sub

sub returnToHome()
    if m.rowlist <> invalid
        m.top.removeChild(m.rowlist)
        m.rowlist = invalid
    end if
    if m.homeScreen <> invalid
        m.homeScreen.visible = true
        m.homeVisible = true
        m.homeScreen.setFocus(true)
    end if
    ' Deep link (roInput) que llego mientras el usuario estaba en otra
    ' pantalla: se resuelve recien aqui, que es cuando Home vuelve a ser
    ' visible (onDlPendingChanged lo salta si homeVisible=false).
    if m.global.dlPending = true then handleDeepLink()
end sub

sub onSubScreenMenuSelected()
    selectedIndex = m.rowlist.menuItemSelected
    if selectedIndex = -1 then
        returnToHome()
        m.homeScreen.returnFocusToNav = 5
        return
    end if
    ' "Cambiar de Perfil" desde Ajustes (unico rowlist que manda esta
    ' señal -- ver SettingsScreen.brs, posicion 8 del menu): quita la
    ' subpantalla actual SIN volver a mostrar Home todavia, y abre el
    ' selector de perfiles, igual que justo despues del login.
    ' onProfileChosen() se encarga de mostrar Home de nuevo una vez
    ' elegido el perfil, y HomeScreen ya recarga Favoritos/Recien
    ' Vistas solo con volverse visible (ver onVisibleChanged en
    ' HomeScreen.brs), asi que no hace falta nada mas para que
    ' reflejen al perfil nuevo.
    if selectedIndex = -2 then
        if m.rowlist <> invalid
            m.top.removeChild(m.rowlist)
            m.rowlist = invalid
        end if
        ShowProfileSelect()
        return
    end if
    returnToHome()
    if selectedIndex = 5
        return
    end if
    m.homeScreen.menuItemSelected = selectedIndex
end sub

sub onHomeMenuSelected()
    selectedIndex = m.homeScreen.menuItemSelected
    if selectedIndex < 0 then return

    if selectedIndex = 3
        hideHomeScreen()
        m.rowlist = createObject("roSGNode", "SettingsScreen")
        m.rowlist.observeField("menuItemSelected", "onSubScreenMenuSelected")
        m.rowlist.observeField("unlinked", "onDeviceUnlinked")
        m.top.appendChild(m.rowlist)
        m.rowlist.setFocus(true)

    elseif selectedIndex = 0
        hideHomeScreen()
        m.global.row = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_live_categories"
        m.global.items = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_live_streams&category_id="
        m.global.play = "/live/" + m.global.user + "/" + m.global.pass + "/"
        m.global.epg = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_short_epg&stream_id="
        m.global.catGet = "CatLiveTV"
        ' Cert: par de beacons EPGLaunch (inicia al abrir la guia; el
        ' Complete lo dispara EpgGuiaScreen cuando la guia queda navegable).
        m.top.signalBeacon("EPGLaunchInitiate")
        m.rowlist = createObject("roSGNode", "EpgGuiaScreen")
        m.rowlist.observeField("menuItemSelected", "onSubScreenMenuSelected")
        m.top.appendChild(m.rowlist)
        m.rowlist.setFocus(true)

    elseif selectedIndex = 1
        hideHomeScreen()
        m.global.row = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_vod_categories"
        m.global.items = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_vod_streams&category_id="
        m.global.play = "/movie/" + m.global.user + "/" + m.global.pass + "/"
        m.global.serie = "false"
        m.global.catGet = "CatMovie"
        m.rowlist = createObject("roSGNode", "MoviesBrowseScreen")
        m.rowlist.screenLabel = "Peliculas"
        m.rowlist.serie = false
        m.rowlist.observeField("menuItemSelected", "onSubScreenMenuSelected")
        m.top.appendChild(m.rowlist)
        m.rowlist.setFocus(true)

    elseif selectedIndex = 2
        hideHomeScreen()
        m.global.row = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series_categories"
        m.global.items = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series&category_id="
        m.global.episode = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series_info&series_id="
        m.global.play = "/series/" + m.global.user + "/" + m.global.pass + "/"
        m.global.serie = "true"
        m.global.catGet = "CatSerie"
        m.rowlist = createObject("roSGNode", "MoviesBrowseScreen")
        m.rowlist.screenLabel = "Series"
        m.rowlist.serie = true
        m.rowlist.observeField("menuItemSelected", "onSubScreenMenuSelected")
        m.top.appendChild(m.rowlist)
        m.rowlist.setFocus(true)

    elseif selectedIndex = 4
        hideHomeScreen()
        m.rowlist = createObject("roSGNode", "SearchScreen")
        m.rowlist.observeField("menuItemSelected", "onSubScreenMenuSelected")
        m.top.appendChild(m.rowlist)
        m.rowlist.setFocus(true)

    elseif selectedIndex = 5
        ' Item de "Perfil" en la barra de menu (a la derecha de
        ' Ajustes) -- HomeScreen.brs ya pregunto "¿Deseas cambiar de
        ' perfil?" y el usuario dijo que si. Mismo flujo que "Cambiar
        ' de Perfil" desde Ajustes (ver onSubScreenMenuSelected,
        ' selectedIndex=-2): se quita Home y se vuelve a mostrar el
        ' selector de perfiles; onProfileChosen() se encarga de volver
        ' a mostrar Home una vez elegido.
        hideHomeScreen()
        ShowProfileSelect()
    end if
end sub

sub showExitConfirmationDialog()
    dialog = createObject("roSGNode", "Dialog")
    dialog.message = "¿Estás seguro de cerrar cesión?"
    dialog.buttons = ["CERRAR CESIÓN", "NO CERRAR CESIÓN"]
    dialog.observeField("buttonSelected", "onDialogButtonSelected")
    m.top.dialog = dialog
end sub

sub onDialogButtonSelected()
    if m.top.dialog.buttonSelected = 0
        m.top.close = true
    else
        m.top.dialog.close = true
    end if
end sub

sub showExitButton()
    m.top.dialog.close = true
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    ' === BLOQUEAR BACK mientras se reproduce el video intro ===
    if m.introPlaying = true
        if key = "back"
            return true   ' Ignorar Back durante el intro
        end if
    end if

    ' === Deep link: pantallas abiertas por handleDeepLink() ===
    ' Mismo criterio que SearchScreen: si Details/Seasons esta visible,
    ' todas las teclas salvo back/options se quedan ahi (no deben caer
    ' en los handlers de escena: menu de salida, returnToHome, etc.).
    if m.dlDetails <> invalid and m.dlDetails.visible
        if key <> "back" and key <> "options" then return true
    end if
    if m.dlSeasons <> invalid and m.dlSeasons.visible
        if key <> "back" and key <> "options" then return true
        if key = "back"
            ' Back en el nivel raiz de Seasons burbujea hacia aqui
            ' (Seasons solo lo consume para volver de episodios o
            ' detener el video) -> cerrar y regresar a Home.
            m.dlSeasons.visible = false
            m.top.removeChild(m.dlSeasons)
            m.dlSeasons = invalid
            if m.homeScreen <> invalid then m.homeScreen.setFocus(true)
            return true
        end if
    end if

    if key = "options"
        if m.homeVisible = false and m.regscreen = invalid and m.global.info = ""
            returnToHome()
            return true
        end if
    end if

    if key = "OK"
        if m.spGroup <> invalid and m.spGroup.visible = true
            onSettingsPinResult()
            return true
        end if
    end if

    if key = "back"
        if m.spGroup <> invalid and m.spGroup.visible = true
            m.spGroup.visible = false
            m.spPad.pin = ""
            if m.homeScreen <> invalid then m.homeScreen.setFocus(true)
            return true
        end if
        if m.homeVisible = false and m.regscreen = invalid and m.global.info = ""
            returnToHome()
            return true
        elseif m.homeVisible = true
            if m.homeScreen <> invalid and m.homeScreen.isInMenu = true
                showExitConfirmationDialog()
                return true
            end if
            return false
        end if
    end if

    return false
end function

sub onSettingsPinResult()
    ingresado = m.spPad.pin
    if ingresado = invalid then return
    if ingresado.len() < 4 then return

    pinGuardado = RegRead("lock", "IPTV_PC")
    if pinGuardado = invalid or pinGuardado = "" then pinGuardado = RegRead("betotun_pin", "BETOTUN")
    if pinGuardado = invalid or pinGuardado = "" then pinGuardado = "0000"

    if ingresado = pinGuardado then
        m.spGroup.visible = false
        hideHomeScreen()
        m.rowlist = createObject("roSGNode", "SettingsScreen")
        m.rowlist.observeField("menuItemSelected", "onSubScreenMenuSelected")
        m.rowlist.observeField("unlinked", "onDeviceUnlinked")
        m.top.appendChild(m.rowlist)
        m.rowlist.setFocus(true)
    else
        m.spPad.pin     = ""
        m.spErr.text    = "PIN incorrecto"
        m.spErr.visible = true
        m.spPad.setFocus(true)
    end if
end sub

sub onDeviceUnlinked()
    if m.rowlist = invalid then return
    if m.rowlist.unlinked = true then
        m.top.getScene().close = true
    end if
end sub

' ============================================================
' DEEP LINKING (cert 5.1) + DIRECT TO PLAY (cert 5.2)
' Flujo: main.brs guarda contentId/mediaType en m.global (args de
' Main() al lanzar, o roInputEvent con la app ya corriendo) y marca
' dlPending. Desde ahi:
'   - movie        -> GetVodInfo via task -> DetailsScreen en AUToplay
'                     (resumeFromRW=0 antes de content => playVideo()
'                     directo: satisface Direct to Play de voz)
'   - series/season/episode -> task get_series_info -> pantalla Seasons
'   - live         -> task get_live_streams -> registry CatID/LastChannelID
'                     -> EpgGuiaScreen (arranca y reproduce ese canal)
'   - id inexistente o mediaType desconocido -> dialogo de error y el
'     usuario queda en Home (comportamiento que exige Roku).
' ============================================================

sub onDlPendingChanged()
    if m.global.dlPending <> true then return
    ' Si Home todavia no existe (intro/login/perfiles), showMenuList()
    ' lo resuelve apenas quede visible.
    if not m.homeVisible then return
    handleDeepLink()
end sub

sub handleDeepLink()
    if m.global.dlPending <> true then return
    if not m.homeVisible then return
    mediaType = LCase(m.global.dlMediaType.Trim())
    contentId = m.global.dlContentId.Trim()
    ' Consumir primero: evita re-ejecucion si el observer vuelve a
    ' dispararse con dlPending=false.
    m.global.dlPending = false
    print "DEEPLINK handle: mediaType="; mediaType; " contentId="; contentId
    if contentId = "" or mediaType = ""
        showDeepLinkError()
        return
    end if
    if mediaType = "movie"
        startDeepLinkTask("deepLinkMovie", contentId)
    else if mediaType = "series" or mediaType = "season" or mediaType = "episode" or mediaType = "special"
        startDeepLinkTask("deepLinkSeries", contentId)
    else if mediaType = "live" or mediaType = "tv"
        openDeepLinkLive(contentId)
    else
        showDeepLinkError()
    end if
end sub

sub startDeepLinkTask(taskType as String, contentId as String)
    m.dlTask = CreateObject("roSGNode", "HomeContentTask")
    m.dlTask.taskType = taskType
    m.dlTask.deepLinkId = contentId
    m.dlTask.observeField("contentResults", "onDlContent")
    m.dlTask.control = "RUN"
end sub

sub onDlContent()
    task = m.dlTask
    if task = invalid then return
    results = task.contentResults
    node = invalid
    if results <> invalid and results.getChildCount() > 0 then node = results.getChild(0)
    isMovie = (task.taskType = "deepLinkMovie")
    if node = invalid
        showDeepLinkError()
        return
    end if
    if isMovie
        openDeepLinkDetails(node)
    else
        openDeepLinkSeasons(node)
    end if
end sub

sub closeDeepLinkOverlays()
    if m.dlDetails <> invalid
        m.top.removeChild(m.dlDetails)
        m.dlDetails = invalid
    end if
    if m.dlSeasons <> invalid
        m.dlSeasons.visible = false
        m.top.removeChild(m.dlSeasons)
        m.dlSeasons = invalid
    end if
end sub

sub openDeepLinkDetails(node as Object)
    if not m.homeVisible then return
    closeDeepLinkOverlays()
    ' Mismas bases que SearchScreen.onMovieSelected (DetailsScreen
    ' arma el stream con m.global.play + id del nodo).
    m.global.play = "/movie/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie = "false"
    m.dlDetails = CreateObject("roSGNode", "DetailsScreen")
    m.dlDetails.observeField("requestClose", "onDlDetailsClose")
    m.top.appendChild(m.dlDetails)
    ' resumeFromRW=0 ANTES de asignar content: OnContentChange ve
    ' resumeFromRW>=0 y llama playVideo() sin dialogo (Direct to Play).
    m.dlDetails.resumeFromRW = 0
    m.dlDetails.content = node
    m.dlDetails.visible = true
    m.dlDetails.setFocus(true)
end sub

sub onDlDetailsClose()
    if m.dlDetails = invalid then return
    if m.dlDetails.requestClose <> true then return
    m.top.removeChild(m.dlDetails)
    m.dlDetails = invalid
    if m.homeScreen <> invalid then m.homeScreen.setFocus(true)
end sub

sub openDeepLinkSeasons(node as Object)
    if not m.homeVisible then return
    closeDeepLinkOverlays()
    ' Mismas bases que SearchScreen.onSerieSelected.
    m.global.play    = "/series/" + m.global.user + "/" + m.global.pass + "/"
    m.global.serie   = "true"
    m.global.episode = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_series_info&series_id="
    m.dlSeasons = CreateObject("roSGNode", "Seasons")
    m.top.appendChild(m.dlSeasons)
    m.dlSeasons.content = node
    m.dlSeasons.visible = true
    m.dlSeasons.setFocus(true)
end sub

sub openDeepLinkLive(contentId as String)
    if not m.homeVisible then return
    closeDeepLinkOverlays()
    ' Mismas bases que el bloque selectedIndex=0 de onHomeMenuSelected.
    m.global.row    = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_live_categories"
    m.global.items  = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_live_streams&category_id="
    m.global.play   = "/live/" + m.global.user + "/" + m.global.pass + "/"
    m.global.epg    = "/player_api.php?username=" + m.global.user + "&password=" + m.global.pass + "&action=get_short_epg&stream_id="
    m.global.catGet = "CatLiveTV"
    ' El task escribe CatID/CatTITLE/LastChannelID en registry ANTES de
    ' que la guia arranque, para que abra y reproduzca ese canal.
    m.dlLiveTask = CreateObject("roSGNode", "HomeContentTask")
    m.dlLiveTask.taskType = "deepLinkLive"
    m.dlLiveTask.deepLinkId = contentId
    m.dlLiveTask.observeField("contentResults", "onDlLiveContent")
    m.dlLiveTask.control = "RUN"
end sub

sub onDlLiveContent()
    task = m.dlLiveTask
    if task = invalid then return
    results = task.contentResults
    if results = invalid or results.getChildCount() = 0
        showDeepLinkError()
        return
    end if
    if not m.homeVisible then return
    hideHomeScreen()
    ' Cert: par de beacons EPGLaunch (igual que onHomeMenuSelected,
    ' indice 0; EpgGuiaScreen dispara el Complete en onContentLoaded).
    m.top.signalBeacon("EPGLaunchInitiate")
    m.rowlist = createObject("roSGNode", "EpgGuiaScreen")
    m.rowlist.observeField("menuItemSelected", "onSubScreenMenuSelected")
    m.top.appendChild(m.rowlist)
    m.rowlist.setFocus(true)
end sub

sub showDeepLinkError()
    if m.dlErrorDialog <> invalid then return
    fireDialogInitiate()
    dlg = createObject("roSGNode", "Dialog")
    dlg.title = "Contenido no disponible"
    dlg.message = "No pudimos encontrar el contenido que solicitaste."
    dlg.buttons = ["OK"]
    dlg.observeField("buttonSelected", "onDlErrorDismiss")
    m.dlErrorDialog = dlg
    m.top.dialog = dlg
end sub

sub onDlErrorDismiss()
    fireDialogComplete()
    if m.dlErrorDialog <> invalid
        m.dlErrorDialog.close = true
        m.dlErrorDialog = invalid
    end if
    if m.homeScreen <> invalid then m.homeScreen.setFocus(true)
end sub
