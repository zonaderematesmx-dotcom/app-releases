' ============================================================
' WatchProgressLocalStore.brs
' Fuente de verdad LOCAL para el progreso de capitulos vistos
' (para pintar la barra de "visto" tipo Netflix en la lista de
' episodios). Mismo patron que RecentlyWatchedLocalStore.brs /
' FavoritesLocalStore.brs: local primero, servidor solo para
' sembrar el local cuando esta vacio o sincronizar cambios.
'
' Formato de guardado: roRegistrySection("WatchProgress")
'   key   = "wp-<usuario>-<episodeId>"   episodeId = id unico del
'           capitulo (NO episodeNumber, que se repite entre series)
'   value = JSON {pos, duration, updatedAt}
' ============================================================

' Devuelve la URL de progreso.php que llego del config.json
' (m.global.urlProgreso, editable desde el panel en "Base de datos").
' Ya no trae ningun link fijo en el codigo.
function WP_ApiBase() as String
    if m.global <> invalid and m.global.urlProgreso <> invalid then
        return m.global.urlProgreso
    end if
    return ""
end function

function WP_Section() as Object
    return CreateObject("roRegistrySection", "WatchProgress")
end function

function WP_CurrentUser() as String
    ' m.global.user puede no estar poblado todavia en este momento del
    ' arranque (si la app ya estaba logueada de antes y solo se
    ' reabrio) -- causaba que se guardara/leyera con una llave
    ' distinta ("wp-unknown-...") a la que se uso originalmente al ver
    ' el capitulo ("wp-<usuario real>-..."), perdiendo el avance
    ' visualmente aunque el dato siguiera intacto en el registro. Se
    ' usa la misma lectura directa del registro que ya usan
    ' Fav_SyncFromServer/RW_SyncFromServer para esto mismo.
    u = "unknown"
    raw = getStrValFromReg("user_tv", "datos_tv")
    if raw <> invalid and raw <> ""
        u = raw
    else if m.global <> invalid and m.global.user <> invalid and m.global.user <> ""
        u = m.global.user
    end if

    ' Se agrega la variante de servidor actual: el mismo usuario puede
    ' autenticar en mas de un servidor de "serverURLs" (config.json), y
    ' el progreso (episodeId) corresponde a contenido de un servidor
    ' especifico -- mismo motivo que Cat_SafeUsuario/RW_CurrentUser.
    return u + "-v" + WP_SafeVariante() + "-p" + WP_SafeProfile()
end function

function WP_SafeVariante() as String
    if m.global <> invalid and m.global.serverVariant <> invalid and m.global.serverVariant.toStr() <> ""
        return m.global.serverVariant.toStr()
    end if
    return "0"
end function

' Perfil actual (hasta 5 por cuenta+servidor) -- mismo motivo y patron
' que WP_SafeVariante(): sin esto, todos los perfiles de una cuenta
' compartirian el mismo progreso de capitulos.
function WP_SafeProfile() as String
    if m.global <> invalid and m.global.profileId <> invalid and m.global.profileId.toStr() <> ""
        return m.global.profileId.toStr()
    end if
    return "0"
end function

function WP_LocalKey(episodeId as String) as String
    return "wp-" + WP_CurrentUser() + "-" + episodeId
end function

' Lee el progreso local de un capitulo. Devuelve {pos, duration,
' updatedAt} o invalid si no hay nada guardado.
function WP_LocalRead(episodeId as String) as Object
    sec = WP_Section()
    raw = sec.Read(WP_LocalKey(episodeId))
    if raw = invalid or raw = "" then return invalid
    parsed = ParseJSON(raw)
    if parsed = invalid or type(parsed) <> "roAssociativeArray" then return invalid
    return parsed
end function

' Fraccion de 0.0 a 1.0 vista de un capitulo (para el ancho de la
' barra de progreso). 0 si no hay dato o la duracion es invalida.
function WP_LocalFraction(episodeId as String) as Float
    data = WP_LocalRead(episodeId)
    if data = invalid then return 0.0
    if data.duration = invalid or data.duration <= 0 then return 0.0
    if data.pos = invalid then return 0.0
    frac = data.pos / data.duration
    if frac < 0.0 then return 0.0
    if frac > 1.0 then return 1.0
    return frac
end function

sub WP_LocalWrite(episodeId as String, posSec as Integer, duration as Integer)
    dataAA = {}
    dataAA["pos"] = posSec
    dataAA["duration"] = duration
    dataAA["updatedAt"] = CreateObject("roDateTime").AsSeconds()
    sec = WP_Section()
    sec.Write(WP_LocalKey(episodeId), FormatJSON(dataAA))
    sec.Flush()
end sub

sub WP_LocalDelete(episodeId as String)
    sec = WP_Section()
    sec.Delete(WP_LocalKey(episodeId))
    sec.Flush()
end sub

' true si el usuario actual no tiene NINGUN progreso guardado
' localmente (senal para decidir si hace falta sembrar desde
' servidor la primera vez que se abre la lista de capitulos).
function WP_LocalIsEmpty() as Boolean
    sec = WP_Section()
    prefix = "wp-" + WP_CurrentUser() + "-"
    keys = sec.GetKeyList()
    if keys = invalid then return true
    for each key in keys
        if Left(key, Len(prefix)) = prefix then return false
    end for
    return true
end function

' ------------------------------------------------------------
' Trae TODO el progreso guardado del usuario desde el servidor y
' lo siembra en el local. Solo se llama cuando WP_LocalIsEmpty()
' es true (primera vez en el dispositivo, o despues de desvincular).
' ------------------------------------------------------------
sub WP_SeedFromServer(usuario as String)
    baseUrl = WP_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=list&user=" + usuario + "&variante=" + WP_SafeVariante() + "&perfil=" + WP_SafeProfile())
    listData = ParseJSON(request.GetToString())
    if listData = invalid or type(listData) <> "roArray" then return

    for each row in listData
        if type(row) = "roAssociativeArray" and row.cve <> invalid
            posSec = 0
            duration = 0
            if row.pos <> invalid then posSec = row.pos.toStr().toInt()
            if row.duration <> invalid then duration = row.duration.toStr().toInt()
            WP_LocalWrite(row.cve.toStr(), posSec, duration)
        end if
    end for
end sub

' ============================================================
' SINCRONIZACION ENTRE DISPOSITIVOS ("changes" incremental)
' Mismo patron que Fav_SyncFromServer/RW_SyncFromServer, pero mas
' simple: el progreso ya trae todo el dato que hace falta (pos,
' duration), no necesita resolverse contra el proveedor.
' ============================================================

function WP_SyncSection() as Object
    return CreateObject("roRegistrySection", "WPSync")
end function

function WP_GetLastSync(usuario as String) as Integer
    sec = WP_SyncSection()
    raw = sec.Read(usuario)
    if raw = invalid or raw = "" then return 0
    return raw.toInt()
end function

sub WP_SetLastSync(usuario as String, epoch as Integer)
    sec = WP_SyncSection()
    sec.Write(usuario, epoch.toStr())
    sec.Flush()
end sub

' Baja lo que cambio desde la ultima sincronizacion (posiciones
' nuevas y borrados) y lo aplica al local. Al final reconcilia el
' sentido contrario: progreso que el dispositivo tiene pero el
' servidor no reporta, se vuelve a subir. Se llama SIEMPRE que se
' abre la lista de capitulos, no solo si el local esta vacio.
sub WP_SyncFromServer(usuario as String)
    ' El cursor de sincronizacion tiene que ser uno POR PERFIL (y por
    ' servidor) -- antes se compartia entre los hasta 5 perfiles de la
    ' cuenta, asi que sincronizar el progreso de un perfil adelantaba
    ' el cursor de todos los demas, y el avance mas viejo de otro
    ' perfil (con fecha anterior al cursor ya avanzado) dejaba de
    ' traerse.
    syncKey = usuario + "-v" + WP_SafeVariante() + "-p" + WP_SafeProfile()

    ' --- MIGRACION UNICA (recuperacion) ---
    ' Mismo mecanismo que ya se aplico en Favoritos y Recien Vistas: se
    ' fuerza UN resync completo (since=0) la primera vez que corre esta
    ' version, por si el cursor se quedo atorado (de pruebas viejas,
    ' cambios de throttle, etc.) y nunca mas se recuperaba progreso
    ' real que si esta en el servidor. Despues de esta unica vez, no
    ' se vuelve a repetir (bandera en el registro). v2: la bandera (y
    ' el cursor) ahora se guardan por perfil+servidor (syncKey), no
    ' solo por usuario -- mismo motivo y mismo cambio que en
    ' RecentlyWatchedLocalStore.brs/FavoritesLocalStore.brs.
    migFlagKey = "migrated-fullresync-v2-" + syncKey
    migSec = WP_SyncSection()
    migFlagVal = migSec.Read(migFlagKey)
    if migFlagVal = invalid or migFlagVal = ""
        print "DEBUG WP_SyncFromServer - migracion unica: reseteando cursor para recuperar progreso perdido"
        WP_SetLastSync(syncKey, 0)
        migSec.Write(migFlagKey, "1")
        migSec.Flush()
    end if

    since = WP_GetLastSync(syncKey)

    baseUrl = WP_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=changes&user=" + usuario + "&since=" + since.toStr() + "&variante=" + WP_SafeVariante() + "&perfil=" + WP_SafeProfile())
    raw = request.GetToString()
    print "DEBUG WP_SyncFromServer - since="; since; " respuesta cruda (primeros 300 chars) = "; Left(raw, 300)
    resp = ParseJSON(raw)
    if resp = invalid or type(resp) <> "roAssociativeArray" or resp.rows = invalid
        print "DEBUG WP_SyncFromServer - respuesta invalida o sin campo rows, abortando"
        return
    end if
    print "DEBUG WP_SyncFromServer - filas recibidas = "; resp.rows.count()

    for each row in resp.rows
        if type(row) = "roAssociativeArray" and row.cve <> invalid
            epId = row.cve.toStr()
            isDeleted = (row.deleted <> invalid and row.deleted.toStr() <> "0")

            if isDeleted
                WP_LocalDelete(epId)
            else
                posSec = 0
                duration = 0
                if row.pos <> invalid then posSec = row.pos.toStr().toInt()
                if row.duration <> invalid then duration = row.duration.toStr().toInt()
                ' Mismo guard que ya se usa en Favoritos/Recien Vistos
                ' (Fav_LocalHasValidTitle / RW_LocalHasValidTitle): si ya
                ' hay un progreso local guardado para este capitulo, no
                ' se pisa con lo que traiga el servidor (que solo se
                ' actualiza cada 10 minutos y puede venir viejo o
                ' incompleto si cerraste la app antes de ese ciclo).
                if WP_LocalRead(epId) = invalid
                    WP_LocalWrite(epId, posSec, duration)
                end if
            end if
        end if
    end for

    if resp.serverNow <> invalid then WP_SetLastSync(syncKey, resp.serverNow.toStr().toInt())

    WP_ReconcileLocalToServer(usuario)
end sub

' Progreso que el dispositivo tiene guardado local pero el servidor
' no reporta (una actualizacion anterior no se guardo por una falla
' de red) se vuelve a subir.
sub WP_ReconcileLocalToServer(usuario as String)
    baseUrl = WP_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=list&user=" + usuario + "&variante=" + WP_SafeVariante() + "&perfil=" + WP_SafeProfile())
    serverList = ParseJSON(request.GetToString())
    if serverList = invalid or type(serverList) <> "roArray" then return

    serverIds = {}
    for each row in serverList
        if type(row) = "roAssociativeArray" and row.cve <> invalid
            serverIds[row.cve.toStr()] = true
        end if
    end for

    sec = WP_Section()
    prefix = "wp-" + WP_CurrentUser() + "-"
    keys = sec.GetKeyList()
    if keys = invalid then return
    for each key in keys
        if Left(key, Len(prefix)) = prefix
            epId = Mid(key, Len(prefix) + 1)
            if not serverIds.doesExist(epId)
                raw = sec.Read(key)
                if raw <> invalid and raw <> ""
                    data = ParseJSON(raw)
                    if data <> invalid and data.pos <> invalid and data.duration <> invalid
                        WP_PushToServer(usuario, epId, data.pos, data.duration)
                    end if
                end if
            end if
        end if
    end for
end sub

sub WP_PushToServer(usuario as String, epId as String, posSec as Integer, duration as Integer)
    baseUrl = WP_ApiBase()
    request = CreateObject("roUrlTransfer")
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.SetUrl(baseUrl + "?action=set&user=" + usuario + "&cve=" + epId + "&pos=" + posSec.toStr() + "&duration=" + duration.toStr() + "&variante=" + WP_SafeVariante() + "&perfil=" + WP_SafeProfile())
    request.GetToString()
    print "DEBUG WP_ReconcileLocalToServer - re-subido al servidor: cve="; epId
end sub
