sub init()
    m.top.functionName = "run"
end sub

sub run()
    su = m.global.serverURL
    u  = m.global.user
    p  = m.global.pass

    if su = "" or u = "" or p = "" then
        m.top.cats = []
        return
    end if

    accion = m.top.action
    url = su + "/player_api.php?username=" + u + "&password=" + p + "&action=" + accion

    data = requestData(url)
    if data = invalid or data = "" then
        m.top.cats = []
        return
    end if

    json = ParseJSON(data)
    if json = invalid or type(json) <> "roArray" then
        m.top.cats = []
        return
    end if

    m.top.cats = json
end sub
