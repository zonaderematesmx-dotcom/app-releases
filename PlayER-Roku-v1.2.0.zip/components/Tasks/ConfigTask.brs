' ============================================================
' ConfigTask.brs
' Descarga config.json en un hilo TASK (roUrlTransfer no puede
' crearse en el hilo de render, por eso no se hace en MainScene).
' ============================================================

sub init()
    m.top.functionName = "run"
end sub

sub run()
    url = m.top.uri
    if url = invalid or url = ""
        m.top.response = ""
        return
    end if

    raw = requestData(url, 10000)
    if raw = invalid then raw = ""
    m.top.response = raw
end sub
