' PCActivateTask.brs
' Descarga categorias de VOD, Series y Live
' Detecta las adultas con PC_isAdultName() y las guarda como bloqueadas
' Se usa al ACTIVAR el control parental desde Settings

sub init()
    m.top.functionName = "run"
end sub

sub run()
    su = m.global.serverURL
    u  = m.global.user
    p  = m.global.pass

    if su = "" or u = "" or p = "" then
        m.top.done = true
        return
    end if

    blockVod(su, u, p)
    blockSeries(su, u, p)
    blockLive(su, u, p)

    m.top.done = true
end sub

sub blockVod(su as String, u as String, p as String)
    url  = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_vod_categories"
    data = requestData(url)
    if data = invalid or data = "" then return
    json = ParseJSON(data)
    if json = invalid or type(json) <> "roArray" then return
    blocked = {}
    for each cat in json
        name = ""
        if cat.category_name <> invalid then name = cat.category_name
        if PC_isAdultName(name) then
            cid = PC_id(cat.category_id)
            if cid <> "" then blocked[cid] = true
        end if
    end for
    PC_saveBlocked("vod", blocked)
end sub

sub blockSeries(su as String, u as String, p as String)
    url  = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_series_categories"
    data = requestData(url)
    if data = invalid or data = "" then return
    json = ParseJSON(data)
    if json = invalid or type(json) <> "roArray" then return
    blocked = {}
    for each cat in json
        name = ""
        if cat.category_name <> invalid then name = cat.category_name
        if PC_isAdultName(name) then
            cid = PC_id(cat.category_id)
            if cid <> "" then blocked[cid] = true
        end if
    end for
    PC_saveBlocked("series", blocked)
end sub

sub blockLive(su as String, u as String, p as String)
    url  = su + "/player_api.php?username=" + u + "&password=" + p + "&action=get_live_categories"
    data = requestData(url)
    if data = invalid or data = "" then return
    json = ParseJSON(data)
    if json = invalid or type(json) <> "roArray" then return
    blocked = {}
    for each cat in json
        name = ""
        if cat.category_name <> invalid then name = cat.category_name
        if PC_isAdultName(name) then
            cid = PC_id(cat.category_id)
            if cid <> "" then blocked[cid] = true
        end if
    end for
    PC_saveBlocked("live", blocked)
end sub
