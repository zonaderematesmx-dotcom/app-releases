sub init()
    'print "In PinTask.brs"
    m.top.functionName = "pinJson"
end sub

sub pinJson()
    request = CreateObject("roUrlTransfer")
    usuario = getStrValFromReg("user_tv", "datos_tv")
    pass = getStrValFromReg("pass_tv", "datos_tv")
    url = m.global.serverURL+"/RokuDevSG/cambiar_pin.php?pin="+m.top.pin+"&user="+usuario+"&idu="+ GetDeviceESN() +"&t="+ m.top.tipo +"&token="+generar_token()
    'print "Url = "; url
    ba = CreateObject("roByteArray") 
    ba.FromAsciiString(usuario+":"+pass) 
    request.AddHeader("X-Roku-Reserved-Dev-Id", "132fdf0cb94f9eb9a3a0132af460b8cd")
    request.AddHeader("X-Content", ba.ToBase64String())    
    request.SetUrl(url)
    html = request.GetToString()
    data = html.Trim() 
    json = ParseJSON(data)

    if json <> invalid then
        if json.error <> "si" then
            m.top.result = true
        end if
        'print json.mensaje
    else
        m.top.result = false
    end if
    
End sub