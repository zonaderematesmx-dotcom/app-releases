' ============================================================
' CategoriesSyncTask.brs
' Descarga TODAS las categorias (nombres + contenido) de Peliculas
' (isSerie=false) o Series (isSerie=true) y las guarda con
' CategoriesLocalStore.brs. Se dispara "en silencio" desde
' MoviesBrowseScreen; nunca toca la UI directamente.
'
' Nota: fillMovieNode/fillSerieNode/safeStr/setBackdrop/setDescription/
' setDuration estan duplicadas aqui a proposito (son copia exacta de
' las de HomeContentTask.brs). No se comparten en un archivo comun
' para no tener que tocar HomeContentTask.brs/.xml mas alla del fix
' de sortByAdded ya acordado.
' ============================================================

sub init()
    m.top.functionName = "execute"
end sub

function safeStr(val as dynamic) as string
    if val = invalid then return ""
    vt = type(val)
    if vt = "roString" or vt = "String" then return val
    if vt = "roInt" or vt = "roInteger" or vt = "Integer" then return val.toStr()
    if vt = "roFloat" or vt = "Float" then return str(int(val)).trim()
    if vt = "roDouble" or vt = "Double" then return str(int(val)).trim()
    if vt = "roLongInteger" or vt = "LongInteger" then return val.toStr()
    return ""
end function

sub setBackdrop(node as Object, item as Object)
    if item.backdrop_path <> invalid
        bpType = type(item.backdrop_path)
        if bpType = "roArray" and item.backdrop_path.Count() > 0
            node.hdBackgroundImageUrl = item.backdrop_path[0]
        else if bpType = "roString" or bpType = "String"
            if item.backdrop_path <> "" then node.hdBackgroundImageUrl = item.backdrop_path
        end if
    end if
end sub

sub setDescription(node as Object, item as Object)
    if item.plot <> invalid and item.plot <> ""
        node.description = item.plot
    else if item.description <> invalid and item.description <> ""
        node.description = item.description
    else
        node.description = ""
    end if
end sub

sub setDuration(node as Object, item as Object)
    if item.duration_secs <> invalid
        durType = type(item.duration_secs)
        if durType = "roInt" or durType = "roInteger" or durType = "Integer"
            node.length = item.duration_secs
        else if durType = "roString" or durType = "String"
            node.length = val(item.duration_secs)
        end if
    end if
end sub

sub fillMovieNode(node as Object, item as Object, su as String, u as String, p as String)
    sid = safeStr(item.stream_id)
    node.id = sid
    node.ContentType = "1"
    if item.name <> invalid and item.name <> ""
        node.title = item.name
    else
        localTitle = ""
        aa = Fav_LocalRead("pelicula", sid)
        if aa <> invalid and aa.title <> invalid and aa.title <> "" then localTitle = aa.title
        if localTitle <> "" then node.title = localTitle
    end if
    setDescription(node, item)
    ext = "ts"
    if item.container_extension <> invalid and item.container_extension <> "" then ext = item.container_extension
    node.url = su + "/movie/" + u + "/" + p + "/" + sid + "." + ext
    if item.stream_icon <> invalid and item.stream_icon <> "" then
        node.HDPosterUrl = item.stream_icon
    else
        node.HDPosterUrl = "pkg:/images/no-poster.jpg"
    end if
    if item.rating <> invalid then node.rating = safeStr(item.rating)
    if item.container_extension <> invalid
        extLower = LCase(item.container_extension)
        if extLower = "m3u8" then node.StreamFormat = "hls"
        if extLower = "mpd" then node.StreamFormat = "mpeg-dash"
    end if
    if item.releasedate <> invalid then node.releaseDate = safeStr(item.releasedate)
    setBackdrop(node, item)
    setDuration(node, item)
    if not node.hasField("genre") then node.addFields({genre: "", director: "", episodeRunTime: ""})
    if item.genre <> invalid then node.genre = item.genre
    if item.director <> invalid then node.director = item.director
    if item.episode_run_time <> invalid then node.episodeRunTime = safeStr(item.episode_run_time)
end sub

sub fillSerieNode(node as Object, item as Object)
    node.id = safeStr(item.series_id)
    node.ContentType = "2"
    if item.name <> invalid and item.name <> ""
        node.title = item.name
    else
        localTitle = ""
        aa = Fav_LocalRead("serie", safeStr(item.series_id))
        if aa <> invalid and aa.title <> invalid and aa.title <> "" then localTitle = aa.title
        if localTitle <> "" then node.title = localTitle
    end if
    setDescription(node, item)
    if item.releasedate <> invalid then node.releaseDate = safeStr(item.releasedate)
    if item.cover <> invalid and item.cover <> "" then
        node.HDPosterUrl = item.cover
    else
        node.HDPosterUrl = "pkg:/images/no-poster.jpg"
    end if
    if item.rating <> invalid then node.rating = safeStr(item.rating)
    if not node.hasField("genre") then node.addFields({genre: "", director: "", episodeRunTime: ""})
    if item.genre <> invalid then node.genre = item.genre
    if item.episode_run_time <> invalid then node.episodeRunTime = safeStr(item.episode_run_time)
    setBackdrop(node, item)
end sub

' --- Sort O(n log n) por "mas reciente" (merge sort) ---
' Reemplaza el insertion sort O(n^2) que con categorias de 1000+
' items se vuelve el cuello de botella principal.
'
' Criterio de "mas reciente" = ID (stream_id/series_id), NO "added".
' El campo "added" de Xtream es notoriamente poco confiable en varios
' proveedores (algunos lo ponen una sola vez al importar el catalogo
' completo y nunca lo vuelven a actualizar por item). El ID en cambio
' es autoincremental en la inmensa mayoria de paneles Xtream: el
' numero mas alto SIEMPRE es lo mas nuevo, sin depender de que el
' proveedor mantenga bien esa otra fecha. "added" queda solo de
' respaldo, por si el item no trajera id por algun motivo raro.
function addedOf(item as Object) as Integer
    idVal = item.stream_id
    if idVal = invalid then idVal = item.series_id
    if idVal <> invalid
        t = type(idVal)
        if t = "roString" or t = "String" then return val(idVal)
        if t = "roInt" or t = "roInteger" or t = "Integer" then return idVal
    end if
    if item.added <> invalid
        t = type(item.added)
        if t = "roString" or t = "String" then return val(item.added)
        if t = "roInt" or t = "roInteger" or t = "Integer" then return item.added
    end if
    return 0
end function

function mergeByAdded(left as Object, right as Object) as Object
    result = []
    i = 0
    j = 0
    while i < left.count() and j < right.count()
        if addedOf(left[i]) >= addedOf(right[j])
            result.push(left[i])
            i = i + 1
        else
            result.push(right[j])
            j = j + 1
        end if
    end while
    while i < left.count()
        result.push(left[i])
        i = i + 1
    end while
    while j < right.count()
        result.push(right[j])
        j = j + 1
    end while
    return result
end function

function sortByAddedFast(items as Object) as Object
    if items = invalid or items.count() <= 1 then return items
    mid = items.count() \ 2
    left = []
    right = []
    for i = 0 to mid - 1
        left.push(items[i])
    end for
    for i = mid to items.count() - 1
        right.push(items[i])
    end for
    left = sortByAddedFast(left)
    right = sortByAddedFast(right)
    return mergeByAdded(left, right)
end function

sub execute()
    su = m.global.serverURL
    u  = m.global.user
    p  = m.global.pass
    usuario = getStrValFromReg("user_tv", "datos_tv")
    isSerie = m.top.isSerie

    tipo = "vod"
    if isSerie then tipo = "series"

    if su = "" or u = "" or p = ""
        m.top.syncComplete = true
        return
    end if

    ' 1) Lista de categorias (filtrando adultas/bloqueadas, igual que
    ' ya hace MoviesBrowseScreen con el resultado de GetContent)
    catAction = "get_vod_categories"
    if isSerie then catAction = "get_series_categories"
    catUrl = su + "/player_api.php?username=" + u + "&password=" + p + "&action=" + catAction
    catJson = ParseJSON(requestData(catUrl, 15000))

    simpleCats = []
    if catJson <> invalid and type(catJson) = "roArray"
        pcTipo = "vod"
        if isSerie then pcTipo = "series"
        for each cat in catJson
            catName = ""
            if cat.category_name <> invalid then catName = cat.category_name
            catIdStr = safeStr(cat.category_id)
            if not PC_isAdultName(catName) and not PC_isCatBlocked(catIdStr, pcTipo)
                simpleCats.push({ category_id: catIdStr, category_name: catName })
            end if
        end for

        ' --- Purgar categorias que el proveedor ya NO manda ---
        ' El contenido DENTRO de cada categoria ya se reemplaza completo
        ' cada vez (Cat_LocalWriteCategoryItems sobreescribe el archivo
        ' entero, no lo mezcla con lo viejo), pero si una categoria
        ' ENTERA desaparecio del proveedor, su archivo viejo nunca se
        ' volvia a tocar (el indice nuevo ya no la incluye) y se quedaba
        ' huerfano para siempre con contenido que ya no deberia
        ' aparecer. Se compara contra el indice ANTERIOR (antes de
        ' pisarlo) y se borra el archivo de cualquier categoria que ya
        ' no este en la lista nueva.
        newCatIds = {}
        for each c in simpleCats
            newCatIds[c.category_id] = true
        end for
        oldIdx = Cat_LocalReadIndex(usuario, tipo)
        if oldIdx <> invalid and oldIdx.categories <> invalid
            for each oldCat in oldIdx.categories
                oldCatId = safeStr(oldCat.category_id)
                if oldCatId <> "" and not newCatIds.doesExist(oldCatId)
                    Cat_LocalDeleteCategoryItems(usuario, tipo, oldCatId)
                    print "DEBUG CategoriesSyncTask - categoria eliminada por el proveedor, se purga del cache local: tipo="; tipo; " catId="; oldCatId
                end if
            end for
        end if

        Cat_LocalWriteIndex(usuario, tipo, simpleCats)
    end if

    ' 2) Contenido completo de cada categoria. Esto es lo pesado, pero
    ' corre en este Task en segundo plano -- no bloquea la pantalla.
    itemsAction = "get_vod_streams"
    if isSerie then itemsAction = "get_series"

    for each cat in simpleCats
        catId = cat.category_id
        itemUrl = su + "/player_api.php?username=" + u + "&password=" + p + "&action=" + itemsAction + "&category_id=" + catId
        itemsJson = ParseJSON(requestData(itemUrl, 20000))
        if itemsJson <> invalid and type(itemsJson) = "roArray"
            itemsJson = sortByAddedFast(itemsJson)
            aaList = []
            for each raw in itemsJson
                node = createObject("roSGNode", "ContentNode")
                if isSerie
                    fillSerieNode(node, raw)
                else
                    fillMovieNode(node, raw, su, u, p)
                end if
                aaList.push(Fav_NodeToAA(node, Fav_VodSerieFields()))
            end for
            Cat_LocalWriteCategoryItems(usuario, tipo, catId, aaList)
        end if
    end for

    m.top.syncComplete = true
end sub
