' ============================================================
' CategoriesLocalStore.brs
' Fuente de verdad LOCAL para las categorias de Peliculas y Series
' (nombres + contenido completo de cada categoria). Se incluye como
' <script> extra en los componentes que lo necesiten (junto a
' generalUtils.brs), no es un componente propio -- mismo patron que
' FavoritesLocalStore.brs / RecentlyWatchedLocalStore.brs.
'
' A diferencia de esos otros stores (que usan roRegistrySection
' porque manejan listas chicas), aqui se guarda en ARCHIVOS dentro de
' cachefs:/categories/ porque una sola categoria puede traer 1000+
' peliculas con titulo/poster/descripcion/etc, y eso no cabe bien en
' el registro de Roku (pensado para valores pequenos).
'
' Formato de guardado:
'   cachefs:/categories/<usuario>_<tipo>_index.json
'       -> {"categories":[{category_id, category_name}, ...], "lastSync": epoch}
'   cachefs:/categories/<usuario>_<tipo>_cat_<catId>.json
'       -> [ {AA de un item, mismos campos que Fav_VodSerieFields()}, ... ]
'   tipo: "vod" | "series"
' ============================================================

function Cat_BaseDir() as String
    return "cachefs:/categories"
end function

sub Cat_EnsureDir()
    fs = CreateObject("roFileSystem")
    if fs <> invalid and not fs.Exists(Cat_BaseDir())
        fs.CreateDirectory(Cat_BaseDir())
    end if
end sub

function Cat_SafeUsuario(usuario as String) as String
    if usuario = invalid or usuario = "" then usuario = "default"
    ' Sanitizar por si el usuario trae caracteres raros para nombre de archivo
    clean = usuario
    clean = clean.Replace("/", "_")
    clean = clean.Replace("\", "_")
    clean = clean.Replace(" ", "_")

    ' Se agrega la variante de servidor actual (ver Cat_SafeVariante) al
    ' nombre del archivo: el mismo usuario puede autenticar en mas de un
    ' servidor de "serverURLs" (config.json), y cada uno puede tener un
    ' catalogo distinto (mismos ids no necesariamente son el mismo
    ' contenido/portada). Sin esto, cambiar de servidor con el mismo
    ' usuario reusaba el catalogo cacheado del servidor anterior --
    ' causaba portadas rotas / contenido que no correspondia.
    return clean + "-v" + Cat_SafeVariante()
end function

' Numero de variante (1,2,3...) del servidor actualmente conectado,
' asignado por LoginTask.brs/ConfirmUser.brs al autenticar (ver
' NormalizeServerList en generalUtils.brs). "0" como respaldo si
' todavia no esta disponible (por ejemplo, justo al arrancar antes de
' terminar el login).
function Cat_SafeVariante() as String
    if m.global <> invalid and m.global.serverVariant <> invalid and m.global.serverVariant.toStr() <> ""
        return m.global.serverVariant.toStr()
    end if
    return "0"
end function

function Cat_IndexPath(usuario as String, tipo as String) as String
    return Cat_BaseDir() + "/" + Cat_SafeUsuario(usuario) + "_" + tipo + "_index.json"
end function

function Cat_ItemsPath(usuario as String, tipo as String, catId as String) as String
    return Cat_BaseDir() + "/" + Cat_SafeUsuario(usuario) + "_" + tipo + "_cat_" + catId + ".json"
end function

' Devuelve {categories:[...], lastSync: epoch} o invalid si no existe/corrupto.
function Cat_LocalReadIndex(usuario as String, tipo as String) as Object
    raw = ReadAsciiFile(Cat_IndexPath(usuario, tipo))
    if raw = invalid or raw = "" then return invalid
    parsed = ParseJSON(raw)
    if parsed = invalid or type(parsed) <> "roAssociativeArray" then return invalid
    if parsed.categories = invalid then return invalid
    return parsed
end function

sub Cat_LocalWriteIndex(usuario as String, tipo as String, categoriesArr as Object)
    Cat_EnsureDir()
    if categoriesArr = invalid then categoriesArr = []
    aa = {}
    aa.categories = categoriesArr
    aa.lastSync = CreateObject("roDateTime").AsSeconds()
    WriteAsciiFile(Cat_IndexPath(usuario, tipo), FormatJSON(aa))
end sub

' Devuelve un array de AAs (items) para una categoria, o invalid si no
' hay cache local para ella todavia.
function Cat_LocalReadCategoryItems(usuario as String, tipo as String, catId as String) as Object
    raw = ReadAsciiFile(Cat_ItemsPath(usuario, tipo, catId))
    if raw = invalid or raw = "" then return invalid
    parsed = ParseJSON(raw)
    if parsed = invalid or type(parsed) <> "roArray" then return invalid
    return parsed
end function

sub Cat_LocalWriteCategoryItems(usuario as String, tipo as String, catId as String, itemsAAArr as Object)
    Cat_EnsureDir()
    if itemsAAArr = invalid then itemsAAArr = []
    WriteAsciiFile(Cat_ItemsPath(usuario, tipo, catId), FormatJSON(itemsAAArr))
end sub

' Borra el archivo de una categoria puntual. Se usa cuando una nueva
' sincronizacion detecta que el proveedor ya no manda esa categoria
' (se elimino por completo) -- sin esto, el archivo se quedaria
' huerfano para siempre con contenido viejo que ya no deberia
' aparecer (nunca se vuelve a tocar porque el indice nuevo ya no la
' incluye, pero seguia ocupando espacio en disco).
sub Cat_LocalDeleteCategoryItems(usuario as String, tipo as String, catId as String)
    fs = CreateObject("roFileSystem")
    path = Cat_ItemsPath(usuario, tipo, catId)
    if fs <> invalid and fs.Exists(path) then fs.Delete(path)
end sub

function Cat_LocalHasIndex(usuario as String, tipo as String) as Boolean
    return Cat_LocalReadIndex(usuario, tipo) <> invalid
end function

' Busca un item (pelicula o serie) por su id en el catalogo YA
' descargado localmente, recorriendo las categorias guardadas. No hace
' ninguna llamada de red -- si el catalogo local no tiene ese id
' todavia (por ejemplo, recien se agrego en el proveedor y no se ha
' vuelto a sincronizar el catalogo completo), regresa invalid.
function Cat_LocalFindById(usuario as String, tipo as String, id as String) as Object
    idx = Cat_LocalReadIndex(usuario, tipo)
    if idx = invalid or idx.categories = invalid then return invalid
    for each cat in idx.categories
        catId = cat.category_id
        items = Cat_LocalReadCategoryItems(usuario, tipo, catId)
        if items <> invalid
            for each item in items
                if item.id <> invalid and item.id.toStr() = id then return item
            end for
        end if
    end for
    return invalid
end function

' Convierte el array de AAs guardado localmente de vuelta a un
' ContentNode listo para asignar directo a un MarkupGrid/PosterGrid.
function Cat_ItemsToContentNode(itemsAAArr as Object) as Object
    cn = createObject("roSGNode", "ContentNode")
    if itemsAAArr = invalid then return cn
    for each aa in itemsAAArr
        cn.appendChild(Fav_AAToNode(aa))
    end for
    return cn
end function
