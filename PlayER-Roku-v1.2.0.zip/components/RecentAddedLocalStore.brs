' ============================================================
' RecentAddedLocalStore.brs
' Cache local de "Recien Agregados" (Peliculas y Series) para el
' Home. Mismo patron que FavoritesLocalStore.brs /
' RecentlyWatchedLocalStore.brs: roRegistrySection, porque son solo
' los top-20 de cada tipo (cabe perfecto en el registro, a diferencia
' del cache de categorias completas que usa cachefs).
'
' Formato de guardado: roRegistrySection("RecentAdded")
'   key   = "recent-movies" | "recent-series"
'   value = JSON de un array de AAs (mismos campos que
'           Fav_VodSerieFields(), para reconstruir con Fav_AAToNode)
' ============================================================

function RA_Section() as Object
    return CreateObject("roRegistrySection", "RecentAdded")
end function

' Usuario+variante de servidor actualmente conectado, mismo patron que
' RW_CurrentUser/WP_CurrentUser. Antes esta cache NO tenia usuario en
' su llave (solo "recent-movies"/"recent-series"), asi que CUALQUIER
' cuenta que iniciara sesion en el dispositivo veia los "Recien
' Agregados" de la ultima cuenta que los sincronizo -- este era uno de
' los dos causantes directos de "aparecen favoritos/recientes que no
' son mios" al cambiar de usuario o de servidor.
function RA_CurrentUser() as String
    u = "unknown"
    raw = getStrValFromReg("user_tv", "datos_tv")
    if raw <> invalid and raw <> ""
        u = raw
    else if m.global <> invalid and m.global.user <> invalid and m.global.user <> ""
        u = m.global.user
    end if
    variante = "0"
    if m.global <> invalid and m.global.serverVariant <> invalid and m.global.serverVariant.toStr() <> ""
        variante = m.global.serverVariant.toStr()
    end if
    return u + "-v" + variante
end function

function RA_Key(tipo as String) as String
    return "recent-" + RA_CurrentUser() + "-" + tipo
end function

' Devuelve un array de AAs, o invalid si no hay cache todavia.
function RA_LocalRead(tipo as String) as Object
    sec = RA_Section()
    raw = sec.Read(RA_Key(tipo))
    if raw = invalid or raw = "" then return invalid
    parsed = ParseJSON(raw)
    if parsed = invalid or type(parsed) <> "roArray" then return invalid
    return parsed
end function

sub RA_LocalWrite(tipo as String, itemsAAArr as Object)
    if itemsAAArr = invalid then itemsAAArr = []
    sec = RA_Section()
    sec.Write(RA_Key(tipo), FormatJSON(itemsAAArr))
    sec.Flush()
end sub

' Convierte el array de AAs guardado localmente de vuelta a un
' ContentNode listo para asignar directo al grid.
function RA_ItemsToContentNode(itemsAAArr as Object) as Object
    cn = createObject("roSGNode", "ContentNode")
    if itemsAAArr = invalid then return cn
    for each aa in itemsAAArr
        cn.appendChild(Fav_AAToNode(aa))
    end for
    return cn
end function
